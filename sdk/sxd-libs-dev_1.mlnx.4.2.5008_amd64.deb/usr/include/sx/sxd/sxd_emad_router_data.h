/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_ROUTER_DATA_H__
#define __SXD_EMAD_ROUTER_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/sxd_router.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_rcap_data_t structure is used to store RCAP register data.
 */
typedef struct sxd_emad_rcap_data {
    sxd_emad_common_data_t common;
    struct ku_rcap_reg    *reg_data;
} sxd_emad_rcap_data_t;

/**
 * sxd_emad_rgcr_data_t structure is used to store RGCR register data.
 */
typedef struct sxd_emad_rgcr_data {
    sxd_emad_common_data_t common;
    struct ku_rgcr_reg    *reg_data;
} sxd_emad_rgcr_data_t;

/**
 * sxd_emad_ritr_data_t structure is used to store RITR register data.
 */
typedef struct sxd_emad_ritr_data {
    sxd_emad_common_data_t common;
    struct ku_ritr_reg    *reg_data;
} sxd_emad_ritr_data_t;

/**
 * sxd_emad_rigr_data_t structure is used to store RIGR register data.
 */
typedef struct sxd_emad_rigr_data {
    sxd_emad_common_data_t common;
    struct ku_rigr_reg    *reg_data;
} sxd_emad_rigr_data_t;

/**
 * sxd_emad_rigr_v2_data_t structure is used to store RIGRv2 register data.
 */
typedef struct sxd_emad_rigr_v2_data {
    sxd_emad_common_data_t common;
    struct ku_rigr_v2_reg *reg_data;
} sxd_emad_rigr_v2_data_t;

/**
 * sxd_emad_rmeir_data_t structure is used to store RMEIR register data.
 */
typedef struct sxd_emad_rmeir_data {
    sxd_emad_common_data_t common;
    struct ku_rmeir_reg   *reg_data;
} sxd_emad_rmeir_data_t;

/**
 * sxd_emad_rmid_data_t structure is used to store RMID register data.
 */
typedef struct sxd_emad_rmid_data {
    sxd_emad_common_data_t common;
    struct ku_rmid_reg    *reg_data;
} sxd_emad_rmid_data_t;

/**
 * sxd_emad_rmpe_data_t structure is used to store RMPE register data.
 */
typedef struct sxd_emad_rmpe_data {
    sxd_emad_common_data_t common;
    struct ku_rmpe_reg    *reg_data;
} sxd_emad_rmpe_data_t;

/**
 * sxd_emad_rmpu_data_t structure is used to store RMPU register data.
 */
typedef struct sxd_emad_rmpu_data {
    sxd_emad_common_data_t common;
    struct ku_rmpu_reg    *reg_data;
} sxd_emad_rmpu_data_t;

/**
 * sxd_emad_rtar_data_t structure is used to store RTAR register data.
 */
typedef struct sxd_emad_rtar_data {
    sxd_emad_common_data_t common;
    struct ku_rtar_reg    *reg_data;
} sxd_emad_rtar_data_t;

/**
 * sxd_emad_recr_data_t structure is used to store RECR register data.
 */
typedef struct sxd_emad_recr_data {
    sxd_emad_common_data_t common;
    struct ku_recr_reg    *reg_data;
} sxd_emad_recr_data_t;

/**
 * sxd_emad_recr_v2_data_t structure is used to store RECRv2 register data.
 */
typedef struct sxd_emad_recr_v2_data {
    sxd_emad_common_data_t common;
    struct ku_recr_v2_reg *reg_data;
} sxd_emad_recr_v2_data_t;

/**
 * sxd_emad_ruft_data_t structure is used to store RUFT register data.
 */
typedef struct sxd_emad_ruft_data {
    sxd_emad_common_data_t common;
    struct ku_ruft_reg    *reg_data;
} sxd_emad_ruft_data_t;

/**
 * sxd_emad_ruht_data_t structure is used to store RUHT register data.
 */
typedef struct sxd_emad_ruht_data {
    sxd_emad_common_data_t common;
    struct ku_ruht_reg    *reg_data;
} sxd_emad_ruht_data_t;

/**
 * sxd_emad_ruht_data_t structure is used to store RUHT register data.
 */
typedef struct sxd_emad_rauht_data {
    sxd_emad_common_data_t common;
    struct ku_rauht_reg   *reg_data;
} sxd_emad_rauht_data_t;

/**
 * sxd_emad_rauhtd_data_t structure is used to store RAUHTD register data.
 */
typedef struct sxd_emad_rauhtd_data {
    sxd_emad_common_data_t common;
    struct ku_rauhtd_reg  *reg_data;
} sxd_emad_rauhtd_data_t;

/**
 * sxd_emad_rmft_data_t structure is used to store RMFT register data.
 */
typedef struct sxd_emad_rmft_data {
    sxd_emad_common_data_t common;
    struct ku_rmft_reg    *reg_data;
} sxd_emad_rmft_data_t;

/**
 * sxd_emad_rmft_v2_data_t structure is used to store RMFTv2 register data.
 */
typedef struct sxd_emad_rmft_v2_data {
    sxd_emad_common_data_t common;
    struct ku_rmft_v2_reg *reg_data;
} sxd_emad_rmft_v2_data_t;

/**
 * sxd_emad_ratr_data_t structure is used to store RATR register data.
 */
typedef struct sxd_emad_ratr_data {
    sxd_emad_common_data_t common;
    struct ku_ratr_reg    *reg_data;
} sxd_emad_ratr_data_t;

/**
 * sxd_emad_ratrad_data_t structure is used to store RATRAD register data.
 */
typedef struct sxd_emad_ratrad_data {
    sxd_emad_common_data_t common;
    struct ku_ratrad_reg  *reg_data;
} sxd_emad_ratrad_data_t;

/**
 * sxd_emad_rtdp_data_t structure is used to store RTDP register data.
 */
typedef struct sxd_emad_rtdp_data {
    sxd_emad_common_data_t common;
    struct ku_rtdp_reg    *reg_data;
} sxd_emad_rtdp_data_t;

/**
 * sxd_emad_rdpm_data_t structure is used to store RDPM register data.
 */
typedef struct sxd_emad_rdpm_data {
    sxd_emad_common_data_t common;
    struct ku_rdpm_reg    *reg_data;
} sxd_emad_rdpm_data_t;

/**
 * sxd_emad_rrcr_data_t structure is used to store RRCR register
 * data.
 */
typedef struct sxd_emad_rrcr_data {
    sxd_emad_common_data_t common;
    struct ku_rrcr_reg    *reg_data;
} sxd_emad_rrcr_data_t;

/**
 * sxd_emad_rica_data_t structure is used to store RICA register data.
 */
typedef struct sxd_emad_rica_data {
    sxd_emad_common_data_t common;
    struct ku_rica_reg    *reg_data;
} sxd_emad_rica_data_t;

/**
 * sxd_emad_ricnt_data_t structure is used to store RICNT register data.
 */
typedef struct sxd_emad_ricnt_data {
    sxd_emad_common_data_t common;
    struct ku_ricnt_reg   *reg_data;
} sxd_emad_ricnt_data_t;

/**
 * sxd_emad_rtca_data_t structure is used to store RTCA
 * register data.
 */
typedef struct sxd_emad_rtca_data {
    sxd_emad_common_data_t common;
    struct ku_rtca_reg    *reg_data;
} sxd_emad_rtca_data_t;

/**
 * sxd_emad_rtps_data_t structure is used to store RTPS
 * register data.
 */
typedef struct sxd_emad_rtps_data {
    sxd_emad_common_data_t common;
    struct ku_rtps_reg    *reg_data;
} sxd_emad_rtps_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_SYSTEM_DATA_H__ */
