/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_RM_REG_H__
#define __SXD_EMAD_RM_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_iddd_reg_t structure is used to store IDDD register
 * layout.
 */
typedef struct sxd_emad_iddd_reg {
    uint8_t entry_type;
    uint8_t duplication;
} PACK_SUFFIX sxd_emad_iddd_reg_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_RM_REG_H__ */
