/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_POLICER_H__
#define __SXD_EMAD_POLICER_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_policer_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpcr_set(sxd_emad_qpcr_data_t         *qpcr_data_arr,
                               uint32_t                      qpcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_qpcr_get(sxd_emad_qpcr_data_t         *qpcr_data_arr,
                               uint32_t                      qpcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

#endif /* __SXD_EMAD_POLICER_H__ */
