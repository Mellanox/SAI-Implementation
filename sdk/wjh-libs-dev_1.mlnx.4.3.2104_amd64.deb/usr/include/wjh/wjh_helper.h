/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef WJH_HELPER_H_
#define WJH_HELPER_H_

int wjh_helper_drop_reason_group_init(wjh_drop_reason_group_e      drop_reason_group,
                                      wjh_drop_reason_group_attr_t attr,
                                      int                          fd);


#endif /* WJH_HELPER_H_ */
