/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef WJH_LIB_TYPES_H_
#define WJH_LIB_TYPES_H_

#include <stdint.h>
#include <time.h>
#include <stdio.h>
#include <string.h>
#include "complib/cl_types_osd.h"

/************************************************
 *  Macros
 ***********************************************/

#define WJH_USER_CHANNEL_ID_INVALID (0xFFFFFFFF)

#define WJH_MEM_CLR(src) (memset(&(src), 0, sizeof(src)))
/************************************************
 *  Type definitions
 ***********************************************/

typedef enum wjh_drop_reason_group {
    WJH_DROP_REASON_GROUP_BUFFER_E,
    WJH_DROP_REASON_GROUP_ACL_E,
    WJH_DROP_REASON_GROUP_L1_E,
    WJH_DROP_REASON_GROUP_L2_E,
    WJH_DROP_REASON_GROUP_ROUTER_E,
    WJH_DROP_REASON_GROUP_TUNNEL_E,
    WJH_DROP_REASON_GROUP_MIN_E = WJH_DROP_REASON_GROUP_BUFFER_E,
    WJH_DROP_REASON_GROUP_MAX_E = WJH_DROP_REASON_GROUP_TUNNEL_E,
    WJH_DROP_REASON_GROUP_INVALID_E,
} wjh_drop_reason_group_e;

typedef enum wjh_severity {
    WJH_SEVERITY_ALL_E,
    WJH_SEVERITY_NOTICE_E,
    WJH_SEVERITY_WARNING_E,
    WJH_SEVERITY_ERROR_E,
    WJH_SEVERITY_MIN_E = WJH_SEVERITY_ALL_E,
    WJH_SEVERITY_MAX_E = WJH_SEVERITY_ERROR_E,
    WJH_SEVERITY_INVALID_E,
} wjh_severity_e;

typedef uint32_t wjh_drop_reason_id_t;
typedef uint32_t wjh_port_log_id_t;
typedef uint8_t wjh_traffic_class_t;
typedef uint64_t wjh_acl_rule_id_t;

typedef struct wjh_buffer_drop_basic_attr {
    wjh_port_log_id_t recirculation_port; /**< The port to be used as the analyzer port.
                                           *    This port should not be used as a switch port.
                                           *    Prerequisites for this port:
                                           *    A network port, not a LAG member, no ACL is bound to it,
                                           *    Not an analyzer port already, not an OpenFlow or NVE port,
                                           *    was removed from all L2 protocols,
                                           *    was set to external loopback mode (will require port admin state to be set to DOWN before),
                                           *    is a member of all vlans, switch prio to PG and buffers are set correctly,
                                           *    Recommended to use single PG with 128Kb of reserved buffer (no shared),
                                           *    is in UP admin state. */
    uint16_t truncate_size; /**< Optional. Packets will be truncated to this size.
                             *    Units of bytes. The default value is 64B.
                             */
} wjh_buffer_drop_basic_attr_t;

typedef struct wjh_buffer_drop_advanced_attr {
    uint32_t trap_probability; /**< Optional. 1 of trap_probability packets will be trapped.
                                *    Must be a power of 2. Min value of 1, max value of 4096.
                                *    The default value is 128 */
    uint32_t trap_id; /**< Optional. SDK trap ID to be used.
                       *              The default value is SX_TRAP_ID_ACL_MAX */
    boolean_t ptp_disabled; /**< Optional. If set, WJH lib will initialize a thread that will update
                             *   the HW clock with the SW clock every minute. This is needed
                             *   to have meaningful timestamps .Suggested to set in case
                             *   the switch is not running a PTP protocol */
} wjh_buffer_drop_advanced_attr_t;

typedef struct wjh_buffer_drop_attr {
    wjh_buffer_drop_basic_attr_t    basic_attr;
    wjh_buffer_drop_advanced_attr_t advanced_attr;
} wjh_buffer_drop_attr_t;

typedef struct wjh_drop_reason_group_attr {
    union {
        wjh_buffer_drop_attr_t buffer_drop;
    } attr;
} wjh_drop_reason_group_attr_t;

typedef enum wjh_acl_binding_point {
    WJH_ACL_BINDING_POINT_INGRESS = 0,
    WJH_ACL_BINDING_POINT_EGRESS = 1,
    WJH_ACL_BINDING_POINT_RIF_INGRESS = 2,
    WJH_ACL_BINDING_POINT_RIF_EGRESS = 3,
    WJH_ACL_BINDING_POINT_MAX = WJH_ACL_BINDING_POINT_RIF_EGRESS,
} wjh_acl_binding_point_t;

typedef struct wjh_drop_reason {
    wjh_drop_reason_id_t id;
    const char         * reason;
    wjh_severity_e       severity;
    const char         * description;
} wjh_drop_reason_t;

/* raw */
typedef struct wjh_buffer_drop_raw_info {
    void              * packet;
    uint32_t            packet_size;
    wjh_port_log_id_t   ingress_port;
    wjh_port_log_id_t   egress_port;     /* Spectrum-2 only */
    wjh_traffic_class_t tc;              /* Spectrum-2 only */
    wjh_drop_reason_t   drop_reason;
    struct timespec     timestamp;
    uint8_t             is_lag_member;
    wjh_port_log_id_t   ingress_lag;
} wjh_buffer_drop_raw_info_t;

typedef struct wjh_acl_drop_raw_info {
    void                  * packet;
    uint32_t                packet_size;
    wjh_port_log_id_t       ingress_port;
    wjh_acl_binding_point_t binding_point;
    wjh_acl_rule_id_t       rule_id;
    const char            * acl_name;
    const char            * rule;
    struct timespec         timestamp;
    uint8_t                 is_lag_member;
    wjh_port_log_id_t       ingress_lag;
} wjh_acl_drop_raw_info_t;

typedef struct wjh_L2_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
} wjh_L2_drop_raw_info_t;

typedef struct wjh_router_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
} wjh_router_drop_raw_info_t;

typedef struct wjh_tunnel_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
    uint8_t           is_lag_member;
    wjh_port_log_id_t ingress_lag;
} wjh_tunnel_drop_raw_info_t;

/* aggregate */
typedef struct wjh_aggregate_timestamp {
    struct timespec first_timestamp;
    struct timespec last_timestamp;
} wjh_aggregate_timestamp_t;

typedef struct wjh_aggregate_five_tuples {
    const char * sip;
    const char * dip;
    uint8_t      proto;
    uint32_t     sport;
    uint32_t     dport;
} wjh_aggregate_five_tuples_t;

typedef struct wjh_buffer_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;
} wjh_buffer_drop_aggregate_key_t;

typedef struct wjh_buffer_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_buffer_drop_aggregate_data_t;

typedef struct wjh_acl_drop_aggregate_key {
    wjh_acl_rule_id_t rule_id;
    const char      * acl_name;
    const char      * rule;
} wjh_acl_drop_aggregate_key_t;

typedef struct wjh_acl_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
    uint32_t                  flows_num;      /* Spectrum-2 only */
} wjh_acl_drop_aggregate_data_t;

typedef struct wjh_router_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;
    const char                * reason;
} wjh_router_drop_aggregate_key_t;

typedef struct wjh_router_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_router_drop_aggregate_data_t;

typedef struct wjh_tunnel_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;    /* only valid for ip4/6, will be 0 otherwise */
    unsigned char               dmac[6];
    unsigned char               smac[6];
    const char                * reason;
} wjh_tunnel_drop_aggregate_key_t;

typedef struct wjh_tunnel_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_tunnel_drop_aggregate_data_t;

typedef struct wjh_L2_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;    /* only valid for ip4/6, will be 0 otherwise */
    unsigned char               dmac[6];
    unsigned char               smac[6];
    const char                * reason;
} wjh_L2_drop_aggregate_key_t;

typedef struct wjh_L2_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_L2_drop_aggregate_data_t;

typedef struct wjh_L1_drop_aggregate_key {
    wjh_port_log_id_t ingress_port;
} wjh_L1_drop_aggregate_key_t;

typedef struct wjh_L1_drop_aggregate_data {
    uint8_t                   is_port_up;
    char                     *port_down_reason;
    char                     *description;
    uint64_t                  state_change_count;
    uint64_t                  symbol_error_count;
    uint64_t                  crc_error_count;
    wjh_aggregate_timestamp_t timestamp;
} wjh_L1_drop_aggregate_data_t;

typedef enum wjh_status {
    WJH_STATUS_SUCCESS,
    WJH_STATUS_ERROR,
    WJH_STATUS_PARAM_ERROR,
    WJH_STATUS_PARAM_NULL,
    WJH_STATUS_ENTRY_NOT_FOUND,
    WJH_STATUS_NOT_INITIALIZED,
    WJH_STATUS_ALREADY_INITIALIZED,
    WJH_STATUS_NO_RESOURCES,
    WJH_STATUS_NO_MEMORY,
    WJH_STATUS_UNSUPPORTED,
    WJH_STATUS_IN_PROGRESS
} wjh_status_t;

typedef enum wjh_verbosity_level {
    WJH_VERBOSITY_LEVEL_NONE = 0,
    WJH_VERBOSITY_LEVEL_ERROR,
    WJH_VERBOSITY_LEVEL_WARNING,
    WJH_VERBOSITY_LEVEL_NOTICE,
    WJH_VERBOSITY_LEVEL_INFO,
    WJH_VERBOSITY_LEVEL_DEBUG,
    WJH_VERBOSITY_LEVEL_FUNCS,
    WJH_VERBOSITY_LEVEL_FRAMES,
    WJH_VERBOSITY_LEVEL_ALL,
    WJH_VERBOSITY_LEVEL_MIN = WJH_VERBOSITY_LEVEL_NONE,
    WJH_VERBOSITY_LEVEL_MAX = WJH_VERBOSITY_LEVEL_ALL,
} wjh_verbosity_level_t;

typedef wjh_status_t (*wjh_buffer_drop_raw_cb)(wjh_buffer_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);
typedef wjh_status_t (*wjh_acl_drop_raw_cb)(wjh_acl_drop_raw_info_t *raw_info_list_p,
                                            uint32_t                *raw_info_list_size_p);
typedef wjh_status_t (*wjh_router_drop_raw_cb)(wjh_router_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);
typedef wjh_status_t (*wjh_L2_drop_raw_cb)(wjh_L2_drop_raw_info_t *raw_info_list_p,
                                           uint32_t               *raw_info_list_size_p);
typedef wjh_status_t (*wjh_tunnel_drop_raw_cb)(wjh_tunnel_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);

typedef wjh_status_t (*wjh_buffer_drop_aggregate_cb)(wjh_buffer_drop_aggregate_key_t  *key_list_p,
                                                     wjh_buffer_drop_aggregate_data_t *data_list_p,
                                                     uint32_t                         *keys_cnt_p);
typedef wjh_status_t (*wjh_acl_drop_aggregate_cb)(wjh_acl_drop_aggregate_key_t  *key_list_p,
                                                  wjh_acl_drop_aggregate_data_t *data_list_p,
                                                  uint32_t                      *keys_cnt_p);
typedef wjh_status_t (*wjh_router_drop_aggregate_cb)(wjh_router_drop_aggregate_key_t  *key_list_p,
                                                     wjh_router_drop_aggregate_data_t *data_list_p,
                                                     uint32_t                         *keys_cnt_p);
typedef wjh_status_t (*wjh_L2_drop_aggregate_cb)(wjh_L2_drop_aggregate_key_t  *key_list_p,
                                                 wjh_L2_drop_aggregate_data_t *data_list_p,
                                                 uint32_t                     *keys_cnt_p);
typedef wjh_status_t (*wjh_L1_drop_aggregate_cb)(wjh_L1_drop_aggregate_key_t  *key_list_p,
                                                 wjh_L1_drop_aggregate_data_t *data_list_p,
                                                 uint32_t                     *keys_cnt_p);
typedef wjh_status_t (*wjh_tunnel_drop_aggregate_cb)(wjh_tunnel_drop_aggregate_key_t  *key_list_p,
                                                     wjh_tunnel_drop_aggregate_data_t *data_list_p,
                                                     uint32_t                         *keys_cnt_p);

typedef struct wjh_drop_callbacks {
    wjh_drop_reason_group_e drop_reason_group;
    union {
        wjh_buffer_drop_raw_cb buffer;
        wjh_acl_drop_raw_cb    acl;
        wjh_router_drop_raw_cb router;
        wjh_L2_drop_raw_cb     L2;
        wjh_tunnel_drop_raw_cb tunnel;
    } raw_cb;
    union {
        wjh_buffer_drop_aggregate_cb buffer;
        wjh_acl_drop_aggregate_cb    acl;
        wjh_router_drop_aggregate_cb router;
        wjh_L2_drop_aggregate_cb     L2;
        wjh_L1_drop_aggregate_cb     L1;
        wjh_tunnel_drop_aggregate_cb tunnel;
    } aggregate_cb;
} wjh_drop_callbacks_t;

typedef uint32_t wjh_user_channel_id_t;

typedef enum wjh_user_channel_type {
    WJH_USER_CHANNEL_TAILDROP_E,
    WJH_USER_CHANNEL_CYCLIC_E,
    WJH_USER_CHANNEL_AGGREGATE_E,
    WJH_USER_CHANNEL_MIN_E = WJH_USER_CHANNEL_TAILDROP_E,
    WJH_USER_CHANNEL_MAX_E = WJH_USER_CHANNEL_AGGREGATE_E,
} wjh_user_channel_type_e;

/* In push mode, the WJH library periodically queries the dropped packets or statistics and deliver them via user callbacks.
 * In pull mode, the WJH library stops the periodical query. The dropped packets or statistics can be delivered via user callbacks
 * which are explicitly triggered by API wjh_user_channel_pull. Please note that the user callbacks will be executed in the same
 * context/thread of the caller of wjh_user_channel_pull.
 */
typedef enum wjh_user_channel_mode {
    WJH_USER_CHANNEL_MODE_PUSH_E,
    WJH_USER_CHANNEL_MODE_PULL_E,
    WJH_USER_CAHNNEL_MODE_MIN_E = WJH_USER_CHANNEL_MODE_PUSH_E,
    WJH_USER_CAHNNEL_MODE_MAX_E = WJH_USER_CHANNEL_MODE_PULL_E,
} wjh_user_channel_mode_e;

typedef struct wjh_user_channel_attr {
    uint32_t polling_interval; /* The polling interval in milliseconds, only valid for
                                * cyclic and aggregation channels. Value 0 means default value.
                                * Default values: cyclic channel - 5000 milliseconds (5 seconds)
                                *                 aggregation channel - 30000 milliseconds (30 seconds) */
    wjh_user_channel_mode_e mode; /* Only valid for cyclic and aggregation channels.
                                   * Default value is push mode.
                                   */
} wjh_user_channel_attr_t;

typedef struct wjh_drop_counter {
    uint64_t dropped_packets;      /* total dropped packets counter, for CYCLIC user channel only */
    uint64_t received_packets;     /* trapped drop packets counter */
} wjh_drop_counter_t;

typedef void (*wjh_deactive_cb)(void);

typedef void (*wjh_log_cb_t)(wjh_verbosity_level_t severity, char *msg);

typedef struct wjh_init_param {
    uint8_t         force;
    wjh_deactive_cb deactive_cb;
    uint8_t         max_bandwidth_percent; /* bandwidth percentage, valid value is 0 - 100, 0 means default value which is 80 percent */
    wjh_log_cb_t    log_cb;
    const char     *conf_xml_path; /* NULL means using default XML file */
} wjh_init_param_t;

#endif /* WJH_LIB_TYPES_H_ */
