/*
 * Copyright (C) Mellanox Technologies, Ltd. 2008-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __BSORT_H__
#define __BSORT_H__

#include <sx/utils/sx_utils_status.h>
#include <sx/utils/sx_utils_types.h>
#include <complib/cl_types.h>

typedef void* bsort_handle_t;

typedef enum bsort_notification_type {
    BSORT_RESIZE_TABLE_E = 0,
    BSORT_ADD_ENTRY_E,
    BSORT_MOVE_ENTRY_E,
    BSORT_DELETE_ENTRY_E
} bsort_notification_type_e;

typedef enum {
    BSORT_LOW_PRIORITY = 0,
    BSORT_HIGH_PRIORITY,
} bsort_priority_t;

static __attribute__((__used__)) const char* bsort_priority_str[] = {
    "LOW",
    "HIGH",
};

#define BSORT_PRIORITY_STR_LEN (sizeof(bsort_priority_str) / sizeof(char*))

#define BSORT_PRIORITY_STR(index)                      \
    (SX_CHECK_MAX(index, BSORT_PRIORITY_STR_LEN - 1) ? \
     bsort_priority_str[index] : "UNKNOWN")

typedef struct bsort_entry_param {
    uint32_t         index;
    bsort_priority_t priority;
} bsort_entry_param_t;

typedef struct bsort_resize_table_param {
    uint32_t old_size;
    uint32_t new_size;
} bsort_resize_table_param_t;

typedef struct bsort_add_param {
    uint32_t index;
} bsort_add_param_t;

typedef struct bsort_move_param {
    uint32_t old_index;
    uint32_t new_index;
    uint32_t block_size;
} bsort_move_param_t;

typedef struct bsort_delete_param {
    uint32_t index;
} bsort_delete_param_t;

typedef union bsort_param {
    bsort_resize_table_param_t resize_param;
    bsort_add_param_t          add_param;
    bsort_move_param_t         move_param;
    bsort_delete_param_t       delete_param;
} bsort_callback_param_t;

typedef sx_utils_status_t (*bsort_notification_func_ptr_t)(bsort_notification_type_e notif_type,
                                                           bsort_callback_param_t  * data,
                                                           void                     *context);

/**
 * bsort_init_param_t is used to store the bSort
 * init configuration parameters.
 */
typedef struct bsort_init_param {
    uint32_t                      initial_table_size;
    uint32_t                      resize_threshold;
    uint32_t                      reduce_threshold;
    void                         *context;
    bsort_notification_func_ptr_t notif_callback;
} bsort_init_param_t;

/* Set bsort log level */
sx_utils_status_t bsort_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
/* Init bsort and return the handle */
sx_utils_status_t bsort_init(const bsort_init_param_t* param, bsort_handle_t* handle);
/* Deinit the given bsort handle */
sx_utils_status_t bsort_deinit(const bsort_handle_t handle);
/* Add entry with priority to table */
sx_utils_status_t bsort_add_entry(const bsort_handle_t handle, bsort_entry_param_t* param);
/* Delete entry with index from table */
sx_utils_status_t bsort_delete_entry(const bsort_handle_t handle, const bsort_entry_param_t* param);
/* Dump the table */
sx_utils_status_t bsort_debug_dump(const bsort_handle_t handle, FILE* stream);

#endif /* ifndef __BSORT_H__ */
