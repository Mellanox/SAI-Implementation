/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __BLOOMFILTER_H__
#define __BLOOMFILTER_H__

#include <complib/cl_types.h>
#include <sx/utils/sx_utils_status.h>

/**
 * This bloom filter is updated only using 1 hash function. It should be supplied by
 * the caller.
 */
typedef uint16_t (*bf_hash_func) (const uint8_t* data, uint32_t size);

typedef struct bloom_filter {
    bf_hash_func hash_func;
    uint16_t    *data;
    uint32_t     size;
    boolean_t    is_initialized;
} bloom_filter_t;


/**
 * Initializes a bloom filter.
 *
 * @param[in] hash_func - hash function to access this bloom filter
 * @param[in] size - actual size of bloom filter
 * @param[out] bf - A bloom filter with the given data is allocated and returned to caller
 */
sx_utils_status_t bloom_filter_init(IN bf_hash_func      hash_func,
                                    IN uint32_t          size,
                                    OUT bloom_filter_t **bf);


/**
 * Frees the memory of the bloom filter.
 *
 * @param[in] bf - The bloom filter to free.
 */
sx_utils_status_t bloom_filter_deinit(IN bloom_filter_t** bf);


/**
 * Returns the size of the given bloom-filer.
 *
 * @param[in] bf - a valid bloom_filter
 * @param[out] size - The size of the bloom_filter 'bf'
 */
sx_utils_status_t bloom_filter_size(IN const bloom_filter_t* bf,
                                    OUT uint16_t           * size);

/**
 * Increases the bloom filter 'bf' at a specific index determined by the given key.
 *
 * @param[in]  bf - a valid bloom_filter pointer
 * @param[in]  key
 * @param[in]  key_size - size of key about
 * @param[out] res_index - if not NULL - the index of the hash is returned to caller
 * @param[out] is_first - if not NULL - TRUE if the above index was incremented for the first time,
 *                                                FALSE otherwise
 */
sx_utils_status_t bloom_filter_increase(IN const bloom_filter_t *bf,
                                        IN const uint8_t        *key,
                                        IN uint32_t              key_size,
                                        OUT uint32_t            *res_index,
                                        OUT boolean_t           *is_first);


/**
 * Decreases the bloom filter 'bf' at a specific index determined by the given key.
 *
 * @param[in]  bf - a valid bloom_filter pointer
 * @param[in]  key
 * @param[in]  key_size - size of key about
 * @param[out] res_index - if not NULL, the index of the hash is returned to caller
 * @param[out] is_first - if not NULL, returns TRUE if the above index was decremented and reached 0
 *                                                FALSE otherwise
 */
sx_utils_status_t bloom_filter_decrease(IN const bloom_filter_t *bf,
                                        IN const uint8_t        *key,
                                        IN uint32_t              key_size,
                                        OUT uint32_t            *res_index,
                                        OUT boolean_t           *is_last);

/**
 * FOR DEBUG PURPOSES - DO NOT USE AS IS.
 *
 * Returns the index and the value of the data obtain by applying the key to 'bf' hash
 *
 * @param[in]  bf - a valid bloom_filter pointer
 * @param[in]  key
 * @param[in]  key_size - size of key about
 * @param[out] res_index - The index of the hash is returned to caller
 * @param[out] res_value - The value at 'res_index'
 */
sx_utils_status_t bloom_filter_get(IN const bloom_filter_t *bf,
                                   IN const uint8_t        *key,
                                   IN uint32_t              key_size,
                                   OUT uint32_t            *res_index,
                                   OUT uint32_t            *res_value);


#endif /* __BLOOMFILTER_H__ */
