/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_LAG_H__
#define __SX_LAG_H__

#include <complib/cl_passivelock.h>
#include <sx/sxd/sxd_lag.h>
#include <sx/sdk/sx_port.h>


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * Link aggregation group ID.
 */
typedef uint16_t sx_lag_id_t;

/**
 * Max number of LAGs
 */
#define SX_LAG_ID_MIN   (SXD_LAG_ID_MIN)
#define SX_LAG_ID_MAX   (SXD_LAG_ID_MAX)
#define SX_LAG_ID_COUNT (SX_LAG_ID_MAX - SX_LAG_ID_MIN + 1)
#define SX_LAG_ID_CHECK_RANGE(LAG_ID) SX_CHECK_MAX(LAG_ID, SX_LAG_ID_MAX)

/**
 * Max number of LAGs
 */
#define SX_LAG_MAX_NUM_LAG_PORTS (SX_LAG_ID_MAX - SX_LAG_ID_MIN + 1)

/**
 * Max number of ports per LAG
 */
#define SX_LAG_MAX_PORTS_PER_LAG      SXD_LAG_MAX_PORTS
#define SX_LAG_DEFAULT_LAG_HASH       0x01FE
#define SX_LAG_DEFAULT_HASH_TYPE      0
#define SX_LAG_DEFAULT_HASH_SEED      0
#define SX_LAG_DEFAULT_SYMMETRIC_HASH FALSE

#define MAX_LAG_HASH_VALUE 0xFFFFF
#define MIN_LAG_HASH_VALUE 0

#define LAG_SHM_PATH           "/lag"
#define INVALID_LAG_LOG_PORT   0
#define INVALID_LAG_PORT_INDEX 0xFF
#define INVALID_LAG_ID         rm_resource_global.lag_num_max
#define INVALID_LAG_ID_LOG_PORT(id)            \
    id = 0;                                    \
    SX_PORT_TYPE_ID_SET(id, SX_PORT_TYPE_LAG); \
    SX_PORT_LAG_ID_SET(id, INVALID_LAG_ID);    \
    SX_PORT_SUB_ID_SET(id, 0)

typedef enum sx_distributor_mode {
    DISTRIBUTOR_ENABLE,
    DISTRIBUTOR_DISABLE
} sx_distributor_mode_t;

typedef enum sx_collector_mode {
    COLLECTOR_ENABLE,
    COLLECTOR_DISABLE
} sx_collector_mode_t;


#define FOREACH_LAG_HASH_BIT_NUMBER(F)                                                                                \
    F(SX_LAG_HASH_INGRESS_PORT = 0, "INGRESS_PORT") /**< Ingress port accounted in flow hash */                       \
    F(SX_LAG_HASH_SMAC_IP = 1, "SMAC_IP") /**< Source MAC accounted in flow hash for IPv4 and IPv6 frames */          \
    F(SX_LAG_HASH_SMAC_NON_IP = 2, "SMAC_NON_IP") /**< Source MAC accounted in flow hash for non IP frames */         \
    F(SX_LAG_HASH_DMAC_IP = 3, "DMAC_IP") /**< Destination MAC accounted in flow hash for IPv4 and IPv6 frames */     \
    F(SX_LAG_HASH_DMAC_NON_IP = 4, "DMAC_NON_IP") /**< Destination MAC accounted in flow hash for non IP frames */    \
    F(SX_LAG_HASH_ETHER_IP = 5, "ETHER_IP") /**< Ethertype accounted in flow hash for IPv4 and IPv6 frames */         \
    F(SX_LAG_HASH_ETHER_NON_IP = 6, "ETHER_NON_IP") /**< Ethertype accounted in flow hash for non IP frames */        \
    F(SX_LAG_HASH_VID_IP = 7, "VID_IP") /**< Vlan ID accounted in flow hash for IPv4 and IPv6 frames */               \
    F(SX_LAG_HASH_VID_NON_IP = 8, "VID_NON_IP") /**< Vlan ID accounted in flow hash for non IP frames */              \
    F(SX_LAG_HASH_S_IP = 9, "SRC_IP") /**< Source IP accounted in flow hash */                                        \
    F(SX_LAG_HASH_D_IP = 10, "DST_IP") /**< Destination IP accounted in flow hash  */                                 \
    F(SX_LAG_HASH_L4_SPORT = 11, "L4_SRC_PORT") /**< TCP/UDP source port accounted in flow hash  */                   \
    F(SX_LAG_HASH_L4_DPORT = 12, "L4_DST_PORT") /**< TCP/UDP destination port accounted in flow hash  */              \
    F(SX_LAG_HASH_L3_PROTO = 13, "L3_PROTOCOL") /**< IPv4 next protocol / IPv6 next header accounted in flow hash  */ \
    F(SX_LAG_HASH_IPV6_FLOW_LABEL = 14, "IPV6_FLOW_LABEL") /**< IPv6 flow label accounted in flow hash  */            \
    F(SX_LAG_HASH_SID = 15, "FCoE SRC ID") /**< FCoE source ID accounted in flow hash */                              \
    F(SX_LAG_HASH_DID = 16, "FCoE DEST ID") /**< FCoE destination ID accounted in flow hash */                        \
    F(SX_LAG_HASH_OXID = 17, "FCoE ORIG EX ID") /**< FCoE originator exchange ID accounted in flow hash */            \
    F(SX_LAG_HASH_D_QP = 19, "DESTINATION_QP") /**< Destination QP number accounted in flow hash */
/**
 * sx_lag_hash_bit_number_t enum  is used for indicating bit
 * numbers of the hash flow parameters setting in API
 * sx_api_lag_hash_flow_params_set
 */
typedef enum sx_lag_hash_bit_number {
    FOREACH_LAG_HASH_BIT_NUMBER(SX_GENERATE_ENUM)
} sx_lag_hash_bit_number_t;

/**
 * sx_lag_hash_t is a bit map of required flow parameters
 * the user sets the bits indicating flow hash parameters
 * according to  sx_lag_hash_bit_number_t enum
 */
typedef uint32_t sx_lag_hash_t;

/**
 * sx_lag_seed_t is a uint32_t type. it is used for LAG flow
 * hash parameters
 */
typedef uint32_t sx_lag_seed_t;

typedef uint32_t sx_lag_symmetric_t;

typedef enum sx_lag_hash_type {
    SX_LAG_HASH_TYPE_FIRST = 0,
    SX_LAG_HASH_TYPE_CRC = 0,
    SX_LAG_HASH_TYPE_XOR = 1,
    SX_LAG_HASH_TYPE_LAST = SX_LAG_HASH_TYPE_XOR,
    SX_LAG_HASH_TYPE_RANDOM = 2, /**< Spectrum and on */
    SX_LAG_HASH_TYPE_CRC2 = 3,   /**< Spectrum2 and on */
    SX_LAG_HASH_TYPE_MIN = SX_LAG_HASH_TYPE_CRC,
    SX_LAG_HASH_TYPE_MAX = SX_LAG_HASH_TYPE_CRC2,
} sx_lag_hash_type_t;

typedef struct sx_lag_hash_param {
    sx_lag_hash_type_t lag_hash_type;   /**< Hash type */
    sx_lag_hash_t      lag_hash;             /**< bit field - sx_lag_hash_bit_number_t */
    sx_lag_seed_t      lag_seed;             /**< LAG seed */
    boolean_t          is_lag_hash_symmetric;   /* < TRUE=symmetric, FALSE=asymmetric */
} sx_lag_hash_param_t;

#define SX_LAG_HASH_TYPE_SPECTRUM_CHECK_RANGE(LAG_HASH_TYPE) \
    SX_CHECK_MAX(LAG_HASH_TYPE, SX_LAG_HASH_TYPE_RANDOM)

/**
 * sx_lag_hash_field_enable_t enumerated type is used to specify which
 *
 * fields are enabled in the hash calculation.
 */

#define SX_LAG_HASH_OUTER_ENABLES_OFFSET 1
#define SX_LAG_HASH_INNER_ENABLES_OFFSET 1000

typedef enum sx_lag_hash_field_enable {
    /* Outer header enables */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_NON_IP = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 0,        /**< Enable L2      header fields if packet is not IPv4/IPv6 */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV4 = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 1,          /**< Enable L2      header fields if packet is     IPv4 */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_IPV6 = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 2,          /**< Enable L2      header fields if packet is     IPv6 */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 3, /**< Enable IPv4    header fields if packet is not TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 4,     /**< Enable IPv4    header fields if packet is     TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_NON_TCP_UDP = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 5, /**< Enable IPv6    header fields if packet is not TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 6,     /**< Enable IPv6    header fields if packet is     TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_L4_IPV4 = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 7,          /**< Enable TCP/UDP header fields if packet is     IPv4 */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_L4_IPV6 = SX_LAG_HASH_OUTER_ENABLES_OFFSET + 8,          /**< Enable TCP/UDP header fields if packet is     IPv6 */
    SX_LAG_HASH_FIELD_ENABLE_OUTER_FIRST = SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_NON_IP,
    SX_LAG_HASH_FIELD_ENABLE_OUTER_LAST = SX_LAG_HASH_FIELD_ENABLE_OUTER_L4_IPV6,

    /* Inner header enables */
    SX_LAG_HASH_FIELD_ENABLE_INNER_L2_NON_IP = SX_LAG_HASH_INNER_ENABLES_OFFSET + 0,        /**< Enable L2      header fields if packet is not IPv4/IPv6 */
    SX_LAG_HASH_FIELD_ENABLE_INNER_L2_IPV4 = SX_LAG_HASH_INNER_ENABLES_OFFSET + 1,          /**< Enable L2      header fields if packet is     IPv4 */
    SX_LAG_HASH_FIELD_ENABLE_INNER_L2_IPV6 = SX_LAG_HASH_INNER_ENABLES_OFFSET + 2,          /**< Enable L2      header fields if packet is     IPv6 */
    SX_LAG_HASH_FIELD_ENABLE_INNER_IPV4_NON_TCP_UDP = SX_LAG_HASH_INNER_ENABLES_OFFSET + 3, /**< Enable IPv4    header fields if packet is not TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_INNER_IPV4_TCP_UDP = SX_LAG_HASH_INNER_ENABLES_OFFSET + 4,     /**< Enable IPv4    header fields if packet is     TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_INNER_IPV6_NON_TCP_UDP = SX_LAG_HASH_INNER_ENABLES_OFFSET + 5, /**< Enable IPv6    header fields if packet is not TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_INNER_IPV6_TCP_UDP = SX_LAG_HASH_INNER_ENABLES_OFFSET + 6,     /**< Enable IPv6    header fields if packet is     TCP/UDP */
    SX_LAG_HASH_FIELD_ENABLE_INNER_L4_IPV4 = SX_LAG_HASH_INNER_ENABLES_OFFSET + 7,          /**< Enable TCP/UDP header fields if packet is     IPv4 */
    SX_LAG_HASH_FIELD_ENABLE_INNER_L4_IPV6 = SX_LAG_HASH_INNER_ENABLES_OFFSET + 8,          /**< Enable TCP/UDP header fields if packet is     IPv6 */
    SX_LAG_HASH_FIELD_ENABLE_INNER_FIRST = SX_LAG_HASH_FIELD_ENABLE_INNER_L2_NON_IP,
    SX_LAG_HASH_FIELD_ENABLE_INNER_LAST = SX_LAG_HASH_FIELD_ENABLE_INNER_L4_IPV6,

    SX_LAG_HASH_FIELD_ENABLE_MIN = SX_LAG_HASH_FIELD_ENABLE_OUTER_L2_NON_IP,
    SX_LAG_HASH_FIELD_ENABLE_MAX = SX_LAG_HASH_FIELD_ENABLE_INNER_L4_IPV6,
} sx_lag_hash_field_enable_t;

#define SX_LAG_HASH_OUTER_FIELDS_OFFSET   1
#define SX_LAG_HASH_INNER_FIELDS_OFFSET   1000
#define SX_LAG_HASH_GENERAL_FIELDS_OFFSET (RM_COMMON_CUSTOM_BYTES_ENUM_START - 2)

/**
 * sx_lag_hash_field_t enumerated type is used to store the specific
 * layer fields and fields that should be included in the hash calculation, for
 * both the outer header and the inner header.
 */
typedef enum sx_lag_hash_field {
    /* Outer header fields enables */
    SX_LAG_HASH_OUTER_SMAC = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 0,
    SX_LAG_HASH_OUTER_DMAC = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 1,
    SX_LAG_HASH_OUTER_ETHERTYPE = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 2,
    SX_LAG_HASH_OUTER_OVID = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 3, /** < Outer VID> */
    SX_LAG_HASH_OUTER_OPCP = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 4, /** < Outer PCP> */
    SX_LAG_HASH_OUTER_ODEI = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 5, /** < Outer DEI> */
    SX_LAG_HASH_OUTER_IVID = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 6, /** < Inner VID> */
    SX_LAG_HASH_OUTER_IPCP = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 7, /** < Inner PCP> */
    SX_LAG_HASH_OUTER_IDEI = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 8, /** < Inner DEI> */
    SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_0 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 9,
    SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_1 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 10,
    SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_2 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 11,
    SX_LAG_HASH_OUTER_IPV4_SIP_BYTE_3 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 12,
    SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_0 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 13,
    SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_1 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 14,
    SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_2 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 15,
    SX_LAG_HASH_OUTER_IPV4_DIP_BYTE_3 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 16,
    SX_LAG_HASH_OUTER_IPV4_PROTOCOL = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 17,
    SX_LAG_HASH_OUTER_IPV4_DSCP = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 18,
    SX_LAG_HASH_OUTER_IPV4_ECN = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 19,
    SX_LAG_HASH_OUTER_IPV4_IP_L3_LENGTH = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 20,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 21,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_8 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 29,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_9 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 30,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_10 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 31,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_11 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 32,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_12 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 33,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_13 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 34,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_14 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 35,
    SX_LAG_HASH_OUTER_IPV6_SIP_BYTE_15 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 36,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTES_0_TO_7 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 37,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_8 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 45,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_9 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 46,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_10 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 47,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_11 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 48,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_12 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 49,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_13 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 50,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_14 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 51,
    SX_LAG_HASH_OUTER_IPV6_DIP_BYTE_15 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 52,
    SX_LAG_HASH_OUTER_IPV6_NEXT_HEADER = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 53,
    SX_LAG_HASH_OUTER_IPV6_DSCP = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 54,
    SX_LAG_HASH_OUTER_IPV6_ECN = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 55,
    SX_LAG_HASH_OUTER_IPV6_IP_L3_LENGTH = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 56,
    SX_LAG_HASH_OUTER_IPV6_FLOW_LABEL = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 57,
/* these GRH fields are supported by HW but are not yet opened by verification
 *   SX_LAG_HASH_OUTER_ROCE_GRH_SIP = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 58,
 *   SX_LAG_HASH_OUTER_ROCE_GRH_DIP = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 59,
 *   SX_LAG_HASH_OUTER_ROCE_GRH_NEXT_PROTOCOL = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 60,
 *   SX_LAG_HASH_OUTER_ROCE_GRH_DSCP = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 61,
 *   SX_LAG_HASH_OUTER_ROCE_GRH_ECN = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 62,
 *   SX_LAG_HASH_OUTER_ROCE_GRH_L3_LENGTH = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 63,
 *   SX_LAG_HASH_OUTER_ROCE_GRH_FLOW_LABEL = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 64,
 */
/* these Fibre-channel fields are supported by HW but are not yet opened by verification
 *   SX_LAG_HASH_OUTER_FCOE_SID = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 65,
 *   SX_LAG_HASH_OUTER_FCOE_DID = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 66,
 *   SX_LAG_HASH_OUTER_FCOE_OXID = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 67,
 */
    SX_LAG_HASH_OUTER_MPLS_LABEL_0 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 68,
    SX_LAG_HASH_OUTER_MPLS_LABEL_1 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 69,
    SX_LAG_HASH_OUTER_MPLS_LABEL_2 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 70,
    SX_LAG_HASH_OUTER_MPLS_LABEL_3 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 71,
    SX_LAG_HASH_OUTER_MPLS_LABEL_4 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 72,
    SX_LAG_HASH_OUTER_MPLS_LABEL_5 = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 73,
    SX_LAG_HASH_OUTER_TCP_UDP_SPORT = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 74,
    SX_LAG_HASH_OUTER_TCP_UDP_DPORT = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 75,
    SX_LAG_HASH_OUTER_BTH_DQPN = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 76,
    SX_LAG_HASH_OUTER_BTH_PKEY = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 77,
    SX_LAG_HASH_OUTER_BTH_OPCODE = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 78,
    SX_LAG_HASH_OUTER_DETH_QKEY = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 79,
    SX_LAG_HASH_OUTER_DETH_SQPN = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 80,
    SX_LAG_HASH_OUTER_VNI = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 81,
    SX_LAG_HASH_OUTER_NVGRE_FLOW = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 82,
    SX_LAG_HASH_OUTER_NVGRE_PROTOCOL = SX_LAG_HASH_OUTER_FIELDS_OFFSET + 83,
    SX_LAG_HASH_OUTER_FIRST = SX_LAG_HASH_OUTER_SMAC,
    SX_LAG_HASH_OUTER_LAST = SX_LAG_HASH_OUTER_NVGRE_PROTOCOL,

    /* Inner header fields enables */
    SX_LAG_HASH_INNER_SMAC = SX_LAG_HASH_INNER_FIELDS_OFFSET + 0,
    SX_LAG_HASH_INNER_DMAC = SX_LAG_HASH_INNER_FIELDS_OFFSET + 1,
    SX_LAG_HASH_INNER_ETHERTYPE = SX_LAG_HASH_INNER_FIELDS_OFFSET + 2,
    SX_LAG_HASH_INNER_IPV4_SIP_BYTE_0 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 3,
    SX_LAG_HASH_INNER_IPV4_SIP_BYTE_1 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 4,
    SX_LAG_HASH_INNER_IPV4_SIP_BYTE_2 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 5,
    SX_LAG_HASH_INNER_IPV4_SIP_BYTE_3 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 6,
    SX_LAG_HASH_INNER_IPV4_DIP_BYTE_0 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 7,
    SX_LAG_HASH_INNER_IPV4_DIP_BYTE_1 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 8,
    SX_LAG_HASH_INNER_IPV4_DIP_BYTE_2 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 9,
    SX_LAG_HASH_INNER_IPV4_DIP_BYTE_3 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 10,
    SX_LAG_HASH_INNER_IPV4_PROTOCOL = SX_LAG_HASH_INNER_FIELDS_OFFSET + 11,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTES_0_TO_7 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 12,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_8 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 20,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_9 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 21,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_10 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 22,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_11 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 23,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_12 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 24,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_13 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 25,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_14 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 26,
    SX_LAG_HASH_INNER_IPV6_SIP_BYTE_15 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 27,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTES_0_TO_7 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 28,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_8 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 36,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_9 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 37,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_10 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 38,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_11 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 39,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_12 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 40,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_13 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 41,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_14 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 42,
    SX_LAG_HASH_INNER_IPV6_DIP_BYTE_15 = SX_LAG_HASH_INNER_FIELDS_OFFSET + 43,
    SX_LAG_HASH_INNER_IPV6_NEXT_HEADER = SX_LAG_HASH_INNER_FIELDS_OFFSET + 44,
    SX_LAG_HASH_INNER_IPV6_FLOW_LABEL = SX_LAG_HASH_INNER_FIELDS_OFFSET + 45,
    SX_LAG_HASH_INNER_TCP_UDP_SPORT = SX_LAG_HASH_INNER_FIELDS_OFFSET + 46,
    SX_LAG_HASH_INNER_TCP_UDP_DPORT = SX_LAG_HASH_INNER_FIELDS_OFFSET + 47,
    SX_LAG_HASH_INNER_ROCE_BTH_DQPN = SX_LAG_HASH_INNER_FIELDS_OFFSET + 48,
    SX_LAG_HASH_INNER_ROCE_BTH_PKEY = SX_LAG_HASH_INNER_FIELDS_OFFSET + 49,
    SX_LAG_HASH_INNER_ROCE_BTH_OPCODE = SX_LAG_HASH_INNER_FIELDS_OFFSET + 50,
    SX_LAG_HASH_INNER_ROCE_DETH_QKEY = SX_LAG_HASH_INNER_FIELDS_OFFSET + 51,
    SX_LAG_HASH_INNER_ROCE_DETH_SQPN = SX_LAG_HASH_INNER_FIELDS_OFFSET + 52,
    SX_LAG_HASH_INNER_FIRST = SX_LAG_HASH_INNER_SMAC,
    SX_LAG_HASH_INNER_LAST = SX_LAG_HASH_INNER_ROCE_DETH_SQPN,

    /* General fields */
    SX_LAG_HASH_GENERAL_FIELDS_INGRESS_PORT = SX_LAG_HASH_GENERAL_FIELDS_OFFSET,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_0 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 2,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_1 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 3,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_2 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 4,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_3 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 5,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_4 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 6,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_5 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 7,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_6 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 8,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_7 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 9,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_8 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 10,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_9 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 11,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_10 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 12,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_11 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 13,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_12 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 14,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_13 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 15,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_14 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 16,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_15 = SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 17,
    SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_LAST = SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_15,
    SX_LAG_HASH_GENERAL_FIELDS_FIRST = SX_LAG_HASH_GENERAL_FIELDS_INGRESS_PORT,
    SX_LAG_HASH_GENERAL_FIELDS_LAST = SX_LAG_HASH_GENERAL_FIELDS_CUSTOM_BYTE_LAST,

    SX_LAG_HASH_FIELDS_MIN = SX_LAG_HASH_OUTER_SMAC,
    SX_LAG_HASH_FIELDS_MAX = SX_LAG_HASH_GENERAL_FIELDS_LAST,
} sx_lag_hash_field_t;

#define SX_LAG_HASH_OUTER_FIELD_ENABLES_NUM \
    (SX_LAG_HASH_FIELD_ENABLE_OUTER_LAST -  \
     SX_LAG_HASH_FIELD_ENABLE_OUTER_FIRST + 1)

#define SX_LAG_HASH_INNER_FIELD_ENABLES_NUM \
    (SX_LAG_HASH_FIELD_ENABLE_INNER_LAST -  \
     SX_LAG_HASH_FIELD_ENABLE_INNER_FIRST + 1)

#define SX_LAG_HASH_OUTER_FIELDS_NUM (SX_LAG_HASH_OUTER_LAST - SX_LAG_HASH_OUTER_FIRST + 1)
#define SX_LAG_HASH_INNER_FIELDS_NUM (SX_LAG_HASH_INNER_LAST - SX_LAG_HASH_INNER_FIRST + 1)

#define SX_LAG_HASH_GENERAL_FIELDS_NUM (SX_LAG_HASH_GENERAL_FIELDS_LAST - SX_LAG_HASH_GENERAL_FIELDS_OFFSET + 1)
#define SX_LAG_HASH_FIELDS_NUM                                           \
    ((SX_LAG_HASH_GENERAL_FIELDS_NUM) + (SX_LAG_HASH_OUTER_FIELDS_NUM) + \
     (SX_LAG_HASH_INNER_FIELDS_NUM))
#define SX_LAG_HASH_FIELD_ENABLES_NUM ((SX_LAG_HASH_OUTER_FIELD_ENABLES_NUM) + (SX_LAG_HASH_INNER_FIELD_ENABLES_NUM))

typedef struct sx_lag_port_hash_params {
    sx_lag_hash_type_t lag_hash_type;
    boolean_t          is_lag_hash_symmetric;
    sx_lag_seed_t      lag_seed;
} sx_lag_port_hash_params_t;

/**
 * sx_lag_params_t structure is used to store initialization parameters of
 * LAG Library.
 */
typedef struct sx_lag_params {
    uint32_t      max_ports_per_lag; /**< Maximum ports in a LAG */
    sx_lag_hash_t default_lag_hash; /**< LAG Hash */
} sx_lag_params_t;

typedef struct sx_lag_fine_grain_member {
    sx_port_log_id_t log_port;     /**< logical Port ID */
    uint32_t         weight;       /**< the weight of the port */
} sx_lag_fine_grain_member_t;

typedef struct sx_lag_fine_grain_params {
    uint32_t resolution;             /**< resolution of the distribution list.
                                      * possible values: 512, 1024, 2048, 4096 */
} sx_lag_fine_grain_params_t;


/**
 * sx_ladb_port_data_t structure is used to store LAG port's data
 */
typedef struct {
    sx_port_id_t        port;    /** Lag port */
    sx_collector_mode_t collector_state;    /** collector state */
} sx_ladb_port_data_t;

/**
 * sx_ladb_port_indices_t structure is used to store LAG port's indices DB
 */
typedef struct {
    cl_plock_t          p_lock;
    uint32_t            max_lag_ports;
    uint32_t            max_lid;
    sx_ladb_port_data_t lag_ports[0];    /** Place keeper, actual size determined on init*/
} sx_ladb_port_indices_t;

typedef struct sx_lag_filter {
    /* Reserved for future expansion*/
} sx_lag_filter_t;


#endif /* __SX_LAG_H__ */
