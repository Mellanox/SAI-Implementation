/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_ROUTER_H__
#define __SX_ROUTER_H__

#include <sx/sxd/sxd_router.h>

#include <sx/sdk/sx_mac.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_swid.h>
#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_init.h>
#include <sx/sdk/sx_trap_id.h>
#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_next_hop.h>
#include <resource_manager/resource_manager.h>

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * Router ID.
 */
typedef uint16_t sx_router_id_t;

/**
 * SX_ROUTER_ECMP_ID_INVALID defines an invalid ECMP container ID
 */
#define SX_ROUTER_ECMP_ID_INVALID ((sx_ecmp_id_t)0)

#define SX_ROUTER_ECMP_ID_CHECK_RANGE(ECMP_ID) \
    ((ECMP_ID) != SX_ROUTER_ECMP_ID_INVALID)

/**
 * SX_MC_CONTAINER_ID_INVALID defines an invalid MC container ID
 */
#define SX_MC_CONTAINER_ID_INVALID ((sx_mc_container_id_t)0)

#define SX_MC_CONTAINER_ID_CHECK_RANGE(MC_ID) \
    ((MC_ID) != SX_MC_CONTAINER_ID_INVALID)

#define FOREACH_ROUTER_INTERFACE_TYPE(F)                            \
    F(SX_L2_INTERFACE_TYPE_VLAN, "VLAN")                            \
    F(SX_L2_INTERFACE_TYPE_PORT_VLAN, "Port Vlan")                  \
    F(SX_L2_INTERFACE_TYPE_VPORT, "VPort")                          \
    F(SX_L2_INTERFACE_TYPE_PKEY, "Pkey")                            \
    F(SX_L2_INTERFACE_TYPE_BRIDGE_PORT, "Bridge Port")              \
    F(SX_L2_INTERFACE_TYPE_BRIDGE, "Bridge")                        \
    F(SX_L2_INTERFACE_TYPE_LOOPBACK, "Loopback")                    \
    F(SX_L2_INTERFACE_TYPE_MIN = SX_L2_INTERFACE_TYPE_VLAN, "")     \
    F(SX_L2_INTERFACE_TYPE_MAX = SX_L2_INTERFACE_TYPE_LOOPBACK, "") \
    F(SX_L2_INTERFACE_TYPE_PORT = 2 /* THIS VALUE IS DEPRECATED AND LEFT FOR BACKWARD COMPATIBILITY */, "")


/**
 * sx_router_interface_type_t enumerated type is used to note the Layer 2 interface
 * type.
 */
typedef enum sx_router_interface_type {
    FOREACH_ROUTER_INTERFACE_TYPE(SX_GENERATE_ENUM)
} sx_router_interface_type_t;

#define SX_L2_INTERFACE_TYPE_CHECK_RANGE(L2_INTERFACE_TYPE) \
    SX_CHECK_RANGE(SX_L2_INTERFACE_TYPE_MIN,                \
                   L2_INTERFACE_TYPE,                       \
                   SX_L2_INTERFACE_TYPE_MAX)                \



typedef struct supported_rif_types {
    uint8_t type[SX_L2_INTERFACE_TYPE_MAX + 1];
} supported_rif_types_t;

#define FOREACH_ROUTER_QOS_MODE(F)                             \
    F(SX_ROUTER_QOS_MODE_NOP = 0, "NOP")                       \
    F(SX_ROUTER_QOS_MODE_PRIO_FROM_DSCP = 1, "Prio from DSCP") \
    F(SX_ROUTER_QOS_MODE_PRESERVE_PRIO, "Reserve Prio")        \
    F(SX_ROUTER_QOS_MODE_MIN = SX_ROUTER_QOS_MODE_NOP, "")     \
    F(SX_ROUTER_QOS_MODE_MAX = SX_ROUTER_QOS_MODE_PRESERVE_PRIO, "")

typedef enum sx_router_qos_mode {
    FOREACH_ROUTER_QOS_MODE(SX_GENERATE_ENUM)
} sx_router_qos_mode_t;

#define SX_ROUTER_QOS_MODE_CHECK_RANGE(QOS_MODE) \
    SX_CHECK_MAX(QOS_MODE,                       \
                 SX_ROUTER_QOS_MODE_MAX)         \

/**
 * sx_router_interface_param structure is used to note Layer 2 interface.
 */
typedef struct sx_router_interface_param {
    sx_router_interface_type_t type;   /**< Router Interface type */
    union {
        struct {
            sx_swid_t    swid;               /**< Switch ID */
            sx_vlan_id_t vlan;               /**< VLAN ID */
        } vlan;                              /**< VLAN Router Interface */
        struct {
            sx_port_id_t port;               /**< Port */
            sx_vlan_id_t vlan;               /**< VLAN ID */
        } port_vlan;                         /**< Router Port UNSUPPORTED */
        struct {
            sx_port_id_t               port; /**< Port */
            sx_vlan_id_t               vlan; /**< External VLAN ID */
            sx_untagged_member_state_t egress_mode; /**< Tagged / Untagged */
        } bridge_port;                 /**< Bridge port Interface .1D ONLY */
        struct {
            sx_port_id_t vport;               /**< VPort ID */
        } vport;                              /**< Vport Interface*/
        struct {
            sx_swid_t      swid;              /**< Switch ID */
            sx_bridge_id_t bridge;             /**< bridge ID */
        } bridge;                      /**< Bridge Interface*/
    } ifc;                  /**< Router Interface parameters */
} sx_router_interface_param_t;

/**
 * sx_interface_attributes structure is used to store interface
 * attributes.
 */
typedef struct sx_interface_attributes {
    sx_mac_addr_t        mac_addr; /**< MAC address. reserved if type is IPINIP_OVERLAY */
    uint16_t             mtu;
    sx_router_qos_mode_t qos_mode;
    uint8_t              multicast_ttl_threshold;
    boolean_t            loopback_enable;
} sx_interface_attributes_t;

#define FOREACH_ROUTER_ENABLE_STATE(F)                                 \
    F(SX_ROUTER_ENABLE_STATE_DISABLE, "DISABLE")                       \
    F(SX_ROUTER_ENABLE_STATE_ENABLE, "ENABLE")                         \
    F(SX_ROUTER_ENABLE_STATE_FORWARDING_DISABLE, "No FWD")             \
    F(SX_ROUTER_ENABLE_STATE_MIN = SX_ROUTER_ENABLE_STATE_DISABLE, "") \
    F(SX_ROUTER_ENABLE_STATE_MAX = SX_ROUTER_ENABLE_STATE_FORWARDING_DISABLE, "")

typedef enum sx_router_enable_state {
    FOREACH_ROUTER_ENABLE_STATE(SX_GENERATE_ENUM)
} sx_router_enable_state_t;

#define SX_ROUTER_ENABLE_STATE_CHECK_RANGE(STATE) \
    SX_CHECK_MAX(STATE,                           \
                 SX_ROUTER_ENABLE_STATE_MAX)      \

typedef struct sx_router_interface_state_t {
    sx_router_enable_state_t ipv4_enable;
    sx_router_enable_state_t ipv6_enable;
    sx_router_enable_state_t ipv4_mc_enable;
    sx_router_enable_state_t ipv6_mc_enable;
    sx_router_enable_state_t mpls_enable;
} sx_router_interface_state_t;

/**
 * sx_neigh_data_t is used to store a neighbors data.
 */
typedef struct sx_neigh_data {
    sx_router_action_t    action;
    sx_mac_addr_t         mac_addr;
    sx_router_interface_t rif; /**< \deprecated This field is deprecated and will be removed in the future */
    sx_trap_attributes_t  trap_attr; /**< valid in case neigh action is not FORWARD */
    boolean_t             is_software_only; /**< Don't set to neigh HW if True.*/
} sx_neigh_data_t;

/**
 * Router next hop minimum value.
 */
#define SX_ROUTER_NEXT_HOP_MIN (1)

/**
 * sx_uc_route_type_e defines the type of a UC route
 */
typedef enum sx_uc_route_type {
    SX_UC_ROUTE_TYPE_NEXT_HOP = 0, /**< Route with next hop(s). with ECMP container */
    SX_UC_ROUTE_TYPE_LOCAL, /**< A route to a local subnet, directly attached to the router */
    SX_UC_ROUTE_TYPE_IP2ME, /**< A route to the router's local IP address */
    SX_UC_ROUTE_TYPE_MIN = SX_UC_ROUTE_TYPE_NEXT_HOP,
    SX_UC_ROUTE_TYPE_MAX = SX_UC_ROUTE_TYPE_IP2ME,
} sx_uc_route_type_e;

#define SX_UC_ROUTE_TYPE_CHECK_RANGE(UC_ROUTE_TYPE) \
    SX_CHECK_MAX(UC_ROUTE_TYPE, SX_UC_ROUTE_TYPE_MAX)

/**
 * sx_uc_route_data_t structure is used to store a UC routes data.
 */
typedef struct sx_uc_route_data {
    sx_router_action_t   action; /**< Only valid for types NEXT_HOP and LOCAL */
    uint32_t             next_hop_cnt; /**< \deprecated This field is deprecated and will be removed in the future */
    sx_trap_attributes_t trap_attr; /**< valid in case action is TRAP or TRAP_FORWARD */
    sx_ip_addr_t         next_hop_list_p[RM_API_ROUTER_NEXT_HOP_MAX]; /**< \deprecated This field is deprecated and will be removed in the future */
    sx_uc_route_type_e   type;
    union {
        sx_router_interface_t local_egress_rif; /**< The router interface where the subnet is attached. Only valid for LOCAL route type, with action FORWARD, TRAP_FORWARD or SPAN */
        sx_ecmp_id_t          ecmp_id; /**< The ECMP container which specifies the set of next-hops. Only valid for NEXT_HOP route type, with action FORWARD, TRAP_FORWARD or SPAN.*/
    } uc_route_param;
} sx_uc_route_data_t;

#define FOREACH_ROUTER_RPF_ACTION(F)                                                            \
    F(SX_ROUTER_RPF_ACTION_DISABLED = 0, "Disabled")                                            \
    F(SX_ROUTER_RPF_ACTION_DROP = 1, "Drop")                                                    \
    F(SX_ROUTER_RPF_ACTION_TRAP = 2, "Trap")                                                    \
    F(SX_ROUTER_RPF_ACTION_DIRECTIONAL = 3, "Directional")                                      \
    F(SX_ROUTER_RPF_ACTION_DROP_LIST = 4 /**< Like DROP but with an RPF-group. */, "Drop List") \
    F(SX_ROUTER_RPF_ACTION_TRAP_LIST = 5 /**< Like TRAP but with an RPF-group. */, "Trap List") \
    F(SX_ROUTER_RPF_ACTION_MIN = SX_ROUTER_RPF_ACTION_DISABLED, "")                             \
    F(SX_ROUTER_RPF_ACTION_MAX = SX_ROUTER_RPF_ACTION_TRAP_LIST, "")

/**
 * sx_router_rpf_action_t enumerated type is used to note the RPF action.
 */
typedef enum sx_router_rpf_action {
    FOREACH_ROUTER_RPF_ACTION(SX_GENERATE_ENUM)
} sx_router_rpf_action_t;

#define SX_ROUTER_RPF_ACTION_CHECK_RANGE(ROUTER_RPF_ACTION) \
    SX_CHECK_MAX(ROUTER_RPF_ACTION, SX_ROUTER_RPF_ACTION_MAX)


/**
 * sx_router_assert_action_t enumerated type is used to note the Assert action.
 */
typedef enum sx_router_assert_action_t {
    SX_ROUTER_ASSERT_ACTION_DROP,
    SX_ROUTER_ASSERT_ACTION_TRAP,
    SX_ROUTER_ASSERT_ACTION_MIN = SX_ROUTER_ASSERT_ACTION_DROP,
    SX_ROUTER_ASSERT_ACTION_MAX = SX_ROUTER_ASSERT_ACTION_TRAP,
} sx_router_assert_action_t;

#define SX_ROUTER_ASSERT_ACTION_CHECK_RANGE(ROUTER_ASSERT_ACTION) \
    SX_CHECK_MAX(ROUTER_ASSERT_ACTION, SX_ROUTER_ASSERT_ACTION_MAX)

#define FOREACH_ROUTER_ECMP_HASH_TYPE(F)                               \
    F(SX_ROUTER_ECMP_HASH_TYPE_CRC = 0, "CRC")                         \
    F(SX_ROUTER_ECMP_HASH_TYPE_XOR = 1, "Xor")                         \
    F(SX_ROUTER_ECMP_HASH_TYPE_RANDOM = 2, "Random")                   \
    F(SX_ROUTER_ECMP_HASH_TYPE_MIN = SX_ROUTER_ECMP_HASH_TYPE_CRC, "") \
    F(SX_ROUTER_ECMP_HASH_TYPE_MAX = SX_ROUTER_ECMP_HASH_TYPE_RANDOM, "")
/**
 * sx_router_ecmp_hash_bit_t enumerated type is used to store router ECMP hash
 * type.
 */
typedef enum sx_router_ecmp_hash_type {
    FOREACH_ROUTER_ECMP_HASH_TYPE(SX_GENERATE_ENUM)
} sx_router_ecmp_hash_type_t;

#define SX_ROUTER_ECMP_HASH_TYPE_SWITCHX_CHECK_RANGE(ECMP_HASH_TYPE) \
    SX_CHECK_MAX(ECMP_HASH_TYPE, SX_ROUTER_ECMP_HASH_TYPE_XOR)
#define SX_ROUTER_ECMP_HASH_TYPE_SPECTRUM_CHECK_RANGE(ECMP_HASH_TYPE) \
    SX_CHECK_MAX(ECMP_HASH_TYPE, SX_ROUTER_ECMP_HASH_TYPE_MAX)

/**
 * sx_router_ecmp_hash_bit_t enumerated type is used to store router ECMP hash
 * configuration bits.
 */
typedef enum sx_router_ecmp_hash_bit {
    SX_ROUTER_ECMP_HASH_SRC_IP = (1 << 0),
    SX_ROUTER_ECMP_HASH_DST_IP = (1 << 1),
    SX_ROUTER_ECMP_HASH_TCLASS = (1 << 2),
    SX_ROUTER_ECMP_HASH_FLOW_LABEL = (1 << 3),
    SX_ROUTER_ECMP_HASH_TCP_UDP = (1 << 4),
    SX_ROUTER_ECMP_HASH_TCP_UDP_SRC_PORT = (1 << 5),
    SX_ROUTER_ECMP_HASH_TCP_UDP_DST_PORT = (1 << 6),
    SX_ROUTER_ECMP_HASH_SMAC = (1 << 7),
    SX_ROUTER_ECMP_HASH_DMAC = (1 << 8),
    SX_ROUTER_ECMP_HASH_ETH_TYPE = (1 << 9),
    SX_ROUTER_ECMP_HASH_VID = (1 << 10),
    SX_ROUTER_ECMP_HASH_PCP = (1 << 11),
    SX_ROUTER_ECMP_HASH_DEI = (1 << 12),
} sx_router_ecmp_hash_bit_t;

/**
 * sx_router_ecmp_hash_t type is used to store router ECMP hash configuration.
 * It consists of bitwise OR of sx_router_ecmp_hash_bit_t.
 */
typedef uint32_t sx_router_ecmp_hash_t;

/**
 * ECMP Hash default value.
 */
#define SX_ROUTER_ECMP_HASH_DEFAULT         \
    (SX_ROUTER_ECMP_HASH_SRC_IP |           \
     SX_ROUTER_ECMP_HASH_DST_IP |           \
     SX_ROUTER_ECMP_HASH_TCLASS |           \
     SX_ROUTER_ECMP_HASH_FLOW_LABEL |       \
     SX_ROUTER_ECMP_HASH_TCP_UDP |          \
     SX_ROUTER_ECMP_HASH_TCP_UDP_SRC_PORT | \
     SX_ROUTER_ECMP_HASH_TCP_UDP_DST_PORT)

#define SX_ROUTER_ECMP_HASH_BIT_MAX SX_ROUTER_ECMP_HASH_DEI

#define SX_ROUTER_ECMP_INFINITE_UNBALANCED_TIME ((uint32_t)(0xFFFFFFFF))

/**
 * sx_router_ecmp_hash_params_t type is used to store router ECMP hash
 * configuration parameters.
 */
typedef struct sx_router_ecmp_hash_params {
    sx_router_ecmp_hash_type_t ecmp_hash_type;
    sx_router_ecmp_hash_t      ecmp_hash;
    boolean_t                  symmetric_hash;
    uint32_t                   seed;
} sx_router_ecmp_hash_params_t;

/**
 * sx_router_ecmp_pp_type_t enumerated type is used to store the per-port
 * configuration type.
 */
typedef enum sx_router_ecmp_pp_type {
    SX_ROUTER_ECMP_PP_TYPE_GLOBAL = SXD_ROUTER_ECMP_PP_TYPE_GLOBAL,
    SX_ROUTER_ECMP_PP_TYPE_PER_PORT = SXD_ROUTER_ECMP_PP_TYPE_PER_PORT,
} sx_router_ecmp_pp_type_t;


/**
 * sx_router_ecmp_hash_field_enable_t enumerated type is used to specify which
 *
 * fields are enabled in the hash calculation.
 */

#define SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET 1
#define SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET 1000

typedef enum sx_router_ecmp_hash_field_enable {
    /* Outer header enables */
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_NON_IP = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 0,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV4 = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 1,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_IPV6 = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 2,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_NON_TCP_UDP = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 3,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 4,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV6_NON_TCP_UDP = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 5,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 6,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L4_IPV4 = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 7,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L4_IPV6 = SX_ROUTER_ECMP_HASH_OUTER_ENABLES_OFFSET + 8,

    /* Inner header enables */
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L2_NON_IP = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 0,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L2_IPV4 = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 1,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L2_IPV6 = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 2,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV4_NON_TCP_UDP = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 3,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV4_TCP_UDP = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 4,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV6_NON_TCP_UDP = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 5,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_IPV6_TCP_UDP = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 6,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L4_IPV4 = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 7,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L4_IPV6 = SX_ROUTER_ECMP_HASH_INNER_ENABLES_OFFSET + 8,

    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_MIN = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_NON_IP,
    SX_ROUTER_ECMP_HASH_FIELD_ENABLE_MAX = SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L4_IPV6,
} sx_router_ecmp_hash_field_enable_t;

#define SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET   1
#define SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET   1000
#define SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET (RM_COMMON_CUSTOM_BYTES_ENUM_START - 2)

/**
 * sx_router_ecmp_hash_field_t enumerated type is used to store the specific
 * layer fields and fields that should be included in the hash calculation, for
 * both the outer header and the inner header.
 */
typedef enum sx_router_ecmp_hash_field {
    /* Outer header fields enables */
    SX_ROUTER_ECMP_HASH_OUTER_SMAC = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 0,
    SX_ROUTER_ECMP_HASH_OUTER_DMAC = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 1,
    SX_ROUTER_ECMP_HASH_OUTER_ETHERTYPE = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 2,
    SX_ROUTER_ECMP_HASH_OUTER_OVID = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 3, /** < Outer VID> */
    SX_ROUTER_ECMP_HASH_OUTER_OPCP = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 4, /** < Outer PCP> */
    SX_ROUTER_ECMP_HASH_OUTER_ODEI = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 5, /** < Outer DEI> */
    SX_ROUTER_ECMP_HASH_OUTER_IVID = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 6, /** < Inner VID> */
    SX_ROUTER_ECMP_HASH_OUTER_IPCP = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 7, /** < Inner PCP> */
    SX_ROUTER_ECMP_HASH_OUTER_IDEI = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 8, /** < Inner DEI> */
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_0 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 9,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_1 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 10,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_2 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 11,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_SIP_BYTE_3 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 12,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_0 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 13,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_1 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 14,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_2 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 15,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_DIP_BYTE_3 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 16,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_PROTOCOL = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 17,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_DSCP = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 18,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_ECN = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 19,
    SX_ROUTER_ECMP_HASH_OUTER_IPV4_IP_L3_LENGTH = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 20,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 21,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_8 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 29,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_9 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 30,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_10 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 31,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_11 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 32,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_12 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 33,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_13 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 34,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_14 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 35,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_SIP_BYTE_15 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 36,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTES_0_TO_7 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 37,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_8 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 45,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_9 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 46,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_10 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 47,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_11 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 48,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_12 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 49,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_13 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 50,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_14 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 51,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DIP_BYTE_15 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 52,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_NEXT_HEADER = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 53,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_DSCP = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 54,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_ECN = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 55,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_IP_L3_LENGTH = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 56,
    SX_ROUTER_ECMP_HASH_OUTER_IPV6_FLOW_LABEL = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 57,
    SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_SIP = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 58,
    SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_DIP = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 59,
    SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_NEXT_PROTOCOL = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 60,
    SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_DSCP = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 61,
    SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_ECN = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 62,
    SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_L3_LENGTH = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 63,
    SX_ROUTER_ECMP_HASH_OUTER_ROCE_GRH_FLOW_LABEL = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 64,
    SX_ROUTER_ECMP_HASH_OUTER_FCOE_SID = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 65,
    SX_ROUTER_ECMP_HASH_OUTER_FCOE_DID = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 66,
    SX_ROUTER_ECMP_HASH_OUTER_FCOE_OXID = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 67,
    SX_ROUTER_ECMP_HASH_OUTER_MPLS_LABEL_0 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 68,
    SX_ROUTER_ECMP_HASH_OUTER_MPLS_LABEL_1 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 69,
    SX_ROUTER_ECMP_HASH_OUTER_MPLS_LABEL_2 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 70,
    SX_ROUTER_ECMP_HASH_OUTER_MPLS_LABEL_3 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 71,
    SX_ROUTER_ECMP_HASH_OUTER_MPLS_LABEL_4 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 72,
    SX_ROUTER_ECMP_HASH_OUTER_MPLS_LABEL_5 = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 73,
    SX_ROUTER_ECMP_HASH_OUTER_TCP_UDP_SPORT = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 74,
    SX_ROUTER_ECMP_HASH_OUTER_TCP_UDP_DPORT = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 75,
    SX_ROUTER_ECMP_HASH_OUTER_BTH_DQPN = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 76,
    SX_ROUTER_ECMP_HASH_OUTER_BTH_PKEY = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 77,
    SX_ROUTER_ECMP_HASH_OUTER_BTH_OPCODE = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 78,
    SX_ROUTER_ECMP_HASH_OUTER_DETH_QKEY = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 79,
    SX_ROUTER_ECMP_HASH_OUTER_DETH_SQPN = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 80,
    SX_ROUTER_ECMP_HASH_OUTER_VNI = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 81,
    SX_ROUTER_ECMP_HASH_OUTER_NVGRE_FLOW = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 82,
    SX_ROUTER_ECMP_HASH_OUTER_NVGRE_PROTOCOL = SX_ROUTER_ECMP_HASH_OUTER_FIELDS_OFFSET + 83,
    SX_ROUTER_ECMP_HASH_OUTER_LAST = SX_ROUTER_ECMP_HASH_OUTER_NVGRE_PROTOCOL,

    /* Inner header fields enables */
    SX_ROUTER_ECMP_HASH_INNER_SMAC = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 0,
    SX_ROUTER_ECMP_HASH_INNER_DMAC = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 1,
    SX_ROUTER_ECMP_HASH_INNER_ETHERTYPE = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 2,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_0 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 3,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_1 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 4,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_2 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 5,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_SIP_BYTE_3 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 6,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_0 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 7,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_1 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 8,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_2 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 9,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_DIP_BYTE_3 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 10,
    SX_ROUTER_ECMP_HASH_INNER_IPV4_PROTOCOL = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 11,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTES_0_TO_7 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 12,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_8 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 20,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_9 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 21,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_10 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 22,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_11 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 23,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_12 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 24,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_13 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 25,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_14 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 26,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_SIP_BYTE_15 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 27,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTES_0_TO_7 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 28,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_8 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 36,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_9 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 37,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_10 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 38,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_11 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 39,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_12 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 40,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_13 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 41,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_14 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 42,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_DIP_BYTE_15 = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 43,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_NEXT_HEADER = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 44,
    SX_ROUTER_ECMP_HASH_INNER_IPV6_FLOW_LABEL = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 45,
    SX_ROUTER_ECMP_HASH_INNER_TCP_UDP_SPORT = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 46,
    SX_ROUTER_ECMP_HASH_INNER_TCP_UDP_DPORT = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 47,
    SX_ROUTER_ECMP_HASH_INNER_ROCE_BTH_DQPN = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 48,
    SX_ROUTER_ECMP_HASH_INNER_ROCE_BTH_PKEY = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 49,
    SX_ROUTER_ECMP_HASH_INNER_ROCE_BTH_OPCODE = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 50,
    SX_ROUTER_ECMP_HASH_INNER_ROCE_DETH_QKEY = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 51,
    SX_ROUTER_ECMP_HASH_INNER_ROCE_DETH_SQPN = SX_ROUTER_ECMP_HASH_INNER_FIELDS_OFFSET + 52,
    SX_ROUTER_ECMP_HASH_INNER_LAST = SX_ROUTER_ECMP_HASH_INNER_ROCE_DETH_SQPN,

    /* General fields */
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_INGRESS_PORT_NUMBER = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_0 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 2,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_1 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 3,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_2 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 4,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_3 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 5,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_4 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 6,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_5 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 7,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_6 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 8,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_7 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 9,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_8 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 10,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_9 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 11,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_10 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 12,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_11 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 13,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_12 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 14,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_13 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 15,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_14 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 16,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_15 = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 17,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_LAST = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_15,
    SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_LAST = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_CUSTOM_BYTE_LAST,

    SX_ROUTER_ECMP_HASH_MIN = SX_ROUTER_ECMP_HASH_OUTER_SMAC,
    SX_ROUTER_ECMP_HASH_MAX = SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_LAST,
} sx_router_ecmp_hash_field_t;

#define INNER_FIELDS_ENABLE_NUM                       \
    (SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L4_IPV6 - \
     SX_ROUTER_ECMP_HASH_FIELD_ENABLE_INNER_L2_NON_IP + 1)
#define OUTER_FIELDS_ENABLE_NUM                       \
    (SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L4_IPV6 - \
     SX_ROUTER_ECMP_HASH_FIELD_ENABLE_OUTER_L2_NON_IP + 1)
#define OUTER_FIELDS_NUM (SX_ROUTER_ECMP_HASH_OUTER_NVGRE_PROTOCOL - SX_ROUTER_ECMP_HASH_OUTER_SMAC + 1)
#define INNER_FIELDS_NUM (SX_ROUTER_ECMP_HASH_INNER_ROCE_DETH_SQPN - SX_ROUTER_ECMP_HASH_INNER_SMAC + 1)
#define GENERAL_FIELDS_NUM \
    (SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_LAST - SX_ROUTER_ECMP_HASH_GENERAL_FIELDS_OFFSET + 1)
#define FIELDS_NUM         ((GENERAL_FIELDS_NUM) + (OUTER_FIELDS_NUM) + (INNER_FIELDS_NUM))
#define FIELDS_ENABLES_NUM ((OUTER_FIELDS_ENABLE_NUM) + (INNER_FIELDS_ENABLE_NUM))

/**
 * sx_router_ecmp_port_hash_params_t type is used to store router ECMP hash
 * configuration parameters.
 *
 */
typedef struct sx_router_ecmp_port_hash_params {
    sx_router_ecmp_hash_type_t ecmp_hash_type;
    boolean_t                  symmetric_hash;
    uint32_t                   seed;
} sx_router_ecmp_port_hash_params_t;

/**
 * Router Counter ID.
 */
typedef uint32_t sx_router_counter_id_t;

/**
 * Router Counter Set.
 */
typedef struct sx_router_counter_set {
    uint64_t router_ingress_good_unicast_packets;
    uint64_t router_ingress_good_multicast_packets;
    uint64_t router_ingress_good_unicast_bytes;
    uint64_t router_ingress_good_multicast_bytes;
    uint64_t router_ingress_bad_unicast_packets;     /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_ingress_bad_multicast_packets;   /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_ingress_bad_unicast_bytes;       /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_ingress_bad_multicast_bytes;     /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_egress_good_unicast_packets;
    uint64_t router_egress_good_multicast_packets;
    uint64_t router_egress_good_unicast_bytes;
    uint64_t router_egress_good_multicast_bytes;
    uint64_t router_egress_bad_unicast_packets;     /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_egress_bad_multicast_packets;   /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_egress_bad_unicast_bytes;       /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_egress_bad_multicast_bytes;     /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_ingress_good_broadcast_packets;
    uint64_t router_ingress_error_packets;          /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_ingress_discard_packets;
    uint64_t router_ingress_good_broadcast_bytes;
    uint64_t router_ingress_error_bytes;            /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_ingress_discard_bytes;
    uint64_t router_egress_good_broadcast_packets;
    uint64_t router_egress_error_packets;           /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_egress_discard_packets;
    uint64_t router_egress_good_broadcast_bytes;
    uint64_t router_egress_error_bytes;             /**< \deprecated This field is deprecated and will be removed in the future */
    uint64_t router_egress_discard_bytes;
} sx_router_counter_set_t;

/**
 * Router counter types
 */
typedef enum {
    SX_ROUTER_COUNTER_TYPE_BASIC,
    SX_ROUTER_COUNTER_TYPE_ENHANCED,
    SX_ROUTER_COUNTER_TYPE_MIN = SX_ROUTER_COUNTER_TYPE_BASIC,
    SX_ROUTER_COUNTER_TYPE_MAX = SX_ROUTER_COUNTER_TYPE_ENHANCED
} sx_router_counter_type_e;

#define SX_ROUTER_COUNTER_TYPE_CHECK_RANGE(type) \
    (SX_CHECK_MAX(type, SX_ROUTER_COUNTER_TYPE_MAX))

/**
 * Router counter attributes
 */
typedef struct sx_router_counter_attributes {
    sx_router_counter_type_e type;
} sx_router_counter_attributes_t;

/**
 * sx_router_counter_enhanced_t used to
 * store router counter type enhanced user data
 */
typedef struct sx_router_counter_enhanced_set {
    sx_router_counter_set_t ipv4_counters;
    sx_router_counter_set_t ipv6_counters;
    sx_router_counter_set_t mpls_counters;
} sx_router_counter_enhanced_t;

/**
 * sx_api_router_counter_advanced_get params structure is used
 * to store SX-API Router counter parameters.
 */

typedef struct sx_router_counter_set_extended {
    sx_router_counter_type_e type;
    union {
        sx_router_counter_set_t      rif_basic;
        sx_router_counter_enhanced_t rif_enhanced;
    } data;
} sx_router_counter_set_extended_t;

#define SX_ROUTER_COUNTER_SET_SIZE (sizeof(sx_router_counter_set_t) / sizeof(uint64_t))

static __attribute__((__used__)) const char* sx_router_cntr_set_str[SX_ROUTER_COUNTER_SET_SIZE] = {
    "router_ingress_good_unicast_packets",
    "router_ingress_good_multicast_packets",
    "router_ingress_good_unicast_bytes",
    "router_ingress_good_multicast_bytes",
    "router_ingress_bad_unicast_packets",
    "router_ingress_bad_multicast_packets",
    "router_ingress_bad_unicast_bytes",
    "router_ingress_bad_multicast_bytes",
    "router_egress_good_unicast_packets",
    "router_egress_good_multicast_packets",
    "router_egress_good_unicast_bytes",
    "router_egress_good_multicast_bytes",
    "router_egress_bad_unicast_packets",
    "router_egress_bad_multicast_packets",
    "router_egress_bad_unicast_bytes",
    "router_egress_bad_multicast_bytes",
};

#define SX_ROUTER_CNTR_SET_STR_LEN (sizeof(sx_router_cntr_set_str) / sizeof(char*))

#define SX_ROUTER_COUNTER_STR(index)                       \
    (SX_CHECK_MAX(index, SX_ROUTER_CNTR_SET_STR_LEN - 1) ? \
     sx_router_cntr_set_str[index] : "UNKNOWN")

/**
 * sx_router_resources_param_t is used to store the routers resources
 * allocation parameters.
 */
typedef struct sx_router_resources_param {
    uint32_t  max_virtual_routers_num;
    uint32_t  max_vlan_router_interfaces; /**< \deprecated This field is deprecated and will be removed in the future */
    uint32_t  max_port_router_interfaces; /**< \deprecated This field is deprecated and will be removed in the future */
    uint32_t  max_router_interfaces;
    uint32_t  min_ipv4_neighbor_entries;
    uint32_t  min_ipv6_neighbor_entries;
    uint32_t  min_ipv4_uc_route_entries;
    uint32_t  min_ipv6_uc_route_entries;
    uint32_t  min_ipv4_mc_route_entries;
    uint32_t  min_ipv6_mc_route_entries;
    uint32_t  max_ipv4_neighbor_entries;
    uint32_t  max_ipv6_neighbor_entries;
    uint32_t  max_ipv4_uc_route_entries;
    uint32_t  max_ipv6_uc_route_entries;
    uint32_t  max_ipv4_mc_route_entries;
    uint32_t  max_ipv6_mc_route_entries;
    boolean_t ipinip_ipv6_loopback_rif_enable;
    uint32_t  max_ipinip_ipv6_loopback_rifs;
} sx_router_resources_param_t;

/**
 * sx_router_initial_activity_e defines the initial activity bit for a new route
 */
typedef enum sx_router_initial_activity {
    SX_ROUTER_INITIAL_ACTIVITY_SET = 0, /**< Route is created with initial activity set (1) */
    SX_ROUTER_INITIAL_ACTIVITY_CLEARED = 1, /**< Route is created with initial activity cleared (0) */
} sx_router_initial_activity_e;

/**
 * sx_router_general_param is used to store the routers general
 * configuration parameters.
 */
typedef struct sx_router_general_param {
    sx_router_enable_state_t     ipv4_enable;
    sx_router_enable_state_t     ipv6_enable;
    sx_router_enable_state_t     ipv4_mc_enable;
    sx_router_enable_state_t     ipv6_mc_enable;
    boolean_t                    rpf_enable;
    sx_router_initial_activity_e mc_initial_activity;
    boolean_t                    disable_l3_nh_list;
} sx_router_general_param_t;

/**
 * sx_router_attributes_t structure is used to store router attributes.
 */
typedef struct sx_router_attributes {
    sx_router_enable_state_t ipv4_enable;
    sx_router_enable_state_t ipv6_enable;
    sx_router_enable_state_t ipv4_mc_enable;
    sx_router_enable_state_t ipv6_mc_enable;
    sx_router_action_t       uc_default_rule_action; /**< Only TRAP and DROP are supported */
    sx_router_action_t       mc_default_rule_action; /**< Only TRAP and DROP are supported */
    sx_flow_counter_id_t     uc_default_rule_counter;
} sx_router_attributes_t;

/**
 * sx_router_params_t structure is used to store initialization parameters of
 * Router Library.
 */
typedef struct sx_router_params {
    uint32_t                     ipv4_uc_prefix_num;
    uint32_t                     ipv4_mc_prefix_num;
    uint32_t                     ipv6_uc_prefix_num;
    uint32_t                     ipv6_mc_prefix_num;
    uint32_t                     max_vlan_router_interfaces_num;
    uint32_t                     max_port_router_interfaces_num;
    uint32_t                     max_pkey_router_interfaces_num;
    uint32_t                     max_router_interfaces_num;
    sx_router_ecmp_hash_params_t ecmp_hash_params;
    uint32_t                     virtual_routers_num;
} sx_router_params_t;

/**
 * Multicast Router definitions .
 */

#define FOREACH_ROUTE_TTL_CMD(F)                       \
    F(SX_ROUTE_TTL_CMD_INVALID, "N/A")                 \
    F(SX_ROUTE_TTL_CMD_DEC = 1, "Dec")                 \
    F(SX_ROUTE_TTL_CMD_SET, "Set")                     \
    F(SX_ROUTE_TTL_CMD_MIN = SX_ROUTE_TTL_CMD_DEC, "") \
    F(SX_ROUTE_TTL_CMD_MAX = SX_ROUTE_TTL_CMD_SET, "")

typedef enum {
    FOREACH_ROUTE_TTL_CMD(SX_GENERATE_ENUM)
} sx_mc_router_ttl_cmd_t;

#define SX_ROUTER_TTL_CMD_CHECK_RANGE(TTL_CMD) \
    (SX_CHECK_RANGE(SX_ROUTE_TTL_CMD_MIN, (TTL_CMD), SX_ROUTE_TTL_CMD_MAX))


/**
 * sx_mc_route_key_t is used to store a MC routes key.
 */
typedef struct sx_mc_route_key {
    sx_ip_prefix_t        source_addr;
    sx_ip_prefix_t        mc_group_addr;
    sx_router_interface_t ingress_rif;
} sx_mc_route_key_t;

typedef struct sx_mc_route_activity_notify_entry {
    sx_router_id_t    vrid;
    sx_mc_route_key_t key;
} sx_mc_route_activity_notify_entry_t;

typedef struct sx_router_mc_route_activity_notification {
    uint32_t                            entry_cnt;
    sx_mc_route_activity_notify_entry_t notify_entry[SX_ROUTER_ACTIVITY_NOTIFY_CNT_MAX];
} sx_router_mc_route_activity_notification_t;

#define FOREACH_ROUTER_VINTERFACE_TYPE(F)                                \
    F(SX_ROUTER_VINTERFACE_TYPE_RIF = 0, "RIF")                          \
    F(SX_ROUTER_VINTERFACE_TYPE_IP_IN_IP = 1, "IP in IP")                \
    F(SX_ROUTER_VINTERFACE_TYPE_MPLS = 2, "MPLS")                        \
    F(SX_ROUTER_VINTERFACE_TYPE_VXLAN = 3, "VXLAN")                      \
    F(SX_ROUTER_VINTERFACE_TYPE_MIN = SX_ROUTER_VINTERFACE_TYPE_RIF, "") \
    F(SX_ROUTER_VINTERFACE_TYPE_MAX = SX_ROUTER_VINTERFACE_TYPE_VXLAN, "")

typedef enum sx_router_vinterface_type {
    FOREACH_ROUTER_VINTERFACE_TYPE(SX_GENERATE_ENUM)
} sx_router_vinterface_type_t;

#define SX_ROUTER_VINTERFACE_TYPE_CHECK_RANGE(ROUTER_VIF_TYPE) \
    SX_CHECK_MAX(ROUTER_VIF_TYPE, SX_ROUTER_VINTERFACE_TYPE_MAX)

typedef struct sx_router_vif_data_ip_in_ip {
    /** Not implemented yet */
} sx_router_vif_data_ip_in_ip_t;

typedef struct sx_router_vif_data_mpls {
    /** Not implemented yet */
} sx_router_vif_data_mpls_t;

typedef struct sx_router_vif_data_vxlan {
    sx_tunnel_id_t tunnel_id;
} sx_router_vif_data_vxlan_t;

typedef struct sx_router_vinterface {
    sx_router_vinterface_type_t type;
    union {
        sx_router_interface_t         rif;
        sx_router_vif_data_ip_in_ip_t ip_in_ip;
        sx_router_vif_data_mpls_t     mpls;
        sx_router_vif_data_vxlan_t    vxlan;
    } vif;
} sx_router_vinterface_t;

/**
 * sx_mc_route_data_t holds a MC routes data.
 */
typedef struct sx_mc_route_data {
    sx_router_action_t    action;
    sx_router_interface_t ingress_rif;  /**< Applicable for GET commands only. */
    sx_router_interface_t egress_rif_list_p[RM_API_ROUTER_RIFS_MAX];
    uint32_t              egress_rif_cnt;
    sx_mc_container_id_t  egress_container_id;
    sx_trap_attributes_t  trap_attr;  /**< valid in case route action is TRAP */
} sx_mc_route_data_t;

#define FOREACH_ROUTER_PRIO_TYPE(F)               \
    F(SX_PRIO_TYPE_INVALID = 0, "N/A")            \
    F(SX_PRIO_TYPE_MANUAL = 1, "MANUAL")          \
    F(SX_PRIO_TYPE_LPM, "LPM")                    \
    F(SX_PRIO_TYPE_MIN = SX_PRIO_TYPE_MANUAL, "") \
    F(SX_PRIO_TYPE_MAX = SX_PRIO_TYPE_LPM, "")

typedef enum {
    FOREACH_ROUTER_PRIO_TYPE(SX_GENERATE_ENUM)
} sx_router_prio_type_t;

#define SX_PRIO_TYPE_CHECK_RANGE(PRIO_TYPE) \
    (SX_CHECK_RANGE(SX_PRIO_TYPE_MIN, (PRIO_TYPE), SX_PRIO_TYPE_MAX))

typedef struct sx_router_prio {
    sx_router_prio_type_t type;
    uint8_t               manual_prio;  /* priority for MANUAL prio : 1 - 32  */
} sx_router_prio_t;

typedef uint32_t sx_rpf_group_id_t;
typedef uint32_t sx_hw_rpf_group_id_t;
#define SX_RPF_GROUP_ID_INVALID ((sx_rpf_group_id_t)0xFFFF)


/**
 * sx_mc_route_attributes_t holds a MC routes attribute
 */
typedef struct sx_mc_route_attributes {
    sx_router_rpf_action_t rpf_action;
    uint8_t                assert_en; /**< \deprecated This field is deprecated and will be removed in the future */
    sx_mc_router_ttl_cmd_t ttl_cmd;
    uint8_t                ttl_val;
    sx_router_prio_t       prio;
    sx_rpf_group_id_t      rpf_group_id; /**< Valid only for *_LIST RPF actions */
} sx_mc_route_attributes_t;

/**
 * sx_mc_route_get_entry_t holds the returned routes information
 */
typedef struct sx_mc_route_get_entry {
    sx_mc_route_key_t        mc_route_key;
    sx_mc_route_attributes_t mc_route_attr;
    sx_mc_route_data_t       mc_route_data;
} sx_mc_route_get_entry_t;

typedef enum sx_router_mc_act_clr_mode {
    SX_ACT_MODE_DONT_CLR = SXD_ROUTER_TCAM_READ,
    SX_ACT_MODE_CLR_ON_RD = SXD_ROUTER_ACTIVITY_CLEAR_ON_READ,
} sx_router_mc_act_clr_mode_t;

/**
 * router_t structure is used to store router information.
 */
typedef struct router {
    boolean_t              used;
    sx_router_attributes_t attr;
} router_t;

/**
 *  ROUTER counter init params
 */

typedef struct sx_router_profile_params {
    uint32_t min_router_counters;
    uint32_t is_vpi;
} sx_router_profile_params_t;

typedef struct sx_uc_route_get_entry {
    sx_ip_prefix_t     network_addr;
    sx_uc_route_data_t route_data;
} sx_uc_route_get_entry_t;

#define MAX_GET_ALL_ENTRIES 20

/**
 * sx_fdb_key_filter_field_valid enumerated type is set key filter field valid or no valid
 *
 */
typedef enum sx_key_filter_field_valid {
    SX_KEY_FILTER_FIELD_NOT_VALID = 0,
    SX_KEY_FILTER_FIELD_VALID = 1,
    SX_KEY_FILTER_FIELD_MAX = SX_KEY_FILTER_FIELD_VALID
} sx_key_filter_field_valid_t;

#define SX_KEY_FILTER_VALID_CHECK_RANGE(VALID) SX_CHECK_MAX(VALID, SX_KEY_FILTER_FIELD_MAX)

/* Neigh activity notify filter*/
typedef struct sx_router_neigh_activity_filter {
    sx_key_filter_field_valid_t filter_by_rif;
    sx_router_interface_t       rif;
    sx_key_filter_field_valid_t filter_by_type;
    sx_ip_version_t             type;
} sx_router_neigh_activity_filter_t;

typedef struct sx_uc_route_key_filter {
    sx_key_filter_field_valid_t filter_by_nexthop;  /**< Filter by UC Route next hop IP */
    sx_ip_addr_t                next_hop;           /**< Next hop IP to match */
    sx_key_filter_field_valid_t filter_by_prefix;   /**< Filter by prefix */
    sx_ip_prefix_t              prefix;             /**< Prefix to match */
    sx_key_filter_field_valid_t filter_by_type;     /**< Filter by UC Route type */
    sx_uc_route_type_e          type;               /**< UC Route type to match */
} sx_uc_route_key_filter_t;

/**
 * Maximum number of MC routes that can be returned in a call to
 * sx_api_router_mc_route_get.
 */
#define SX_API_MC_ROUTE_GET_MAX_COUNT 128

typedef struct sx_mc_route_key_filter {
    sx_key_filter_field_valid_t filter_by_source_addr;
    sx_ip_prefix_t              source_addr;
    sx_key_filter_field_valid_t filter_by_mc_group_addr;
    sx_ip_prefix_t              mc_group_addr;
    sx_key_filter_field_valid_t filter_by_ingress_rif;
    /** filter_by_ingress_rif_including_rpf_groups should be valid if MC routes
     * with RPF groups containing the given iRIF should be returned as well. */
    sx_key_filter_field_valid_t filter_by_ingress_rif_including_rpf_groups;
    sx_router_interface_t       ingress_rif;
} sx_mc_route_key_filter_t;

typedef struct sx_mc_route_activity_notify_filter {
    sx_key_filter_field_valid_t filter_by_vrid;
    sx_router_id_t              vrid;
    sx_key_filter_field_valid_t filter_by_type;
    sx_ip_version_t             type;
} sx_mc_route_activity_notify_filter_t;

/*
 *       neigh get all
 */
typedef struct sx_neigh_get_entry {
    sx_ip_addr_t    ip_addr;
    sx_neigh_data_t neigh_data;
} sx_neigh_get_entry_t;

typedef struct sx_neigh_key {
    sx_ip_addr_t ip_addr;
} sx_neigh_key_t;

typedef struct sx_neigh_filter {
    /**< If key field is valid then filter by nexthop*/
    sx_key_filter_field_valid_t filter_by_rif;
    sx_router_interface_t       rif;
} sx_neigh_filter_t;

/*
 * Filter for sx_api_router_iter_get
 */
typedef struct sx_vrid_filter {
    /* Reserved for future expansion*/
    sx_key_filter_field_valid_t filter_reserved;
    uint32_t                    reserved;
} sx_vrid_filter_t;

/*define route prio min/max*/
#define SX_ROUTE_PRIO_MIN 1
#define SX_ROUTE_PRIO_MAX 32


/**
 * sx_ecmp_type_e controls load balancing of an ECMP container.
 * Static hashing will rewrite the whole ECMP container when load balancing.
 * Resilient hashing will keep active flows static when adding and removing next hops.
 * Consistent hashing will keep active flows static when removing next hops.
 */

#define FOREACH_ECMP_TYPE(F)                        \
    F(SX_ECMP_TYPE_STATIC_E = 0, "Static")          \
    F(SX_ECMP_TYPE_RESILIENT_E = 1, "Resilient")    \
    F(SX_ECMP_TYPE_CONSISTENT_E = 2, "Consistent")  \
    F(SX_ECMP_TYPE_DYNAMIC_E = 3, "Dynamic")        \
    F(SX_ECMP_TYPE_MIN = SX_ECMP_TYPE_STATIC_E, "") \
    F(SX_ECMP_TYPE_MAX = SX_ECMP_TYPE_DYNAMIC_E, "")

typedef enum sx_ecmp_type {
    FOREACH_ECMP_TYPE(SX_GENERATE_ENUM)
} sx_ecmp_type_e;

/** default type of ECMP is STATIC */
#define SX_ECMP_TYPE_DEFAULT SX_ECMP_TYPE_STATIC_E

#define SX_ECMP_TYPE_CHECK_RANGE(TYPE) \
    SX_CHECK_MAX(TYPE, SX_ECMP_TYPE_MAX)

/** default type of ECMP container is IP */
#define SX_ECMP_CONTAINER_TYPE_DEFAULT SX_ECMP_CONTAINER_TYPE_IP

#define FOREACH_ECMP_CONTAINER_TYPE(F)                                                                                                                                                                          \
    F(SX_ECMP_CONTAINER_TYPE_IP = 0 /** all next hop are IP next hops */, "IP")                                                                                                                                 \
    F(SX_ECMP_CONTAINER_TYPE_MPLS = 1 /** all next hop are MPLS next hops */, "MPLS")                                                                                                                           \
    F(SX_ECMP_CONTAINER_TYPE_NVE_FLOOD = 2 /** all next hop are tunnel_encap next hops */, "NVE Flood")                                                                                                         \
    F(SX_ECMP_CONTAINER_TYPE_NVE_MC = 3 /** all next hop are tunnel_encap next hops */, "NVE MC")                                                                                                               \
    F(                                                                                                                                                                                                          \
        SX_ECMP_CONTAINER_TYPE_NVE = SX_ECMP_CONTAINER_TYPE_NVE_FLOOD /**< /deprecated This value is deprecated and will be removed in the future. Please use SX_ECMP_CONTAINER_TYPE_NVE_FLOOD in its place */, \
        "")                                                                                                                                                                                                     \
    F(SX_ECMP_CONTAINER_TYPE_MIN = SX_ECMP_CONTAINER_TYPE_IP, "")                                                                                                                                               \
    F(SX_ECMP_CONTAINER_TYPE_MAX = SX_ECMP_CONTAINER_TYPE_NVE_MC, "")

typedef enum sx_ecmp_container_type_e_ {
    FOREACH_ECMP_CONTAINER_TYPE(SX_GENERATE_ENUM)
} sx_ecmp_container_type_e;

#define SX_ECMP_CONTAINER_TYPE_CHECK_RANGE(TYPE) \
    SX_CHECK_MAX(TYPE, SX_ECMP_CONTAINER_TYPE_MAX)


typedef struct sx_ecmp_attributes {
    sx_ecmp_type_e           ecmp_type;
    sx_ecmp_container_type_e container_type;  /* type of next hops (ADJs) in the container */
    uint32_t                 active_flow_timer; /**< time to keep the flows active in resilient and
                                                 * consistent load balancing. units of milliseconds */
    uint32_t group_size;            /**< hash group size. Supported sizes: 64, 512, 1024, 2048, 4096 */
    uint32_t max_unbalanced_time;           /**< time to force load balancing. units of milliseconds.
                                             * Use SX_ECMP_INFINITE_UNBALANCED_TIME for Infinite duration*/
} sx_ecmp_attributes_t;

typedef struct sx_router_interface_filter {
    sx_key_filter_field_valid_t filter_by_vrid; /**< If field is valid then filter by vrid*/
    sx_router_id_t              vrid;
} sx_rif_filter_t;

typedef struct sx_router_ecmp_filter {
    /* Reserved for future expansion*/
} sx_ecmp_filter_t;

#endif /* __SX_ROUTER_H__ */
