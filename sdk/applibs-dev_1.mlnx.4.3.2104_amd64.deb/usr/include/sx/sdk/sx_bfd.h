/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_BFD_H__
#define __SX_BFD_H__

/************************************************
 *  Type definitions
 ***********************************************/

typedef uint32_t sx_bfd_session_id_t;

typedef uint64_t sx_bfd_session_opaque_data_t;

/**
 * Placeholder for Filter to be used with the iterator
 */
typedef uint32_t sx_bfd_session_id_filter_t;

/******************************
 *   DEFINITIONS
 *******************************/

/**
 * sx_bfd_session_type_t enumerated type is used
 * to select BFD session type.
 */

#define BFD_NETNS_NAME_LENGTH   512

typedef enum sx_bfd_session_type {
    SX_BFD_ASYNC_ACTIVE_RX,
    SX_BFD_ASYNC_ACTIVE_TX,
} sx_bfd_session_type_t;

static __attribute__((__used__)) const char* sx_bfd_session_type_str[] = {
    "ASYNC_ACTIVE_RX",
    "ASYNC_ACTIVE_TX",
};
#define SX_BFD_SESSION_TYPE_STR_LEN (sizeof(sx_bfd_session_type_str) / sizeof(char*))
#define SX_BFD_SESSION_TYPE_STR(type)                      \
    (SX_CHECK_MAX(type, SX_BFD_SESSION_TYPE_STR_LEN - 1) ? \
            sx_bfd_session_type_str[type] : "UNKNOWN")


/**
 * sx_bfd_encap_type_t enumerated type is used
 * to select BFD encapsulation type.
 */
typedef enum sx_bfd_encap_type {
    SX_BFD_UDP_OVER_IP,
} sx_bfd_encap_type_t;

/**
 * sx_bfd_peer_type_t enumerated type is used
 * to select BFD peer type.
 */
typedef enum sx_bfd_peer_type {
    SX_BFD_PEER_IP_AND_VRF,
    SX_BFD_PEER_IP_AND_RIF,
} sx_bfd_peer_type_t;

typedef struct sx_bfd_packet {
        uint8_t * packet_buffer;
        uint32_t buffer_length;
} sx_bfd_packet_t;

typedef struct sx_bfd_encap_udp_over_ip {
        uint16_t src_udp_port;
        uint16_t dest_udp_port;
        sx_ip_addr_t src_ip_addr;
        sx_ip_addr_t dest_ip_addr;
        uint8_t ttl;
        uint8_t dscp;
} sx_bfd_encap_udp_over_ip_t;

typedef struct sx_bfd_packet_encap {
        sx_bfd_encap_type_t encap_type;
        union {
                sx_bfd_encap_udp_over_ip_t udp_over_ip;
        } encap_data;
} sx_bfd_packet_encap_t;

typedef struct sx_bfd_peer_ip_and_vrf {
        sx_ip_addr_t ip_addr;
        int vrf_id;
        char netns[BFD_NETNS_NAME_LENGTH];
        char default_netns[BFD_NETNS_NAME_LENGTH];
} sx_bfd_peer_ip_and_vrf_t;

typedef struct sx_bfd_peer_ip_and_rif {
        sx_ip_addr_t ip_addr;
        uint32_t rif_id;
} sx_bfd_peer_ip_and_rif_t;

typedef struct sx_bfd_peer {
        sx_bfd_peer_type_t peer_type;
        union {
                sx_bfd_peer_ip_and_vrf_t ip_and_vrf;
                sx_bfd_peer_ip_and_rif_t ip_and_rif;
        } peer_data;
} sx_bfd_peer_t;

typedef struct sx_bfd_session_tx_data {
        sx_bfd_packet_encap_t packet_encap;
        uint32_t interval;
        uint32_t traffic_class;
} sx_bfd_session_tx_data_t;

typedef struct sx_bfd_session_rx_data {
        sx_bfd_session_opaque_data_t opaque_data;
        uint32_t interval;
} sx_bfd_session_rx_data_t;

typedef struct sx_bfd_session {
        sx_bfd_session_type_t type;
        union {
                sx_bfd_session_tx_data_t tx_data;
                sx_bfd_session_rx_data_t rx_data;
        } data;
} sx_bfd_session_t;

/** Defines BFD session parameters */
typedef struct sx_bfd_session_params {
        sx_bfd_session_t      session_data;
        sx_bfd_packet_t       packet;
        sx_bfd_peer_t         peer;
        unsigned long         bfd_pid;
} sx_bfd_session_params_t;

/** Defines BFD init parameters */
typedef struct sx_bfd_init_params {
    uint8_t placeholder[0];     /*place holder*/
} sx_bfd_init_params_t;

typedef struct sx_bfd_session_stats
{
        /**< Number of CC BFD control packets transmitted for this session.  */
        uint64_t num_control;

        /**< Number of CC BFD control packets transmitted for this session that were dropped due to
         * TTL failure or packet mismatch.  for RX Only */
        uint64_t num_dropped_control;

        /**< Time of the last transmitted BFD CC packet, relative to the
         *   time the session was created, in milliseconds.  */
        uint64_t last_time;

        /* todo need to check if it should be usec */
        /**< Interval between (successfully) received BFD CC packets:
         *   min, max and average, in milliseconds, since the last RX session
         *   update. If no packets have been received since the last RX
         *   session update then rx_interval_min and rx_interval_average will
         *   return 0 and rx_interval_max will return 0xFFFFFFFF.   */
        uint64_t interval_min;
        uint64_t interval_max;
        uint64_t interval_average;

        /**< This flag is true if the local system is actively receiving BFD
         *   packets from the remote system, and FALSE if the local system has
         *   not received BFD packets recently (within the detection
         *    interval).   */
        uint8_t remote_heard;

} sx_bfd_session_stats_t;

typedef struct sx_bfd_offload_stats {
    sx_access_cmd_t             cmd;
    sx_bfd_session_type_t       session_type;
    sx_bfd_session_id_t         session_id;
    sx_bfd_session_stats_t      bfd_session_stats;
} sx_bfd_offload_stats_t;

typedef struct sx_bfd_session_counters {
        uint64_t session_counter;
} sx_bfd_session_counters_t;

#endif /* __SX_BFD_H__ */
