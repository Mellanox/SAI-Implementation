/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_TELE_H__
#define __SX_TELE_H__

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define SX_TELE_HIST_MAX_BINS 10 /* should be the max between RM tele_histogram_queue_depth_max_bins for all chips */

#define SX_TELE_HISTOGRAM_MAX_GET_ENTRIES 20

#define FOREACH_TELE_HISTOGRAM_TYPE(F)                                         \
    F(SX_TELE_HISTOGRAM_TYPE_INVALID = 0, "N/A")                               \
    F(SX_TELE_HISTOGRAM_TYPE_QUEUE_DEPTH_E = 1, "Queue Depth")                 \
    F(SX_TELE_HISTOGRAM_TYPE_MIN_E = SX_TELE_HISTOGRAM_TYPE_QUEUE_DEPTH_E, "") \
    F(SX_TELE_HISTOGRAM_TYPE_MAX_E = SX_TELE_HISTOGRAM_TYPE_QUEUE_DEPTH_E, "")

typedef enum sx_tele_histogram_type {
    FOREACH_TELE_HISTOGRAM_TYPE(SX_GENERATE_ENUM)
} sx_tele_histogram_type_e;

#define SX_TELE_HISTOGRAM_TYPE_NUM (SX_TELE_HISTOGRAM_TYPE_MAX_E + 1)

#define SX_TELE_HISTOGRAM_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_TELE_HISTOGRAM_TYPE_MIN_E, (TYPE), SX_TELE_HISTOGRAM_TYPE_MAX_E))


typedef struct sx_tele_histogram_queue_depth_key {
    sx_port_log_id_t       network_port; /**< Network network port. only network ports are supported */
    sx_cos_traffic_class_t traffic_class; /**< Traffic class */
} sx_tele_histogram_queue_depth_key_t;

/** Defines telemetry histogram key */
typedef struct sx_tele_histogram_key {
    sx_tele_histogram_type_e type;
    union {
        sx_tele_histogram_queue_depth_key_t queue_depth;
    } key;
} sx_tele_histogram_key_t;

/** Defines telemetry histogram attributes data */
typedef struct sx_tele_histogram_queue_depth_attributes_data {
    uint32_t sample_time_resolution; /**< Sample time
                                      *  for Spectrum, this value is a time resolution. actual sample_time=(2^sample_time_resolution)*128nSec
                                      *  Max value is defined on the resource manager under tele_histogram_sample_time_resolution_max*/
    uint32_t min_boundary; /**< min boundary, units of cells. Each cell contains shared_buff_buffer_unit_size (defined on resource manager) bytes.*/
    uint32_t bin_size_resolution; /**< Counted in cells.
                                   * The total number of bins is equal to tele_histogram_queue_depth_bins.
                                   * Bin 0 for all queue depth < min_boundary.
                                   * Bins 1..tele_histogram_queue_depth_bins-2 with equal size, distributed evenly between bin 0 and the last bin.
                                   * Bin tele_histogram_queue_depth_bins-1 for all queue depth >= min_boundary + (2^bin_size_resolution).
                                   * min value is defined on the resource manager under tele_histogram_bin_size_resolution_min,
                                   * max value is defined on the resource manager under tele_histogram_bin_size_resolution_max.
                                   *
                                   * for example, if tele_histogram_queue_depth_bins=10 bins distribution will be:
                                   * <----0---|   1   |   2   |   3   |   4   |   5   |   6   |   7   |   8   |---9---->
                                   *         min                                                             max
                                   * where min=min_bondary, max=min_boundary+(2^bin_size_resolution) */
} sx_tele_histogram_queue_depth_attributes_data_t;

/** Defines telemetry histogram attributes data */
typedef struct sx_tele_histogram_attributes_data {
    sx_tele_histogram_type_e type;
    union {
        sx_tele_histogram_queue_depth_attributes_data_t queue_depth;
    } data;
} sx_tele_histogram_attributes_data_t;

/** Defines telemetry histogram attributes data */
typedef struct sx_tele_histogram_data {
    uint64_t bins[SX_TELE_HIST_MAX_BINS]; /**< bins */
    uint32_t bins_cnt; /**< bins count */
} sx_tele_histogram_data_t;

/** Defines the validity of histogram filter */
typedef enum sx_tele_histogram_key_filter_field_valid {
    SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_NOT_VALID_E = 0,
    SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E = 1,
    SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_MAX_E = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E
} sx_tele_histogram_key_filter_field_valid_e;

#define SX_TELE_HISTOGRAM_KEY_FILTER_VALID_CHECK_RANGE(VALID) \
    SX_CHECK_MAX(VALID,                                       \
                 SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_MAX)

typedef struct sx_tele_histogram_filter {
    sx_tele_histogram_key_filter_field_valid_e filter_port_valid;
    sx_port_log_id_t                           port_filter;
    sx_tele_histogram_key_filter_field_valid_e filter_tc_valid;
    sx_cos_traffic_class_t                     tc_filter;
} sx_tele_histogram_filter_t;

/** Defines telemetry init parameters */
typedef struct sx_tele_init_params {
    char placeholder[0];     /*place holder*/
} sx_tele_init_params_t;

/** Defines the type of the threshold entity, for event classification */
typedef enum sx_tele_threshold_entity {
    SX_TELE_THRESHOLD_ENTITY_PORT_TC_E = 0,
    SX_TELE_THRESHOLD_ENTITY_PORT_E = 1
} sx_tele_threshold_entity_e;

#define FOREACH_TELE_THRESHOLD_TYPE(F)                                     \
    F(SX_TELE_THRESHOLD_TYPE_INVALID_E = 0, "N/A")                         \
    F(SX_TELE_THRESHOLD_TYPE_PORT_TC_E = 1, "TC")                          \
    F(SX_TELE_THRESHOLD_TYPE_MAX_E = SX_TELE_THRESHOLD_TYPE_PORT_TC_E, "") \
    F(SX_TELE_THRESHOLD_TYPE_PORT_E = 2, "Port")      /* used for event classification only, not for configuration */

/** Defines the type of the threshold */
typedef enum sx_port_threshold_type {
    FOREACH_TELE_THRESHOLD_TYPE(SX_GENERATE_ENUM)
} sx_port_threshold_type_e;

/** defines a type for telemetry thresholds. Value stored in cells */
typedef uint32_t sx_tele_threshold_t;

typedef struct sx_tele_threshold_port_tc_key {
    sx_port_log_id_t       log_port;
    sx_cos_traffic_class_t tc;
} sx_tele_threshold_port_tc_key_t;

typedef struct sx_tele_threshold_port_key {
    sx_port_log_id_t log_port;
} sx_tele_threshold_port_key_t;

/** Defines the validity of threshold port filter */
typedef enum sx_tele_threshold_key_port_filter_valid {
    SX_TELE_THRESHOLD_KEY_PORT_FILTER_NOT_VALID_E = 0,
    SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E = 1,
    SX_TELE_THRESHOLD_KEY_PORT_FILTER_FIELD_MAX_E = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E
} sx_tele_threshold_key_port_filter_valid_e;

/** Defines the validity of threshold tc filter */
typedef enum sx_tele_threshold_key_tc_filter_valid {
    SX_TELE_THRESHOLD_KEY_TC_FILTER_NOT_VALID_E = 0,
    SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E = 1,
    SX_TELE_THRESHOLD_KEY_TC_FILTER_MAX_E = SX_TELE_THRESHOLD_KEY_TC_FILTER_VALID_E
} sx_tele_threshold_key_tc_filter_valid_e;

/** defines threshold attributes key */
typedef struct sx_tele_threshold_key {
    sx_port_threshold_type_e key_type;
    union {
        sx_tele_threshold_port_tc_key_t port_tc;
        sx_tele_threshold_port_key_t    port;
    } key;
} sx_tele_threshold_key_t;

/** defines threshold attributes data */
typedef struct sx_tele_threshold_data {
    sx_port_threshold_type_e data_type;
    union {
        sx_tele_threshold_t port_tc_threshold;
    } data;
} sx_tele_threshold_data_t;

/** defines the attributed for the threshold filter */
typedef struct sx_tele_threshold_filter {
    sx_tele_threshold_key_port_filter_valid_e port_filter_valid;
    sx_port_log_id_t                          port_filter;
    sx_tele_threshold_key_tc_filter_valid_e   tc_filter_valid;
    sx_cos_traffic_class_t                    tc_filter;
} sx_tele_threshold_filter_t;

/** sx_tele_threshold_crossed_data_direction_e defines threshold crossing data direction */
typedef enum sx_tele_threshold_crossed_data_direction {
    SX_TELE_BELOW_THRESHOLD_E = 0,
    SX_TELE_ABOVE_THRESHOLD_E = 1
} sx_tele_threshold_crossed_data_direction_e;

typedef enum sx_tele_threshold_congestion_status {
    SX_TELE_THRESHOLD_MAYBE_CONGESTED_E = 0,
    SX_TELE_THRESHOLD_CONGESTED_E = 1,
    SX_TELE_THRESHOLD_NOT_CONGESTED_E = 2
} sx_tele_threshold_congestion_status_e;

typedef enum sx_tele_threshold_congestion_fp {
    SX_TELE_THRESHOLD_CONGESTION_FP_DISABLED_E = 0,
    SX_TELE_THRESHOLD_CONGESTION_FP_ENABLED_E = 1
} sx_tele_threshold_congestion_fp_e;

/** sx_tele_threshold_crossed_data_t defines threshold crossing data */
typedef struct sx_tele_threshold_crossed_data {
    sx_port_threshold_type_e type;
    union {
        sx_tele_threshold_crossed_data_direction_e port_tc;
        sx_tele_threshold_congestion_status_e      port;
    } data;
} sx_tele_threshold_crossed_data_t;

typedef struct sx_tele_threshold_crossed_data_keys {
    sx_tele_threshold_key_t          key;
    sx_tele_threshold_crossed_data_t crossed_data;
    uint32_t                         key_index;
} sx_tele_threshold_crossed_data_keys_t;

#define SX_TELE_THRESHOLD_KEY_TYPE_NUM (SX_PORT_THRESHOLD_KEY_TYPE_MAX_E + 1)

#define SX_TELE_THRESHOLD_KEY_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_PORT_THRESHOLD_KEY_TYPE_MIN_E, (TYPE), SX_PORT_THRESHOLD_KEY_TYPE_MAX_E))

#endif /* __SX_TELE_H__ */
