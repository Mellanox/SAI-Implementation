/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __RESOURCE_MANAGER_H__
#define __RESOURCE_MANAGER_H__

#include <complib/cl_types.h>
#include <sx/sdk/sx_dev.h>
#include <sx/sdk/sx_status.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define UNTAGGED_PG         (8)
#define RM_API_PHY_PORT_MAX (128)
/* Local port indexes:
 * - (0): CPU
 * - (1 : RM_API_PHY_PORT_MAX): regular ports
 * - (RM_API_PHY_PORT_MAX + 1): IB router
 * - (RM_API_PHY_PORT_MAX + 2): IP or LSR Router
 * - (RM_API_PHY_PORT_MAX + 3): FCF
 * - (RM_API_PHY_PORT_MAX + 4): Aggregation Node
 */
#define RM_API_LOCAL_PORT_MAX (RM_API_PHY_PORT_MAX + 4)
/*ceil[spectrum,switch_a2,switch_a1,pelican]*/
/* should match SPECTRUM_ROUTER_RIFS_MAX */
#define RM_API_ROUTER_RIF_KEY_NULL               (0xFFFF) /* Invalid RIF value to depict that RIF key was not specified */
#define RM_API_ROUTER_RIFS_MAX                   (4000)
#define RM_API_ROUTER_VIFS_MAX                   (1000)
#define RM_API_ROUTER_NEXT_HOP_MAX               (64)
#define RM_API_COS_TRAFFIC_CLASS_NUM             (8)
#define RM_API_COS_BUFFERS_NUM                   (8)
#define RM_API_COS_PORT_PRIO_MAX                 (14)
#define RM_API_ACL_PORT_RANGES_MAX               (16) /* Used for static array of ranges both legacy and new APIs */
#define RM_API_ACL_PORT_LIST_MAX                 (128)
#define RM_API_ACL_RULES_BLOCK_MAX               (20) /* Legacy definition */
#define RM_API_ACL_FLEX_RULES_BLOCK_MAX          (180)
#define RM_API_ACL_MAX_FIELDS_IN_KEY             (40)
#define RM_API_ACL_MAX_KEYS_IN_RULE              (30)
#define RM_API_ACL_MAX_ACTIONS_IN_RULE           (20)
#define RM_API_ACL_MAX_BYTES_IN_CUSTOM_BYTES_SET (4)
#define RM_API_HOST_IFC_USER_DEFINE_KEY_MAX      (2)
#define RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX   (4)
#define RM_API_HOST_IFC_NUM_MAX                  (RM_API_PHY_PORT_MAX)
#define UNLIMITED_SDK_TABLE_SIZE                 0xFFFFFFFF
#define COS_PCP_MAX_NUM                          7
#define COS_DEI_MAX_NUM                          1
#define COS_EXP_MAX_NUM                          7
#define COS_ECN_MAX_NUM                          3
#define COS_DSCP_MAX_NUM                         63
#define COS_IEEE_PRIO_MAX_NUM                    7
#define RM_ROUTER_ECMP_CONTAINER_TOT_WEIGHT_MAX  4096
#define RM_NUM_OF_SWIDS                          (rm_resource_global.swid_id_max + 1)
#define RM_COMMON_CUSTOM_BYTES_ENUM_START        2000 /** Common definition of Custom bytes for ACL and ECMP Hash */
#define RM_SDK_IPV4_LPM_MIN                      1
#define RM_SDK_IPV4_LPM_MAX                      32
#define RM_SDK_IPV4_LPM_DEFAULT                  9
#define RM_SDK_IPV6_LPM_MIN                      1
#define RM_SDK_IPV6_LPM_MAX                      128
#define RM_SDK_IPV6_LPM_DEFAULT                  33
#define RM_SDK_IPV6_LPM_SINGLE_COST_MAX          64
#define RM_COS_SB_PG_PROFILE_SIZE                (9 + 1)  /* PGs 0-9 */
#define RM_COS_SB_TC_PROFILE_SIZE                (16 + 1) /* TCs 0-16 */
#define RM_COS_SB_HIGH_TC_PROFILE_SIZE           (8)      /* TCs 8-14 */
#define RM_COS_SB_SP_PROFILE_SIZE                (14 + 1) /* SPs 0-14 */

/************************************************
 *  Macros
 ***********************************************/
#define CL_FREE_N_NULL(x) { cl_free(x); x = NULL; } /* while (0) */

#define SDK_COMPILE_TIME_ASSERT(EXPRESSION) \
    switch (0) {                            \
    case 0:                                 \
    case (EXPRESSION):                      \
        ; }

#define RM_SWID_CHECK_RANGE(swid_id) ((SX_SWID_ID_STACKING == swid_id) || (swid_id <= rm_resource_global.swid_id_max))
#define RM_SWID_CHECK_MAX(swid_id)   (swid_id <= rm_resource_global.swid_id_max)

#define RM_PORT_CNT_CHECK_MAX(port_cnt) (port_cnt <= rm_resource_global.port_lcl_num_max)
#define RM_PORT_STORM_CONTROL_CHECK_MAX(storm_control_id) \
    (storm_control_id <=                                  \
     rm_resource_global.port_storm_control_id_max)
#define RM_PORT_STORM_CONTROL_CHECK_RANGE(storm_control_id) \
    (storm_control_id > 0 && storm_control_id <=            \
     rm_resource_global.port_storm_control_id_max)

#define RM_ROUTER_VRID_CHECK_MAX(vrid)     (vrid <= rm_resource_global.router_vrid_max)
#define RM_ROUTER_VRID_NUM_CHECK_MAX(vrid) (vrid <= rm_resource_global.router_vrid_max + 1)
#define RM_ROUTER_RIF_CHECK_MAX(rif)       (rif <= rm_resource_global.router_rifs_max)
#define RM_ROUTER_RIF_CHECK_DONT_CARE(rif) (rif == rm_resource_global.router_rifs_dontcare)
#define RM_ROUTER_UC_IPV4_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E].table_size_max)
#define RM_ROUTER_UC_IPV6_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E].table_size_max)
#define RM_ROUTER_MC_IPV4_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E].table_size_max)
#define RM_ROUTER_MC_IPV6_CHECK_MAX(route)        \
    ((route) <=                                   \
     rm_resource_global_default.rm_sdk_tables_db[ \
         RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E].table_size_max)
#define RM_ROUTER_IPV4_NEIGHS_CHECK_MAX(neighs) \
    ((neighs) <= rm_resource_global_default.router_neigh_max)
#define RM_ROUTER_IPV6_NEIGHS_CHECK_MAX(neighs) \
    ((neighs) <= rm_resource_global_default.router_neigh_max)

#define RM_ACL_RULES_BLOCK_MAX_CHECK_MAX(acl_rules_block) (acl_rules_block <= RM_API_ACL_RULES_BLOCK_MAX)
#define RM_ACL_PORT_CHECK_MAX(range_id)                   (range_id <= (rm_resource_global.acl_port_ranges_max - 1))

#define RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id) \
    (span_session_id <= rm_resource_global.span_session_id_max_internal)
#define RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id) \
    (span_session_id <= rm_resource_global.span_session_id_max_external)

#define RM_VLAN_ID_CHECK_RANGE(vid) ((vid <= rm_resource_global.vlan_id_max) && vid > 0)
#define RM_VLAN_ID_CHECK_MAX(vid)   (vid <= rm_resource_global.vlan_id_max)

#define RM_LAG_ID_CHECK_MAX(lid)   (lid <= rm_resource_global.lag_num_max)
#define RM_LAG_ID_CHECK_RANGE(lid) ((lid <= rm_resource_global.lag_num_max) && lid > 0)

#define SX_RESOURCE_CHECK_RANGE(RESOURCE)   \
    SX_CHECK_RANGE(RM_SDK_TABLE_TYPE_MIN_E, \
                   (int)RESOURCE,           \
                   RM_SDK_TABLE_TYPE_MAX_E)
#define SX_RESOURCE_SUB_TYPE_CHECK_RANGE(sub_type) \
    SX_CHECK_RANGE(SX_SDK_SUB_TYPE_MIN_E,          \
                   (int)sub_type,                  \
                   SX_SDK_SUB_TYPE_MAX_E)
#define SX_RESOURCE_MSG(RESOURCE)                                       \
    SX_RESOURCE_CHECK_RANGE(RESOURCE) ? sx_resource2str_arr[RESOURCE] : \
    "Unknown resource"

#define RM_ROUTER_ECMP_HASH_CHECK_RANGE(ecmp_hash) \
    (ecmp_hash <= rm_resource_global.router_ecmp_hash_max)

#define RM_ROUTER_COUNTER_ID_CHECK_MAX(cntr_id) \
    (cntr_id <= rm_resource_global.router_counters_id_max)

#define RM_SPAN_SESSION_ID_CHECK_RANGE(span_session_id) (span_session_id <= rm_resource_global.span_session_id_max)

#define RM_PORT_INGRESS_SHARED_BUFFER_POOL_ID_CHECK_RANGE(pool_id) \
    (pool_id < rm_resource_global.                                 \
     shared_buff_num_ingress_pools)
#define RM_PORT_INGRESS_SHARED_BUFFER_HARDWARE_POOL_ID_CHECK_RANGE(pool_id) \
    (pool_id < rm_resource_global.                                          \
     shared_buff_num_ingress_pools)
#define RM_PORT_INGRESS_SHARED_BUFFER_PG_ID_CHECK_RANGE(pg) \
    ((pg <= rm_resource_global.shared_buff_num_port_ingress_buff) && (pg != UNTAGGED_PG))
#define RM_PORT_EGRESS_SHARED_BUFFER_POOL_ID_CHECK_RANGE(pool_id) \
    ((pool_id >= rm_resource_global.                              \
      shared_buff_num_ingress_pools) &&                           \
     (pool_id < rm_resource_global.                               \
      shared_buff_total_num_pools))
#define RM_PORT_EGRESS_SHARED_BUFFER_HARDWARE_POOL_ID_CHECK_RANGE(pool_id) \
    ((pool_id < rm_resource_global.shared_buff_num_egress_pools) ||        \
     (pool_id == SX_COS_MC_PORT_HW_POOL_ID))


#define RM_PORT_EGRESS_SHARED_BUFFER_TC_ID_CHECK_RANGE(tc) \
    (tc < rm_resource_global.                              \
     shared_buff_num_port_egress_buff)
#define RM_MULTICAST_SHARED_BUFFER_ID_CHECK_RANGE(mc) \
    (mc < rm_resource_global.                         \
     shared_buff_mc_max_num_prio)

#define RM_IB_ROUTER_UC_LID_CHECK_RANGE(uc_lid)             \
    ((uc_lid <= rm_resource_global.ib_router_uc_lid_max) && \
     (uc_lid >= rm_resource_global.ib_router_uc_lid_min))
#define RM_IB_ROUTER_QPN_CHECK_MAX(qpn) (qpn <= rm_resource_global.ib_router_qpn_max)

#define RM_TRAP_GROUP_PRIORITY_CHECK_RANGE(__priority)                 \
    (((__priority) <= (rm_resource_global.trap_group_priority_max)) && \
     ((__priority) >= (rm_resource_global.trap_group_priority_min)))

/* Converts size in bytes into SB cells */
#define RM_COS_SB_CALC_BUFF_CELLS(size_in_bytes) \
    (size_in_bytes) / (rm_resource_global.shared_buff_buffer_unit_size)

#define RM_COS_SB_CALC_BUFF_CELLS_HEADROOM(size_in_jumbo_frames) \
    (size_in_jumbo_frames)                                       \
    * (rm_resource_global.port_mtu_max)                          \
    / (rm_resource_global.shared_buff_buffer_unit_size)

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * rm_sdk_table_type_e enumerated type is used to list all
 * supported resource types in the RM module.
 *
 * Please note that for the table duplication only some of the
 * listed below types are allowed to use - see the relevant
 * comment opposite each of them.
 */
typedef enum {
    RM_SDK_TABLE_TYPE_UC_MAC_E,            /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_MC_MAC_E,            /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E,       /**< Legal to use for table duplication. Supports sub-types sx_sdk_resource_sub_type_t. */
    RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E,       /**< Legal to use for table duplication. Supports sub-types sx_sdk_resource_sub_type_t. */
    RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E,
    RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E,
    RM_SDK_TABLE_TYPE_ARP_IPV4_E,          /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_ARP_IPV6_E,          /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E,
    RM_SDK_TABLE_TYPE_ADJACENCY_E,
    RM_SDK_TABLE_TYPE_L2_MC_VECTORS_E,
    RM_SDK_TABLE_TYPE_LAG_VECTORS_E,
    RM_SDK_TABLE_TYPE_FLOOD_VECTORS_E,
    RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,  /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_ACL_PBS_E,          /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_ERIF_LIST_E,        /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E,
    RM_SDK_TABLE_TYPE_ILM_E,              /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_RPF_GROUP_E,        /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_VLAN_E,             /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_VPORTS_E,           /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_FID_E,              /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_VNI_E,              /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_TUNNEL_IPV6_FDB_E,
    RM_SDK_TABLE_TYPE_MPLS_NHLFE_E,       /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E,      /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_NVE_IPV6_LIST_E,    /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_ACL_E,
    RM_SDK_TABLE_TYPE_RIPS_E,
    RM_SDK_TABLE_TYPE_IGMP_V3_IPV4_E,
    RM_SDK_TABLE_TYPE_IGMP_V3_IPV6_E,
    RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E,
    RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E,
    RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E,  /*18B KW */
    RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E, /*36B KW */
    RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E,  /*54B KW */
    RM_SDK_TABLE_TYPE_RIF_COUNTER_BASIC_E,
    RM_SDK_TABLE_TYPE_RIF_COUNTER_MIXED_E,
    RM_SDK_TABLE_TYPE_RIF_COUNTER_ENHANCED_E,
    RM_SDK_TABLE_TYPE_FLOW_COUNTER_E,
    RM_SDK_TABLE_TYPE_ACL_GROUPS_E,
    RM_SDK_TABLE_TYPE_INTERNAL_E,
    /**< Types below are internal system types and cannot be queried by user */
    RM_SDK_TABLE_TYPE_ACL_RULES_E,
    RM_SDK_TABLE_TYPE_DECAP_RULES_E,
    RM_SDK_TABLE_TYPE_IGMP_V3_E,
    RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E,
    RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E,
    RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E,
    RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E,
    RM_SDK_TABLE_TYPE_FCF_FORWORDING_E,
    RM_SDK_TABLE_TYPE_RMID_MANAGER_E,
    RM_SDK_TABLE_TYPE_NVE_MC_LIST_E,      /**< Legal to use for table duplication */
    RM_SDK_TABLE_TYPE_SMID_MANAGER_E,
    RM_SDK_TABLE_TYPE_FIB_IPV4_MC_SYSTEM_E,
    RM_SDK_TABLE_TYPE_FIB_IPV6_MC_SYSTEM_E,
    RM_SDK_TABLE_TYPE_RIF_COUNTER_E,
    RM_SDK_TABLE_TYPE_IGMP_V3_PRUNE_E,
    RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E,
    RM_SDK_TABLE_TYPE_MIN_E = RM_SDK_TABLE_TYPE_UC_MAC_E,
    RM_SDK_TABLE_TYPE_MAX_E = RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E,
} rm_sdk_table_type_e;
#define RM_SDK_TABLE_TYPE_NUMBER (RM_SDK_TABLE_TYPE_MAX_E - RM_SDK_TABLE_TYPE_MIN_E + 1)

#define RM_SDK_TABLE_TYPE_INVALID_E (RM_SDK_TABLE_TYPE_MAX_E + 1)


typedef struct rm_hw_table_attrb {
    boolean_t rm_hw_table_supported;
    uint32_t  rm_hw_table_size;
} rm_hw_table_attrb_t;

typedef enum {
    RM_HW_TABLE_TYPE_TCAM_E = 0,
    RM_HW_TABLE_TYPE_LINEAR_E = 1,
    RM_HW_TABLE_TYPE_KVD_HASH_E = 2,
    RM_HW_TABLE_TYPE_KVD_LINEAR_E = 3,
    RM_HW_TABLE_TYPE_ADJACENCY_E = 4,
    RM_HW_TABLE_TYPE_REPLICATION_MATRIX_E = 5,
    RM_HW_TABLE_TYPE_ACL_GROUP_TABLE_E = 6,
    RM_HW_TABLE_TYPE_PGT_E = 7,
    RM_HW_TABLE_TYPE_FLOW_COUNTER_E = 8,
    RM_HW_TABLE_TYPE_ACL_REGIONS_TABLE_E = 9,
    RM_HW_TABLE_TYPE_ACLS_IN_GROUPS_TABLE_E = 10,
    RM_HW_TABLE_TYPE_MIN_E = RM_HW_TABLE_TYPE_TCAM_E,
    RM_HW_TABLE_TYPE_MAX_E = RM_HW_TABLE_TYPE_ACLS_IN_GROUPS_TABLE_E,
} rm_hw_table_type_e;
#define RM_HW_TABLE_TYPE_INVALID RM_HW_TABLE_TYPE_MAX_E + 1
#define RM_HW_TABLE_TYPE_NUMBER  (RM_HW_TABLE_TYPE_MAX_E - RM_HW_TABLE_TYPE_MIN_E + 1)

typedef struct sw_table_resource {
    uint32_t            table_size_min;
    uint32_t            table_size_max;
    uint32_t            entry_cost;
    rm_hw_table_type_e  hw_table_type;
    rm_sdk_table_type_e parent_type;
    boolean_t           is_initialized;
} rm_sw_table_resource_t;

typedef struct rm_cos_sb_pg_min {
    uint32_t size;
    uint32_t is_lossy;
    uint32_t xon;
    uint32_t xoff;
    uint32_t override_headroom;
    uint32_t headroom; /* in jumbo frames */
} rm_cos_sb_pg_min_t;

typedef struct rm_cos_sb_port_profile {
    /*
     * min configuration - in bytes;
     * max configuration depends on the pool mode:
     * - static          - in % of the static pool;
     * - dynamic         - in alpha;
     * - buffer_units    - in % of the shared pool;
     */

    /** ingress data pool **/
    uint32_t           iport_pool_min;
    uint32_t           iport_pool_max;
    rm_cos_sb_pg_min_t iport_pg_min[RM_COS_SB_PG_PROFILE_SIZE];
    uint32_t           iport_pg_max[RM_COS_SB_PG_PROFILE_SIZE];

    /** egress data pool **/
    uint32_t eport_pool_min;
    uint32_t eport_pool_max;
    uint32_t eport_tc_min[RM_COS_SB_TC_PROFILE_SIZE];
    uint32_t eport_tc_max[RM_COS_SB_TC_PROFILE_SIZE];
    uint32_t eport_sp_min[RM_COS_SB_SP_PROFILE_SIZE];
    uint32_t eport_sp_max[RM_COS_SB_SP_PROFILE_SIZE];

    /** ingress management pool **/
    uint32_t iport_mgmt_pool_min;
    uint32_t iport_mgmt_pool_max;

    /** egress management pool **/
    uint32_t eport_mgmt_pool_min;
    uint32_t eport_mgmt_pool_max;
    uint32_t cpu_port_tc_min;
    uint32_t cpu_port_tc_max;

    /** multicast pool **/
    uint32_t eport_mc_min;
    uint32_t eport_mc_max;
    uint32_t eport_tc_mc_min[RM_COS_SB_HIGH_TC_PROFILE_SIZE];
    uint32_t eport_tc_mc_max[RM_COS_SB_HIGH_TC_PROFILE_SIZE];

    /** ingress descriptor pool (1 lane) **/
    uint32_t iport_1_descr_pool_min;
    uint32_t iport_1_descr_pool_max;
    uint32_t iport_1_descr_pg_min[RM_COS_SB_PG_PROFILE_SIZE];
    uint32_t iport_1_descr_pg_max[RM_COS_SB_PG_PROFILE_SIZE];

    /** egress descriptor pool (1 lane) **/
    uint32_t eport_1_descr_pool_min;
    uint32_t eport_1_descr_pool_max;
    uint32_t eport_1_descr_tc_min[RM_COS_SB_TC_PROFILE_SIZE];
    uint32_t eport_1_descr_tc_max[RM_COS_SB_TC_PROFILE_SIZE];

    /** ingress descriptor pool (4 lanes) **/
    uint32_t iport_4_descr_pool_min;
    uint32_t iport_4_descr_pool_max;
    uint32_t iport_4_descr_pg_min[RM_COS_SB_PG_PROFILE_SIZE];
    uint32_t iport_4_descr_pg_max[RM_COS_SB_PG_PROFILE_SIZE];

    /** egress descriptor pool (4 lanes) **/
    uint32_t eport_4_descr_pool_min;
    uint32_t eport_4_descr_pool_max;
    uint32_t eport_4_descr_tc_min[RM_COS_SB_TC_PROFILE_SIZE];
    uint32_t eport_4_descr_tc_max[RM_COS_SB_TC_PROFILE_SIZE];
} rm_cos_sb_port_profile_t;

typedef struct rm_resources {
    /*13*/
    uint32_t acl_ingress_groups_max;
    uint32_t acl_engress_groups_max;
    uint32_t acl_groups_size_max;
    uint32_t acl_groups_num_max;
    uint32_t acl_rules_block_max;
    uint32_t acl_pbs_entries_max;
    uint32_t acl_port_ranges_max;       /* cap max_acl_l4_port_ranges */
    uint32_t acl_regions_max;           /* cap_max_acl_regions */
    uint32_t acl_ingress_tables_max;    /* backward compatible */
    uint32_t acl_egress_tables_max;     /* backward compatible */
    uint32_t acl_tables_max;            /* cap_max_acl_regions */
    uint32_t acl_vlan_groups_max;       /* cap_max_acl_vlan_groups  */
    uint32_t acl_trap_groups_max;
    uint32_t acl_max_actions_per_rule;  /* cap_max_action_per_rule */
    uint32_t acl_max_actions_per_basic_set;      /* number of actions in the rule itself */
    uint32_t acl_max_actions_per_extended_set;   /* number of actions in an extended rule set (kvd) */
    uint32_t acl_parsing_depth;
    uint32_t acl_custom_bytes_set_max;      /* Max number of sets */
    uint32_t acl_custom_bytes_set_size_max; /* Set size */
    uint32_t acl_custom_bytes_extraction_point_offset_max;
    uint32_t acl_pbilm_entries_max;
    uint32_t acl_key_blocks_max;
    uint32_t acl_acls_in_groups_max;    /* Maximum number of total ACLs in all groups */

    /*20*/
    uint32_t router_rifs_max;
    uint32_t router_sdk_rifs_max;       /* allocated by SDK for internal usage (e.g. uRIF for VRID Domain Type in Tunnels) */
    uint32_t router_rifs_dontcare;
    uint32_t router_sub_port_fid_start_index;
    uint32_t router_ipv4_uc_max;
    uint32_t router_ipv4_mc_max;
    uint32_t router_ipv6_uc_max;
    uint32_t router_ipv6_mc_max;
    uint32_t router_ecmp_max;
    uint32_t router_ecmp_hash_max;
    uint32_t router_adj_max;
    uint32_t router_neigh_max;
    uint32_t router_vrid_max;
    uint32_t router_counters_id_max;
    uint32_t router_next_hop_max;
    uint32_t router_ecmp_container_tot_weight_max;
    uint32_t router_shspm_tree_max;
    uint32_t router_shspm_unicast_entry_max;
    uint32_t router_mc_rpf_group_max;

    /*5*/
    uint32_t fcf_port_density_max;
    uint32_t fcf_zones_pairs_max;
    uint32_t fcf_zones_groups_max;
    uint32_t fcf_gateway_max;
    uint32_t fcf_rules_max;

    /*8*/
    uint32_t port_lcl_num_max;
    uint32_t port_ext_num_max;    /* Please note the current value must not be greater than the 'MAX_PHYPORT_NUM' and 'MAX_SWITCHX_PORTS' defines */
    uint32_t port_log_num_max;
    uint32_t port_mtu_max;
    uint32_t port_mtu_min;
    uint32_t port_storm_control_id_max;
    uint32_t port_vepa_channels_num_max;
    uint32_t port_system_ports_max;
    uint32_t port_system_port_modules_max;
    uint32_t port_map_width_max;

    /*6*/
    uint32_t  lag_num_max;
    uint32_t  lag_port_members_max;
    uint32_t  span_session_id_max_internal; /* supported by FW      */
    uint32_t  span_session_id_max_external; /* available to user    */
    uint32_t  fdb_mid_max;
    uint32_t  fdb_mid_start_index;
    uint32_t  fdb_pgt_max;
    uint32_t  fdb_uc_address_max;
    uint32_t  fdb_mc_address_max;
    uint32_t  flooding_table_max;
    uint32_t  flooding_table_per_vid_max;
    uint32_t  cos_port_ets_traffic_class_max;
    uint32_t  cos_port_ets_sub_group_max;
    uint32_t  cos_port_ets_group_max;
    uint32_t  cos_port_prio_max;
    uint32_t  cos_port_color_max;
    uint32_t  cos_port_ets_elements_num;
    double    cos_buffer_64k_size_max;
    double    cos_buffer_128k_size_max;
    uint32_t  cos_redecn_default_aqs_weight;
    boolean_t cos_redecn_red_drop_enabled;
    boolean_t cos_redecn_scd;
    uint32_t  cos_redecn_profiles_max;
    uint32_t  cos_redecn_cell_multiplier;
    boolean_t cos_redecn_default_tc_red_enabled;
    boolean_t cos_redecn_default_tc_ecn_enabled;
    uint8_t   swid_id_max;
    uint32_t  policer_pool_size;
    uint32_t  policer_host_ifc_pool_size;
    uint32_t  policer_storm_control_pool_size;
    uint32_t  policer_bs_min_value_packets;
    uint32_t  policer_bs_min_value_bytes;
    uint32_t  policer_bs_max_value;
    uint32_t  kvd_size;
    uint32_t  kvd_hash_single_min_size;
    uint32_t  kvd_hash_double_min_size;
    double    kvd_guaranteed_capacity;
    uint32_t  kvd_linear_virtual_table_size;
    uint32_t  pgt_size;
    uint32_t  rmpe_size;

    /* Bridge */
    uint32_t bridge_num_max;

    /* Shared buffer */
    uint32_t                 total_buffer_space;  /* cap_total_buffer_size */
    uint32_t                 total_descriptor_buffer_space;
    uint32_t                 max_total_headroom_size;
    uint8_t                  headroom_num_port_buff;
    uint8_t                  shared_buff_num_ingress_pools;
    uint8_t                  shared_buff_num_egress_pools;
    uint8_t                  shared_buff_num_mc_port_pool;
    uint8_t                  shared_buff_num_ingress_descriptor;
    uint8_t                  shared_buff_num_egress_descriptor;
    uint8_t                  shared_buff_num_managment_pools;
    uint8_t                  shared_buff_total_num_pools;
    uint8_t                  shared_buff_num_port_egress_buff;
    uint8_t                  shared_buff_num_port_ingress_buff;
    uint32_t                 shared_buff_max_pool_size;
    uint32_t                 shared_buff_def_ing_data_pool_size;
    uint32_t                 shared_buff_def_egr_data_pool_size;
    uint32_t                 shared_buff_def_ing_mgmt_pool_size;
    uint32_t                 shared_buff_def_egr_mgmt_pool_size;
    uint32_t                 shared_buff_def_ing_desc_pool_size;
    uint32_t                 shared_buff_def_egr_desc_pool_size;
    rm_cos_sb_port_profile_t port_sb_profile;
    uint32_t                 max_num_of_port;
    uint32_t                 max_num_of_tclass;
    uint32_t                 max_num_of_statistics_ret_values;
    uint32_t                 shared_buff_buffer_unit_size;  /*cap_cell_size*/
    uint32_t                 shared_buff_mc_max_num_prio;
    rm_sw_table_resource_t   rm_sdk_tables_db[RM_SDK_TABLE_TYPE_NUMBER];
    rm_hw_table_attrb_t      rm_hw_tables_attrb[RM_HW_TABLE_TYPE_NUMBER];

    /* 16 Counters */
    uint8_t  cntr_bank_pairs;
    uint16_t cntr_lines_per_bank;
    uint8_t  cntr_lines_flow_pkt;
    uint8_t  cntr_type_flow_pkt;
    uint8_t  cntr_lines_flow_byte;
    uint8_t  cntr_type_flow_byte;
    uint8_t  cntr_lines_flow_both;
    uint8_t  cntr_type_flow_both;
    uint8_t  cntr_lines_rif_basic;
    uint8_t  cntr_type_rif_basic;
    uint8_t  cntr_lines_rif_mixed_1;
    uint8_t  cntr_type_rif_mixed_1;
    uint8_t  cntr_lines_rif_mixed_2;
    uint8_t  cntr_type_rif_mixed_2;
    uint8_t  cntr_lines_rif_enhanced;
    uint8_t  cntr_type_rif_enhanced;

    /*10*/
    uint32_t ib_router_pkeys_max;
    uint32_t ib_router_lids_max;
    uint32_t ib_router_mc_lids_num_max;
    uint32_t ib_router_uc_lid_num_max;

    /*1*/
    uint32_t ib_ports_max;

    /* Host interface */
    uint32_t hw_cpu_ingress_tclass_max;
    uint32_t hw_dr_paths_max;
    uint32_t hw_trap_groups_num_max;
    uint32_t trap_group_priority_min;
    uint32_t trap_group_priority_max;
    uint32_t rdq_num_max;
    uint32_t cpu_tclass_num_max;

    /* Tunnel */
    uint32_t tunnel_ipinip_num_max;
    uint32_t tunnel_nve_num_max;
    uint32_t tunnel_nve_group_size_flood_max;
    uint32_t tunnel_nve_group_size_mc_max;
    uint8_t  tunnel_tnumt_ipv6_records_max;

    /* IGMP V3 */
    uint32_t igmpv3_entries_max;

    /* Tele */
    uint32_t tele_histogram_num_max;
    uint32_t tele_histogram_queue_depth_bins;
    uint32_t tele_histogram_sample_time_resolution_max;
    uint32_t tele_histogram_bin_size_resolution_min;
    uint32_t tele_histogram_bin_size_resolution_max;
    uint32_t tele_histogram_data_bin_bits_max;
    uint32_t tele_histogram_min_boundary_min;
    uint32_t tele_threshold_thr_max;

    /* BFD */
    uint32_t bfd_session_num_max;
} rm_resources_t;

/**
 * sx_table_duplication_num_t enumerated type is used to list supported duplication
 * numbers for table duplication.
 */
typedef enum sx_sdk_entry_duplication {
    SX_SDK_ENTRY_DUPLICATION_INVALID_E = 0,
    SX_SDK_ENTRY_DUPLICATION_1_E = 1,      /**< single data entry per table */
    SX_SDK_ENTRY_DUPLICATION_2_E = 2,      /**< 2 the same data entries per table */
    SX_SDK_ENTRY_DUPLICATION_4_E = 4,      /**< 4 the same data entries per table */
    SX_SDK_ENTRY_DUPLICATION_8_E = 8,      /**< 8 the same data entries per table */
    SX_SDK_ENTRY_DUPLICATION_16_E = 16,    /**< 16 the same data entries per table */
    SX_SDK_ENTRY_DUPLICATION_MIN_E = SX_SDK_ENTRY_DUPLICATION_1_E,
    SX_SDK_ENTRY_DUPLICATION_MAX_E = SX_SDK_ENTRY_DUPLICATION_16_E
} sx_sdk_entry_duplication_e;

/**
 * sx_sdk_resource_sub_type_e enumerated type is used to list all supported resource
 * sub-types for table duplication.
 * Please note that sub-type is allowed only for the RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E
 * and RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E table types.
 */
typedef enum sx_sdk_resource_sub_type {
    SX_SDK_SUB_TYPE_NONE_E = 0, /**< Used for resources, which don't support sub type */
    SX_SDK_SUB_TYPE_DEFAULT_E,  /**< Default Prefix Match */
    SX_SDK_SUB_TYPE_LOW_E,      /**< Low Prefix Match */
    SX_SDK_SUB_TYPE_HIGH_E,     /**< High Prefix Match */
    SX_SDK_SUB_TYPE_MIN_E = SX_SDK_SUB_TYPE_NONE_E,
    SX_SDK_SUB_TYPE_MAX_E = SX_SDK_SUB_TYPE_HIGH_E
} sx_sdk_resource_sub_type_e;

/**
 * Calculate the number of available subtypes, since we need to
 * know this number for SDK table rm_sdk_table_resource_t, which
 * contains the number of entry duplication per every sub type.
 */
#define RM_SDK_SUB_TYPE_NUMBER (SX_SDK_SUB_TYPE_MAX_E - SX_SDK_SUB_TYPE_MIN_E + 1)

/**
 * sx_table_duplication_param_t structure is used to hold table duplication parameters
 * such as number of duplication and sub-type which will be used for set to or get
 * from the HW.
 */
typedef struct sx_sdk_table_duplication_param {
    sx_sdk_entry_duplication_e num_of_duplication;
    sx_sdk_resource_sub_type_e sub_type;           /**<  None/Default/Low/High */
} sx_sdk_table_duplication_param_t;

/**
 * sx_sdk_entries_param_t structure is used to hold data entries
 * additional parameters such as router prefix length which is
 * required in RM module for calculation of actual resource
 * utilization
 */
typedef struct sx_sdk_entries_param {
    rm_sdk_table_type_e resource;
    union {
        struct {
            uint32_t prefix_length;
        } router_attr;
    } attr;
} sx_sdk_entries_param_t;

/**
 * sx_tcam_key_width_t is used to define ACL flexible key width in 18B blocks
 */
typedef enum {
    SX_TCAM_KEY_WIDTH_18_E = 1,           /**< TCAM width 18 */
    SX_TCAM_KEY_WIDTH_36_E = 2,           /**< TCAM width 36 */
    SX_TCAM_KEY_WIDTH_54_E = 3,            /**< TCAM width 54 */
    SX_TCAM_KEY_WIDTH_MIN_E = SX_TCAM_KEY_WIDTH_18_E,
    SX_TCAM_KEY_WIDTH_MAX_E = SX_TCAM_KEY_WIDTH_54_E
} sx_tcam_key_width_e;

#define RM_SDK_TCAM_MIN_TABLE_ALLOC_KEY_WIDTH (SX_TCAM_KEY_WIDTH_MAX_E)

typedef struct sx_hw_entries_param {
    rm_sdk_table_type_e logical_resource;
    union {
        struct {
            uint32_t            current_num_entries;  /* Current num entries for resource */
            uint8_t             number_of_copies; /* If Hard optimization, the duplication factor, else 0 */
            sx_tcam_key_width_e key_width;
        } tcam_attrs;
        struct {
            uint32_t hw_cost;             /* For IPv6 entries, the prefix length determines the cost*/
        } kvd_attrs;
    } hw_attr;
} sx_hw_entries_param_t;

typedef struct rm_sdk_table_params {
    union {
        struct {
            uint32_t key_handle;
        } acl_attr;
    } attrs;
} rm_sdk_table_params_t;

typedef struct {
    rm_sdk_table_type_e resource;
    uint32_t            sdk_table_entries_used;                          /* logical # of entries used. Including granularity, excluding optimization like psort */
    uint32_t            sdk_table_entries_allocated;                  /* size of allocated memory >= sdk_table_type_used. Including min, and granularity */
    rm_hw_table_type_e  hw_table_type;                           /* TCAM/KVD linear/KVD hash etc. */
    uint16_t            hw_table_utilization_per_resource;    /* HW utilization in 10th of percent, e.g. 1pct will be 10 */
} sx_api_rm_table_utilization_t;

typedef struct tcam_alloc_params {
    uint32_t entries_count[SX_TCAM_KEY_WIDTH_MAX_E];
} tcam_alloc_params_t;

typedef struct rm_sdk_hw_table_params {
    sx_hw_entries_param_t hw_params;
    tcam_alloc_params_t   tcam_allocation;
} rm_sdk_hw_table_params_t;


/************************************************
 *  Global variables
 ***********************************************/


extern rm_resources_t rm_resource_global;
extern rm_resources_t rm_resource_global_default;

#define SX_SDK_RESOURCE_CHECK_RANGE(RESOURCE) \
    SX_CHECK_RANGE(RM_SDK_TABLE_TYPE_MIN_E,   \
                   (int)RESOURCE,             \
                   RM_SDK_TABLE_TYPE_MAX_E)

static __attribute__((__used__)) const char *sx_resource2str_arr[] = {
    /*RM_SDK_TABLE_TYPE_UC_MAC = 0*/
    "UC MAC ",

    /*RM_SDK_TABLE_TYPE_MC_MAC = 1*/
    "MC MAC ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV4_UC = 2*/
    "FIB IPV4 UC ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV6_UC = 3*/
    "FIB IPV6 UC ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV4_MC = 4*/
    "FIB IPV4 MC ",

    /*RM_SDK_TABLE_TYPE_FIB_IPV6_MC = 5*/
    "FIB IPV6 MC ",

    /*RM_SDK_TABLE_TYPE_ARP_IPV4 = 6*/
    "ARP IPV4 ",

    /*RM_SDK_TABLE_TYPE_ARP_IPV6 = 7*/
    "ARP IPV6 ",

    /*RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS = 8*/
    "L3 MC Replications ",

    /*RM_SDK_TABLE_TYPE_ADJACENCY_E = 9*/
    "Unicast Adjacency ",

    /*RM_SDK_TABLE_TYPE_L2_MC_VECTORS = 10*/
    "L2 MC VECTORS ",

    /*RM_SDK_TABLE_TYPE_LAG_VECTORS = 11*/
    "LAG VECTORS Table ",

    /*RM_SDK_TABLE_TYPE_FlOOD_VECTORS = 12*/
    "FlOOD VECTORS ",

    /*RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS = 13 */
    "ACL Extended Actions ",

    /*RM_SDK_TABLE_TYPE_ACL_PBS_E = 14 */
    "ACL PBS",

    /*RM_SDK_TABLE_TYPE_ERIF_LIST_E = 15 */
    "eRIF List ",

    /* RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E = 16 */
    "Tunnel RTDP",


    /* RM_SDK_TABLE_TYPE_ILM_E = 17 */
    "ILM",

    /* RM_SDK_TABLE_TYPE_RPF_GROUP_E = 18 */
    "RPF Group",

    /* RM_SDK_TABLE_TYPE_VLAN_E = 19 */
    "VLAN",

    /* RM_SDK_TABLE_TYPE_VPORTS_E = 20 */
    "VPorts",

    /* RM_SDK_TABLE_TYPE_FID_E = 21 */
    "FID",

    /* RM_SDK_TABLE_TYPE_VNI_E = 22 */
    "VNI",

    /* RM_SDK_TABLE_TYPE_TUNNEL_IPV6_FDB_E = 23 */
    "Tunnel IPv6 FDB",

    /* RM_SDK_TABLE_TYPE_MPLS_NHLFE_E = 24 */
    "MPLS NHLFE",

    /* RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E = 25 */
    "Policy Based MPLS ILM",

    /* RM_SDK_TABLE_TYPE_NVE_IPV6_LIST_E = 26 */
    "NVE IPv6 List",

    /* RM_SDK_TABLE_TYPE_ACL_E = 27 */
    "ACL",

    /* RM_SDK_TABLE_TYPE_RIPS_E = 28 */
    "RIPS IPv6",

    /*RM_SDK_TABLE_TYPE_IGMP_V3_IPV4_E = 29 */
    "IGMP V3 IPv4",

    /*RM_SDK_TABLE_TYPE_IGMP_V3_IPV6_E = 30 */
    "IGMPv3 IPv6",

    /*RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E = 31 */
    "Tunnel Decap IPv4",

    /*RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E = 32 */
    "Tunnel Decap IPv6",

    /*RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E = 33 */
    "ACL Rule Two Key Block",

    /*RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E = 34 */
    "ACL Rule Four Key Block",

    /*RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E = 35 */
    "ACL Rule Six Key Block",

    /*RM_SDK_TABLE_TYPE_RIF_COUNTER_BASIC_E = 36 */
    "Basic RIF Counter",

    /*RM_SDK_TABLE_TYPE_RIF_COUNTER_MIXED_E = 37 */
    "Mixed Type RIF Counter",

    /*RM_SDK_TABLE_TYPE_RIF_COUNTER_ENHANCED_E = 38 */
    "Enhanced Type RIF Counter",

    /*RM_SDK_TABLE_TYPE_FLOW_COUNTER_E = 39 */
    "Flow Counter",

    /*RM_SDK_TABLE_TYPE_ACL_GROUPS_E = 40*/
    "ACL GROUPS ",

    /* RM_SDK_TABLE_TYPE_INTERNAL_E = 41 */
    "Internal System Table Types ",

    /*RM_SDK_TABLE_TYPE_ACL_RULES_E = 42*/
    "ACL RULES Table ",

    /* RM_SDK_TABLE_TYPE_DECAP_RULES_E = 43 */
    "Decap rules",

    /* RM_SDK_TABLE_TYPE_IGMP_V3_E = 44 */
    "IGMP V3 table",

    /* RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E = 45 */
    "A-TCAM One-key Block Table",

    /* RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E = 46 */
    "A TCAM Two-keys Block Table",

    /* RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E = 47 */
    "A TCAM Four-keys Block Table",

    /* RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E = 48 */
    "A TCAM Six-keys Block Table",

    /*RM_SDK_TABLE_TYPE_FCF_FORWORDING = 49*/
    "FCF FORWARDING Table ",

    /* RM_SDK_TABLE_TYPE_RMID_MANAGER_E = 50 */
    "RMID Manager Table ",

    /*RM_SDK_TABLE_TYPE_NVE_MC_LIST_E = 51 */
    "NVE MC List",

    /* RM_SDK_TABLE_TYPE_SMID_MANAGER_E = 52 */
    "SMID Manager",

    /* RM_SDK_TABLE_TYPE_FIB_IPV4_MC_SYSTEM_E = 53 */
    "FIB IPV4 MC System Table ",

    /* RM_SDK_TABLE_TYPE_FIB_IPV6_MC_SYSTEM_E = 54 */
    "FIB IPV6 MC System Table ",

    /*RM_SDK_TABLE_TYPE_RIF_COUNTER_E = 55 */
    "RIF Counter Table",

    /*RM_SDK_TABLE_TYPE_IGMP_V3_PRUNE_E = 56 */
    "IGMPv3 PRUNE Table",

    /*RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E = 57 */
    "ACLs in Groups",
};

#define SX_SDK_RESOURCE_MSG(RESOURCE)                                                            \
    (RESOURCE < (sizeof(sx_resource2str_arr) / sizeof(char*))) ? sx_resource2str_arr[RESOURCE] : \
    "Unknown resource"


#define SX_HW_RESOURCE_CHECK_RANGE(RESOURCE) \
    SX_CHECK_RANGE(RM_HW_TABLE_TYPE_MIN_E,   \
                   (int)RESOURCE,            \
                   RM_HW_TABLE_TYPE_MAX_E)
#define SX_HW_RESOURCE_MSG(RESOURCE)                                          \
    SX_HW_RESOURCE_CHECK_RANGE(RESOURCE) ? sx_hw_resource2str_arr[RESOURCE] : \
    "Unknown resource"

static __attribute__((__used__)) const char *sx_hw_resource2str_arr[] = {
    /*RM_DB_TYPE_TCAM = 0*/
    "TCAM Table ",

    /*RM_DB_TYPE_LINEAR = 1*/
    "Linear Table ",

    /*RM_DB_TYPE_KVD_HASH = 2*/
    "KVD hash Table ",

    /*RM_DB_TYPE_KVD_LINEAR = 3*/
    "KVD linear Table ",

    /*RM_HW_TABLE_TYPE_ADJACENCY_E = 4*/
    "Adjacency Table ",

    /*RM_HW_TABLE_TYPE_REPLICATION_MATRIX_E = 5*/
    "Mcast Rep Matrix ",

    /*RM_HW_TABLE_TYPE_ACL_GROUP_TABLE_E = 6*/
    "ACL Group Table ",

    /* RM_HW_TABLE_TYPE_PGT_E = 7 */
    "PGT ",

    /* RM_HW_TABLE_TYPE_FLOW_COUNTERS_E = 8 */
    "Flow Counters ",

    /* RM_HW_TABLE_TYPE_ACL_REGIONS_TABLE_E = 9 */
    "ACL Regions Table ",

    /* RM_HW_TABLE_TYPE_ACLS_IN_GROUPS_TABLE_E = 10 */
    "ACLs in Groups Table ",
};

#define SX_HW_RESOURCE_STR_TABLE_LEN (sizeof(sx_hw_resource2str_arr) / sizeof(sx_hw_resource2str_arr[0]))
#define SX_SW_RESOURCE_STR_TABLE_LEN (sizeof(sx_resource2str_arr) / sizeof(sx_resource2str_arr[0]))

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t rm_chip_limits_get(sx_chip_types_t chip_type, rm_resources_t* resource_limits);
#endif /* __RESOURCE_MANAGER_H__ */
