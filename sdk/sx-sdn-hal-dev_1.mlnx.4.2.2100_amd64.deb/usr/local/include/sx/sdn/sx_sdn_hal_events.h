/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_EVENTS_H__
#define __SX_SDN_HAL_EVENTS_H__

#include <netinet/in.h>
#include <sx/sdk/sx_host.h>
#include <sx/sdk/sx_port.h>
#include <complib/cl_passivelock.h>
#include <sx/sdn/sx_sdn_hal_general.h>
#include <sx/sdn/sx_sdn_hal_port.h>

#define SX_SDN_HAL_MAX_FDS         10
#define SX_SDN_HAL_MAX_PACKET_SIZE 4000

typedef enum sx_sdn_hal_port_operation_type {
    SX_SDN_HAL_PORT_OPER_TYPE_ADD,
    SX_SDN_HAL_PORT_OPER_TYPE_REMOVE,
    SX_SDN_HAL_PORT_OPER_TYPE_CHANGE
} sx_sdn_hal_port_operation_type_t;

typedef enum sx_sdn_hal_event {
    SX_SDN_HAL_EVENT_GENERAL_READY,
    SX_SDN_HAL_EVENT_GENERAL_ERROR,
    SX_SDN_HAL_EVENT_TABLE_UPDATE,
    SX_SDN_HAL_EVENT_PORT_CAPABILITIES_UPDATE,
    SX_SDN_HAL_EVENT_PORT_OPER_STATE_CHANGE,
    SX_SDN_HAL_EVENT_PORT_STP_STATE_CHANGE,
    SX_SDN_HAL_EVENT_PORT_LACP_STATE_CHANGE,
    SX_SDN_HAL_EVENT_VLAN_UPDATE,
    SX_SDN_HAL_EVENT_SWITCH_UPDATE,
    SX_SDN_HAL_EVENT_AGENT_UPDATE,
    SX_SDN_HAL_EVENT_PACKET_IN,
    SX_SDN_HAL_EVENT_PACKET_MISS,
    /****************************************************/
    SX_SDN_HAL_EVENT_MIN = SX_SDN_HAL_EVENT_GENERAL_READY,
    SX_SDN_HAL_EVENT_MAX = SX_SDN_HAL_EVENT_PACKET_MISS,
} sx_sdn_hal_event_t;

#define SX_SDN_HAL_EVENT_COUNT SX_SDN_HAL_EVENT_MAX + 1

/**
 * SX_SDN_HAL_EVENT_CHECK_RANGE defines Trap ID check range macro
 */
#define SX_SDN_HAL_EVENT_CHECK_RANGE(EVENT) \
    SX_SDN_HAL_CHECK_MAX(EVENT, SX_SDN_HAL_EVENT_MAX)

static __attribute__((__used__)) const char *sdn_hal_event_type_str[] = {
    /* SX_SDN_HAL_EVENT_GENERAL_READY */
    "GENERAL READY",
    /* SX_SDN_HAL_EVENT_GENERAL_ERROR */
    "GENERAL ERROR",
    /* SX_SDN_HAL_EVENT_TABLE_UPDATE */
    "TABLE UPDATE",
    /* SX_SDN_HAL_EVENT_PORT_CAPABILITIES_UPDATE */
    "PORT CAPABILITIES UPDATE",
    /* SX_SDN_HAL_EVENT_PORT_OPER_STATE_CHANGE */
    "PORT OPER STATE CHANGE",
    /* SX_SDN_HAL_EVENT_PORT_STP_STATE_CHANGE */
    "PORT STP STATE CHANGE",
    /* SX_SDN_HAL_EVENT_PORT_LACP_STATE_CHANGE */
    "PORT LACP STATE CHANGE",
    /* SX_SDN_HAL_EVENT_VLAN_UPDATE */
    "VLAN UPDATE",
    /* SX_SDN_HAL_EVENT_SWITCH_UPDATE */
    "SWITCH UPDATE",
    /* SX_SDN_HAL_EVENT_AGENT_UPDATE */
    "AGENT UPDATE",
    /* SX_SDN_HAL_EVENT_PACKET_IN */
    "PACKET IN",
    /* SX_SDN_HAL_EVENT_PACKET_MISS */
    "PACKET MISS"
};

/**
 * sx_sdn_hal_internal_fd_t structure is used to store the internal SDN HAL file descriptor.
 */
typedef struct sx_sdn_hal_internal_fd {
    int pipefd[2];  /**< pipe */
} sx_sdn_hal_internal_fd_t;

/**
 * sx_sdn_hal_fd_t structure is used to store the SDN HAL file descriptor
 */
typedef struct sx_sdn_hal_fd {
    sx_fd_t                  sdk_fd;        /**< SDK file descriptor */
    sx_sdn_hal_internal_fd_t hal_fd;        /**< Internal HAL file descriptor */
    boolean_t                sdk_fd_valid;  /**< Indicates if SDK file descriptor is valid */
    boolean_t                valid;         /**< Indicates if the descriptor is valid */
} sx_sdn_hal_fd_t;

/**
 * sx_sdn_hal_priority_t data type is used to store the priority of a sent packet
 */
typedef sx_trap_priority_t sx_sdn_hal_priority_t;

/**
 * sx_sdn_hal_event_general_ready_t structure is used to store the GENERAL_READY event data
 */
typedef struct sx_sdn_hal_event_general_ready {
} sx_sdn_hal_event_general_ready_t;

/**
 * sx_sdn_hal_event_general_error_t structure is used to store the GENERAL_ERROR event data
 */
typedef struct sx_sdn_hal_event_general_error {
} sx_sdn_hal_event_general_error_t;

/**
 * sx_sdn_hal_event_table_update_t structure is used to store the TABLE_UPDATE event data
 */
typedef struct sx_sdn_hal_event_table_update {
} sx_sdn_hal_event_table_update_t;

/**
 * sx_sdn_hal_event_port_capabilities_update_t structure is used to store the PORT_CAPABILITIES_UPDATE event data
 */
typedef struct sx_sdn_hal_event_port_capabilities_update {
    sx_sdn_hal_port_operation_type_t operation;                 /**< operation type (add/remove/change) */
    sx_sdn_hal_port_t                port;              /**< port */
    sx_port_oper_state_t             oper_state;            /**< operational state */
    sx_sdn_hal_mac_addr_t            hw_addr;               /**< MAC */
    char                             port_name[SX_SDN_HAL_PORT_NAME_LEN]; /**< Name */
} sx_sdn_hal_event_port_capabilities_update_t;

/**
 * sx_sdn_hal_event_port_oper_state_change_t structure is used to store the PORT_OPER_STATE_CHANGE event data
 */
typedef struct sx_sdn_hal_event_port_oper_state_change {
    sx_sdn_hal_port_t    port;      /**< port */
    sx_port_oper_state_t oper_state;    /**< operational state */
} sx_sdn_hal_event_port_oper_state_change_t;

/**
 * sx_sdn_hal_event_port_stp_state_change_t structure is used to store the PORT_STP_STATE_CHANGE event data
 */
typedef struct sx_sdn_hal_event_port_stp_state_change {
    sx_sdn_hal_port_t port;   /**< port */
} sx_sdn_hal_event_port_stp_state_change_t;

/**
 * sx_sdn_hal_event_port_lacp_state_change_t structure is used to store the PORT_LACP_STATE_CHANGE event data
 */
typedef struct sx_sdn_hal_event_port_lacp_state_change {
    sx_sdn_hal_port_t port;   /**< port */
} sx_sdn_hal_event_port_lacp_state_change_t;

/**
 * sx_sdn_hal_event_vlan_update_t structure is used to store the VLAN_UPDATE event data
 */
typedef struct sx_sdn_hal_event_vlan_update {
} sx_sdn_hal_event_vlan_update_t;

/**
 * sx_sdn_hal_event_switch_update_t structure is used to store the SWITCH_UPDATE event data
 */
typedef struct sx_sdn_hal_event_switch_update {
} sx_sdn_hal_event_switch_update_t;

/**
 * sx_sdn_hal_event_agent_update_t structure is used to store the AGENT_UPDATE event data
 */
typedef struct sx_sdn_hal_event_agent_update {
    sx_ip_addr_t local_ip_address;
    uint16_t     local_port;
    sx_ip_addr_t controller_ip_address;
    uint16_t     controller_port;
    uint64_t     datapath_id;
} sx_sdn_hal_event_agent_update_t;

/**
 * sx_sdn_hal_event_packet_in_t structure is used to store the PACKET_IN event data
 */
typedef struct sx_sdn_hal_event_packet_in {
    uint8_t           packet[SX_SDN_HAL_MAX_PACKET_SIZE]; /**< Packet payload */
    uint32_t          packet_size;              /**< Packet size */
    sx_sdn_hal_port_t egress_port;                  /**< port on which the packet was received */
} sx_sdn_hal_event_packet_in_t;

/**
 * sx_sdn_hal_event_packet_miss_t structure is used to store the PACKET_MISS event data
 */
typedef struct sx_sdn_hal_event_packet_miss {
    uint8_t           packet[SX_SDN_HAL_MAX_PACKET_SIZE]; /**< Packet payload */
    uint32_t          packet_size;              /**< Packet size */
    sx_sdn_hal_port_t egress_port;                  /**< port on which the packet was received */
} sx_sdn_hal_event_packet_miss_t;

/**
 * sx_sdn_hal_event_data_t union is used to store the event data of all events
 */
typedef union sx_sdn_hal_event_data {
    sx_sdn_hal_event_general_ready_t            general_ready;      /**< general ready */
    sx_sdn_hal_event_general_error_t            general_error;      /**< general error */
    sx_sdn_hal_event_table_update_t             table_update;       /**< table update */
    sx_sdn_hal_event_port_capabilities_update_t port_capabilities_update;   /**< port capabilities update */
    sx_sdn_hal_event_port_oper_state_change_t   port_oper_state_change;     /**< port oper state change */
    sx_sdn_hal_event_port_stp_state_change_t    port_stp_state_change;      /**< port stp state change */
    sx_sdn_hal_event_port_lacp_state_change_t   port_lacp_state_change;     /**< port lacp state change */
    sx_sdn_hal_event_vlan_update_t              vlan_update;        /**< vlan update */
    sx_sdn_hal_event_switch_update_t            switch_update;      /**< switch update */
    sx_sdn_hal_event_agent_update_t             agent_update;       /**< agent update */
    sx_sdn_hal_event_packet_in_t                packet_in;      /**< packet in */
    sx_sdn_hal_event_packet_miss_t              packet_miss;        /**< packet miss */
} sx_sdn_hal_event_data_t;

/**
 * sx_sdn_hal_event_data_t structure is used to store the information of a received event
 */
typedef struct sx_sdn_hal_event_info {
    sx_sdn_hal_event_t      event_type; /**< event type */
    sx_sdn_hal_event_data_t event_data; /**< event data */
} sx_sdn_hal_event_info_t;

#endif /* __SX_SDN_HAL_EVENTS_H__ */
