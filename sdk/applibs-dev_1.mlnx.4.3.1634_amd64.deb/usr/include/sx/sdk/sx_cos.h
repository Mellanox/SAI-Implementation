/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_COS_H_
#define SX_COS_H_

#include <sx/sxd/sxd_cos.h>
#include <resource_manager/resource_manager.h>

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define COS_PORT_VALIDITY_CHECK_GROUP    1
#define COS_PORT_VALIDITY_CHECK_BW_ALLOC 2
#define COS_PORT_VALIDITY_CHECK_MAX_BW   3


/**
 * SX_COS_PORT_PRIO_MIN define minimum port priority
 */
#define SX_COS_PORT_PRIO_MIN SXD_COS_PORT_PRIO_MIN
/**
 * SX_COS_PORT_TRUST_LEVEL_MIN define minimum port trust level
 */
#define SX_COS_PORT_TRUST_LEVEL_MIN SXD_COS_PORT_TRUST_LEVEL_MIN
/**
 * SX_COS_PORT_TRUST_LEVEL_MAX define maximum port trust level
 */
#define SX_COS_PORT_TRUST_LEVEL_MAX SXD_COS_PORT_TRUST_LEVEL_MAX
/**
 * SX_COS_PORT_DSCP_MIN define minimum port DSCP
 */
#define SX_COS_PORT_DSCP_MIN SXD_COS_PORT_DSCP_MIN
/**
 * SX_COS_PORT_DSCP_MAX define maximum port DSCP
 */
#define SX_COS_PORT_DSCP_MAX SXD_COS_PORT_DSCP_MAX
/**
 * SX_COS_TCLASS_MIN define minimum traffic class
 */
#define SX_COS_TCLASS_MIN SXD_COS_TCLASS_MIN
/**
 * SX_COS_TCLASS_REQUIRED defines the required num of traffic class
 */
#define SX_COS_TCLASS_REQUIRED SXD_COS_TCLASS_MAX
/**
 * SX_COS_BW_ALLOCATION_MIN define minimum BW allocation number
 */
#define SX_COS_BW_ALLOCATION_MIN SXD_COS_BW_ALLOCATION_MIN
/**
 * SX_COS_BW_ALLOCATION_MAX define maximum BW allocation number
 */
#define SX_COS_BW_ALLOCATION_MAX SXD_COS_BW_ALLOCATION_MAX

/**
 * SX_COS_BW_VALUE_MIN define minimum BW (rate limiter) value number
 */
#define SX_COS_BW_VALUE_MIN SXD_COS_BW_VALUE_MIN

/**
 * SX_COS_BW_VALUE_MAX define maximum BW (rate limiter) value number
 */
#define SX_COS_BW_VALUE_MAX SXD_COS_BW_VALUE_MAX

#define SX_COS_PRIO_CHECK_RANGE(prio) SX_CHECK_MAX(prio, rm_resource_global.cos_port_prio_max)

#define SX_COS_COLOR_CHECK_RANGE(color) SX_CHECK_MAX(color, rm_resource_global.cos_port_color_max)

#define SX_COS_PCP_CHECK_RANGE(pcp) SX_CHECK_MAX(pcp, COS_PCP_MAX_NUM)

#define SX_COS_DEI_CHECK_RANGE(dei) SX_CHECK_MAX(dei, COS_DEI_MAX_NUM)

#define SX_COS_DSCP_CHECK_RANGE(dscp) SX_CHECK_MAX(dscp, COS_DSCP_MAX_NUM)

#define SX_COS_EXP_CHECK_RANGE(exp) SX_CHECK_MAX(exp, COS_EXP_MAX_NUM)

#define SX_COS_ECN_CHECK_RANGE(ecn) SX_CHECK_MAX(ecn, COS_ECN_MAX_NUM)

#define SX_COS_IEEE_PRIO_CHECK_RANGE(ieee) SX_CHECK_MAX(ieee, COS_IEEE_PRIO_MAX_NUM)

#define SX_COS_POOL_ID_INVALID UINT32_MAX

#define SX_COS_PORT_PTP_SHAPER_MAX_BURST_SIZE 52
#define SX_COS_PORT_PTP_SHAPER_MAX_CREDITS    112
#define SX_COS_PORT_PTP_SHAPER_MIN_CREDITS    1

/**
 * SX_COS_ETS_ELEMENT_CONFIG define maximum element hierarchy value
 */
#define SX_COS_ETS_ELEMENT_CONFIG_HIERARCHY_MAX 253

/**
 * Define value that represent the infinite static PG/TC/port.POOL configuration
 */
#define SX_COS_SB_STATIC_BUFF_INFINIT_VAL 0xFFFFFFFF

/*********/
/* ENUMS */
/*********/

/**
 * sx_cos_tc_group_id_t enumerated type is used to store
 * traffic class groups.
 */
typedef enum sx_cos_tc_group_id {
    SX_COS_TC_GROUP_ID_0 = 0, /**< traffic class group 0 */
    SX_COS_TC_GROUP_ID_1 = 1, /**< traffic class group 1 */
    SX_COS_TC_GROUP_ID_2 = 2, /**< traffic class group 2 */
    SX_COS_TC_GROUP_ID_3 = 3, /**< traffic class group 3 */
    SX_COS_TC_GROUP_ID_4 = 4, /**< traffic class group 4 */
    SX_COS_TC_GROUP_ID_5 = 5, /**< traffic class group 5 */
    SX_COS_TC_GROUP_ID_6 = 6, /**< traffic class group 6 */
    SX_COS_TC_GROUP_ID_7 = 7, /**< traffic class group 7 */
    SX_COS_TC_GROUP_ID_8 = 8, /**< traffic class group 8 */
    SX_COS_TC_GROUP_ID_9 = 9, /**< traffic class group 9 */
    SX_COS_TC_GROUP_ID_10 = 10, /**< traffic class group 10 */
    SX_COS_TC_GROUP_ID_11 = 11, /**< traffic class group 11 */
    SX_COS_TC_GROUP_ID_12 = 12, /**< traffic class group 12 */
    SX_COS_TC_GROUP_ID_13 = 13, /**< traffic class group 13 */
    SX_COS_TC_GROUP_ID_14 = 14, /**< traffic class group 14 */
    SX_COS_TC_GROUP_ID_15 = 15, /**< traffic class group 15 */
    SX_COS_TC_GROUP_ID_16 = 16, /**< traffic class group 16 */
    SX_COS_TC_GROUP_ID_MIN = SX_COS_TC_GROUP_ID_0, /**< minimum traffic class group  */
    SX_COS_TC_GROUP_ID_MAX = SX_COS_TC_GROUP_ID_16 /**< maximum traffic class group */
} sx_cos_tc_group_id_t;

/**
 * sx_cos_ets_sub_group_id_t enumerated type is used to store
 * sub group id.
 */
typedef enum sx_cos_ets_sub_group_id {
    SX_COS_ETS_SUB_GROUP_ID_0_E = 0, /**< sub group id 0 */
    SX_COS_ETS_SUB_GROUP_ID_1_E = 1, /**< sub group id 1 */
    SX_COS_ETS_SUB_GROUP_ID_2_E = 2, /**< sub group id 2 */
    SX_COS_ETS_SUB_GROUP_ID_3_E = 3, /**< sub group id 3 */
    SX_COS_ETS_SUB_GROUP_ID_4_E = 4, /**< sub group id 4 */
    SX_COS_ETS_SUB_GROUP_ID_5_E = 5, /**< sub group id 5 */
    SX_COS_ETS_SUB_GROUP_ID_6_E = 6, /**< sub group id 6 */
    SX_COS_ETS_SUB_GROUP_ID_7_E = 7, /**< sub group id 7 */
    SX_COS_ETS_SUB_GROUP_ID_15_E = 15, /**< sub group id 15 */
    SX_COS_ETS_SUB_GROUP_ID_MIN_E = SX_COS_ETS_SUB_GROUP_ID_0_E, /**< minimum sub group id  */
    SX_COS_ETS_SUB_GROUP_ID_MAX_E = SX_COS_ETS_SUB_GROUP_ID_15_E /**< maximum sub group id */
} sx_cos_ets_sub_group_id_t;

/**
 * sx_cos_ets_group_id_t enumerated type is used to store
 * group id.
 */
typedef enum sx_cos_ets_group_id {
    SX_COS_ETS_GROUP_ID_0_E = 0, /**< group id 0 */
    SX_COS_ETS_GROUP_ID_1_E = 1, /**< group id 1 */
    SX_COS_ETS_GROUP_ID_2_E = 2, /**< group id 2 */
    SX_COS_ETS_GROUP_ID_3_E = 3, /**< group id 3 */
    SX_COS_ETS_GROUP_ID_4_E = 4, /**< group id 4 */
    SX_COS_ETS_GROUP_ID_5_E = 5, /**< group id 5 */
    SX_COS_ETS_GROUP_ID_6_E = 6, /**< group id 6 */
    SX_COS_ETS_GROUP_ID_7_E = 7, /**< group id 7 */
    SX_COS_ETS_GROUP_ID_MIN_E = SX_COS_ETS_GROUP_ID_0_E, /**< minimum group id  */
    SX_COS_ETS_GROUP_ID_MAX_E = SX_COS_ETS_GROUP_ID_7_E /**< maximum group id */
} sx_cos_ets_group_id_t;

/**
 * sx_cos_ets_hierarchy_t enumerated type is used to store
 * ets .
 */
typedef enum sx_cos_ets_hierarchy {
    SX_COS_ETS_HIERARCHY_PORT_E = 0, /**< port level */
    SX_COS_ETS_HIERARCHY_GROUP_E = 1, /**< group level */
    SX_COS_ETS_HIERARCHY_SUB_GROUP_E = 2, /**< sub group level */
    SX_COS_ETS_HIERARCHY_TC_E = 3, /**< TC level */
    SX_COS_ETS_HIERARCHY_MIN_E = SX_COS_ETS_HIERARCHY_PORT_E, /**< minimum group id  */
    SX_COS_ETS_HIERARCHY_MAX_E = SX_COS_ETS_HIERARCHY_TC_E /**< maximum group id */
} sx_cos_ets_hierarchy_t;

/**
 * sx_cos_trust_level_t enumerated type is used to store port
 * trust level.
 */
typedef enum sx_cos_trust_level {
    SX_COS_TRUST_LEVEL_PORT = SXD_COS_TRUST_LEVEL_PORT_E, /**< port trust level */
    SX_COS_TRUST_LEVEL_USER = SXD_COS_TRUST_LEVEL_USER_E, /**< user trust level */
    SX_COS_TRUST_LEVEL_DSCP = SXD_COS_TRUST_LEVEL_DSCP_E, /**< DSCP trust level */
    SX_COS_TRUST_LEVEL_BOTH = SXD_COS_TRUST_LEVEL_BOTH_E, /**< BOTH trust level */
    SX_COS_TRUST_LEVEL_MIN = SX_COS_TRUST_LEVEL_PORT,   /**< minimum trust level */
    SX_COS_TRUST_LEVEL_MAX = SX_COS_TRUST_LEVEL_BOTH,   /**< maximum trust level */
    SX_COS_TRUST_LEVEL_L2 = SX_COS_TRUST_LEVEL_USER,    /**< L2 trust level */
    SX_COS_TRUST_LEVEL_L3 = SX_COS_TRUST_LEVEL_DSCP,    /**< L3 trust level */
} sx_cos_trust_level_t;

/**
 * sx_cos_max_bw_units_t enumerated type is used to note
 * a bw unit types
 */
typedef enum sx_cos_max_bw_units {
    SX_COS_MAX_BW_UNITS_RATE_LIMITER_DISABLED = SXD_COS_BW_UNITS_DISABLED_E,        /**< Rate limiter disabled */
    SX_COS_MAX_BW_UNITS_100_MBPS = SXD_COS_BW_UNITS_100_MBPS_E,                 /**< 100 Mbps */
    SX_COS_MAX_BW_UNITS_1_GBPS = SXD_COS_BW_UNITS_1_GBPS_E,                     /**< 1 Gbps */
    SX_COS_MAX_BW_UNITS_MIN = SX_COS_MAX_BW_UNITS_RATE_LIMITER_DISABLED,            /**< Minimum bw unit type */
    SX_COS_MAX_BW_UNITS_MAX = SX_COS_MAX_BW_UNITS_1_GBPS                    /**< Maximum bw type */
} sx_cos_max_bw_units_t;

/**
 * sx_cos_arbitration_t enumerated type is used to note
 * an arbiter type
 */
typedef enum sx_cos_arbitration {
    SX_COS_ARBITRATION_DWRR = SXD_COS_ARBITRATION_DWRR_E,  /**< DWRR arbiter */
    SX_COS_ARBITRATION_SP = SXD_COS_ARBITRATION_SP_E,      /**< SP   arbiter */
    SX_COS_ARBITRATION_MIN = SX_COS_ARBITRATION_DWRR,    /**< Minimum arbiter type */
    SX_COS_ARBITRATION_MAX = SX_COS_ARBITRATION_SP       /**< Maximum arbiter type */
} sx_cos_arbitration_t;

/**
 * sx_cos_port_qcn_mode_t enumerated type is used to note port
 * qcn mode.
 */
typedef enum sx_cos_port_qcn_mode {
    SX_COS_PORT_QCN_MODE_INTERIOR_READY, /**< CN-TAGs can be output on this egress port */
    SX_COS_PORT_QCN_MODE_INTERIOR,  /**< CN-TAGs are not output on this egress port (for both CNM and regular traffic) */
    SX_COS_PORT_QCN_MODE_MIN = SX_COS_PORT_QCN_MODE_INTERIOR_READY,   /**< minimum trust level */
    SX_COS_PORT_QCN_MODE_MAX = SX_COS_PORT_QCN_MODE_INTERIOR,   /**< maximum trust level */
} sx_cos_port_qcn_mode_t;

typedef enum sx_cos_port_buff_alpha {
    SX_COS_PORT_BUFF_ALPHA_0_E = 0x00,
    SX_COS_PORT_BUFF_ALPHA_1_128_E = 0x01,
    SX_COS_PORT_BUFF_ALPHA_1_64_E = 0x02,
    SX_COS_PORT_BUFF_ALPHA_1_32_E = 0x03,
    SX_COS_PORT_BUFF_ALPHA_1_16_E = 0x04,
    SX_COS_PORT_BUFF_ALPHA_1_8_E = 0x05,
    SX_COS_PORT_BUFF_ALPHA_1_4_E = 0x06,
    SX_COS_PORT_BUFF_ALPHA_1_2_E = 0x07,
    SX_COS_PORT_BUFF_ALPHA_1_E = 0x08,
    SX_COS_PORT_BUFF_ALPHA_2_E = 0x09,
    SX_COS_PORT_BUFF_ALPHA_4_E = 0x0A,
    SX_COS_PORT_BUFF_ALPHA_8_E = 0x0B,
    SX_COS_PORT_BUFF_ALPHA_16_E = 0x0C,
    SX_COS_PORT_BUFF_ALPHA_32_E = 0x0D,
    SX_COS_PORT_BUFF_ALPHA_64_E = 0x0E,
    SX_COS_PORT_BUFF_ALPHA_INFINITY_E = 0xFF
} sx_cos_port_buff_alpha_e;

/**
 *  sx_cos_port_buff_type_e defines list of possible buffer
 *  types which we can have
 */
typedef enum sx_cos_port_buff_type {
    SX_COS_PORT_BUFF_TYPE_MASTER_E = 1,
    SX_COS_PORT_BUFF_TYPE_SLAVE_E = 2,

    SX_COS_PORT_BUFF_TYPE_MIN_E = SX_COS_PORT_BUFF_TYPE_MASTER_E,
    SX_COS_PORT_BUFF_TYPE_MAX_E = SX_COS_PORT_BUFF_TYPE_SLAVE_E
} sx_cos_port_buff_type_e;

/**
 *  sx_cos_port_buff_num_e defines list of possible number of
 *  buffers which we can have per single logical port
 */
typedef enum sx_cos_port_buff_num {
    SX_COS_PORT_BUFF_NUM_MASTER_E = 1,
    SX_COS_PORT_BUFF_NUM_MASTER_SLAVE_E = 2,

    SX_COS_PORT_BUFF_NUM_MIN_E = SX_COS_PORT_BUFF_NUM_MASTER_E,
    SX_COS_PORT_BUFF_NUM_MAX_E = SX_COS_PORT_BUFF_NUM_MASTER_SLAVE_E
} sx_cos_port_buff_num_e;

#define FOREACH_COS_BUFFER_MAX_MODE(F)                                    \
    F(SX_COS_BUFFER_MAX_MODE_STATIC_E = 0, "Static")                      \
    F(SX_COS_BUFFER_MAX_MODE_DYNAMIC_E = 1, "Dynamic")                    \
    F(SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E = 2, "Buffer Units")          \
    F(SX_COS_BUFFER_MAX_MODE_MIN_E = SX_COS_BUFFER_MAX_MODE_STATIC_E, "") \
    F(SX_COS_BUFFER_MAX_MODE_MAX_E = SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E, "")

typedef enum sx_cos_buffer_max_mode {
    FOREACH_COS_BUFFER_MAX_MODE(SX_GENERATE_ENUM)
} sx_cos_buffer_max_mode_e;

#define FOREACH_COS_PORT_BUFF_POOL_DIRECTION(F)                                              \
    F(SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E = 0, "Ingress")                              \
    F(SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E = 1, "Egress")                                \
    F(SX_COS_PORT_BUFF_POOL_DIRECTION_MIN_E = SX_COS_PORT_BUFF_POOL_DIRECTION_INGRESS_E, "") \
    F(SX_COS_PORT_BUFF_POOL_DIRECTION_MAX_E = SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E, "")

typedef enum sx_cos_port_buff_pool_direction {
    FOREACH_COS_PORT_BUFF_POOL_DIRECTION(SX_GENERATE_ENUM)
} sx_cos_port_buff_pool_direction_e;

typedef enum sx_cos_pool_active_state {
    SX_COS_POOL_ACTIVE_E = 0,
    SX_COS_POOL_NOT_ACTIVE_E = 1,
} sx_cos_pool_active_state_e;

typedef enum sx_cos_max_occupancy_clear {
    SX_COS_MAX_OCCUPANCY_CLEAR_OFF_E = 0,
    SX_COS_MAX_OCCUPANCY_CLEAR_ON_E = 1
} sx_cos_max_occupancy_clear_e;

typedef enum sx_cos_buffer_type {
    SX_COS_DATA_BUFFER_E = 0,
    SX_COS_BUFFER_RESVERED1_E = 1,
} sx_cos_buffer_type_e;

typedef enum sx_cos_port_buff_attr_type {
    SX_COS_INGRESS_PORT_ATTR_E,
    SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
    SX_COS_EGRESS_PORT_ATTR_E,
    SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
    SX_COS_MULTICAST_ATTR_E,
    SX_COS_MULTICAST_PORT_ATTR_E,
    SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E,
    SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E,
    SX_COS_PORT_BUFF_ATTR_RESERVED1_E,
    SX_COS_PORT_BUFF_ATTR_RESERVED2_E,
    SX_COS_PORT_BUFF_ATTR_RESERVED3_E,
    SX_COS_PORT_BUFF_ATTR_RESERVED4_E,
} sx_cos_port_buff_attr_type_e;

typedef enum sx_cos_pool_info {
    SX_COS_POOL_INFO_USER_POOL_E = 0,
    SX_COS_POOL_INFO_DEFAULT_DATA_INGRESS_E,
    SX_COS_POOL_INFO_DEFAULT_DATA_EGRESS_E,
    SX_COS_POOL_INFO_DEFAULT_DESCRIPTOR_INGRESS_E,
    SX_COS_POOL_INFO_DEFAULT_DESCRIPTOR_EGRESS_E,
    SX_COS_POOL_INFO_DEFAULT_INGRESS_MANAGMENT_E,
    SX_COS_POOL_INFO_DEFAULT_EGRESS_MANAGMENT_E,
    SX_COS_POOL_INFO_DEFAULT_MULTICAST_E,

    SX_COS_POOL_INFO_MIN = SX_COS_POOL_INFO_USER_POOL_E,
    SX_COS_POOL_INFO_MAX = SX_COS_POOL_INFO_DEFAULT_MULTICAST_E
} sx_cos_pool_info_e;

/**
 * sx_cos_port_lanes_width_e defines the valid number of lanes
 * for port width
 */
typedef enum sx_cos_port_lanes_width {
    SX_COS_PORT_1X_LANES_WIDTH_E = 1,
    SX_COS_PORT_2X_LANES_WIDTH_E = 2,
    SX_COS_PORT_4X_LANES_WIDTH_E = 4,
    SX_COS_PORT_8X_LANES_WIDTH_E = 8
} sx_cos_port_lanes_width_e;

typedef uint32_t sx_cos_pool_id_t;

typedef uint32_t sx_cos_priority_group_t;

typedef uint32_t buffer_units_t;
typedef uint32_t basis_points_t;

typedef struct sx_cos_pool_attr {
    sx_cos_port_buff_pool_direction_e pool_dir;
    buffer_units_t                    pool_size;
    sx_cos_buffer_max_mode_e          mode;
    sx_cos_buffer_type_e              buffer_type;
    boolean_t                         infinite_size; /**< if true pool size is reserved */
    sx_cos_pool_info_e                pool_info;
} sx_cos_pool_attr_t;

/**********************************************
 *  DEFINITIONS
 ***********************************************/

/**
 * sx_cos_priority_t is used to store priority value
 */
typedef uint8_t sx_cos_priority_t;

/**
 * sx_cos_traffic_class_t is used to store traffic class value
 */
typedef uint8_t sx_cos_traffic_class_t;

/**
 * SX_COS_TRAFFIC_CLASS_MIN defines minimum traffic class value
 */
#define SX_COS_TRAFFIC_CLASS_MIN 0
/**
 * SX_COS_TRAFFIC_CLASS_MAX defines maximum traffic class value
 */
#define SX_COS_TRAFFIC_CLASS_MAX 7
/**
 * SX_COS_TRAFFIC_CLASS_MIN_MAX defines 'minimum,maximum' value
 */
#define SX_COS_TRAFFIC_CLASS_MIN_MAX SX_COS_TRAFFIC_CLASS_MIN, SX_COS_TRAFFIC_CLASS_MAX
/**
 * SX_COS_TRAFFIC_CLASS_CHECK_RANGE defines a traffic class check range macro
 */
#define SX_COS_TRAFFIC_CLASS_CHECK_RANGE(tc) SX_CHECK_MAX(tc, SX_COS_TRAFFIC_CLASS_MAX)

/**
 * sx_cos_dscp_prio_table_t is used to store dscp priority table
 */
typedef sxd_cos_prio_dscp_table_t sx_cos_dscp_prio_table_t;

/**
 * sx_cos_dscp_t is used to store dscp value
 */
typedef uint8_t sx_cos_dscp_t;

/**
 * sx_cos_stacking_tclass_regen_table_t is used to store stacking tclass regen table
 */
typedef sxd_cos_stacking_tclass_regen_table_t sx_cos_stacking_tclass_regen_table_t;

/**
 * sx_cos_receive_queue_t is used to store receive queue value
 */
typedef uint8_t sx_cos_receive_queue_t;

/**
 * SX_COS_RECEIVE_QUEUE_MIN defines minimum receive queue value
 */
#define SX_COS_RECEIVE_QUEUE_MIN 0
/**
 * SX_COS_RECEIVE_QUEUE_MAX defines maximum receive queue value
 */
#define SX_COS_RECEIVE_QUEUE_MAX 23
/**
 * SX_COS_RECEIVE_QUEUE_MIN_MAX defines 'minimum,maximum' value
 */
#define SX_COS_RECEIVE_QUEUE_MIN_MAX SX_COS_RECEIVE_QUEUE_MIN, SX_COS_RECEIVE_QUEUE_MAX
/**
 * SX_COS_RECEIVE_QUEUE_CHECK_RANGE defines a receive queue check range macro
 */
#define SX_COS_RECEIVE_QUEUE_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_COS_RECEIVE_QUEUE_MAX)

/**
 * sx_cos_bw_allocation_t is used to store bandwidth allocation value
 */
typedef uint8_t sx_cos_bw_allocation_t;

/**
 * sx_cos_max_bw_value_t is used to store max bandwidth allocation value
 */
typedef uint8_t sx_cos_max_bw_value_t;

/**
 * sx_cos_tc_config_params_t structure is used to store
 * shaping per-tc parameters
 */
typedef struct sx_cos_tc_config_params {
    sx_cos_traffic_class_t tc;              /**< Traffic class ID (0-7) to be configured */
    boolean_t              group_update;    /**< mask bit: 1 = update 'tc_group' field, 0 = don't */
    boolean_t              bw_update;       /**< mask bit: 1 = update  'bw_allocation' field, 0 = don't */
    boolean_t              rate_update;     /**< mask bit: 1 = update  'max_bw_value/unit' fields, 0 = don't */
    sx_cos_tc_group_id_t   tc_group;        /**< Traffic class group [0..7 , 15(NO group assigned to tc)]. */
    sx_cos_bw_allocation_t bw_allocation;   /**< Bandwidth percentage guaranteed to traffic_class within its group. */
    sx_cos_max_bw_value_t  max_bw_value;    /**< Maximal bandwidth allowed for the use traffic_class. */
    sx_cos_max_bw_units_t  max_bw_units;    /**< Maximal bandwidth value units. */
    boolean_t              is_valid;        /**< is tc valid. */
} sx_cos_tc_config_params_t;

/**
 * sx_cos_global_shaper_params_t structure is used to store
 * shaping per-port parameters
 */
typedef struct sx_cos_global_shaper_params {
    boolean_t             rate_update;      /**< mask bit: TRUE = update  'max_bw_value/unit' fields, FALSE = don't */
    sx_cos_max_bw_value_t max_bw_value;     /**< Maximal bandwidth allowed for the port (0..255) */
    sx_cos_max_bw_units_t max_bw_units;     /**< Maximal bandwidth value units (SX_COS_MAX_BW_UNITS_RATE_LIMITER_DISABLED,
                                             *     SX_COS_MAX_BW_UNITS_100_MBPS or SX_COS_MAX_BW_UNITS_1_GBPS) */
} sx_cos_global_shaper_params_t;

/**
 * sx_cos_port_ets_gen_config_params_t structure is used to store
 * general port shaper and arbiters attributes.
 */
typedef struct sx_cos_port_ets_gen_config_params {
    boolean_t             rate_update;      /**< mask bit: TRUE = update rate fields, FALSE = don't, used only in SET operation */
    boolean_t             arbiter_update;   /**< mask bit: TRUE = update arbiters fields, FALSE = don't, used only in SET operation */
    sx_cos_max_bw_value_t max_bw_value;     /**< max bandwidth value (0..255) */
    sx_cos_max_bw_units_t max_bw_units;     /**< max bandwidth units (SX_COS_MAX_BW_UNITS_RATE_LIMITER_DISABLED,
                                            *     SX_COS_MAX_BW_UNITS_100_MBPS or SX_COS_MAX_BW_UNITS_1_GBPS) */
    sx_cos_arbitration_t grp07_arb;         /**< select arbitration for groups 0-7 (SX_COS_ARBITRATION_DWRR or SX_COS_ARBITRATION_SP) */
    sx_cos_arbitration_t grp15_arb;         /**< select arbitration for group 15 (SX_COS_ARBITRATION_DWRR or SX_COS_ARBITRATION_SP) */
    sx_cos_arbitration_t glob_arbiter;      /**< arbitration value for Global arbiter (only SX_COS_ARBITRATION_SP supported) */
} sx_cos_port_ets_gen_config_params_t;

/**
 * sx_cos_pfc_threshold_t is used to store PFC threshold value
 */
typedef sxd_cos_pfc_threshold_t sx_cos_pfc_threshold_t;

/**
 * sx_cos_capabilities_t structure is used to store
 * cos capabilities data.
 */
typedef struct sx_cos_capabilities {
    uint8_t max_policers_per_port; /**< max port policers      */
    uint8_t max_policers_global;   /**< max global policers    */
} sx_cos_capabilities_t;

/**
 * sx_cos_qcn_profile_id_t is used to store the profile ID.
 */
typedef uint32_t sx_cos_qcn_profile_id_t;

/**
 * sx_cos_qcn_tc_queue_set_point_t is used to store the set point of the queue
 */
typedef uint32_t sx_cos_qcn_tc_queue_set_point_t;

/**
 * sx_cos_qcn_tc_weight_t is used to store the weight to the change in queue length.
 */
typedef int32_t sx_cos_qcn_tc_weight_t;

/**
 * sx_cos_qcn_tc_sample_base_t is used to store the sample base.
 */
typedef uint32_t sx_cos_qcn_tc_sample_base_t;

/**
 * Congestion point identifier.
 */
typedef uint64_t sx_cos_qcn_cpid_t;

/**
 * sx_cos_qcn_tc_params_t structure is used to store
 * qcn tc parameters
 */
typedef struct sx_cos_qcn_tc_params {
    sx_cos_qcn_tc_queue_set_point_t q_set_point;        /**< the set point of for the queue in octet. */
    sx_cos_qcn_tc_weight_t          weight;             /**< weight to be given to the change in queue length. */
    sx_cos_qcn_tc_sample_base_t     sample_base;        /**< the minimum number of octet between CNM PDUs */
    uint32_t                        min_header_octets;  /**< the minimum header octets. */
} sx_cos_qcn_tc_params_t;

/**
 * sx_cos_qcn_profile_params_t structure is used to store
 * qcn parameters per traffic class.
 */
typedef struct sx_cos_qcn_profile_params {
    sx_cos_qcn_tc_params_t tc_params[RM_API_COS_TRAFFIC_CLASS_NUM];
} sx_cos_qcn_profile_params_t;

/**
 * sx_cos_qcn_tc_params_t structure is used to store
 * qcn tc parameters
 */
typedef struct sx_cos_qcn_params {
    sx_cos_priority_t cnm_priority;         /**< the CNM packet PCP priority to be used */
} sx_cos_qcn_params_t;

/**
 * sx_cos_timer_value_t is used to store cos timer value.
 */
typedef uint16_t sx_cos_timer_value_t;

/**
 * sx_cos_port_buff_size_t is used to store buffer size value.
 */
typedef uint16_t sx_cos_port_buff_size_t;

/**
 * sx_cos_port_buff_params_t structure is used to store
 * cos buffer data. All sizes are stored in KBs
 */
typedef struct sx_cos_port_buff_params {
    sx_cos_port_buff_size_t size;
    sx_cos_port_buff_size_t xof_threshold;
    sx_cos_port_buff_size_t xon_threshold;
} sx_cos_port_buff_params_t;

typedef uint8_t sx_cos_port_buff_t;

/**
 * sx_cos_port_prio_buff_t structure is used to store the mapping between a
 * priority and the 8 buffers.
 */
typedef struct sx_cos_port_prio_buff_t {
    uint8_t prio_to_buff[RM_API_COS_PORT_PRIO_MAX + 1];
} sx_cos_port_prio_buff_t;

/**
 * sx_cos_pcp_t structure is used to stores the PCP values.
 */
typedef uint8_t sx_cos_pcp_t;

/**
 * sx_cos_dei_t structure is used to stores the DEI bit.
 */
typedef uint8_t sx_cos_dei_t;

/**
 * sx_cos_ieee_prio_t structure is used to stores the IEEE priority values.
 */
typedef uint8_t sx_cos_ieee_prio_t;

/**
 * sx_cos_pcp_dei_t structure is used to stores PCP and DEI values.
 */
typedef struct sx_cos_pcp_dei {
    sx_cos_pcp_t pcp;
    sx_cos_dei_t dei;
} sx_cos_pcp_dei_t;

/**
 * sx_cos_rewrite_enable_t structure is used to stores PCP/DEI,
 * DSCP and EXP rewrite enable values.
 */
typedef struct sx_cos_rewrite_enable {
    boolean_t rewrite_pcp_dei;
    boolean_t rewrite_dscp;
    boolean_t rewrite_exp;
} sx_cos_rewrite_enable_t;

/**
 * sx_cos_color_t is used to store traffic color values.
 */
typedef uint8_t sx_cos_color_t;

/**
 * sx_cos_priority_color_t structure is used to stores switch priority and color values.
 */
typedef struct sx_cos_priority_color {
    sx_cos_priority_t priority;
    sx_cos_color_t    color;
} sx_cos_priority_color_t;

/**
 * sx_cos_exp_t structure is used to stores the EXP values.
 */
typedef uint8_t sx_cos_exp_t;

/**
 * sx_cos_ecn_t structure is used to stores the ECN values.
 */
typedef uint8_t sx_cos_ecn_t;

/**
 * sx_cos_pcp_dei_rewrite_e structure is used to stores the PCP, DEI rewrite values.
 */
typedef enum sx_cos_pcp_dei_rewrite {
    SX_COS_PCP_DEI_REWRITE_PRESERVE_E = 0,
    SX_COS_PCP_DEI_REWRITE_DISABE_E = 2,
    SX_COS_PCP_DEI_REWRITE_ENABLE_E = 3,
    SX_COS_PCP_DEI_REWRITE_MIN_E = SX_COS_PCP_DEI_REWRITE_PRESERVE_E,
    SX_COS_PCP_DEI_REWRITE_MAX_E = SX_COS_PCP_DEI_REWRITE_ENABLE_E
} sx_cos_pcp_dei_rewrite_e;

typedef enum sx_cos_ecn_type {
    SX_COS_ECN_NON_ECT_E = 0,
    SX_COS_ECN_ECT0_E = 2,
    SX_COS_ECN_ECT1_E = 1,
    SX_COS_ECN_CE_E = 3,
    SX_COS_ECN_TYPE_MIN_E = SX_COS_ECN_NON_ECT_E,
    SX_COS_ECN_TYPE_MAX_E = SX_COS_ECN_CE_E
} sx_cos_ecn_type_e;

/**
 * sx_cos_dscp_rewrite_e structure is used to choose if we will rewrite the DSCP values.
 */
typedef enum sx_cos_dscp_rewrite {
    SX_COS_DSCP_REWRITE_PRESERVE_E = 0,
    SX_COS_DSCP_REWRITE_DISABLE_E = 2,
    SX_COS_DSCP_REWRITE_ENABLE_E = 3,
    SX_COS_DSCP_REWRITE_MIN_E = SX_COS_DSCP_REWRITE_PRESERVE_E,
    SX_COS_DSCP_REWRITE_MAX_E = SX_COS_DSCP_REWRITE_ENABLE_E
} sx_cos_dscp_rewrite_e;

/**
 * sx_tunnel_cos_dscp_action_e structure is used to choose from where the packet will get the DSCP field.
 */
typedef enum sx_tunnel_cos_dscp_action {
    SX_COS_DSCP_ACTION_PRESERVE_E = 0, /**< only decap*/
    SX_COS_DSCP_ACTION_COPY_E = 1, /**< encap/decap*/
    SX_COS_DSCP_ACTION_SET_E = 2, /**< only encap*/
    SX_COS_DSCP_ACTION_MIN_E = SX_COS_DSCP_ACTION_PRESERVE_E,
    SX_COS_DSCP_ACTION_MAX_E = SX_COS_DSCP_ACTION_SET_E
} sx_tunnel_cos_dscp_action_e;

/**
 * sx_cos_ets_element_config_t structure is used to stores the ETS elements config values.
 */
typedef struct sx_cos_ets_element_config {
    uint8_t   element_hierarchy;   /**< TC=3 sub-group=2 group=1 port=0 ptp-shaper enabled=254 */
    uint8_t   element_index;   /**< index in the hierarchy */
    uint8_t   next_element_index;   /**< index of the connect element in the lower hierarchy */
    boolean_t min_shaper_enable;     /**< true=enabled, false=disabled */
    boolean_t packets_mode;          /**< 0=bytes mode, 1=packets mode. applies to both min and max shaper.
                                      *  for Spectrum packets mode is supported only for TClasses for CPU port */
    uint32_t  min_shaper_rate;    /**< min shaper rate */
    boolean_t max_shaper_enable;     /**< true=enabled, false=disabled */
    uint32_t  max_shaper_rate;    /**< max shaper rate - Units of 1000bps */
    boolean_t dwrr_enable;     /**< DWRR configuration enable, Enables configuration of the dwrr and dwrr_weight */
    boolean_t dwrr;            /**< 0=strict priority, 1=DWRR */
    uint8_t   dwrr_weight;   /**< dwrr weight of the elements in the lower hierarchy level (0,...,100) */
} sx_cos_ets_element_config_t;

/**
 * sx_cos_rate_based_ecn_config_t structure is used to stores the rate based ecn config values.
 */
typedef struct sx_cos_rate_based_ecn_config {
    boolean_t rate_based_ecn_enable;     /**< true=enabled false-disabled */
    uint32_t  rate_based_ecn_threshold;    /**< rate above which the packets are ECN-marked by percentage that is defined in sx_api_cos_redecn_rate_based_set  */
} sx_cos_rate_based_ecn_config_t;

/**
 * sx_cos_ets_ptp_shaper_params structure is used to store the ptp shaper config parameters
 */
typedef struct sx_cos_ets_ptp_shaper_params {
    uint8_t time_exp;                               /** The base-time-interval for updating the shapers tokens (for all hierarchies).
                                                     *   Value = 2 ^ shapers_time_exp * (1 + shaper_time_mantisa) * 32nSec */
    uint8_t time_mantissa;                          /** The base-time-interval for updating the shapers tokens (for all hierarchies).
                                                     *   Value = 2 ^ shapers_time_exp * (1 + shaper_time_mantisa) * 32nSec */
    uint8_t shaper_inc;                             /** Number of tokens added to shaper on each update. Units of 8B */
    uint8_t shaper_bs;                              /** Max shaper Burst size. Burst size is 2^max_shaper_bs * 512 [bits] */
    uint8_t port_to_shaper_credits;                 /** For split ports: range 1..57. For non-split ports: range 1..112 */
    int32_t ing_timestamp_inc;                     /** Ingress timestamp increment. 2's complement */
    int32_t egr_timestamp_inc;                     /** Egress timestamp increment. 2's complement */
} sx_cos_ets_ptp_shaper_params_t;

/**
 * sx_cos_ets_ptp_shaper_port_speed enumerator is used to note port speed
 */
typedef enum sx_cos_ets_ptp_port_speed {
    SX_COS_ETS_PTP_PORT_SPEED_100M = 0,                            /**< 100M */
    SX_COS_ETS_PTP_PORT_SPEED_1000M,                               /**< 1G */
    SX_COS_ETS_PTP_PORT_SPEED_10G,                                 /**< 10G */
    SX_COS_ETS_PTP_PORT_SPEED_25G,                                 /**< 25G */
    SX_COS_ETS_PTP_PORT_SPEED_40G,                                 /**< 40G */
    SX_COS_ETS_PTP_PORT_SPEED_50G,                                 /**< 50G */
    SX_COS_ETS_PTP_PORT_SPEED_100G,                                /**< 100G */
    SX_COS_ETS_PTP_PORT_SPEED_MAX = SX_COS_ETS_PTP_PORT_SPEED_100G, /**< MAX */
    SX_COS_ETS_PTP_PORT_SPEED_1G = SX_COS_ETS_PTP_PORT_SPEED_1000M, /**< 1G */
    SX_COS_ETS_PTP_PORT_SPEED_NUM = SX_COS_ETS_PTP_PORT_SPEED_MAX + 1,
} sx_cos_ets_ptp_port_speed_e;

typedef struct sx_cos_buffer_max {
    sx_cos_buffer_max_mode_e mode;
    union {
        basis_points_t           size;
        sx_cos_port_buff_alpha_e alpha;
    } max;
} sx_cos_buffer_max_t;

typedef struct sx_cos_buff_pipeline_latency {
    boolean_t      override_default;
    buffer_units_t size;
} sx_cos_buff_pipeline_latency_t;

typedef struct sx_cos_ingress_port_buff_attr {
    buffer_units_t   size;
    sx_cos_pool_id_t pool_id;
} sx_cos_ingress_port_buff_attr_t;

typedef struct sx_cos_ingress_port_pg_buff_attr {
    buffer_units_t                 size;
    sx_cos_priority_group_t        pg;
    boolean_t                      is_lossy;
    buffer_units_t                 xon;
    buffer_units_t                 xoff;
    uint32_t                       pool_id; /**< /deprecated This field is deprecated and will be removed in the future. */
    sx_cos_buff_pipeline_latency_t pipeline_latency; /**< valid only for lossy */
} sx_cos_ingress_port_pg_buff_attr_t;

typedef struct sx_cos_egress_port_buff_attr {
    buffer_units_t size;
    uint32_t       pool_id;
} sx_cos_egress_port_buff_attr_t;

typedef struct sx_cos_egress_port_tc_buff_attr {
    buffer_units_t         size;
    sx_cos_traffic_class_t tc;
    sx_cos_pool_id_t       pool_id; /**< /deprecated This field is deprecated and will be removed in the future. */
} sx_cos_egress_port_tc_buff_attr_t;

typedef struct sx_cos_multicast_buff_attr {
    buffer_units_t    size;
    sx_cos_priority_t sp;
    sx_cos_pool_id_t  pool_id; /**< /deprecated This field is deprecated and will be removed in the future. */
} sx_cos_multicast_buff_attr_t;

typedef struct sx_cos_multicast_port_buff_attr {
    buffer_units_t   size;
    sx_cos_pool_id_t pool_id; /**< /deprecated This field is deprecated and will be removed in the future. */
} sx_cos_multicast_port_buff_attr_t;

typedef struct sx_cos_ingress_port_shared_buff_attr {
    sx_cos_buffer_max_t max;
    sx_cos_pool_id_t    pool_id;
} sx_cos_ingress_port_shared_buff_attr_t;

typedef struct sx_cos_ingress_port_pg_shared_buff_attr {
    sx_cos_buffer_max_t     max;
    sx_cos_priority_group_t pg;
    sx_cos_pool_id_t        pool_id;
} sx_cos_ingress_port_pg_shared_buff_attr_t;

typedef struct sx_cos_egress_port_shared_buff_attr {
    sx_cos_buffer_max_t max;
    sx_cos_pool_id_t    pool_id;
} sx_cos_egress_port_shared_buff_attr_t;

typedef struct sx_cos_egress_port_tc_shared_buff_attr {
    sx_cos_buffer_max_t    max;
    sx_cos_traffic_class_t tc;
    sx_cos_pool_id_t       pool_id;
} sx_cos_egress_port_tc_shared_buff_attr_t;

typedef struct sx_cos_multicast_shared_buff_attr {
    sx_cos_buffer_max_t max;
    sx_cos_priority_t   sp;
    sx_cos_pool_id_t    pool_id;
} sx_cos_multicast_shared_buff_attr_t;

typedef struct sx_cos_multicast_port_shared_buff_attr {
    sx_cos_buffer_max_t max;
    sx_cos_pool_id_t    pool_id;
} sx_cos_multicast_port_shared_buff_attr_t;

typedef struct sx_cos_port_buffer_attr {
    sx_cos_port_buff_attr_type_e type;
    union {
        sx_cos_ingress_port_buff_attr_t    ingress_port_buff_attr;
        sx_cos_ingress_port_pg_buff_attr_t ingress_port_pg_buff_attr;
        sx_cos_egress_port_buff_attr_t     egress_port_buff_attr;
        sx_cos_egress_port_tc_buff_attr_t  egress_port_tc_buff_attr;
        sx_cos_multicast_buff_attr_t       multicast_buff_attr;
        sx_cos_multicast_port_buff_attr_t  multicast_port_buff_attr;
    } attr;
} sx_cos_port_buffer_attr_t;

typedef struct sx_cos_port_shared_buffer_attr {
    sx_cos_port_buff_attr_type_e type;
    union {
        sx_cos_ingress_port_shared_buff_attr_t    ingress_port_shared_buff_attr;
        sx_cos_ingress_port_pg_shared_buff_attr_t ingress_port_pg_shared_buff_attr;
        sx_cos_egress_port_shared_buff_attr_t     egress_port_shared_buff_attr;
        sx_cos_egress_port_tc_shared_buff_attr_t  egress_port_tc_shared_buff_attr;
        sx_cos_multicast_shared_buff_attr_t       multicast_shared_buff_attr;
        sx_cos_multicast_port_shared_buff_attr_t  multicast_port_shared_buff_attr;
    } attr;
} sx_cos_port_shared_buffer_attr_t;

typedef struct buffer_status {
    buffer_units_t free_size_ingress;
    buffer_units_t free_size_egress;
} sx_buffer_status_t;

typedef struct sx_cos_buff_statistic {
    buffer_units_t curr_occupancy;
    buffer_units_t watermark;
} sx_cos_buff_statistic_t;

typedef struct sx_port_statistic_usage_params {
    sx_port_log_id_t* log_port_list_p;
    uint32_t          port_cnt;
    struct {
        sx_cos_port_buff_attr_type_e port_params_type;    /*Union type*/
        uint32_t                     port_params_cnt;    /*Union number of entries*/
        union {
            sx_cos_priority_group_t *port_pg_list_p;
            sx_cos_traffic_class_t  *port_tc_list_p;
            sx_cos_pool_id_t        *ingress_port_pool_list_p;
            sx_cos_pool_id_t        *egress_port_pool_list_p;
            sx_cos_priority_t       *mc_switch_prio;
        } port_param;
    } sx_port_params;
} sx_port_statistic_usage_params_t;

typedef struct sx_port_occupancy_statistics {
    sx_port_log_id_t log_port;
    struct {
        sx_cos_port_buff_attr_type_e port_params_type;        /*Union type*/
        union {
            sx_cos_priority_group_t port_pg;
            sx_cos_traffic_class_t  port_tc;
            sx_cos_pool_id_t        ingress_port_pool;
            sx_cos_pool_id_t        egress_port_pool;
            sx_cos_priority_t       mc_switch_prio;
        } port_param;
    } sx_port_params;

    sx_cos_buff_statistic_t statistics; /**< Ordinary buffer statistics */

    struct {
        uint8_t                 cnt;                                    /**< indicates how many instances of statistics were returned */
        sx_cos_buff_statistic_t statistics[SX_COS_PORT_BUFF_NUM_MAX_E]; /**< used for 8x lanes interface, since there we have two buffers */
    } sx_cos_buff_occupancy_lst;
} sx_port_occupancy_statistics_t;

typedef struct sx_cos_pool_occupancy_statistics {
    sx_cos_pool_id_t        pool_id;
    sx_cos_buff_statistic_t statistics;
} sx_cos_pool_occupancy_statistics_t;

typedef struct sx_cos_dscp_switch_prio_color {
    sx_cos_dscp_t           dscp;
    sx_cos_priority_color_t priority_color;
} sx_cos_dscp_switch_prio_color_t;

typedef struct sx_cos_pcpdei_switch_prio_color {
    sx_cos_pcp_dei_t        pcp_dei;
    sx_cos_priority_color_t priority_color;
} sx_cos_pcpdei_switch_prio_color_t;

typedef struct sx_cos_exp_ecn_priority_color {
    sx_cos_exp_t            exp;
    sx_cos_ecn_t            ecn;
    sx_cos_priority_color_t priority_color;
} sx_cos_exp_ecn_priority_color_t;

typedef struct sx_cos_priority_ieee_priority {
    sx_cos_priority_t  priority;
    sx_cos_ieee_prio_t ieee_priority;
} sx_cos_priority_ieee_priority_t;

typedef struct sx_cos_buff_consumption {
    int            reserved_ingress;
    int            reserved_egress;
    buffer_units_t pipeline_latency;
    buffer_units_t management_ingress;
    buffer_units_t management_egress;
} sx_cos_buff_consumption_t;


#endif /* SX_COS_H_ */
