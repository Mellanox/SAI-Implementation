/*
 *  Copyright (C) 2010-2017. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */
#ifndef __SX_MPLS_H__
#define __SX_MPLS_H__

#define SX_MPLS_MAX_LABELS_TO_MATCH           (2)
#define SX_MPLS_MAX_SUPPORTED_LABELS_TO_MATCH (1)
#define SX_MPLS_MIN_LABEL_ID                  0x0
#define SX_MPLS_MAX_LABEL_ID                  0xFFFFF

#define SX_MPLS_IS_LABEL_ID_IN_RANGE(labelid) \
    SX_CHECK_MAX(labelid, SX_MPLS_MAX_LABEL_ID)

typedef uint32_t sx_mpls_label_t;
typedef uint8_t sx_mpls_ilm_table_id_t;

/**
 * MPLS router interface attributes
 */
typedef struct sx_mpls_rif_attr {
    boolean_t              mpls_enabled;
    uint16_t               mpls_mtu;
    sx_mpls_ilm_table_id_t ilm_table_id;
} sx_mpls_router_interface_attr_t;

/**
 * MPLS TTL model
 */
typedef enum sx_mpls_ttl_model_type {
    SX_MPLS_TTL_MODEL_TYPE_UNIFORM, /**< MPLS TTL uniform model */
    SX_MPLS_TTL_MODEL_TYPE_MINIMUM, /**< MPLS TTL minimum model */
    SX_MPLS_TTL_MODEL_TYPE_MIN = SX_MPLS_TTL_MODEL_TYPE_UNIFORM,
    SX_MPLS_TTL_MODEL_TYPE_MAX = SX_MPLS_TTL_MODEL_TYPE_MINIMUM
} sx_mpls_ttl_model_type_e;

/**
 * MPLS general params
 */
typedef struct sx_mpls_general_params {
    uint32_t                 label_id_range_min; /**< minimum label value that can be accepted by device */
    uint32_t                 label_id_range_max; /**< maximum label value that can be accepted by device */
    uint32_t                 reserved_label_id_max; /**< packets with labels 0 - reserved_label_space_max are accepted */
    sx_mpls_ttl_model_type_e ttl_model; /**< MPLS TTL model */
} sx_mpls_general_params_t;

/**
 * QoS params for MPLS next hopm
 */
typedef struct sx_mpls_qos_params {
    boolean_t remap_qos_from_inner_dscp; /** whether to remap QoS parameters from IP header that is exposed or keep current QoS values */
    boolean_t remap_qos_from_inner_exp; /** whether to remap QoS parameters from MPLS header that is exposed or keep current QoS values */
} sx_mpls_qos_params_t;


#endif /* __SX_MPLS_H__ */
