/*
 *  Copyright (C) 2010-2017. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_POLICER_H_
#define SX_POLICER_H_

#include <sx/sxd/sxd_policer.h>

#include <sx/sdk/sx_swid.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * SX_POLICER_ID_INVALID define Invalid Policer ID
 */
#define SX_POLICER_ID_INVALID (0xFFFFFFFF)

typedef uint64_t sx_policer_id_t;

/**
 * Placeholder for Filter to be used with the iterator
 */
typedef uint32_t sx_policer_id_filter_t;

/**
 * Define maximum global policers number
 */
#define SX_POLICER_MAX_POLICERS_GLOBAL 9

/**
 * Define minimum policer CBS
 */
#define SX_POLICER_CBS_MIN (0x10)

/**
 * Define maximum policer CBS
 */
#define SX_POLICER_CBS_MAX (1 << 30)

/**
 * Define minimum policer EBS
 */
#define SX_POLICER_EBS_MIN (1)

/**
 * Define maximum policer EBS
 */
#define SX_POLICER_EBS_MAX (1 << 30)

/**
 * Define minimum policer CIR
 */
#define SX_POLICER_CIR_MIN (1)

/**
 * Define CIR units when metering traffic rate (Mbps)
 */
#define SX_POLICER_CIR_UNIT_TRAFFIC_RATE (5)

/**
 * Define maximum policer CIR (in units) when metering traffic rate
 */
#define SX_POLICER_CIR_MAX_UNITS_TRAFFIC_RATE (0xFFFFFF / SX_POLICER_CIR_UNIT_TRAFFIC_RATE)

/**
 * Define maximum policer CIR (in units) when metering packet rate
 */
#define SX_POLICER_CIR_MAX_UNITS_PACKET_RATE (2566 * 6536)

/**
 * Define CIR units when metering packet rate (fps)
 */
#define SX_POLICER_CIR_UNIT_PACKET_RATE (1)

/*********/
/* ENUMS */
/*********/

/**
 * sx_policer_action_t enumerated type is used to store
 * policer action.
 */
typedef enum sx_policer_action {
    SX_POLICER_ACTION_FORWARD = 0, /**< Forward packets */
    SX_POLICER_ACTION_DISCARD = 1, /**<  Discard packets */
    SX_POLICER_ACTION_FORWARD_SET_RED_COLOR = 2,
    SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR = 2,
    SX_POLICER_ACTION_MIN = SX_POLICER_ACTION_FORWARD,
    SX_POLICER_ACTION_MAX = SX_POLICER_ACTION_FORWARD_SET_RED_COLOR,
} sx_policer_action_t;

/**
 * sx_policer_rate_type_e enumerated type is used to store
 * global rate type.
 */
typedef enum sx_policer_rate_type {
    SX_POLICER_RATE_TYPE_SX_E = 0, /* for backward compatibility */
    SX_POLICER_RATE_TYPE_SINGLE_RATE_E = 1,
    SX_POLICER_RATE_TYPE_DUAL_RATE_E = 2,
    SX_POLICER_RATE_TYPE_MIN = SX_POLICER_RATE_TYPE_SX_E,
    SX_POLICER_RATE_TYPE_MAX = SX_POLICER_RATE_TYPE_DUAL_RATE_E,
} sx_policer_rate_type_e;


/**
 * sx_policer_meter_t enumerated type is used to store
 * policer operations.
 */
typedef enum sx_policer_meter {
    SX_POLICER_METER_PACKETS = 0,     /**< Meter packets */
    SX_POLICER_METER_TRAFFIC = 1,       /**< Meter traffic */
    SX_POLICER_METER_MIN = SX_POLICER_METER_PACKETS,
    SX_POLICER_METER_MAX = SX_POLICER_METER_TRAFFIC,
} sx_policer_meter_t;

/**
 * sx_policer_ir_units_e enumerated type is used to store
 * cir & eir units type.
 */
typedef enum sx_policer_ir_units {
    SX_POLICER_IR_UNITS_10_POWER_6_E = 0,     /**<10^6 */
    SX_POLICER_IR_UNITS_10_POWER_3_E = 1,       /**10^3 */
    SX_POLICER_IR_UNITS_MIN_E = SX_POLICER_IR_UNITS_10_POWER_6_E,
    SX_POLICER_IR_UNITS_MAX_E = SX_POLICER_IR_UNITS_10_POWER_3_E,
} sx_policer_ir_units_e;

static __attribute__((__used__)) const char* sx_policer_ir_units_str[] = {
    "10^6",
    "10^3",
};
#define SX_POLICER_IR_UNITS_STR_LEN (sizeof(sx_policer_ir_units_str) / sizeof(char*))
#define SX_POLICER_IR_UNITS_STR(index)                      \
    (SX_CHECK_MAX(index, SX_POLICER_IR_UNITS_STR_LEN - 1) ? \
     sx_policer_ir_units_str[index] : "UNKNOWN")

static __attribute__((__used__)) const char* sx_policer_rate_type_str[] = {
    "SX",
    "SINGLE",
    "DUAL",
};
#define SX_POLICER_RATE_TYPE_STR_LEN (sizeof(sx_policer_rate_type_str) / sizeof(char*))
#define SX_POLICER_RATE_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_POLICER_RATE_TYPE_STR_LEN - 1) ? \
     sx_policer_rate_type_str[index] : "UNKNOWN")

static __attribute__((__used__)) const char* sx_policer_meter_type_str[] = {
    "PACKETS",
    "TRAFFIC",
};
#define SX_POLICER_METER_TYPE_STR_LEN (sizeof(sx_policer_meter_type_str) / sizeof(char*))
#define SX_POLICER_METER_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_POLICER_METER_TYPE_STR_LEN - 1) ? \
     sx_policer_meter_type_str[index] : "UNKNOWN")

static __attribute__((__used__)) const char* sx_policer_action_str[] = {
    "FORWARD",
    "DISCARD",
    "SET COLOR",
};
#define SX_POLICER_ACTION_STR_LEN (sizeof(sx_policer_action_str) / sizeof(char*))
#define SX_POLICER_ACTION_STR(index)                      \
    (SX_CHECK_MAX(index, SX_POLICER_ACTION_STR_LEN - 1) ? \
     sx_policer_action_str[index] : "UNKNOWN")

/**
 * Policer attributes:
 *
 * ir_units (CIR and EIR units) possible values for traffic metering:
 * - in SwitchX:
 *      not in use.
 *  - in Spectrum:
 *      10^3 or 10^6. relevant only for traffic metering.
 *
 * CIR possible values for traffic metering:
 * - in SwitchX:
 *      Unit is SX_POLICER_CIR_UNIT_TRAFFIC_RATE (5Mbps)
 *      Values: From 1 to SX_POLICER_CIR_MAX_UNITS_TRAFFIC_RATE
 *      The resulting rate is <Unit> * <Value>
 * - in Spectrum:
 *      Unit is ir_units bits/sec (see ir_units field)
 *      Maximum value is 2Tbps (after ir_units calculation)
 *
 * CIR possible values for packet metering:
 * - in SwitchX:
 *      Unit is SX_POLICER_CIR_UNIT_PACKET_RATE (1 fps)
 *      Values:
 *          From 100 to 6500 with step 100
 *          From 6536 to SX_POLICER_CIR_MAX_UNITS_PACKET_RATE with step 6536
 *          The resulting rate is <Unit> * <Value>
 * - in Spectrum:
 *      Unit is 1 packet/sec
 *      Maximum value is 2 Gigs packets per second
 *
 * EIR possible values for traffic metering:
 * - in SwitchX:
 *      not in use.
 * - in Spectrum:
 *      Unit is ir_units bits/sec (see ir_units_field)
 *      Maximum value is 2Tbps (after ir_units calculation)
 *
 * EIR possible values for packet metering:
 * - in SwitchX:
 *      not in use.
 * - in Spectrum:
 *      Unit is 1 packet/sec
 *      Maximum value is 2 Gigs packets per second
 *
 * CBS and EBS possible values for traffic metering
 * - in SwitchX:
 *      Unit is 1MByte
 *      Values: 8, 16, 32, 64, 128, 256, 512, 1024
 *      Resulting rate is limited to the range of 8 MByte to 1024 MByte
 * - in Spectrum:
 *      burst size is (2^CBS)*512 [bits]
 *      range is from CIR*rate*50uSec to 32Gbit while rate is according
 *      to ir_units (10^3/10^6)
 *      Minimum value is 4
 *      Maximum value is 30
 *
 * CBS possible values for packet metering and CIR <= 6500fps:
 * - in SwitchX:
 *      Unit is 1 frame
 *      Values are powers of 2 from 2 to SX_POLICER_CBS_MAX
 *      EBS must be equal to CBS
 * - in Spectrum:
 *      burst size is (2^CBS) [packets]
 *      range is from CIR*50uSec to 32Gbit
 *      Minimum value is 4
 *      Maximum value is 30
 *
 * CBS and EBS possible values for packet metering and CIR > 6500fps:
 * - in SwitchX:
 *      Unit is 1 frame
 *      Values: 8000000, 16000000, 32000000, 64000000, 128000000, 256000000,
 *              512000000, 1024000000
 * - in Spectrum:
 *      burst size is 2^CBS [packets]
 *      range is from CIR*50uSec to 32Gbit
 *      Minimum value is 4
 *      Maximum value is 30
 *
 * Yellow and Red actions:
 * in SwitchX:
 *      - For traffic metering - may be FORWARD and DROP
 *      - For packet metering and CIR < 6500fps - may be DROP only
 *      - For packet metering and CIR > 6500fps - may be FORWARD and DROP
 * in Spectrum:
 *      - Yellow action must be SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR
 *      - Red action may be SX_POLICER_ACTION_FORWARD_SET_RED_COLOR
 *        or SX_POLICER_ACTION_DISCARD
 *
 * Rate type:
 * - in SwitchX:
 *      Must be SX_POLICER_RATE_TYPE_SX_E.
 *  - in Spectrum:
 *      SX_POLICER_RATE_TYPE_SINGLE_RATE_E or SX_POLICER_RATE_TYPE_DUAL_RATE_E.
 *
 * Color aware:
 * - in SwitchX:
 *      not in use.
 *  - in Spectrum:
 *      Determines if the policer decisions are made according to the packets' color.
 *
 * Is host interface policer:
 * - in SwitchX:
 *      not in use.
 *  -in Spectrum:
 *     Will the policer be bound to a host interface trap group.
 */
typedef struct sx_policer_attributes {
    sx_policer_meter_t meter_type;  /** Packets/Bytes. Supported devices:
                                     *  SwitchX, SwitchX2, Spectrum. */
    uint32_t cbs;            /** Committed Burst Size. Supported devices:
                              *  SwitchX, SwitchX2, Spectrum. */
    uint32_t ebs;            /** Excess Burst Size. Supported devices:
                              *      SwitchX, SwitchX2, Spectrum. */
    uint32_t cir;            /** Committed Information Rate.
                              *      Supported devices: SwitchX, SwitchX2, Spectrum. */
    sx_policer_action_t yellow_action; /** Packets that exceed cbs will be handled with this action.
                                        *  Supported devices: SwitchX, SwitchX2 */
    sx_policer_action_t red_action; /** Packets that exceed ebs will be handled with this action.
                                     *  Supported devices: SwitchX, SwitchX2, Spectrum. */
    uint32_t               eir; /** Excess Information Rate. Supported devices: Spectrum */
    sx_policer_rate_type_e rate_type;   /** SX/single-rate/dual-rate.
                                         *  Supported devices: Spectrum.*/
    boolean_t color_aware;   /** Is the policer color aware.
                              *    Supported devices: Spectrum. */
    boolean_t is_host_ifc_policer; /** Is the policer a host_ifc policer.
                                    * Supported devices: Spectrum. */
    sx_policer_ir_units_e ir_units; /** CIR and EIR units (10^3 or 10^6)
                                     * Supported devices: Spectrum. */
} sx_policer_attributes_t;

/**
 * sx_policer_params_t structure is used to store initialization parameters of
 * Policer Library.
 */
typedef struct sx_policer_params {
    uint8_t priority_group_num;      /**< Number of priority groups */
} sx_policer_params_t;

/**
 * sx_policer_counters_clear_t structure is used to store policer counter reset values.
 */
typedef struct sx_policer_counters_clear {
    boolean_t clear_violation_counter; /**< clear violation counter */
} sx_policer_counters_clear_t;

/**
 * sx_policer_counters_t structure is used to store policer counters values.
 */
typedef struct sx_policer_counters {
    uint64_t violation_counter; /**< violation counter */
} sx_policer_counters_t;


#endif /* SX_POLICER_H_ */
