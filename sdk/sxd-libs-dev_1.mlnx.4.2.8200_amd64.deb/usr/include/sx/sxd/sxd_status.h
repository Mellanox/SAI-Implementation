/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_STATUS_H__
#define __SXD_STATUS_H__

#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_status_t
 * Enumerated type - Used to provide function return values.
 */
typedef enum sxd_status {
    SXD_STATUS_SUCCESS = 0,             /**< Success */
    SXD_STATUS_ERROR,                   /**< Error */
    SXD_STATUS_NO_RESOURCES,            /**< Not Enough Resources Left */
    SXD_STATUS_NO_MEMORY,               /**< No Memory */
    SXD_STATUS_PARAM_ERROR,             /**< Parameters Error */
    SXD_STATUS_NOT_INITIALIZED,         /**< Not Initialized */
    SXD_STATUS_DEVICE_OPEN_ERROR,       /**< Device Open Error */
    SXD_STATUS_DEVICE_CLOSE_ERROR,      /**< Device Close Error */
    SXD_STATUS_DEVICE_GET_ERROR,        /**< Device Get Error */
    SXD_STATUS_DEVICE_IOCTL_ERROR,      /**< Device IOCTL Error */
    SXD_STATUS_HANDLE_ERROR,            /**< Handle Error */
    SXD_STATUS_INVALID_ACCESS_CMD,      /**< Invalid Access Command */
    SXD_STATUS_TIMEOUT,                 /**< TimeOut */
    SXD_STATUS_CMD_UNSUPPORTED,         /**< Access Command unsupported */
    SXD_STATUS_NO_PATH_TO_DEVICE,       /**< No valid path to reach the device */
    SXD_STATUS_FW_ERROR,                /**< FW Error */
    SXD_STATUS_FW_BUSY,                 /**< FW Busy */
    SXD_STATUS_FW_NO_RESOURCES,     /**< FW Resource not available*/

    SXD_STATUS_MIN = SXD_STATUS_SUCCESS,            /**< Min ENUM value */
    SXD_STATUS_MAX = SXD_STATUS_FW_NO_RESOURCES,    /**< Max ENUM value */
} sxd_status_t;

/************************************************
 *  Global variables
 ***********************************************/

static __attribute__((__used__)) const char *sxd_status2str_arr[] = {
    /*SXD_STATUS_SUCCESS*/
    "SUCCESS",
    /*SXD_STATUS_ERROR*/
    "ERROR",
    /*SXD_STATUS_NO_RESOURCES*/
    "NO RESOURCES",
    /*SXD_STATUS_NO_MEMORY*/
    "NO MEMORY",
    /*SXD_STATUS_PARAM_ERROR*/
    "PARAM ERROR",
    /*SXD_STATUS_NOT_INITIALIZED*/
    "NOT INITIALIZED",
    /*SXD_STATUS_DEVICE_OPEN_ERROR*/
    "DEVICE OPEN ERROR",
    /*SXD_STATUS_DEVICE_CLOSE_ERROR*/
    "DEVICE CLOSE ERROR",
    /*SXD_STATUS_DEVICE_GET_ERROR*/
    "DEVICE GET ERROR",
    /*SXD_STATUS_DEVICE_IOCTL_ERROR*/
    "DEVICE IOCTL ERROR",
    /*SXD_STATUS_HANDLE_ERROR*/
    "HANDLE ERROR",
    /*SXD_STATUS_INVALID_ACCESS_CMD*/
    "INVALID ACCESS CMD",
    /*SXD_STATUS_TIMEOUT*/
    "TIMEOUT",
    /*SXD_STATUS_CMD_UNSUPPORTED*/
    "ACCESS COMMAND UNSUPPORTED",
    /*SXD_STATUS_NO_PATH_TO_DEVICE*/
    "No valid path to reach the device",
    /*SXD_STATUS_FW_ERROR*/
    "FW RETURN VALUE != SUCCESS",
    /*SXD_STATUS_FW_BUSY*/
    "FW BUSY",
    /*SXD_STATUS_FW_NO_RESOURCES*/
    "FW Resource unavailable"
};


/************************************************
 *  Macros
 ***********************************************/

/**
 * SXD_STATUS_CHECK_RANGE:
 * Check the validity of the supplied STATUS
 * STATUS - Status to be checked
 */
#define SXD_STATUS_CHECK_RANGE(STATUS) SXD_CHECK_RANGE(SXD_STATUS_MIN, (int)STATUS, SXD_STATUS_MAX)

/**
 * SXD_STATUS_MSG:
 *  Check the validity of the supplied STATUS & return string
 *  STATUS - Status to be checked
 */
#define SXD_STATUS_MSG(STATUS) SXD_STATUS_CHECK_RANGE(STATUS) ? sxd_status2str_arr[STATUS] : "Unknown return code"

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_STATUS_H__ */
