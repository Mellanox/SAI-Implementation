/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#if 0
/*! \main page Mellanox SwitchX API Guide
 *
 * \section intro_sec Introduction
 *
 * The SwitchX Ethernet SDK is a layered software stack, used for building a complete L2/L3 switching software.
 * The SwitchX SDK comprises of the SwitchX Driver (SxD) and the Application Libraries (AppLibs),
 * where each layer has its own independent application interface (APIs).
 * \image html SwitchXSDKSWcomponents.gif
 * \section sdk_sec SDK Libraries
 * The SDK library is a logic layer that enables porting standard-driven protocol stacks and management systems on top of the SwitchX features set.
 * The SDK libraries are used to invoke the SwitchX Driver APIs (SXD API) in order to invoke hardware configurations.
 *
 * \section sxd_sec SwitchX Driver
 * SwitchX is a hardware oriented layer that reflects register level interfaces.
 * For further information, refer to the Hardware Programmer Reference Manual.
 *
 */
#endif
#ifndef __SX_API_H__
#define __SX_API_H__

#include <sx/sxd/kernel_user.h>

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_init.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sx_api_applib_t enumerated type is used to note an
 * application library.
 */
typedef enum sx_api_applib {
    SX_API_FLOW_COUNTER = 1 << 0,   /**< Flow Counter Application Library */
        SX_API_POLICER = 1 << 1,    /**< Policer Application Library */
        SX_API_HOST_IFC = 1 << 2,   /**< Host Interface Application Library */
        SX_API_ETH_L2 = 1 << 3,     /**< Ethernet L2 Application Library */
        SX_API_ETH_L3 = 1 << 4,     /**< Ethernet L3 Application Library */
        SX_API_ACL = 1 << 5,        /**< ACL Application Library */
        SX_API_IB = 1 << 6,         /**< InfiniBand Application Library */
        SX_API_IB_ROUTER = 1 << 7,  /**< InfiniBand Router Application Library */
        SX_API_SPAN = 1 << 8,       /**< SPAN Application Library */
        SX_API_TUNNEL = 1 << 9,     /**< Tunnel Application Library */
} sx_api_applib_t;

/**
 * sx_api_arb_policy_t struct defines the internal sdk api
 * dispatching policy
 */
typedef enum sx_api_arb_policy {
    SX_API_ARB_POLICY_PROTOCOL,
    SX_API_ARB_POLICY_CLIENT,
    SX_API_ARB_POLICY_CMD_PRIORITY,
} sx_api_arb_policy_t;

static __attribute__((__used__)) const char* sx_api_arb_policy_str[] = {
    "SX_API_ARB_POLICY_PROTOCOL",
    "SX_API_ARB_POLICY_CLIENT",
    "SX_API_ARB_POLICY_CMD_PRIORITY",
};

#define SX_API_ARB_POLICY_STR_LEN (sizeof(sx_api_arb_policy_str) / sizeof(char*))
#define SX_API_ARB_POLICY_STR(index)                      \
    (SX_CHECK_MAX(index, SX_API_ARB_POLICY_STR_LEN - 1) ? \
     sx_api_arb_policy_str[index] : "UNKNOWN")

/**
 * sx_api_worker_arb_policy_t struct is used for holding all of the internal sdk api
 * dispatching arbitration mechanism
 */
typedef struct sx_api_worker_arb_policy {
    sx_api_arb_policy_t policy;
} sx_api_worker_arb_policy_t;

typedef struct sx_pipeline_latency_params {
    uint32_t  size;
    boolean_t pipeline_latency_valid;
} sx_pipeline_latency_params_t;

/**
 * sx_api_profile_t structure is part of the sx_api_sx_sdk_init_t structure
 * this is the same struct currently conveyed to the sxd api
 */
typedef struct ku_profile sx_api_profile_t;

/**
 * sx_api_pci_profile_t structure is part of the sx_api_sx_sdk_init_t structure
 * this is the same struct currently conveyed to the sxd api
 */
typedef struct sx_pci_profile sx_api_pci_profile_t;

/**
 * sx_api_sx_sdk_init_t structure is used to store various SwitchX
 * SDK init parameters.
 */
typedef struct sx_api_sx_sdk_init {
    uint32_t                     app_id; /**< Application unique ID */
    sx_api_profile_t             profile; /**< SwitchX init profile params */
    sx_api_pci_profile_t         pci_profile; /**< SwitchX init PCI profile params */
    uint32_t                     applibs_mask; /**< Application library mask*/
    sx_policer_params_t          policer_params; /**< Policer init params */
    sx_port_params_t             port_params; /**< Port lib init params */
    sx_topo_params_t             topo_params; /**< Topology init params */
    sx_lag_params_t              lag_params; /**< LAG lib init params */
    sx_vlan_params_t             vlan_params; /**< VLAN lib init params */
    sx_fdb_params_t              fdb_params; /**< FDB lib init params */
    sx_mstp_params_t             mstp_params; /**< MSTP lib init params */
    sx_router_params_t           router_params; /**< ETH L3 lib init params */
    sx_acl_params_t              acl_params; /**< ACL lib init params */
    sx_api_worker_arb_policy_t   arb_policy; /**< SwitchX API Internal dispatch policy */
    sx_flow_counter_params_t     flow_counter_params;   /**< Flow Counter lib init params */
    sx_router_profile_params_t   router_profile_params;     /**< ROUTER counter init params */
    sx_bridge_params_t           bridge_init_params; /**<802.1Q/802.1D init parameters */
    sx_tcam_opt_params_t         tcam_opt_params; /**< TCAM optimization parameters */
    sx_pipeline_latency_params_t pipeline_latency;     /**< Shared buffer pipeline latency size*/
} sx_api_sx_sdk_init_t;

typedef enum sx_async_api_notify_type {
    SX_ASYNC_API_NOTIFY_TYPE_ADD_ACL_RULE,
    SX_ASYNC_API_NOTIFY_TYPE_ADD_ROUTE,

    SX_ASYNC_API_NOTIFY_TYPE_MIN = SX_ASYNC_API_NOTIFY_TYPE_ADD_ACL_RULE,
    SX_ASYNC_API_NOTIFY_TYPE_MAX = SX_ASYNC_API_NOTIFY_TYPE_ADD_ROUTE,
} sx_async_api_notify_type_e;

typedef struct sx_acl_rule_async_notif_data_t {
    boolean_t is_add; /* add - true, delete - false */
    uint32_t  rule_num;
} sx_acl_rule_async_notif_data_t;

typedef struct sx_async_api_complete_notify_data {
    sx_async_api_notify_type_e type;
    union {
        sx_acl_rule_async_notif_data_t acl_rule_data;
    } dest;
} sx_async_api_complete_notify_data_t;

/**
 * Last digit:   API is compatible with previous versions.
 * Middle digit: API changes require code fixing.
 * First digit: API has completely changed.
 */
#define SX_API_VERSION "1.0.0"

/**
 * Version maximum string length.
 */
#define SX_API_VERSION_MAX_LEN 64

/**
 * Invalid Handle Definition
 */
#define SX_API_INVALID_HANDLE 0
/**
 * sx_api_sx_sdk_versions_t structure is used to store various SwitchX
 * SDK components version.
 */
typedef struct sx_api_sx_sdk_versions {
    char sx_sdk[SX_API_VERSION_MAX_LEN]; /**< SDK version array*/
    char sx_api[SX_API_VERSION_MAX_LEN]; /**< API version array*/
    char sx_sxd[SX_API_VERSION_MAX_LEN]; /**< SXD version array*/
} sx_api_sx_sdk_versions_t;

/**
 * SX API handle.
 */
typedef uint64_t sx_api_handle_t;

/**
 * sx_object_type_t is used to distinguish between different SDK objects.
 */
typedef enum sx_object_type {
    SX_OBJECT_TYPE_VRID = 1,
    SX_OBJECT_TYPE_RIF = 2,
    SX_OBJECT_TYPE_ECMP = 3,
    SX_OBJECT_TYPE_MIN = SX_OBJECT_TYPE_VRID,
    SX_OBJECT_TYPE_MAX = SX_OBJECT_TYPE_ECMP
} sx_object_type_t;

#define SX_OBJECT_TYPE_CHECK_RANGE(OBJECT_TYPE) \
    SX_CHECK_RANGE(SX_OBJECT_TYPE_MIN,          \
                   OBJECT_TYPE,                 \
                   SX_OBJECT_TYPE_MAX)          \

static __attribute__((__used__)) const char* sx_object_type_str[] = {
    "VRID",
    "RIF",
    "ECMP"
};

#define SX_OBJECT_TYPE_STR_LEN (sizeof(sx_object_type_str) / sizeof(char*))

#define SX_OBJECT_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_OBJECT_TYPE_STR_LEN - 1) ? \
     sx_object_type_str[index] : "UNKNOWN")

/**
 * sx_object_id_t structure is used as an abstract representation for SDK
 * object IDs.
 */
typedef struct sx_object_id {
    sx_object_type_t object_type;     /**< Object type */
    union {
        sx_router_id_t        vrid;  /**< Virtual router ID */
        sx_router_interface_t rif_id;         /**< Router interface ID */
        sx_ecmp_id_t          ecmp_id; /**< ECMP container ID */
    } object_id;
} sx_object_id_t;

#endif /* __SX_API_H__ */
