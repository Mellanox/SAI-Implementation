/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_STATUS_H__
#define __SX_STATUS_H__

#include <sx/sdk/sx_check.h>
#include <sx/sxd/sxd_status.h>

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sx_status_t
 * Enumerated type - Provides functions' return values.
 */
typedef enum sx_status {
    SX_STATUS_SUCCESS = 0,
    SX_STATUS_ERROR = 1,
    SX_STATUS_SDK_NOT_INITIALIZED = 2,
    SX_STATUS_INVALID_HANDLE = 3,
    SX_STATUS_COMM_ERROR = 4,
    SX_STATUS_NO_RESOURCES = 5,
    SX_STATUS_NO_MEMORY = 6,
    SX_STATUS_MEMORY_ERROR = 7,
    SX_STATUS_CMD_ERROR = 8,
    SX_STATUS_CMD_INCOMPLETE = 9,
    SX_STATUS_CMD_UNSUPPORTED = 10,
    SX_STATUS_CMD_UNPERMITTED = 11,
    SX_STATUS_PARAM_NULL = 12,
    SX_STATUS_PARAM_ERROR = 13,
    SX_STATUS_PARAM_EXCEEDS_RANGE = 14,
    SX_STATUS_MESSAGE_SIZE_ZERO = 15,
    SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT = 16,
    SX_STATUS_DB_ALREADY_INITIALIZED = 17,
    SX_STATUS_DB_NOT_INITIALIZED = 18,
    SX_STATUS_DB_NOT_EMPTY = 19,
    SX_STATUS_END_OF_DB = 20,
    SX_STATUS_ENTRY_NOT_FOUND = 21,
    SX_STATUS_ENTRY_ALREADY_EXISTS = 22,
    SX_STATUS_ENTRY_NOT_BOUND = 23,
    SX_STATUS_ENTRY_ALREADY_BOUND = 24,
    SX_STATUS_WRONG_POLICER_TYPE = 25,
    SX_STATUS_UNEXPECTED_EVENT_TYPE = 26,
    SX_STATUS_TRAP_ID_NOT_CONFIGURED = 27,
    SX_STATUS_INT_COMM_CLOSE = 28,
    SX_STATUS_RESOURCE_IN_USE = 29,
    SX_STATUS_EVENT_TRAP_ALREADY_ASSOCIATED = 30,
    SX_STATUS_ALREADY_INITIALIZED = 31,
    SX_STATUS_TIMEOUT = 32,
    SX_STATUS_MODULE_UNINITIALIZED = 33,
    SX_STATUS_UNSUPPORTED = 34,
    SX_STATUS_SX_UTILS_RETURNED_NON_ZERO = 35,
    SX_STATUS_PARTIALLY_COMPLETE = 36,
    SX_STATUS_ACCEPTED = 37,
    SX_STATUS_SXD_RETURNED_NON_ZERO = 101,
    /****************************************************/
    SX_STATUS_MIN = SX_STATUS_SUCCESS,
    SX_STATUS_MAX = SX_STATUS_SXD_RETURNED_NON_ZERO,
} sx_status_t;

static __attribute__((__used__)) const sx_status_t sxd_status2sx_status_arr[] = {
    /* SXD_STATUS_SUCCESS */
    SX_STATUS_SUCCESS,
    /* SXD_STATUS_ERROR */
    SX_STATUS_ERROR,
    /* SXD_STATUS_NO_RESOURCES */
    SX_STATUS_NO_RESOURCES,
    /* SXD_STATUS_NO_MEMORY */
    SX_STATUS_NO_MEMORY,
    /* SXD_STATUS_PARAM_ERROR */
    SX_STATUS_PARAM_ERROR,
    /* SXD_STATUS_NOT_INITIALIZED */
    SX_STATUS_ERROR,
    /* SXD_STATUS_DEVICE_OPEN_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_CLOSE_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_GET_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_IOCTL_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_HANDLE_ERROR */
    SX_STATUS_INVALID_HANDLE,
    /* SXD_STATUS_INVALID_ACCESS_CMD */
    SX_STATUS_CMD_ERROR,
    /* SXD_STATUS_TIMEOUT */
    SX_STATUS_TIMEOUT,
    /* SXD_STATUS_CMD_UNSUPPORTED */
    SX_STATUS_CMD_UNSUPPORTED,
    /* SXD_STATUS_NO_PATH_TO_DEVICE */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_BUSY */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_NO_RESOURCES */
    SX_STATUS_NO_RESOURCES
};

#define SXD_STATUS_TO_SX_STATUS(STATUS)                                 \
    SXD_STATUS_CHECK_RANGE(STATUS) ? sxd_status2sx_status_arr[STATUS] : \
    SX_STATUS_SXD_RETURNED_NON_ZERO

static inline sx_status_t sxd_status_to_sx_status(sxd_status_t sxd_status)
{
    return SXD_STATUS_TO_SX_STATUS((int)sxd_status);
}


/************************************************
 *  Macro definitions
 ***********************************************/


#define SX_STATUS_CHECK_RANGE(STATUS) SX_CHECK_RANGE(SX_STATUS_MIN, (int)STATUS, SX_STATUS_MAX)

#define SX_STATUS_MSG(STATUS) SX_STATUS_CHECK_RANGE(STATUS) ? sx_status2str_arr[STATUS] : "Unknown return code"


static __attribute__((__used__)) const char *sx_status2str_arr[] = {
    /*SX_STATUS_SUCCESS = 0*/
    "Success",

    /*SX_STATUS_ERROR = 1*/
    "Internal Error",

    /*SX_STATUS_SDK_NOT_INITIALIZED = 2*/
    "SwitchX SDK wasn't Initialized",

    /*SX_STATUS_INVALID_HANDLE = 3*/
    "Invalid Handle",

    /*SX_STATUS_COMM_ERROR = 4*/
    "Communication Error",

    /*SX_STATUS_NO_RESOURCES = 5*/
    "No More Resources",

    /*SX_STATUS_NO_MEMORY = 6*/
    "No More Memory",

    /*SX_STATUS_MEMORY_ERROR = 7*/
    "Memory Error",

    /*SX_STATUS_CMD_ERROR = 8*/
    "Command Error",

    /*SX_STATUS_CMD_INCOMPLETE = 9*/
    "Command Not Completed",

    /*SX_STATUS_CMD_UNSUPPORTED = 10*/
    "Command Unsupported",

    /*SX_STATUS_CMD_UNPERMITTED = 11*/
    "Command Unpermitted",

    /*SX_STATUS_PARAM_NULL = 12*/
    "Parameter NULL",

    /*SX_STATUS_PARAM_ERROR = 13*/
    "Parameter Error",

    /*SX_STATUS_PARAM_EXCEEDS_RANGE = 14*/
    "Parameter Exceeds Range",

    /*SX_STATUS_MESSAGE_SIZE_ZERO = 15*/
    "Message Size Exceeds Limit",

    /*SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT = 16*/
    "Message Size Exceeds Limit",

    /*SX_STATUS_DB_ALREADY_INITIALIZED = 17*/
    "Database Already Initialized",

    /*SX_STATUS_DB_NOT_INITIALIZED = 18*/
    "Database Wasn't Initialized",

    /*SX_STATUS_DB_NOT_EMPTY = 19*/
    "Database Not Empty",

    /*SX_STATUS_END_OF_DB = 20*/
    "End of Database",

    /*SX_STATUS_ENTRY_NOT_FOUND = 21*/
    "Entry Not Found",

    /*SX_STATUS_ENTRY_ALREADY_EXISTS = 22*/
    "Entry Already Exists",

    /*SX_STATUS_ENTRY_NOT_BOUND = 23*/
    "Entry Not Bound",

    /*SX_STATUS_ENTRY_ALREADY_BOUND = 24*/
    "Entry Already bound",

    /*SX_STATUS_WRONG_POLICER_TYPE = 25*/
    "Wrong Policer Type",

    /*SX_STATUS_UNEXPECTED_EVENT_TYPE = 26*/
    "Unexpected event type",

    /*SX_STATUS_TRAP_ID_NOT_CONFIGURED = 27*/
    "Trap ID not configured",

    /*SX_STATUS_INT_COMM_CLOSE = 28*/
    "Internal Communication close",

    /*SX_STATUS_RESOURCE_IN_USE = 29*/
    "Resource is in use",

    /*SX_STATUS_EVENT_TRAP_ALREADY_ASSOCIATED = 30*/
    "Trap ID is already associated to another trap priority",

    /*SX_STATUS_ALREADY_INITIALIZED = 31*/
    "Already initialized",

    /*SX_STATUS_TIMEOUT = 32*/
    "TIMEOUT",

    /*SX_STATUS_MODULE_UNINITIALIZED = 33*/
    "Module is uninitialized",

    /*SX_STATUS_UNSUPPORTED = 34*/
    "Operation Unsupported",

    /*SX_STATUS_SX_UTILS_RETURNED_NON_ZERO = 35*/
    "Utils return status is Non-Zero",

    /*SX_STATUS_PARTIALLY_COMPLETE = 36*/
    "Partially complete",

    /*SX_STATUS_ = 37*/
    "",

    /*SX_STATUS_ = 38*/
    "",

    /*SX_STATUS_ = 39*/
    "",

    /*SX_STATUS_ = 40*/
    "",

    /*SX_STATUS_ = 41*/
    "",

    /*SX_STATUS_ = 42*/
    "",

    /*SX_STATUS_ = 43*/
    "",

    /*SX_STATUS_ = 44*/
    "",

    /*SX_STATUS_ = 45*/
    "",

    /*SX_STATUS_ = 46*/
    "",

    /*SX_STATUS_ = 47*/
    "",

    /*SX_STATUS_ = 48*/
    "",

    /*SX_STATUS_ = 49*/
    "",

    /*SX_STATUS_ = 50*/
    "",

    /*SX_STATUS_ = 51*/
    "",

    /*SX_STATUS_ = 52*/
    "",

    /*SX_STATUS_ = 53*/
    "",

    /*SX_STATUS_ = 54*/
    "",

    /*SX_STATUS_ = 55*/
    "",

    /*SX_STATUS_ = 56*/
    "",

    /*SX_STATUS_ = 57*/
    "",

    /*SX_STATUS_ = 58*/
    "",

    /*SX_STATUS_ = 59*/
    "",

    /*SX_STATUS_ = 60*/
    "",

    /*SX_STATUS_ = 61*/
    "",

    /*SX_STATUS_ = 62*/
    "",

    /*SX_STATUS_ = 63*/
    "",

    /*SX_STATUS_ = 64*/
    "",

    /*SX_STATUS_ = 65*/
    "",

    /*SX_STATUS_ = 66*/
    "",

    /*SX_STATUS_ = 67*/
    "",

    /*SX_STATUS_ = 68*/
    "",

    /*SX_STATUS_ = 69*/
    "",

    /*SX_STATUS_ = 70*/
    "",

    /*SX_STATUS_ = 71*/
    "",

    /*SX_STATUS_ = 72*/
    "",

    /*SX_STATUS_ = 73*/
    "",

    /*SX_STATUS_ = 74*/
    "",

    /*SX_STATUS_ = 75*/
    "",

    /*SX_STATUS_ = 76*/
    "",

    /*SX_STATUS_ = 77*/
    "",

    /*SX_STATUS_ = 78*/
    "",

    /*SX_STATUS_ = 79*/
    "",

    /*SX_STATUS_ = 80*/
    "",

    /*SX_STATUS_ = 81*/
    "",

    /*SX_STATUS_ = 82*/
    "",

    /*SX_STATUS_ = 83*/
    "",

    /*SX_STATUS_ = 84*/
    "",

    /*SX_STATUS_ = 85*/
    "",

    /*SX_STATUS_ = 86*/
    "",

    /*SX_STATUS_ = 87*/
    "",

    /*SX_STATUS_ = 88*/
    "",

    /*SX_STATUS_ = 89*/
    "",

    /*SX_STATUS_ = 90*/
    "",

    /*SX_STATUS_ = 91*/
    "",

    /*SX_STATUS_ = 92*/
    "",

    /*SX_STATUS_ = 93*/
    "",

    /*SX_STATUS_ = 94*/
    "",

    /*SX_STATUS_ = 95*/
    "",

    /*SX_STATUS_ = 96*/
    "",

    /*SX_STATUS_ = 97*/
    "",

    /*SX_STATUS_ = 98*/
    "",

    /*SX_STATUS_ = 99*/
    "",

    /*SX_STATUS_ = 100*/
    "",

    /*SX_STATUS_SXD_RETURNED_NON_ZERO = 101*/
    "Driver's Return Status is Non-Zero",
};


#endif /* __SX_STATUS_H__ */
