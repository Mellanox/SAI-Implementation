/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_ACCESS_CMD_H__
#define __SX_ACCESS_CMD_H__

#include <sx/sdk/sx_check.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sx_access_cmd_t
 * Enumerated type - Used to note the command access required. *
 */
typedef enum sx_access_cmd {
    SX_ACCESS_CMD_NONE = 0,
    SX_ACCESS_CMD_ADD = 1,
    SX_ACCESS_CMD_EDIT = 2,
    SX_ACCESS_CMD_DELETE = 3,
    SX_ACCESS_CMD_DELETE_ALL = 4,
    SX_ACCESS_CMD_SOFT_ADD = 5,
    SX_ACCESS_CMD_SOFT_EDIT = 6,
    SX_ACCESS_CMD_SOFT_DELETE = 7,
    SX_ACCESS_CMD_TEST = 8,
    SX_ACCESS_CMD_APPLY = 9,
    SX_ACCESS_CMD_ENABLE = 10,
    SX_ACCESS_CMD_DISABLE = 11,
    SX_ACCESS_CMD_CREATE = 12,
    SX_ACCESS_CMD_DESTROY = 13,
    SX_ACCESS_CMD_COUNT = 14,
    SX_ACCESS_CMD_SET = 15,
    SX_ACCESS_CMD_UNSET = 16,
    SX_ACCESS_CMD_GET = 17,
    SX_ACCESS_CMD_GETNEXT = 18,
    SX_ACCESS_CMD_REGISTER = 19,
    SX_ACCESS_CMD_DEREGISTER = 20,
    SX_ACCESS_CMD_GET_ALL = 21,
    SX_ACCESS_CMD_TEST_HW = 22,
    SX_ACCESS_CMD_ADD_PORTS = 23,
    SX_ACCESS_CMD_DELETE_PORTS = 24,
    SX_ACCESS_CMD_BIND = 25,
    SX_ACCESS_CMD_UNBIND = 26,
    SX_ACCESS_CMD_GET_FIRST = 27,
    SX_ACCESS_CMD_REPLACE_ALL_PORTS = 28,
    SX_ACCESS_CMD_DELETE_ALL_PORTS = 29,
    SX_ACCESS_CMD_READY = 30,
    SX_ACCESS_CMD_READ = 31,
    SX_ACCESS_CMD_READ_CLEAR = 32,
    SX_ACCESS_CMD_CLEAR = 33,
    SX_ACCESS_CMD_DELETE_PORT = 34,
    SX_ACCESS_CMD_MIN = SX_ACCESS_CMD_NONE,
    SX_ACCESS_CMD_MAX = SX_ACCESS_CMD_DELETE_PORT,
} sx_access_cmd_t;

/************************************************
 *  Macro definitions
 ***********************************************/

#define SX_ACCESS_CMD_DEFAULT SX_ACCESS_CMD_NONE
#define SX_ACCESS_CMD_MIN_MAX SX_ACCESS_CMD_MIN, SX_ACCESS_CMD_MAX
#define SX_ACCESS_CMD_CHECK_RANGE(cmd) SX_CHECK_RANGE(SX_ACCESS_CMD_MIN, (int)cmd, SX_ACCESS_CMD_MAX)

static const char *sx_access_cmd_str[] = {
    "NONE",
    "ADD",
    "EDIT",
    "DELETE",
    "DELETE ALL",
    "SOFT-ADD",
    "SOFT-EDIT",
    "SOFT-DELETE",
    "TEST",
    "APPLY",
    "ENABLE",
    "DISABLE",
    "CREATE",
    "DESTROY",
    "COUNT",
    "SET",
    "UNSET",
    "GET",
    "GETNEXT",
    "REGISTER",
    "DEREGISTER",
    "GET ALL",
    "TEST HW",
    "ADD PORTS",
    "DELETE PORTS",
    "BIND",
    "UNBIND",
    "GET FIRST",
    "REPLACE_ALL_PORTS",
    "DELETE_ALL_PORTS",
    "READY",
    "READ",
    "READ CLEAR",
    "CLEAR",
    "DELETE_PORT",
};
static const int   sx_access_cmd_str_len = sizeof(sx_access_cmd_str) / sizeof(char*);

#define SX_ACCESS_CMD_STR(cmd)                           \
    (SX_CHECK_RANGE(0, (int)cmd, sx_access_cmd_str_len - \
                    1) ? sx_access_cmd_str[cmd] : "UNKNOWN")

#endif /* __SX_ACCESS_CMD_H__ */
