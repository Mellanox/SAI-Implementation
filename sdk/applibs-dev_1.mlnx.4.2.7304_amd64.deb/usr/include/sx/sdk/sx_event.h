/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_EVENT_H__
#define __SX_EVENT_H__

#include <sx/sdk/sx_check.h>


/***********************************************
*  Types definition
***********************************************/

/**
 * Event generation mode:
 ******************************************************************************
 * 00 - Do not generate.
 * 01 - Generate.
 */
typedef enum sx_event_generate_mode {
    SX_EVENT_GENERATE_MODE_DONT_GENRATE,
    SX_EVENT_GENERATE_MODE_GENRATE,
    SX_EVENT_GENERATE_MODE_GENRATE_SINGLE,
    SX_EVENT_GENERATE_MODE_MIN = SX_EVENT_GENERATE_MODE_DONT_GENRATE,
    SX_EVENT_GENERATE_MODE_MAX = SX_EVENT_GENERATE_MODE_GENRATE_SINGLE,
} sx_event_generate_mode_t;

#define SX_EVENT_GENERATE_MODE_DEFAULT SX_EVENT_GENERATE_MODE_DONT_GENRATE
#define SX_EVENT_GENERATE_MODE_MIN_MAX SX_EVENT_GENERATE_MODE_MIN, SX_EVENT_GENERATE_MODE_MAX
#define SX_EVENT_GENERATE_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_EVENT_GENERATE_MODE_MIN,   \
                   (int)mode,                    \
                   SX_EVENT_GENERATE_MODE_MAX)

static const char *sx_event_generate_mode_str[] = {
    "Don't Generate",
    "Generate",
    "Generate Single Event",
};
static const int   sx_event_generate_mode_str_len = sizeof(sx_event_generate_mode_str) / sizeof(char*);

#define SX_EVENT_GENERATE_MODE_STR(index) \
    (SX_CHECK_RANGE(0, index,             \
                    sx_event_generate_mode_str_len) ? sx_event_generate_mode_str[index] : "UNKNOWN")

#endif  /*      __SX_EVENT_H__  */
