/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_VLAN_DATA_H__
#define __SXD_EMAD_VLAN_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/**
 * SXD_EMAD_SPVM_MAX_VLANS define maximum VLANs supported by
 * one SPVM EMAD.
 */
#define SXD_EMAD_SPVM_MAX_VLANS 255

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_spvid_data_t structure is used to store SPVID
 * register data.
 */
typedef struct sxd_emad_spvid_data {
    sxd_emad_common_data_t common;
    struct ku_spvid_reg   *reg_data;
} sxd_emad_spvid_data_t;

/**
 * sxd_emad_spvm_vlan_data_t structure is used to store SPVM
 * vlan data.
 */
typedef struct sxd_emad_spvm_vlan_data {
    uint8_t  ingress_membership;
    uint8_t  egress_membership;
    uint8_t  untagged_membership;
    uint16_t vid;
} sxd_emad_spvm_vlan_data_t;

/**
 * sxd_emad_spvm_data_t structure is used to store SPVM
 * register data.
 */
typedef struct sxd_emad_spvm_data {
    sxd_emad_common_data_t common;
    struct ku_spvm_reg    *reg_data;
} sxd_emad_spvm_data_t;

/**
 * sxd_emad_spvtr_data_t structure is used to store SPVTR
 * register data.
 */
typedef struct sxd_emad_spvtr_data {
    sxd_emad_common_data_t common;
    struct ku_spvtr_reg   *reg_data;
} sxd_emad_spvtr_data_t;

/**
 * sxd_emad_spaft_data_t structure is used to store SPAFT
 * register data.
 */
typedef struct sxd_emad_spaft_data {
    sxd_emad_common_data_t common;
    struct ku_spaft_reg   *reg_data;
} sxd_emad_spaft_data_t;

/**
 * sxd_emad_spvc_data_t structure is used to store SPVC
 * register data.
 */
typedef struct sxd_emad_spvc_data {
    sxd_emad_common_data_t common;
    struct ku_spvc_reg    *reg_data;
} sxd_emad_spvc_data_t;

/**
 * sxd_emad_sver_data_t structure is used to store SVER
 * register data.
 */
typedef struct sxd_emad_sver_data {
    sxd_emad_common_data_t common;
    struct ku_sver_reg    *reg_data;
} sxd_emad_sver_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_VLAN_DATA_H__ */
