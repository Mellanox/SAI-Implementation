/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_RM_H__
#define __SXD_EMAD_PARSER_RM_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_rm_data.h>
#include <sx/sxd/sxd_emad_rm_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_rm_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function formats IDDD register layout from IDDD
 *  register data.
 *
 * @param[in] iddd_data - IDDD register data.
 * @param[out] iddd_reg - IDDD register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_iddd(sxd_emad_iddd_data_t *iddd_data,
                                 sxd_emad_iddd_reg_t  *iddd_reg);

/**
 *  This function formats IDDD register data from IDDD register
 *  layout.
 *
 * @param[out] iddd_data - IDDD register data.
 * @param[in] iddd_reg - IDDD register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_iddd(sxd_emad_iddd_data_t *iddd_data,
                                   sxd_emad_iddd_reg_t  *iddd_reg);

#endif /* __SXD_EMAD_PARSER_RM_H__ */
