/*
 *  Copyright (C) 2010-2015. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_NET_LIB_H__
#define __SX_NET_LIB_H__

#include <complib/sx_log.h>
#include <sx/sdk/sx_router.h>
#ifdef IB_PRESENT_FLAG
#include <sx/ib/sx_ib_router.h>
#endif
#include <sx/sxd/sxdev.h>
#include <net/if.h>
#include <sx/sdk/sx_types.h>
#include <netlink/msg.h>
#include <netlink/netlink.h>
#include <netlink/socket.h>
#include <netlink/genl/genl.h>
#include <netlink/genl/ctrl.h>

typedef enum if_state_t {
    IF_DOWN = 0,
    IF_UP,
    IF_CHANGE
} if_state_t;

#define MAX_IF_NAME_SIZE    IFNAMSIZ
#define EX_ETH_ALEN         20
#define EX_MAC_PREFIX_ALEN  14
#define SX_NET_MAX_ATTR     400
#define UNKNOWN_RIF         0xffff
#define UNKNOWN_VRID        0xff
#define UNKNOWN_SYS_IFINDEX 0
#define INVALID_DEV_ID      0
#define INVALID_SWID        0xFF
#define SX_MLAG_ID_MAX      1000
#define SX_MLAG_ID_MIN      1
#define INVALID_SLOT_ID     0
#define INVALID_SPLIT_INDEX 0

typedef struct nl_sock sx_nl_sock;
typedef sxd_ctrl_pack_t sx_ctrl_pack_t;
typedef sx_access_cmd_t sx_net_access_cmd_t;
typedef uint32_t system_ifindex;
typedef uint16_t sx_mlag_id_t;

typedef enum sx_net_if_event_t {
    SX_NET_EVENT_UNKNOWN = 0, /**< unknown event  */
    SX_NET_EVENT_IF_DOWN, /**< Interface link down event  */
    SX_NET_EVENT_IF_UP, /**< Interface link up event  */
    SX_NET_EVENT_IF_CREATED, /**< Interface link created event  */
    SX_NET_EVENT_IF_DELETED, /**< Interface link deleted event  */
    SX_NET_EVENT_PATH_UPDATE, /**< path update event  */
    SX_NET_EVENT_PATH_DEL,    /**< path delete event  */
    SX_NET_EVENT_MC_GROUP_JOIN, /**< multicast group join event  */
    SX_NET_EVENT_MC_GROUP_LEAVE, /**< multicast group leave event  */
    SX_NET_EVENT_MC_GROUP_DETAILS, /**< multicast group details event  */
    SX_NET_EVENT_CHNG_ACK,
/**< change moderation ack event  */
} sx_net_if_event_t;

typedef enum sx_net_if_event_group_t {
    SX_NET_EVENT_GROUP_IF_STATE_CHANGE = 0, /**< Interface state change event group */
    SX_NET_EVENT_GROUP_PATH_UPDATE,         /**< Interface path update event group */
    SX_NET_EVENT_GROUP_MULTICAST,           /**< Interface MC update event group */
    SX_NET_EVENT_GROUP_IPOIB_ALL,           /**< All IPOIB events: Path update & MC */
/**< Interface multicast event group */
} sx_net_if_event_group_t;

typedef enum sx_net_action_t {
    JOIN_MC_GROUP = 0, /**< join multicast group action type */
    DONT_JOIN_MC_GROUP,
/**< don't join multicast group action type */
} sx_net_action_t;

typedef enum sx_net_vlan_name_format_t {
    SX_NET_NAME_FORMAT_PREFIX_SWID = 0,     /**< swid<swid_num>_eth.<vlan_id> */
    SX_NET_NAME_FORMAT_PREFIX_VLAN,     /**< vlan<vlan_id> */
    SX_NET_NAME_FORMAT_MIN = SX_NET_NAME_FORMAT_PREFIX_SWID,
    SX_NET_NAME_FORMAT_MAX = SX_NET_NAME_FORMAT_PREFIX_VLAN,
} sx_net_vlan_name_format_t;

#define SX_NET_NAME_FORMAT_CHECK_RANGE(format) \
    SX_CHECK_RANGE(SX_NET_NAME_FORMAT_MIN,     \
                   (int)format,                \
                   SX_NET_NAME_FORMAT_MAX)

typedef enum sx_socket_t {
    SX_UNKNOWN_SOCKET = 0, /**< unknown socket type */
    SX_NETLINK_SOCKET, /**< netlink socket type */
    SX_GEN_NETLINK_SOCKET,
/**< generic netlink socket type */
} sx_socket_t;

typedef struct sx_net_fd {
    sx_socket_t socket_type;
    int         family_id;
    union {
        int              fd;
        struct nl_sock * sk;
    } type_properties;
} sx_net_fd;

#ifdef IB_PRESENT_FLAG

typedef enum sx_net_ipoib_join_state {
    SX_IB_JOIN_STATE_DONT_JOIN = 0,
    SX_IB_JOIN_STATE_FULL_MEMBER,
    SX_IB_JOIN_STATE_NON_MEMBER,
    SX_IB_JOIN_STATE_MIN = SX_IB_JOIN_STATE_DONT_JOIN,
    SX_IB_JOIN_STATE_MAX = SX_IB_JOIN_STATE_NON_MEMBER,
} sx_net_ipoib_join_state_t;

typedef enum sx_net_ipoib_cmd {
    SX_NET_IPOIB_CMD_COMMAND_UNSPECIFIED,
    SX_NET_IPOIB_CMD_ENABLE_PATH,
    SX_NET_IPOIB_CMD_REPORT_PATH,
    SX_NET_IPOIB_CMD_ENABLE_MC,
    SX_NET_IPOIB_CMD_GET_MCG,
    SX_NET_IPOIB_CMD_REPORT_MCG,
    SX_NET_IPOIB_CMD_ADD_RULE,
    SX_NET_IPOIB_CMD_VALIDATE_RULES,
    SX_NET_IPOIB_CMD_APPEND_RULE,
    SX_NET_IPOIB_CMD_DELETE_RULE,
} sx_net_ipoib_cmd_t;

typedef struct sx_net_ib_if_attributes_t {
    sx_qkey_t qkey;
    sx_qpn_t  qp;
} sx_net_ib_if_attributes_t;

typedef struct sx_net_ib_path_data_t {
    sx_gid_t gid;
    sx_lid_t dlid;
    sx_sl_t  sl;
    uint8_t  reserved;
} sx_net_ib_path_data_t;

typedef struct sx_net_ib_path_updates_data_t {
    uint32_t              num_updates;
    sx_net_ib_path_data_t paths[SX_NET_MAX_ATTR];
} sx_net_ib_path_updates_data_t;

typedef struct sx_net_ipoib_path_del_notify_t {
    sx_gid_t gid;
} sx_net_ipoib_path_del_notify_t;

typedef struct sx_net_ipoib_path_del_data_t {
    uint32_t                       num_values;
    sx_net_ipoib_path_del_notify_t records[SX_NET_MAX_ATTR];
} sx_net_ipoib_path_del_data_t;

typedef struct sx_net_ipoib_mc_join_notify_t {
    sx_gid_t                  mgid;
    sx_lid_t                  mlid;
    sx_sl_t                   sl;
    sx_net_ipoib_join_state_t join_state;
} sx_net_ipoib_mc_join_notify_t;

typedef struct sx_net_ipoib_mc_join_data_t {
    uint32_t                      num_values;
    sx_net_ipoib_mc_join_notify_t records[SX_NET_MAX_ATTR];
} sx_net_ib_mc_join_data_t;

typedef struct sx_net_ipoib_mc_leave_notify_t {
    sx_gid_t mgid;
} sx_net_ipoib_mc_leave_notify_t;

typedef struct sx_net_ipoib_mc_leave_data_t {
    uint32_t                       num_values;
    sx_net_ipoib_mc_leave_notify_t records[SX_NET_MAX_ATTR];
} sx_net_ipoib_mc_leave_data_t;

typedef struct sx_net_ipoib_mcg_details_notify {
    sx_gid_t                  mgid;
    sx_lid_t                  mlid;
    sx_sl_t                   sl;
    sx_net_ipoib_join_state_t join_state;
} sx_net_ipoib_mcg_details_notify_t;

typedef struct sx_net_ipoib_mcg_details_data_t {
    uint32_t                          num_values;
    sx_net_ipoib_mcg_details_notify_t records[SX_NET_MAX_ATTR];
} sx_net_ipoib_mcg_details_data_t;

typedef struct sx_net_ipoib_mc_rule_t {
    sx_gid_t                  mgid;
    sx_gid_t                  mask;
    sx_net_ipoib_join_state_t join_state;
    uint8_t                   priority;
} sx_net_ipoib_mc_rule_t;

typedef struct sx_net_ipoib_cmd_param_t {
    union {
        struct sx_net_ipoib_mc_rule_t mc_rule;
    } params;
} sx_net_ipoib_cmd_param_t;
#endif /* ifdef IB_PRESENT_FLAG */

typedef struct sx_net_if_event_data_t {
    sx_net_if_event_t event_type;
    system_ifindex    sys_ifindex;   /** the related interface system ifindex */
#ifdef IB_PRESENT_FLAG
    union {
        struct sx_net_ib_path_updates_data_t   path_updates;
        struct sx_net_ipoib_path_del_data_t    path_del;
        struct sx_net_ipoib_mc_join_data_t     mc_join;
        struct sx_net_ipoib_mc_leave_data_t    mc_leave;
        struct sx_net_ipoib_mcg_details_data_t mcg_details;
    } type_properties;
#endif
} sx_net_if_event_data_t;

typedef struct sx_net_ex_mac_addr_t {
    u_int8_t ether_addr_octet[EX_ETH_ALEN];
} sx_net_ex_mac_addr_t;

typedef struct sx_net_l2_address_eth_t {
    sx_mac_addr_t mac_addr;
    sx_vlan_id_t  vlan;
} sx_net_l2_address_eth_t;

#ifdef IB_PRESENT_FLAG
typedef struct sx_net_l2_address_ib_t {
    sx_qpn_t  qp;
    sx_gid_t  gid;
    sx_pkey_t pkey;
} sx_net_l2_address_ib_t;
#endif

typedef struct sx_net_l2_address_t {
    sx_router_interface_type_t l2_if_t;
    union {
        sx_net_l2_address_eth_t eth;
#ifdef IB_PRESENT_FLAG
        sx_net_l2_address_ib_t ib;
#endif
    } if_t_properties;
} sx_net_l2_address_t;

typedef struct sx_net_mc_params_t {
    sx_mac_addr_t mac_addr;
} sx_net_mc_params_t;

typedef union sx_net_interface_data {
#ifdef IB_PRESENT_FLAG
    struct {
        sx_pkey_t pkey; /**< Partition Key */
        sx_swid_t swid; /**< Switch ID */
    } ipoib;
#endif
    struct {
        sx_swid_t                 swid; /**< Switch ID */
        sx_vlan_id_t              vlan; /**< VLAN ID */
        sx_net_vlan_name_format_t netdev_name_format; /**< Net device name format */
    } vlan;
    struct {
        sx_swid_t    swid; /**< Switch ID */
        sx_port_id_t port; /**< Logical Port ID / LAG ID */
    } port;
    struct {
        sx_swid_t    swid; /**< Switch ID */
        sx_port_id_t port; /**< Logical Port ID / LAG ID */
        sx_vlan_id_t vlan; /**< VLAN ID */
        char         parent_name[MAX_IF_NAME_SIZE];
    } port_vlan;
} sx_net_interface_data_t;

typedef struct sx_net_interface_attributes {
    char                       name[MAX_IF_NAME_SIZE];
    sx_router_interface_type_t type;
    sx_net_interface_data_t    data;
} sx_net_interface_attributes_t;

typedef struct sx_net_interface_params {
    system_ifindex                sys_ifindex;
    unsigned int                  linux_ifindex;
    sx_net_interface_attributes_t if_attributes;
    sx_router_interface_t         router_interface;
    sx_router_id_t                vrid;
#ifdef IB_PRESENT_FLAG
    sx_net_ib_if_attributes_t ib_if_attributes;
#endif
} sx_net_interface_params_t;

typedef enum sx_sys_port_direction {
    SX_SYS_PORT_DIRECTION_UNKNOWN,
    SX_SYS_PORT_DIRECTION_INT,
    SX_SYS_PORT_DIRECTION_EXT,
    SX_SYS_PORT_DIRECTION_MIN = SX_SYS_PORT_DIRECTION_UNKNOWN,
    SX_SYS_PORT_DIRECTION_MAX = SX_SYS_PORT_DIRECTION_EXT
} sx_sys_port_direction_t;

typedef enum sx_sys_port_proto {
    SX_SYS_PORT_PROTO_UNKNOWN,
    SX_SYS_PORT_PROTO_IB,
    SX_SYS_PORT_PROTO_EN,
    SX_SYS_PORT_PROTO_MIN = SX_SYS_PORT_PROTO_UNKNOWN,
    SX_SYS_PORT_PROTO_MAX = SX_SYS_PORT_PROTO_EN
} sx_sys_port_proto_t;

typedef enum sx_split_2_cap {
    SX_SPLIT_2_CAP_UNKNOWN,
    SX_SPLIT_2_CAP_NOT_SPLITABLE,
    SX_SPLIT_2_CAP_SPLITABLE,
    SX_SPLIT_2_CAP_MIN = SX_SPLIT_2_CAP_UNKNOWN,
    SX_SPLIT_2_CAP_MAX = SX_SPLIT_2_CAP_SPLITABLE
} sx_split_2_cap_t;

typedef enum sx_split_4_cap {
    SX_SPLIT_4_CAP_UNKNOWN,
    SX_SPLIT_4_CAP_NOT_SPLITABLE,
    SX_SPLIT_4_CAP_SPLITABLE,
    SX_SPLIT_4_CAP_MIN = SX_SPLIT_4_CAP_UNKNOWN,
    SX_SPLIT_4_CAP_MAX = SX_SPLIT_4_CAP_SPLITABLE
} sx_split_4_cap_t;

typedef enum sx_split_state {
    SX_SPLIT_STATE_UNKNOWN,
    SX_SPLIT_STATE_NOT_SPLIT,
    SX_SPLIT_STATE_SPLIT,
    SX_SPLIT_STATE_MIN = SX_SPLIT_STATE_UNKNOWN,
    SX_SPLIT_STATE_MAX = SX_SPLIT_STATE_SPLIT
} sx_split_state_t;

typedef enum sx_bay_port_type {
    SX_BAY_PORT_TYPE_UNKNOWN,
    SX_BAY_PORT_TYPE_NON_BAY,
    SX_BAY_PORT_TYPE_BAY,
    SX_BAY_PORT_TYPE_MIN = SX_BAY_PORT_TYPE_UNKNOWN,
    SX_BAY_PORT_TYPE_MAX = SX_BAY_PORT_TYPE_BAY
} sx_bay_port_type_t;

typedef struct sx_net_port_params {
    sx_dev_id_t             device_id;
    sx_swid_t               swid;
    sx_sys_port_direction_t direction;
    sx_sys_port_proto_t     proto;
    sx_port_log_id_t        log_port; /* Also valid for LAG ports */
    sx_port_log_id_t        lag_port; /* Logical port of LAG that this port is a
                                       *  member of, or 0 if not a member of a
                                       *  LAG */
    uint8_t              ib_port;
    uint8_t              label_port;
    sx_port_phy_id_t     local_port;
    sx_port_ucroute_id_t system_port;
    sx_mlag_id_t         mlag_id;
    char                 name[MAX_IF_NAME_SIZE];
    uint8_t              slot_id;
    sx_split_2_cap_t     split_2_cap;
    sx_split_4_cap_t     split_4_cap;
    sx_split_state_t     split_state;
    uint8_t              split_index;
    sx_bay_port_type_t   bay_type;
} sx_net_port_params_t;

/**************************
*       NET LIB APIs     *
* ************************/

/**
 *  This function initializes the net lib interfaces and ports DB and should be
 *  called before any use of the it.
 *
 * @param[in] logging_cb - Call back function for log prints
 * @param[in] verbosity_level - the desired verbosity level
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_init(sx_log_cb_t                logging_cb,
                        const sx_verbosity_level_t verbosity_level,
                        boolean_t                  erase_db);

/**
 *  This function de-initializes the net lib. Further
 *  use of the library should not be made after it was called.
 *  Note: This function should only be called if sx_net_init() was called before
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the Databaste was not initialized
 */
sx_status_t sx_net_deinit(void);

/**
 *  This function initializes the net lib interfaces DB and should be
 *  called before any use of the it.
 *
 * @param[in] logging_cb - Call back function for log prints
 * @param[in] verbosity_level - the desired verbosity level
 * @param[in] erase_db - Should the DB be erased if already exists
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_interfaces_init(sx_log_cb_t                logging_cb,
                                   const sx_verbosity_level_t verbosity_level,
                                   boolean_t                  erase_db);

/**
 *  This function de-initializes the net lib interfaces DB. Further
 *  use of the library should not be made after it called.
 *
 * @param[in] erase_db - Should the DB be erased
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters is exceeds range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the Database was not initialized
 */
sx_status_t sx_net_interfaces_deinit(boolean_t erase_db);

/**
 * This function sets the log verbosity level of the NET LIB MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level   - verbosity level
 *
 * @return SX_STATUS_SUCCESS if oper ation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_log_verbosity_level(sx_net_access_cmd_t   cmd,
                                       sx_verbosity_level_t *verbosity_level);

/**
 * This function adds/removes an interface to/from the DB according the the command (CREATE/DESTROY)
 * in case of CREATE it also creates the relevant network interface
 * in case of DESTROY it removes the corresponding network interface
 * @param[in] cmd		- command (SX_ACCESS_CMD_CREATE/SX_ACCESS_CMD_DESTROY)
 * @param[in] sys_ifindex	- system interface index
 * @param[in] if_attributes	- interface attributes, not valid on DESTROY operations
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_ALREADY_EXISTS if the RIF for this interface was already set
 */
sx_status_t sx_net_interface_set(sx_net_access_cmd_t            cmd,
                                 system_ifindex                 sys_ifindex,
                                 sx_net_interface_attributes_t *if_attributes);

/**
 * This function retrieves interface parameters
 * @param[in] sys_ifindex	- system interface index
 * @param[out] if_params	- interface parameters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_PARAM_NULL if any input parameters is a NULL pointer
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_interface_params_get(system_ifindex             sys_ifindex,
                                        sx_net_interface_params_t *if_params);

/**
 * This function retrieves interface parameters
 * @param[in] linux_ifindex	- Linux interface index
 * @param[out] if_params	- interface parameters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_PARAM_NULL if any input parameters is a NULL pointer
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_interface_params_get_by_linux_ifindex(unsigned int               linux_ifindex,
                                                         sx_net_interface_params_t *if_params);

/**
 * This function sets router interface for the given interface
 * @param[in] sys_ifindex	- system interface index
 * @param[in] rif		- router interface
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_ALREADY_EXISTS if the RIF for this interface was already set
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_interface_rif_set(system_ifindex        sys_ifindex,
                                     sx_router_interface_t rif);

/**
 * This function sets virtual router ID for the given interface
 * @param[in] sys_ifindex	- system interface index
 * @param[in] vrid		- virtual router ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_ALREADY_EXISTS if the RIF for this interface was already set
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_interface_vrid_set(system_ifindex sys_ifindex,
                                      sx_router_id_t vrid);

/**
 * This function is used for getting interface current state
 * @param[in]     sys_ifindex            - interface handle (contain if name).
 * @param[out]    state                  - SX_NET_EVENT_IF_DOWN/SX_NET_EVENT_IF_UP
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_interface_state_get(system_ifindex sys_ifindex,
                                       if_state_t    *state);
/**
 * This function used to to set the current state of an interface.
 * @param[in]	sys_ifindex		- system interface index
 * @param[in]	state			- IF_UP/IF_DOWN
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_interface_state_set(const system_ifindex sys_ifindex,
                                       const if_state_t     state);

/**
 * This function used to to set the operational state of an interface.
 * @param[in]	sys_ifindex		- system interface index
 * @param[in]   state			- IF_UP/IF_DOWN
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_interface_oper_state_set(const system_ifindex sys_ifindex,
                                            const if_state_t     state);


/**
 * This function used to to set an alias for an interface.
 * @param[in]     cmd                    - ADD/DELETE
 * @param[in]     sys_ifindex            - system interface index
 * @param[in]     name                   - Alias name
 * @param[in]     ip_addr                - IP address
 * @param[in]     network_addr           - Network address
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_ENTRY_NOT_FOUND if the interface isn't found in the database
 */
sx_status_t sx_net_virtual_net_if_alias_set(const sx_access_cmd_t cmd,
                                            const system_ifindex  sys_ifindex,
                                            const char           *name,
                                            const sx_ip_addr_t   *ip_addr,
                                            const sx_ip_prefix_t *network_addr);

/**
 * This function is used in order to register to net events.
 * upon registration user gets a sx_net_fd type which could later be converted to FD
 *
 * @param[in]     cmd                    - SX_ACCESS_CMD_CREATE - to register , SX_ACCESS_CMD_DESTROY- to close the socket
 * @param[in]     event_group            - SX_NET_EVENT_GROUP_IF_STATE_CHANGE
 * @param[out]    out_net_sock           - pointer to the sx_net_fd (file descriptor / nl_sock) allocated for connection.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_register_net_if_event_group(sx_net_access_cmd_t     cmd,
                                               sx_net_if_event_group_t event_group,
                                               sx_net_fd              *out_net_sock);

#ifdef IB_PRESENT_FLAG
/**
 * This function is used in order to register to a pkey events
 * @param[in]     cmd                    - SX_ACCESS_CMD_CREATE - to register , SX_ACCESS_CMD_DESTROY- to close the socket
 * @param[in]     event_group            - SX_NET_EVENT_GROUP_PATH_UPDATE/SX_NET_EVENT_GROUP_MULTICAST/SX_NET_EVENT_GROUP_IPOIB_ALL
 * @param[out]    out_net_sock            - pointer to the sx_net_fd (file descriptor / nl_sock) allocated for connection.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_register_ib_if_event_group(sx_net_access_cmd_t     cmd,
                                              sx_net_if_event_group_t event_group,
                                              sx_net_fd              *out_net_sock);
#endif

/**
 * This function is used in order to receive if event and its data
 * @param[in]     in_net_sock            - pointer to the sx_net_fd (file descriptor/nl_sock)
 * @param[out]    received_event         - received event+data for in_fd
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_if_event_receive(sx_net_fd              *in_net_sock,
                                    sx_net_if_event_data_t *received_event);

/**
 * This function resolves l2 address attribute (extended mac dissolution)
 * @param[in]     ex_mac_add             - extended mac address (20 byte)
 * @param[out]    l2_address             - l2_address struct
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_resolve_l2_attribute(sx_net_ex_mac_addr_t ex_mac_add,
                                        sx_net_l2_address_t *l2_address);

/**
 * This function is for getting a common FD from the sx_net_fd type. this common FD may be used for all native FD system calls
 * @param[in]     in_net_sk             - pointer to the sx_net_fd (file descriptor/nl_sock)
 * @param[out]    out_fd                - pointer to the file descriptor
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_get_fd(sx_net_fd *in_net_sk,
                          int       *out_fd);

/**
 * Sets RX and TX buffer size of the netlink socket.
 * For SX_NETLINK_SOCKET uses setsockopt and for SX_GEN_NETLINK_SOCKET uses
 * nl_socket_set_buffer_size
 *
 * @author sashav (9/9/2014)
 *
 * @param in_net_sk
 * @param in_rxbuf
 * @param in_txbuf
 *
 * @return sx_status_t
 */
sx_status_t sx_net_set_buffer_size(sx_net_fd *in_net_sk, int in_rxbuf, int in_txbuf);

#ifdef IB_PRESENT_FLAG
/**
 * This function sends IPOIB command
 * @param[in]     net_sock       - Netlink socket
 * @param[in]     sys_ifindex    - system ifindex of IPOIB interface or 0 for "all IPOIB interfaces"
 * @param[in]     cmd            - ENABLE_PATH, ENABLE_MC, GET_MCG, ADD_RULE, VALIDATE_RULES
 * @param[in]     cmd_params     - command parameters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_ipoib_cmd_send(const sx_net_fd          *net_sock_p,
                                  const system_ifindex      sys_ifindex,
                                  const sx_net_ipoib_cmd_t  cmd,
                                  sx_net_ipoib_cmd_param_t *cmd_params_p);

/**
 * This function used for query the existing MC table in the driver.
 * @param[in]     swid                   - swid_t
 * @param[out]    mc_params_lst          - MGID,MLID,SL
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_mc_table_query(sx_swid_t          swid,
                                  sx_net_mc_params_t mc_params_list);

/**
 * This function used for MC load balancing  ,the IPoIB layer will decide whether to join a group according to the filter
 * @param[in]     swid                   - swid_t
 * @param[in]     cmd                    - ADD/DELETE
 * @param[in]     mgid
 * @param[in]     mgid_mask
 * @param[in]     action                 - join/don't join
 * @param[in]     list_size
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_mc_filter(sx_swid_t           swid,
                             sx_net_access_cmd_t cmd,
                             sx_gid_t            mgid,
                             sx_gid_t            mgid_mask,
                             sx_net_action_t     action,
                             int                 list_size);
#endif

/**
 *  This function return if the given hw_addr is ETH or NOT
 *
 * @param[in] addr - hw address
 * @param[in] addr_len - hw address len
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_is_addr_eth(uint8_t *addr,
                               int      addr_len);

/**
 *  This function initializes the net lib ports DB and should be
 *  called before any use of the it.
 *
 * @param[in] logging_cb - Call back function for log prints
 * @param[in] verbosity_level - the desired verbosity level
 * @param[in] erase_db - Should the DB be erased if already exists
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_net_ports_init(sx_log_cb_t                logging_cb,
                              const sx_verbosity_level_t verbosity_level,
                              boolean_t                  erase_db);

/**
 *  This function de-initializes the net lib ports DB. Further
 *  use of the library should not be made after it called.
 *
 * @param[in] erase_db - Should the DB be erased
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceeds its range
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the Database was not initialized
 */
sx_status_t sx_net_ports_deinit(boolean_t erase_db);

/**
 * This function adds/edits/removes a port to/from the DB according the the command (SET/DESTROY)
 * in case of DESTROY it removes the corresponding network interface
 * @param[in] cmd		- command (SX_ACCESS_CMD_SET/SX_ACCESS_CMD_DESTROY)
 * @param[in] sys_ifindex	- system interface index
 * @param[in] port_params	- port parameters, not valid on DESTROY operations
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if any input parameters is NULL
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if an entry with the sys_ifindex wasn't found in DESTROY command
 */
sx_status_t sx_net_port_set(sx_net_access_cmd_t   cmd,
                            system_ifindex        sys_ifindex,
                            sx_net_port_params_t *port_params);

/**
 * This function retrieves port parameters from the DB
 *
 * @param[in] sys_ifindex	- system interface index
 * @param[out] port_params	- port parameters, not valid on DESTROY operations
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if any input parameters is NULL
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if an entry with the sys_ifindex wasn't found
 */
sx_status_t sx_net_port_get(system_ifindex        sys_ifindex,
                            sx_net_port_params_t *port_params);

/**
 * This function returns the mapping between Logical port and System ifindex
 *
 * @param[in] log_port	- Port logical ID
 * @param[out] sys_ifindex	- system interface index
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if any input parameters is NULL
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if an entry with the logical port wasn't found
 */
sx_status_t sx_net_log_port_get(sx_port_log_id_t log_port,
                                system_ifindex  *sys_ifindex);

/**
 * This function returns the mapping between MLAG ID and LAG ID
 *
 * @param[in] mlag_id	- MLAG ID
 * @param[out] lag_id	- LAG ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if any input parameters is NULL
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if an entry with the mlag_id wasn't found
 */
sx_status_t sx_net_lag_get(sx_mlag_id_t      mlag_id,
                           sx_port_log_id_t *lag_id);

/**
 * This function returns the mapping between LAG ID and MLAG ID
 *
 * @param[in] lag_id	- LAG ID
 * @param[out] mlag_id	- MLAG ID
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if any input parameters is NULL
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if an entry with the lag_id wasn't found
 */
sx_status_t sx_net_mlag_get(sx_port_log_id_t lag_id,
                            sx_mlag_id_t    *mlag_id);


/**
 * This function set mapping between VID and IP
 *
 * @param[in] vid           - VID
 * @param[in] ip_addr       - ip address
 * @param[in] valid         - valid
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if any input parameters is NULL
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 * @return SX_STATUS_ENTRY_NOT_FOUND if an entry with the lag_id wasn't found
 */
sx_status_t sx_net_vid2ip_set(uint16_t vid,
                              uint32_t ip_addr,
                              uint8_t  valid);

/**
 * This function returns all ports of the given protocol type (or all ports if
 * UNKNOWN protocol type is given), and the number of ports returned in total.
 * If the given port buffer is NULL, then only the number of ports will be
 * returned.
 *
 * @param[in] proto                 - protocol type (SX_SYS_PORT_PROTO_EN/SX_SYS_PORT_PROTO_IB/SX_SYS_PORT_PROTO_UNKNOWN)
 * @param[in/out] port_params_list_p- buffer for port parameters (pass NULL if
 *                                                                        only size is needed)
 * @param[in/out] data_cnt_p        - In: size of port_params_buff
 *                                    Out: total number of ports returned
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceed the valid range
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 */
sx_status_t sx_net_ports_get_all(sx_sys_port_proto_t   proto,
                                 sx_net_port_params_t *port_params_list_p,
                                 uint32_t             *data_cnt_p);

/**
 * This function sets/unsets the logical port number of the LAG that this port is
 * a member of.
 *
 * @param[in] cmd - SX_ACCESS_CMD_SET/SX_ACCESS_CMD_UNSET
 * @param[in] sys_ifindex - system ifindex of port whose LAG should be set/unset
 * @param[in] lag_port - logical port number of LAG that this port belongs to
 *                                              (for use with SET)
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameters is invalid
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if any input parameters exceed the valid range
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_DB_NOT_INITIALIZED if the database was not initialized
 */
sx_status_t sx_net_port_lag_set(sx_net_access_cmd_t cmd, system_ifindex sys_ifindex,
                                sx_port_log_id_t lag_port);

#endif /* __SX_NET_LIB_H__ */
