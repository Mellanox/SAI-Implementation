/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

/*
 * NOTE:
 * sx_router_next_hop_base.h is a base file with common types and definitions used by router next hops.
 * The various next hops types are defined in sx_next_hop.h
 * Avoid from adding #include of additional sx h files that further includes sx_next_hop.h (it will cause cyclic dependency)
 *
 */
#ifndef __SX_ROUTER_NEXT_HOP_BASE_H__
#define __SX_ROUTER_NEXT_HOP_BASE_H__

#include <sx/sdk/sx_ip.h>


/** next hop offset as defined in next_hop_list given in sx_api_router_ecmp_set */
#define INVALID_NEXT_HOP_OFFSET 0xFFFFFFFF


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Router Interface ID.
 */
typedef uint16_t sx_router_interface_t;

/**
 * ECMP Container ID.
 */
typedef uint32_t sx_ecmp_id_t;


/**
 * sx_router_action_t enumerated type is used to note the route action.
 */
typedef enum sx_router_action {
    SX_ROUTER_ACTION_DROP,
    SX_ROUTER_ACTION_TRAP,
    SX_ROUTER_ACTION_FORWARD,
    SX_ROUTER_ACTION_MIRROR, /**< This value is deprecated, please use SX_ROUTER_ACTION_TRAP_FORWARD instead */
    SX_ROUTER_ACTION_TRAP_FORWARD = SX_ROUTER_ACTION_MIRROR,
    SX_ROUTER_ACTION_SPAN,
    SX_ROUTER_ACTION_MIN = SX_ROUTER_ACTION_DROP,
    SX_ROUTER_ACTION_MAX = SX_ROUTER_ACTION_SPAN,
} sx_router_action_t;

#define SX_ROUTER_ACTION_CHECK_RANGE(ROUTER_ACTION) \
    SX_CHECK_MAX(ROUTER_ACTION, SX_ROUTER_ACTION_MAX)

static __attribute__((__used__)) const char* sx_router_action_str[] = {
    "DROP",
    "TRAP",
    "FORWARD",
    "TRAP AND FORWARD",
    "SPAN",
};

#define SX_ROUTER_ACTION_STR_LEN (sizeof(sx_router_action_str) / sizeof(char*))

#define SX_ROUTER_ACTION_STR(index)                      \
    (SX_CHECK_MAX(index, SX_ROUTER_ACTION_STR_LEN - 1) ? \
     sx_router_action_str[index] : "UNKNOWN")

/**
 * sx_trap_attributes_t structure is used to store router trap attributes.
 */
typedef struct sx_trap_attributes {
    sx_trap_priority_t prio;
} sx_trap_attributes_t;

/**
 * Next hop weight.
 */
typedef uint32_t sx_next_hop_weight_t;

typedef struct sx_ip_next_hop {
    sx_ip_addr_t          address;
    sx_router_interface_t rif;
} sx_ip_next_hop_t;

#endif /* __SX_ROUTER_NEXT_HOP_BASE_H__ */
