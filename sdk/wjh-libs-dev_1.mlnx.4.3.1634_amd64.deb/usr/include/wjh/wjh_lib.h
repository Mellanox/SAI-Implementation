/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef WJH_LIB_H_
#define WJH_LIB_H_

#include <stdint.h>
#include <time.h>
#include <stdio.h>

/************************************************
 *  Macros
 ***********************************************/

#define WJH_USER_CHANNEL_ID_INVALID (0xFFFFFFFF)

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum wjh_drop_reason_group {
    WJH_DROP_REASON_GROUP_BUFFER_E,
    WJH_DROP_REASON_GROUP_ACL_E,
    WJH_DROP_REASON_GROUP_L1_E,
    WJH_DROP_REASON_GROUP_L2_E,
    WJH_DROP_REASON_GROUP_ROUTER_E,
    WJH_DROP_REASON_GROUP_TUNNEL_E,
    WJH_DROP_REASON_GROUP_MIN_E = WJH_DROP_REASON_GROUP_BUFFER_E,
    WJH_DROP_REASON_GROUP_MAX_E = WJH_DROP_REASON_GROUP_TUNNEL_E,
    WJH_DROP_REASON_GROUP_INVALID_E,
} wjh_drop_reason_group_e;

typedef enum wjh_severity {
    WJH_SEVERITY_ALL_E,
    WJH_SEVERITY_NOTICE_E,
    WJH_SEVERITY_WARNING_E,
    WJH_SEVERITY_ERROR_E,
    WJH_SEVERITY_MIN_E = WJH_SEVERITY_ALL_E,
    WJH_SEVERITY_MAX_E = WJH_SEVERITY_ERROR_E,
    WJH_SEVERITY_INVALID_E,
} wjh_severity_e;

typedef uint32_t wjh_drop_reason_id_t;
typedef uint32_t wjh_port_log_id_t;
typedef uint8_t wjh_traffic_class_t;
typedef uint64_t wjh_acl_rule_id_t;

typedef struct wjh_buffer_drop_attr {
    wjh_port_log_id_t port;
} wjh_buffer_drop_attr_t;

typedef struct wjh_drop_reason_group_attr {
    union {
        wjh_buffer_drop_attr_t buffer_drop;
    } attr;
} wjh_drop_reason_group_attr_t;

typedef enum wjh_acl_direction {
    WJH_ACL_DIRECTION_INGRESS = 0,        /**< bind to ingress direction  */
    WJH_ACL_DIRECTION_EGRESS = 1,         /**< bind to egress direction  */
    WJH_ACL_DIRECTION_RIF_INGRESS = 2,
    WJH_ACL_DIRECTION_RIF_EGRESS = 3,
    WJH_ACL_DIRECTION_MAX = WJH_ACL_DIRECTION_RIF_EGRESS,
} wjh_acl_direction_t;

typedef struct wjh_drop_reason {
    wjh_drop_reason_id_t id;
    const char         * reason;
    wjh_severity_e       severity;
    const char         * description;
} wjh_drop_reason_t;

/* raw */
typedef struct wjh_buffer_drop_raw_info {
    void              * packet;
    uint32_t            packet_size;
    wjh_port_log_id_t   ingress_port;
    wjh_port_log_id_t   egress_port;     /* Spectrum-2 only */
    wjh_traffic_class_t tc;              /* Spectrum-2 only */
    wjh_drop_reason_t   drop_reason;
    struct timespec     timestamp;
} wjh_buffer_drop_raw_info_t;

typedef struct wjh_acl_drop_raw_info {
    void              * packet;
    uint32_t            packet_size;
    wjh_acl_direction_t direction;
    wjh_acl_rule_id_t   rule_id;
    const char        * acl_name;
    const char        * rule;
    struct timespec     timestamp;
} wjh_acl_drop_raw_info_t;

typedef struct wjh_L2_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
} wjh_L2_drop_raw_info_t;

typedef struct wjh_router_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
} wjh_router_drop_raw_info_t;

typedef struct wjh_tunnel_drop_raw_info {
    void            * packet;
    uint32_t          packet_size;
    wjh_port_log_id_t ingress_port;
    wjh_drop_reason_t drop_reason;
    struct timespec   timestamp;
} wjh_tunnel_drop_raw_info_t;

/* aggregate */
typedef struct wjh_aggregate_timestamp {
    struct timespec first_timestamp;
    struct timespec last_timestamp;
} wjh_aggregate_timestamp_t;

typedef struct wjh_aggregate_five_tuples {
    const char * sip;
    const char * dip;
    uint8_t      proto;
    uint32_t     sport;
    uint32_t     dport;
} wjh_aggregate_five_tuples_t;

typedef struct wjh_buffer_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;
} wjh_buffer_drop_aggregate_key_t;

typedef struct wjh_buffer_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_buffer_drop_aggregate_data_t;

typedef struct wjh_acl_drop_aggregate_key {
    wjh_acl_rule_id_t rule_id;
    const char      * acl_name;
    const char      * rule;
} wjh_acl_drop_aggregate_key_t;

typedef struct wjh_acl_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
    uint32_t                  flows_num;      /* Spectrum-2 only */
} wjh_acl_drop_aggregate_data_t;

typedef struct wjh_router_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;
    const char                * reason;
} wjh_router_drop_aggregate_key_t;

typedef struct wjh_router_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_router_drop_aggregate_data_t;

typedef struct wjh_tunnel_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;    /* only valid for ip4/6, will be 0 otherwise */
    unsigned char               dmac[6];
    unsigned char               smac[6];
    const char                * reason;
} wjh_tunnel_drop_aggregate_key_t;

typedef struct wjh_tunnel_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_tunnel_drop_aggregate_data_t;

typedef struct wjh_L2_drop_aggregate_key {
    wjh_aggregate_five_tuples_t five_tuples;    /* only valid for ip4/6, will be 0 otherwise */
    unsigned char               dmac[6];
    unsigned char               smac[6];
    const char                * reason;
} wjh_L2_drop_aggregate_key_t;

typedef struct wjh_L2_drop_aggregate_data {
    wjh_aggregate_timestamp_t timestamp;
    uint32_t                  count;
} wjh_L2_drop_aggregate_data_t;

typedef struct wjh_L1_drop_aggregate_key {
    wjh_port_log_id_t ingress_port;
    const char      * reason;
} wjh_L1_drop_aggregate_key_t;

typedef struct wjh_L1_drop_aggregate_data {
    uint32_t count;
} wjh_L1_drop_aggregate_data_t;

typedef enum wjh_status {
    WJH_STATUS_SUCCESS,
    WJH_STATUS_ERROR,
    WJH_STATUS_PARAM_ERROR,
    WJH_STATUS_PARAM_NULL,
    WJH_STATUS_ENTRY_NOT_FOUND,
    WJH_STATUS_NOT_INITIALIZED,
    WJH_STATUS_ALREADY_INITIALIZED,
    WJH_STATUS_NO_RESOURCES,
    WJH_STATUS_NO_MEMORY,
    WJH_STATUS_UNSUPPORTED,
    WJH_STATUS_IN_PROGRESS
} wjh_status_t;

typedef enum wjh_verbosity_level {
    WJH_VERBOSITY_LEVEL_NONE = 0,
    WJH_VERBOSITY_LEVEL_ERROR,
    WJH_VERBOSITY_LEVEL_WARNING,
    WJH_VERBOSITY_LEVEL_NOTICE,
    WJH_VERBOSITY_LEVEL_INFO,
    WJH_VERBOSITY_LEVEL_DEBUG,
    WJH_VERBOSITY_LEVEL_FUNCS,
    WJH_VERBOSITY_LEVEL_FRAMES,
    WJH_VERBOSITY_LEVEL_ALL,
    WJH_VERBOSITY_LEVEL_MIN = WJH_VERBOSITY_LEVEL_NONE,
    WJH_VERBOSITY_LEVEL_MAX = WJH_VERBOSITY_LEVEL_ALL,
} wjh_verbosity_level_t;

typedef wjh_status_t (*wjh_buffer_drop_raw_cb)(wjh_buffer_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);
typedef wjh_status_t (*wjh_acl_drop_raw_cb)(wjh_acl_drop_raw_info_t *raw_info_list_p,
                                            uint32_t                *raw_info_list_size_p);
typedef wjh_status_t (*wjh_router_drop_raw_cb)(wjh_router_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);
typedef wjh_status_t (*wjh_L2_drop_raw_cb)(wjh_L2_drop_raw_info_t *raw_info_list_p,
                                           uint32_t               *raw_info_list_size_p);
typedef wjh_status_t (*wjh_tunnel_drop_raw_cb)(wjh_tunnel_drop_raw_info_t *raw_info_list_p,
                                               uint32_t                   *raw_info_list_size_p);

typedef wjh_status_t (*wjh_buffer_drop_aggregate_cb)(wjh_buffer_drop_aggregate_key_t  *key_p,
                                                     wjh_buffer_drop_aggregate_data_t *data_p);
typedef wjh_status_t (*wjh_acl_drop_aggregate_cb)(wjh_acl_drop_aggregate_key_t  *key_p,
                                                  wjh_acl_drop_aggregate_data_t *data_p);
typedef wjh_status_t (*wjh_router_drop_aggregate_cb)(wjh_router_drop_aggregate_key_t  *key_p,
                                                     wjh_router_drop_aggregate_data_t *data_p);
typedef wjh_status_t (*wjh_L2_drop_aggregate_cb)(wjh_L2_drop_aggregate_key_t  *key_p,
                                                 wjh_L2_drop_aggregate_data_t *data_p);
typedef wjh_status_t (*wjh_L1_drop_aggregate_cb)(wjh_L1_drop_aggregate_key_t  *key_p,
                                                 wjh_L1_drop_aggregate_data_t *data_p);
typedef wjh_status_t (*wjh_tunnel_drop_aggregate_cb)(wjh_tunnel_drop_aggregate_key_t  *key_p,
                                                     wjh_tunnel_drop_aggregate_data_t *data_p);

typedef struct wjh_drop_callbacks {
    wjh_drop_reason_group_e drop_reason_group;
    union {
        wjh_buffer_drop_raw_cb buffer;
        wjh_acl_drop_raw_cb    acl;
        wjh_router_drop_raw_cb router;
        wjh_L2_drop_raw_cb     L2;
        wjh_tunnel_drop_raw_cb tunnel;
    } raw_cb;
    union {
        wjh_buffer_drop_aggregate_cb buffer;
        wjh_acl_drop_aggregate_cb    acl;
        wjh_router_drop_aggregate_cb router;
        wjh_L2_drop_aggregate_cb     L2;
        wjh_L1_drop_aggregate_cb     L1;
        wjh_tunnel_drop_aggregate_cb tunnel;
    } aggregate_cb;
} wjh_drop_callbacks_t;

typedef uint32_t wjh_user_channel_id_t;

typedef enum wjh_user_channel_type {
    WJH_USER_CHANNEL_TAILDROP_E,
    WJH_USER_CHANNEL_CYCLIC_E,
    WJH_USER_CHANNEL_AGGREGATE_E,
    WJH_USER_CHANNEL_MIN_E = WJH_USER_CHANNEL_TAILDROP_E,
    WJH_USER_CHANNEL_MAX_E = WJH_USER_CHANNEL_AGGREGATE_E,
} wjh_user_channel_type_e;

typedef struct wjh_drop_counter {
    uint64_t dropped_packets;      /* total dropped packets counter, for CYCLIC user channel only */
    uint64_t received_packets;     /* trapped drop packets counter */
} wjh_drop_counter_t;

typedef void (*wjh_deactive_cb)(void);

typedef struct wjh_init_param {
    uint8_t         force;
    wjh_deactive_cb deactive_cb;
    uint8_t         max_bandwidth_percent; /* bandwidth percentage, valid value is 0 - 100, 0 means default value which is 80 percent */
} wjh_init_param_t;


/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This API sets the log verbosity level.
 *
 * @param[in] level    - verbosity level
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_log_verbosity_level_set(const wjh_verbosity_level_t level);

/**
 * This API gets the log verbosity level.
 *
 * @param[out] level    - verbosity level
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_log_verbosity_level_get(wjh_verbosity_level_t *level_p);

/**
 * This API init WJH service lib.
 * Note: During initialization, shared memory file /dev/shm/wjh_libs_shm will be created for synchronization,
 *       it must be accessible (read and write) among any WJH clients.
 *
 * @param[in] param_p    - init param
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_init(const wjh_init_param_t *param_p);

/**
 * This API deinit WJH service lib.
 *
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_deinit(void);

/**
 * This API init drop reason group.
 *
 * @param[in] drop_reason_group    - drop reason group
 * @param[in] attr_p               - drop reason group attribute
 * @param[in] callbacks_p          - callbacks for the drop packets of input drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_init(const wjh_drop_reason_group_e       drop_reason_group,
                                        const wjh_drop_reason_group_attr_t *attr_p,
                                        const wjh_drop_callbacks_t         *callbacks_p);

/**
 * This API deinit drop reason group.
 *
 * @param[in] drop_reason_group    - drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_deinit(const wjh_drop_reason_group_e drop_reason_group);

/**
 * This API create user channel.
 *
 * @param[in] channel_type          - user channel type
 * @param[out] channel_id_p         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_create(const wjh_user_channel_type_e channel_type,
                                     wjh_user_channel_id_t        *channel_id_p);

/**
 * This API destroy wjh user channel.
 *
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_destroy(const wjh_user_channel_id_t channel_id);

/**
 * This API flush user channel.
 *
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_UNSUPPORTED if operation unsupported
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_flush(const wjh_user_channel_id_t channel_id);

/**
 * This API bind drop reason group to user channel.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_bind(const wjh_drop_reason_group_e drop_reason_group,
                                        const wjh_user_channel_id_t   channel_id);

/**
 * This API unbind drop reason group from user channel.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_unbind(const wjh_drop_reason_group_e drop_reason_group);

/**
 * This API enable drop reason group to get dropped packets via callbacks.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] severity           - severity level
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_enable(const wjh_drop_reason_group_e drop_reason_group,
                                          const wjh_severity_e          severity);

/**
 * This API disable drop reason group to stop getting dropped packets.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] severity           - severity level
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_disable(const wjh_drop_reason_group_e drop_reason_group,
                                           const wjh_severity_e          severity);

/**
 * This API get counter per user channel.
 *
 * @param[in] channel_id         - user channel id
 * @param[out] counter_p         - drop counter
 * @param[in] clear              - clear drop counter
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_counter_get(const wjh_user_channel_id_t channel_id,
                             wjh_drop_counter_t         *counter_p,
                             const uint8_t               clear);

/**
 * This API get global counter of all user channel.
 *
 * @param[in] channel_id         - user channel id
 * @param[out] counter_p         - drop counter
 * @param[in] clear              - clear drop counter
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_global_counter_get(wjh_drop_counter_t *counter_p,
                                    const uint8_t       clear);

/**
 * This API generate the debug dump to file stream.
 *
 * @param[in] stream_p         - file stream
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_dbg_generate_dump(FILE* stream_p);

#endif /* WJH_LIB_H_ */
