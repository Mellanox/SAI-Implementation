/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_RM_H__
#define __SXD_EMAD_PARSER_RM_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_rm_data.h>
#include <sx/sxd/sxd_emad_rm_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_rm_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                IN sx_verbosity_level_t *verbosity_level_p);

#endif /* __SXD_EMAD_PARSER_RM_H__ */
