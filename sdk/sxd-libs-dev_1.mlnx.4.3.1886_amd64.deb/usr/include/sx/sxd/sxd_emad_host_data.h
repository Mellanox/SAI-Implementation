/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_HOST_DATA_H__
#define __SXD_EMAD_HOST_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_host.h>
#include <sx/sxd/sxd_trap_id.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_hcap_data_t structure is used to store HCAP register
 * data.
 */
typedef struct sxd_emad_hcap_data {
    sxd_emad_common_data_t common;
    struct ku_hcap_reg    *reg_data;
} sxd_emad_hcap_data_t;

/**
 * sxd_emad_htgt_data_t structure is used to store HTGT register
 * data.
 */
typedef struct sxd_emad_htgt_data {
    sxd_emad_common_data_t common;
    struct ku_htgt_reg    *reg_data;
} sxd_emad_htgt_data_t;

/**
 * sxd_emad_hpkt_data_t structure is used to store HPKT register
 * data.
 */
typedef struct sxd_emad_hpkt_data {
    sxd_emad_common_data_t common;
    struct ku_hpkt_reg    *reg_data;
} sxd_emad_hpkt_data_t;

/**
 * emad_hdrt_data_t structure is used to store HDRT register
 * layout.
 */
typedef struct sxd_emad_hdrt_data {
    sxd_emad_common_data_t common;
    struct ku_hdrt_reg    *reg_data;
} sxd_emad_hdrt_data_t;

/**
 * emad_hctr_data_t structure is used to store HCTR register
 * layout.
 */
typedef struct sxd_emad_hctr_data {
    sxd_emad_common_data_t common;
    struct ku_hctr_reg    *reg_data;
} sxd_emad_hctr_data_t;

/**
 * sxd_emad_hespr_data_t structure is used to store HESPR
 * register data.
 */
typedef struct sxd_emad_hespr_data {
    sxd_emad_common_data_t common;
    struct ku_hespr_reg   *reg_data;
} sxd_emad_hespr_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_HOST_DATA_H__ */
