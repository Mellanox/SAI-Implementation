/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_ACL_H__
#define __SXD_EMAD_PARSER_ACL_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_acl_data.h>
#include <sx/sxd/sxd_emad_acl_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of ACL PARSER MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t emad_parser_acl_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] ptar_data - register data struct.
 * @param[out] ptar_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ptar(sxd_emad_ptar_data_t *ptar_data,
                                 sxd_emad_ptar_reg_t  *ptar_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] ptar_data - register data struct.
 * @param[in] ptar_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_ptar(sxd_emad_ptar_data_t *ptar_data,
                                   sxd_emad_ptar_reg_t  *ptar_reg);


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pacl_data - register data struct.
 * @param[out] pacl_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pacl(sxd_emad_pacl_data_t *pacl_data,
                                 sxd_emad_pacl_reg_t  *pacl_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pacl_data - register data struct.
 * @param[in] pacl_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_pacl(sxd_emad_pacl_data_t *ptar_data,
                                   sxd_emad_pacl_reg_t  *ptar_reg);


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] ptce_data - register data struct.
 * @param[out] ptce_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ptce(sxd_emad_ptce_data_t *ptce_data,
                                 sxd_emad_ptce_reg_t  *ptce_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] ptce_data - register data struct.
 * @param[in] ptce_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_ptce(sxd_emad_ptce_data_t *ptce_data,
                                   sxd_emad_ptce_reg_t  *ptce_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] prcr_data - register data struct.
 * @param[out] prcr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_prcr(sxd_emad_prcr_data_t *prcr_data,
                                 sxd_emad_prcr_reg_t  *prcr_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] prcr_data - register data struct.
 * @param[in] prcr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_prcr(sxd_emad_prcr_data_t *prcr_data,
                                   sxd_emad_prcr_reg_t  *prcr_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] ppbt_data - register data struct.
 * @param[out] ppbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ppbt(sxd_emad_ppbt_data_t *ppbt_data,
                                 sxd_emad_ppbt_reg_t  *ppbt_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] ppbt_data - register data struct.
 * @param[in] ppbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_ppbt(sxd_emad_ppbt_data_t *ppbt_data,
                                   sxd_emad_ppbt_reg_t  *ppbt_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pvbt_data - register data struct.
 * @param[out] pvbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pvbt(sxd_emad_pvbt_data_t *pvbt_data,
                                 sxd_emad_pvbt_reg_t  *pvbt_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pvbt_data - register data struct.
 * @param[in] pvbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pvbt(sxd_emad_pvbt_data_t *pvbt_data,
                                   sxd_emad_pvbt_reg_t  *pvbt_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pagt_data - register data struct.
 * @param[out] pagt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pagt(sxd_emad_pagt_data_t *pagt_data,
                                 sxd_emad_pagt_reg_t  *pagt_reg);


/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pagt_data - register data struct.
 * @param[in] pagt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pagt(sxd_emad_pagt_data_t *pagt_data,
                                   sxd_emad_pagt_reg_t  *pagt_reg);


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pprr_data - register data struct.
 * @param[out] pprr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pprr(sxd_emad_pprr_data_t *pprr_data,
                                 sxd_emad_pprr_reg_t  *pprr_reg);


/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pprr_data - register data struct.
 * @param[in] pprr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pprr(sxd_emad_pprr_data_t *pprr_data,
                                   sxd_emad_pprr_reg_t  *pprr_reg);


/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pvgt_data - register data struct.
 * @param[out] pvgt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pvgt(sxd_emad_pvgt_data_t *pvgt_data, sxd_emad_pvgt_reg_t *pvgt_reg);


/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pvgt_data - register data struct.
 * @param[in] pvgt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pvgt(sxd_emad_pvgt_data_t *pvgt_data, sxd_emad_pvgt_reg_t *pvgt_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pgcr_data - register data struct.
 * @param[out] pgcr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pgcr(sxd_emad_pgcr_data_t *pgcr_data, sxd_emad_pgcr_reg_t *pgcr_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pgcr_data - register data struct.
 * @param[in] pgcr_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pgcr(sxd_emad_pgcr_data_t *pgcr_data, sxd_emad_pgcr_reg_t *pgcr_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] puet_data - register data struct.
 * @param[out] puet_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_puet(sxd_emad_puet_data_t *puet_data, sxd_emad_puet_reg_t *puet_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] puet_data - register data struct.
 * @param[in] puet_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_puet(sxd_emad_puet_data_t *puet_data, sxd_emad_puet_reg_t *puet_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] prbt_data - register data struct.
 * @param[out] prbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_prbt(sxd_emad_prbt_data_t *prbt_data,
                                 sxd_emad_prbt_reg_t  *prbt_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] prbt_data - register data struct.
 * @param[in] prbt_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_prbt(sxd_emad_prbt_data_t *prbt_data,
                                   sxd_emad_prbt_reg_t  *prbt_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] ptce2_data - register data struct.
 * @param[out] ptce2_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ptce2(sxd_emad_ptce2_data_t *ptce2_data,
                                  sxd_emad_ptce2_reg_t  *ptce2_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] ptce2_data - register data struct.
 * @param[in] ptce2_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_ptce2(sxd_emad_ptce2_data_t *ptce2_data,
                                    sxd_emad_ptce2_reg_t  *ptce2_reg);
/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pefa_data - register data struct.
 * @param[out] pefa_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pefa(sxd_emad_pefa_data_t *pefa_data,
                                 sxd_emad_pefa_reg_t  *pefa_reg);

/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pefa_data - register data struct.
 * @param[in] pefa_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_pefa(sxd_emad_pefa_data_t *pefa_data,
                                   sxd_emad_pefa_reg_t  *pefa_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pecb_data - register data struct.
 * @param[out] pecb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pecb(sxd_emad_pecb_data_t *pecb_data,
                                 sxd_emad_pecb_reg_t  *pecb_reg);
/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pecb_data - register data struct.
 * @param[in] pecb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_pecb(sxd_emad_pecb_data_t *pecb_data,
                                   sxd_emad_pecb_reg_t  *pecb_reg);

/**
 *  This function Parses Data -> EMAD struct.
 *
 * @param[in] pemb_data - register data struct.
 * @param[out] pemb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pemb(sxd_emad_pemb_data_t *pemb_data,
                                 sxd_emad_pemb_reg_t  *pemb_reg);
/**
 *  This function Parses EMAD -> Data struct.
 *
 * @param[out] pemb_data - register data struct.
 * @param[in] pemb_reg - EMAD fields struct
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pemb(sxd_emad_pemb_data_t *pemb_data,
                                   sxd_emad_pemb_reg_t  *pemb_reg);

/**
 *  This helper function Parses flex_action_set  Data -> EMAD struct.
 *
 * @param[in] action_data -  sxd_flex_action_set struct.
 * @param[out] action_reg - sxd_emad_flex_action_set_reg_t struct
 *
 */

void sxd_emad_parse_flex_action(struct sxd_flex_action_set    * action_data,
                                sxd_emad_flex_action_set_reg_t* action_reg);

/**
 *  This helper function Parses flex_action_set EMAD ->  Data struct.
 *
 * @param[out] action_data -  sxd_flex_action_set struct.
 * @param[in] action_reg - sxd_emad_flex_action_set_reg_t struct
 *
 */
void sxd_emad_deparse_flex_action(struct sxd_flex_action_set    * action_data,
                                  sxd_emad_flex_action_set_reg_t* action_reg);

#endif /* ifndef __SXD_EMAD_PARSER_ACL_H__ */
