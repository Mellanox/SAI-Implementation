/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_ACCESS_CMD_H__
#define __SXD_ACCESS_CMD_H__

#include <sx/sxd/sxd_check.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_access_cmd_t enumerated type is used to note the command
 * access required.
 */
typedef enum sxd_access_cmd {
    SXD_ACCESS_CMD_ADD,     /** < ADD command */
    SXD_ACCESS_CMD_DELETE,  /** < DELETE command */
    SXD_ACCESS_CMD_TEST,    /** < TEST command */
    SXD_ACCESS_CMD_GET,     /** < GET command */
    SXD_ACCESS_CMD_SET,     /** < SET command */
    SXD_ACCESS_CMD_GET_ALL, /** < GET ALL command */
    SXD_ACCESS_CMD_MIN = SXD_ACCESS_CMD_ADD,    /** < MIN value */
    SXD_ACCESS_CMD_MAX = SXD_ACCESS_CMD_GET_ALL, /** < MAX value */
} sxd_access_cmd_t;

/**
 * SXD_ACCESS_CMD_CHECK_RANGE() - Check the command range for
 * valid value.
 */
#define SXD_ACCESS_CMD_CHECK_RANGE(ACCESS_CMD) \
    SXD_CHECK_RANGE(SXD_ACCESS_CMD_MIN, ACCESS_CMD, SXD_ACCESS_CMD_MAX)

static const char *sxd_access_cmd_str[] = {
    "ADD",
    "DELETE",
    "TEST",
    "GET",
    "SET",
    "GET ALL"
};
static const int   sxd_access_cmd_str_len = sizeof(sxd_access_cmd_str) / sizeof(char*);

#define SXD_ACCESS_CMD_STR(cmd)                            \
    (SXD_CHECK_RANGE(0, (int)cmd, sxd_access_cmd_str_len - \
                     1) ? sxd_access_cmd_str[cmd] : "UNKNOWN")

#endif /* __SXD_ACCESS_CMD_H__ */
