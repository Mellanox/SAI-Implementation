/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_RM_H__
#define __SXD_EMAD_RM_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_rm_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD RM MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */

sxd_status_t sxd_emad_rm_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                             IN sx_verbosity_level_t *verbosity_level_p);


/**
 * This function sets the IDDD register.
 *
 * @param[in,out]       iddd_data_arr - IDDD EMAD array
 * @param[in]           iddd_data_num - Number of IDDD EMAD data
 * @param[in]           handler - Sender ID
 * @param[in,out]       context - Cookie
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS       - operation completes successfully
 * @return SXD_STATUS_ERROR         - EMAD transaction error
 * @return SXD_STATUS_PARAM_ERROR   - Input parameters error
 * @return SXD_STATUS_NO_RESOURCES  - Transaction could not be completed
 * @return SXD_STATUS_NO_MEMORY     - No memory in transaction pool
 */
sxd_status_t sxd_emad_iddd_set(sxd_emad_iddd_data_t         *iddd_data_arr,
                               uint32_t                      iddd_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function gets the IDDD Register.
 *
 * @param[in] iddd_data_arr - Pointer to allocated structure
 *        contained the parameters to be configured.
 * @param[in] iddd_data_num - Number of data blocks to be gets
 * @param[in] handler - Completion handler
 * @param[in,out] context - Completion handler context
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS      - Success
 * @return SXD_STATUS_PARAM_ERROR  - Input parameters validation
 *  error
 * @return SXD_STATUS_NO_MEMORY    - Memory allocation error
 * @return SXD_STATUS_NO_RESOURCES - Transaction could not be
 *  completed. emad_transaction_init() should be called
 */
sxd_status_t sxd_emad_iddd_get(sxd_emad_iddd_data_t         *iddd_data_arr,
                               uint32_t                      idddl_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


#endif /* __SXD_EMAD_RM_H__ */
