/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_COS_DATA_H__
#define __SXD_EMAD_COS_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_cos.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_qpdp_data_t structure is used to store QPDP register
 * data.
 */
typedef struct sxd_emad_qpdp_data {
    sxd_emad_common_data_t common;
    struct ku_qpdp_reg    *reg_data;
} sxd_emad_qpdp_data_t;

/**
 * sxd_emad_qprt_data_t structure is used to store QPRT register
 * data.
 */
typedef struct sxd_emad_qprt_data {
    sxd_emad_common_data_t common;
    struct ku_qprt_reg    *reg_data;
} sxd_emad_qprt_data_t;

/**
 * sxd_emad_qsptc_data_t structure is used to store QSPTC
 * register data.
 */
typedef struct sxd_emad_qsptc_data {
    sxd_emad_common_data_t common;
    struct ku_qsptc_reg   *reg_data;
} sxd_emad_qsptc_data_t;

/**
 * sxd_emad_qtct_data_t structure is used to store QTCT register
 * data.
 */
typedef struct sxd_emad_qtct_data {
    sxd_emad_common_data_t common;
    struct ku_qtct_reg    *reg_data;
} sxd_emad_qtct_data_t;

/**
 * sxd_emad_qstct_data_t structure is used to store QSTCT
 * register data.
 */
typedef struct sxd_emad_qstct_data {
    sxd_emad_common_data_t common;
    struct ku_qstct_reg   *reg_data;
} sxd_emad_qstct_data_t;

/**
 * sxd_emad_qcap_data_t structure is used to store QCAP register
 * data.
 */
typedef struct sxd_emad_qcap_data {
    sxd_emad_common_data_t common;
    struct ku_qcap_reg    *reg_data;
} sxd_emad_qcap_data_t;

/**
 * sxd_emad_qpts_data_t structure is used to store QPTS register
 * data.
 */
typedef struct sxd_emad_qpts_data {
    sxd_emad_common_data_t common;
    struct ku_qpts_reg    *reg_data;
} sxd_emad_qpts_data_t;

/**
 * sxd_emad_qdpm_data_t structure is used to store QDPM register
 * data.
 */
typedef struct sxd_emad_qdpm_data {
    sxd_emad_common_data_t common;
    struct ku_qdpm_reg    *reg_data;
} sxd_emad_qdpm_data_t;

/**
 * sxd_emad_qetcr_data_t structure is used to store QETCR
 * register data.
 */
typedef struct sxd_emad_qetcr_data {
    sxd_emad_common_data_t common;
    struct ku_qetcr_reg   *reg_data;
} sxd_emad_qetcr_data_t;

/**
 * sxd_emad_qpfcr_data_t structure is used to store QPFCR
 * register data.
 */
typedef struct sxd_emad_qpfcr_data {
    sxd_emad_common_data_t common;
    struct ku_qpfcr_reg   *reg_data;
} sxd_emad_qpfcr_data_t;

/**
 * sxd_emad_qegcs_data_t structure is used to store QEGCS
 * register data.
 */
typedef struct sxd_emad_qegcs_data {
    sxd_emad_common_data_t common;
    struct ku_qegcs_reg   *reg_data;
} sxd_emad_qegcs_data_t;

/**
 * sxd_emad_cnct_data_t structure is used to store CNCT
 * register data.
 */
typedef struct sxd_emad_cnct_data {
    sxd_emad_common_data_t common;
    struct ku_cnct_reg    *reg_data;
} sxd_emad_cnct_data_t;

/**
 * sxd_emad_cpid_data_t structure is used to store CPID
 * register data.
 */
typedef struct sxd_emad_cpid_data {
    sxd_emad_common_data_t common;
    struct ku_cpid_reg    *reg_data;
} sxd_emad_cpid_data_t;

/**
 * sxd_emad_cpcs_data_t structure is used to store CPCS
 * register data.
 */
typedef struct sxd_emad_cpcs_data {
    sxd_emad_common_data_t common;
    struct ku_cpcs_reg    *reg_data;
} sxd_emad_cpcs_data_t;

/**
 * sxd_emad_cnmc_data_t structure is used to store CNMC
 * register data.
 */
typedef struct sxd_emad_cnmc_data {
    sxd_emad_common_data_t common;
    struct ku_cnmc_reg    *reg_data;
} sxd_emad_cnmc_data_t;

/**
 * sxd_emad_sbmm_data_t structure is used to store SBMM register
 * data.
 */
typedef struct sxd_emad_sbmm_data {
    sxd_emad_common_data_t common;
    struct ku_sbmm_reg    *reg_data;
} sxd_emad_sbmm_data_t;

/** sxd_emad_sbsr_data_t structure is used to store SBSR register
 * data.
 */
typedef struct sxd_emad_sbsr_data {
    sxd_emad_common_data_t common;
    struct ku_sbsr_reg    *reg_data;
} sxd_emad_sbsr_data_t;

/**
 * sxd_emad_qpdpm_data_t structure is used to store QPDPM
 * register data.
 */
typedef struct sxd_emad_qpdpm_data {
    sxd_emad_common_data_t common;
    struct ku_qpdpm_reg   *reg_data;
} sxd_emad_qpdpm_data_t;

/**
 * sxd_emad_qepm_data_t structure is used to store QEPM
 * register data.
 */
typedef struct sxd_emad_qepm_data {
    sxd_emad_common_data_t common;
    struct ku_qepm_reg    *reg_data;
} sxd_emad_qepm_data_t;

/**
 * sxd_emad_qeec_data_t structure is used to store QEEC
 * register data.
 */
typedef struct sxd_emad_qeec_data {
    sxd_emad_common_data_t common;
    struct ku_qeec_reg    *reg_data;
} sxd_emad_qeec_data_t;

/**
 * sxd_emad_qdpcp_data_t structure is used to store QPDCP
 * register data.
 */
typedef struct sxd_emad_qpdpc_data {
    sxd_emad_common_data_t common;
    struct ku_qpdpc_reg   *reg_data;
} sxd_emad_qpdpc_data_t;

/**
 * sxd_emad_qtctm_data_t structure is used to store QTCTM
 * register data.
 */
typedef struct sxd_emad_qtctm_data {
    sxd_emad_common_data_t common;
    struct ku_qtctm_reg   *reg_data;
} sxd_emad_qtctm_data_t;

/**
 * sxd_emad_qspip_data_t structure is used to store QSPIP
 * register data.
 */
typedef struct sxd_emad_qspip_data {
    sxd_emad_common_data_t common;
    struct ku_qspip_reg   *reg_data;
} sxd_emad_qspip_data_t;

/**
 * sxd_emad_qspcp_data_t structure is used to store QSPCP
 * register data.
 */
typedef struct sxd_emad_qspcp_data {
    sxd_emad_common_data_t common;
    struct ku_qspcp_reg   *reg_data;
} sxd_emad_qspcp_data_t;

/**
 * sxd_emad_qrwe_data_t structure is used to store QRWE
 * register data.
 */
typedef struct sxd_emad_qrwe_data {
    sxd_emad_common_data_t common;
    struct ku_qrwe_reg    *reg_data;
} sxd_emad_qrwe_data_t;

/**
 * sxd_emad_qpem_data_t structure is used to store QPEM
 * register data.
 */
typedef struct sxd_emad_qpem_data {
    sxd_emad_common_data_t common;
    struct ku_qpem_reg    *reg_data;
} sxd_emad_qpem_data_t;

/**
 * sxd_emad_qpdsm_data_t structure is used to store QPDSM
 * register data.
 */
typedef struct sxd_emad_qpdsm_data {
    sxd_emad_common_data_t common;
    struct ku_qpdsm_reg   *reg_data;
} sxd_emad_qpdsm_data_t;

/**
 * sxd_emad_qppm_data_t structure is used to store QPPM
 * register data.
 */
typedef struct sxd_emad_qppm_data {
    sxd_emad_common_data_t common;
    struct ku_qppm_reg    *reg_data;
} sxd_emad_qppm_data_t;

/**
 * sxd_emad_qsll_data structure is used to store QSLL
 * register data.
 */
typedef struct sxd_emad_qsll_data {
    sxd_emad_common_data_t common;
    struct ku_qsll_reg    *reg_data;
} sxd_emad_qsll_data_t;

/**
 * sxd_emad_qhll_data structure is used to store QHLL
 * register data.
 */
typedef struct sxd_emad_qhll_data {
    sxd_emad_common_data_t common;
    struct ku_qhll_reg    *reg_data;
} sxd_emad_qhll_data_t;

/**
 * sxd_emad_sbhrr_data_t structure is used to store SBHRR
 * register data.
 */
typedef struct sxd_emad_sbhrr_data {
    sxd_emad_common_data_t common;
    struct ku_sbhrr_reg   *reg_data;
} sxd_emad_sbhrr_data_t;

/**
 * sxd_emad_sbhbr_data_t structure is used to store SBHBR
 * register data.
 */
typedef struct sxd_emad_sbhbr_data {
    sxd_emad_common_data_t common;
    struct ku_sbhbr_reg   *reg_data;
} sxd_emad_sbhbr_data_t;

/**
 * sxd_emad_sbdcc_data_t structure is used to store SBDCC
 * register data.
 */
typedef struct sxd_emad_sbdcc_data {
    sxd_emad_common_data_t common;
    struct ku_sbdcc_reg   *reg_data;
} sxd_emad_sbdcc_data_t;

/**
 * sxd_emad_sbdcm_data_t structure is used to store SBDCM
 * register data.
 */
typedef struct sxd_emad_sbdcm_data {
    sxd_emad_common_data_t common;
    struct ku_sbdcm_reg   *reg_data;
} sxd_emad_sbdcm_data_t;

/**
 * sxd_emad_sbctc_data_t structure is used to store SBCTC
 * register data.
 */
typedef struct sxd_emad_sbctc_data {
    sxd_emad_common_data_t common;
    struct ku_sbctc_reg   *reg_data;
} sxd_emad_sbctc_data_t;

/**
 * sxd_emad_sbctr_data_t structure is used to store SBCTR
 * register data.
 */
typedef struct sxd_emad_sbctr_data {
    sxd_emad_common_data_t common;
    struct ku_sbctr_reg   *reg_data;
} sxd_emad_sbctr_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_COS_DATA_H__ */
