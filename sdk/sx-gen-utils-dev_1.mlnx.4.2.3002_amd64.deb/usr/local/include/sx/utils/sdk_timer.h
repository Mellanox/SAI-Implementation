/*
 * Copyright (C) Mellanox Technologies, Ltd. 2001-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef SDK_TIMER_H_
#define SDK_TIMER_H_

#include "sx/utils/sx_utils_status.h"
#include "sx/utils/sx_utils_types.h"

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/
typedef enum sdk_timer_type {
    SDK_TIMER_TYPE_PERIODIC = 0,
    SDK_TIMER_TYPE_ONE_SHOT = 1,
    SDK_TIMER_TYPE_MIN = SDK_TIMER_TYPE_PERIODIC,
    SDK_TIMER_TYPE_MAX = SDK_TIMER_TYPE_ONE_SHOT
} sdk_timer_type_t;

#define SDK_TIMER_TYPE_CHECK_RANGE(SDK_TIMER_TYPE) \
    SX_CHECK_MAX(SDK_TIMER_TYPE, SDK_TIMER_TYPE_MAX)

static __attribute__((__used__)) const char* sdk_timer_type_str[] = {
    "PERIODIC",
    "ONE SHOT"
};

#define SDK_TIMER_TYPE_STR_LEN (sizeof(sdk_timer_type_str) / sizeof(char*))

#define SDK_TIMER_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SDK_TIMER_TYPE_STR_LEN - 1) ? \
     sdk_timer_type_str[index] : "UNKNOWN")

typedef uint32_t sdk_timer_handle_t;

/**
 * This function is a prototype of internal job callback from the sdk.
 * It should be used for modules in sx_gen_utils that wish to push items to
 * the work queue.
 *
 * @return sx_utils_status_t:
 * @return SX_UTILS_STATUS_SUCCESS - Operation completes successfully
 */
typedef sx_utils_status_t (*sx_utils_add_intern_job_cb)(uint32_t opcode,
                                                        uint8_t *buffer,
                                                        uint32_t cmd_size,
                                                        uint8_t  buf_idx);

typedef enum sx_utils_int_cmd {
    SX_UTILS_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E
} sx_utils_int_cmd_e;

typedef enum {
    SX_UTILS_LOW_PRIO_BUF_E = 0,
    SX_UTILS_MED_PRIO_BUF_E,
    SX_UTILS_HIGH_PRIO_BUF_E,

    SX_UTILS_MIN_PRIO_BUF_E = SX_UTILS_LOW_PRIO_BUF_E,
    SX_UTILS_MAX_PRIO_BUF_E = SX_UTILS_HIGH_PRIO_BUF_E,
    SX_UTILS_MAX_NON_HIGH_PRIO_BUF_E = SX_UTILS_MED_PRIO_BUF_E,

    SX_UTILS_NUM_OF_PRIO_BUFS_E = (SX_UTILS_MAX_PRIO_BUF_E + 1),

    SX_UTILS_NUM_OF_LOWER_PRIO_BUFS_E = SX_UTILS_MAX_PRIO_BUF_E
} sx_utils_prio_buffer_num_e;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/*
 * Registers a job callback in the SDK timer module.
 *
 * @param[in] cb    - callback to be registered
 *
 */
void sdk_timer_register_cb(sx_utils_add_intern_job_cb cb);

/*
 * Initializes the SDK timer module.
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_ALREADY_INITIALIZED if module is already initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t sdk_timer_init(void);

/*
 * Deinitializes the SDK timer module
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t sdk_timer_deinit(void);

/*
 * Gets an initialized timer for the client's use.
 *
 * @param[in] cmd - job command to be performed when timer expires
 * @param[in] type - timer type (ONE_SHOT/PERIODIC)
 * @param[in] context - client context to be used when timer expires
 * @param[in] context_size - size of context in bytes
 * @param[in] priority - priority of job command
 * @param[out] p_timer_hdl - timer handle returned to client
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR      if an invalid parameter is given
 * @return SX_UTILS_STATUS_PARAM_NULL if a NULL parameter is given
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_NO_RESOURCES if no timers are available
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t sdk_timer_get(sx_utils_int_cmd_e         cmd,
                                sdk_timer_type_t           type,
                                void                      *context,
                                uint32_t                   context_size,
                                sx_utils_prio_buffer_num_e priority,
                                sdk_timer_handle_t        *p_timer_hdl);

/*
 * Returns a timer handle that is no longer needed.
 *
 * @param[in] timer_hdl - timer handle to be returned
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR      if an invalid parameter is given
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND if the timer isn't found
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t sdk_timer_put(sdk_timer_handle_t timer_hdl);

/*
 * Starts a previously received timer. When the timer expires, the internal job command
 * specified when the timer was created will be pushed to the work queue.
 * If the timer type is periodic, it will be reset after the callback is called
 * every time it expires, until the client stops it, or until the internal job
 * callback is set to NULL.
 *
 * @param[in] timer_hdl - timer handle to be started
 * @param[in] interval - time to be set, in milliseconds. Must be larger than 0
 *                       for periodic timers. For one-shot timers, 0 means that
 *                       the timer will expire immediately.
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR      if an invalid parameter is given
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND if the timer isn't found
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t sdk_timer_start(sdk_timer_handle_t timer_hdl, uint32_t interval);

/*
 * Stops a timer.
 *
 * @param[in] timer_hdl - timer handle to be stopped.
 *
 * @return SX_UTILS_STATUS_SUCCESS             if operation completes successfully
 * @return SX_UTILS_STATUS_ENTRY_NOT_FOUND if the timer isn't found
 * @return SX_UTILS_STATUS_MODULE_UNINITIALIZED if module is not initialized
 * @return SX_UTILS_STATUS_ERROR               general error.
 */
sx_utils_status_t sdk_timer_stop(sdk_timer_handle_t timer_hdl);

sx_utils_status_t sdk_timer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif /* SDK_TIMER_H_ */
