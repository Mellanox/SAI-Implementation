/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __SDK_REFCOUNT_H__
#define __SDK_REFCOUNT_H__

#include <stdint.h>
#include "sx/utils/sx_utils_status.h"
#include "sx/utils/dbg_utils.h"

/************************************************
 *  Local Defines
 ***********************************************/

#define REFERENCED_NAME_MAX_LEN 65
#define REFERENCE_NAME_MAX_LEN  65

/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/
typedef uint64_t sdk_refcount_t;
typedef uint64_t sdk_ref_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes the refcount infrastracture.
 */
sx_utils_status_t sdk_refcount_system_init(void);

/**
 * Deinitialize the refcount infrastracture.
 *
 * @param[in] is_forced - whether the function should or should not fail
 *                    on open references.
 */
sx_utils_status_t sdk_refcount_system_deinit(boolean_t is_forced);

/**
 * debug dump function. Prints its internal data types, which includes:
 *  - All the referenced objects that are currently allive alive in the system.
 *  - All the objects referencing each referenced object.
 *
 * @param[in] stream - the output stream to which the output will be directed.
 */
void sdk_refcount_debug_dump(FILE* stream);

/**
 * The init refcount function.
 * This function is used to initalize a sdk_refcount_t object.
 *
 * Memory consumpion: the memory consumption cost of that infrastracture is mainly the
 * REFERENCE_NAME_MAX_LEN bytes per reference of an object.
 *
 * @param[in] refcount_p- the refcount to initalize.
 * @param[in] referended_name - the name of the object that contain this refcount object.
 *                              the name is restricted to size of REFERENCED_NAME_MAX_LEN
 */
sx_utils_status_t sdk_refcount_init(sdk_refcount_t *refcount_p, const char* referenced_name);

/**
 * Deinitlize a sdk_refcount_t object, and free its memory.
 * If is_forced == FALSE, the function will fail deinitalize a refcount object if there are objects
 * referencing A.
 * it (refcount > 0).
 *
 * @param[in] refcount_p - the refcount to deinitalize.
 * @param[in] is_forced - whether to fail on open references
 */
sx_utils_status_t sdk_refcount_deinit(sdk_refcount_t *refcount_p, boolean_t is_forced);

/**
 * Add a reference to a refcount object.
 * This function will return the refernce handle used to free that reference.
 *
 * @param[in]  refcount_p - the refcount object that should be increased
 * @param[in]  reference_name - the name of the reference that should be used.
 *                              the name is restricted to size of REFERENCE_NAME_MAX_LEN.
 *                              this name should be informative and represent the holding's object
 *                              name.
 * @param[out] reference - the newly created reference.
 */
sx_utils_status_t sdk_refcount_inc(sdk_refcount_t *refcount_p, const char* reference_name, sdk_ref_t *reference);

/**
 * Removes a reference from a refcount object.
 * This function gets the refernce handle got by the sdk_refcount_inc function.
 *
 * @param[in] refcount_p - the refcount object that should be increased
 * @param[in] reference - the reference handle that was returned by sdk_refcount_inc
 */
sx_utils_status_t sdk_refcount_dec(sdk_refcount_t *refcount_p, const sdk_ref_t* reference);

/**
 * Renames a reference.
 * This function will change the name of the specific reference, as was set by the sdk_refcount_inc function.
 *
 * @param[in] reference - the reference to rename.
 * @param[in] reference_name - the new name of the reference that should be used.
 *                             the name is restricted to size of REFERENCE_NAME_MAX_LEN
 */
sx_utils_status_t sdk_refcount_rename_ref(const sdk_ref_t *reference, const char* reference_name);

/**
 * Return the reference count of a specific sdk_refcount_t object, as if the number of
 * objects that increased the reference or the number of reference handles given.
 *
 * @param[in]  refcount_p - the refcount object
 * @param[out] val - the output value.
 */
sx_utils_status_t sdk_refcount_get(sdk_refcount_t *refcount_p, int32_t* val);

/**
 * Return a name of all reference for refcount object.
 *
 * @param[in] refcount_p - the reference to rename.
 * @param[in] buf_size  - size of output buffer for reference
 *       name
 * @param[out] reference_name - the name of all references.
 *
 */
sx_utils_status_t sdk_refcount_getname_ref(sdk_refcount_t *refcount_p, uint32_t buf_size, char* references_name);

#endif /* __SDK_REFCOUNT_H__ */
