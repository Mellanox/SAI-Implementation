/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef     __SXD_CHECK_H__
#define     __SXD_CHECK_H__

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#ifndef     SXD_CHECK_RANGE
#define SXD_CHECK_RANGE(min, val, max) (((max) >= (val)) && ((val) >= (min)))
#endif  /*	SXD_CHECK_RANGE	*/

#ifndef     SXD_CHECK_MAX
#define SXD_CHECK_MAX(val, max) ((max) >= (val))
#endif  /*	SXD_CHECK_MAX	*/

/**
 * Macro is used to test if status isn't success.
 */
#ifndef     SXD_CHECK_FAIL
#define SXD_CHECK_FAIL(STATUS) (SXD_STATUS_SUCCESS != (STATUS))
#endif  /*	SXD_CHECK_FAIL	*/

/**
 * Macro is used to test if status is success.
 */
#ifndef     SXD_CHECK_PASS
#define SXD_CHECK_PASS(STATUS) (SXD_STATUS_SUCCESS == (STATUS))
#endif  /*	SXD_CHECK_PASS	*/

/**
 * Macro is used to test if status isn't success.
 */
#ifndef     SXD_EMAD_CHECK_FAIL
#define SXD_EMAD_CHECK_FAIL(STATUS) (SXD_EMAD_STATUS_SUCCESS != (STATUS))
#endif  /*	SXD_EMAD_CHECK_FAIL	*/


/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


#endif  /*	__SXD_CHECK_H__	*/
