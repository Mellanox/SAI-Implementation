/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_MSTP_REG_H__
#define __SXD_EMAD_MSTP_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_spms_reg_t structure is used to store SPMS register
 * layout.
 */
typedef struct sxd_emad_spms_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    net32_t state[256];
} PACK_SUFFIX sxd_emad_spms_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_MSTP_REG_H__ */
