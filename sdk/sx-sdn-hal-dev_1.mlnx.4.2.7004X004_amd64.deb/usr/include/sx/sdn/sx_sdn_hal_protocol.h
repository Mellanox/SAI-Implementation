/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_PROTOCOL_H__
#define __SX_SDN_HAL_PROTOCOL_H__

#include <sx/sdk/sx_trap_id.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * SDN HAL control protocol
 */
typedef enum sx_sdn_hal_control_protocol_id {
    SX_SDN_HAL_CONTROL_PROTOCOL_STP = SX_TRAP_ID_ETH_L2_STP,
    SX_SDN_HAL_CONTROL_PROTOCOL_LACP = SX_TRAP_ID_ETH_L2_LACP,
    SX_SDN_HAL_CONTROL_PROTOCOL_LLDP = SX_TRAP_ID_ETH_L2_LLDP,
    SX_SDN_HAL_CONTROL_PROTOCOL_FIP = SX_TRAP_ID_FCOE_FIP,
    SX_SDN_HAL_CONTROL_PROTOCOL_DHCP = SX_TRAP_ID_ETH_L2_DHCP,
    SX_SDN_HAL_CONTROL_PROTOCOL_ARPBC = SX_TRAP_ID_ARP_REQUEST,
    SX_SDN_HAL_CONTROL_PROTOCOL_ARPUC = SX_TRAP_ID_ARP_RESPONSE,
    SX_SDN_HAL_CONTROL_PROTOCOL_OSPF = SX_TRAP_ID_OSPF,
    SX_SDN_HAL_CONTROL_PROTOCOL_RIPV1 = SX_TRAP_ID_RIP_V1,
    SX_SDN_HAL_CONTROL_PROTOCOL_RIPV2 = SX_TRAP_ID_RIP_V2,
    SX_SDN_HAL_CONTROL_PROTOCOL_PIM = SX_TRAP_ID_PIM,
    SX_SDN_HAL_CONTROL_PROTOCOL_LAST
} sx_sdn_hal_control_protocol_id_t;

#endif /* __SX_SDN_HAL_PROTOCOL_H__ */
