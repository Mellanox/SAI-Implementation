/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_FCF_H__
#define __SXD_EMAD_PARSER_FCF_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_fcf_data.h>
#include <sx/sxd/sxd_emad_fcf_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 *  This function formats FGCR register layout from FGCR register data.
 *
 * @param[in] fgcr_data - FGCR register data.
 * @param[out] fgcr_reg - FGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_fgcr(sxd_emad_fgcr_data_t *fgcr_data,
                                 sxd_emad_fgcr_reg_t  *fgcr_reg);

/**
 *  This function formats FGCR register data from FGCR register layout.
 *
 * @param[out] fgcr_data - FGCR register data.
 * @param[in] fgcr_reg - FGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_fgcr(sxd_emad_fgcr_data_t *fgcr_data,
                                   sxd_emad_fgcr_reg_t  *fgcr_reg);

/**
 *  This function formats FVET register layout from FVET register data.
 *
 * @param[in] fvet_data - FVET register data.
 * @param[out] fvet_reg - FVET register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_fvet(sxd_emad_fvet_data_t *fvet_data,
                                 sxd_emad_fvet_reg_t  *fvet_reg);

/**
 *  This function formats FVET register data from FVET register layout.
 *
 * @param[out] fvet_data - FVET register data.
 * @param[in] fvet_reg - FVET register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_fvet(sxd_emad_fvet_data_t *fvet_data,
                                   sxd_emad_fvet_reg_t  *fvet_reg);

/**
 *  This function formats FIPL register layout from FIPL register data.
 *
 * @param[in] fipl_data - FIPL register data.
 * @param[out] fipl_reg - FIPL register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_fipl(sxd_emad_fipl_data_t *fipl_data,
                                 sxd_emad_fipl_reg_t  *fipl_reg);

/**
 *  This function formats FIPL register data from FIPL register layout.
 *
 * @param[out] fipl_data - FIPL register data.
 * @param[in] fipl_reg - FIPL register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_fipl(sxd_emad_fipl_data_t *fipl_data,
                                   sxd_emad_fipl_reg_t  *fipl_reg);

/**
 *  This function formats FITR register layout from FITR register data.
 *
 * @param[in] fitr_data - FITR register data.
 * @param[out] fitr_reg - FITR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_fitr(sxd_emad_fitr_data_t *fitr_data,
                                 sxd_emad_fitr_reg_t  *fitr_reg);

/**
 *  This function formats FITR register data from FITR register layout.
 *
 * @param[out] fitr_data - FITR register data.
 * @param[in] fitr_reg - FITR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_fitr(sxd_emad_fitr_data_t *fitr_data,
                                   sxd_emad_fitr_reg_t  *fitr_reg);

/**
 *  This function formats FFAR register layout from FFAR register data.
 *
 * @param[in] ffar_data - FFAR register data.
 * @param[out] ffar_reg - FFAR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ffar(sxd_emad_ffar_data_t *ffar_data,
                                 sxd_emad_ffar_reg_t  *ffar_reg);

/**
 *  This function formats FFAR register data from FFAR register layout.
 *
 * @param[out] ffar_data - FFAR register data.
 * @param[in] ffar_reg - FFAR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ffar(sxd_emad_ffar_data_t *ffar_data,
                                   sxd_emad_ffar_reg_t  *ffar_reg);

/**
 *  This function formats FFTR register layout from FFTR register data.
 *
 * @param[in] fftr_data - FFTR register data.
 * @param[out] fftr_reg - FFTR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_fftr(sxd_emad_fftr_data_t *fftr_data,
                                 sxd_emad_fftr_reg_t  *fftr_reg);

/**
 *  This function formats FFTR register data from FFTR register layout.
 *
 * @param[out] fftr_data - FFTR register data.
 * @param[in] fftr_reg - FFTR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_fftr(sxd_emad_fftr_data_t *fftr_data,
                                   sxd_emad_fftr_reg_t  *fftr_reg);

#endif /* __SXD_EMAD_PARSER_FCF_H__ */
