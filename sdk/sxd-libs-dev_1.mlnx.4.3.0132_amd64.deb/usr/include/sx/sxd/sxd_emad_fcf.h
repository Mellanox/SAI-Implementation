/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FCF_H__
#define __SXD_EMAD_FCF_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_fcf_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 *  This function sets FGCR register data.
 *
 * @param[in] fgcr_data_arr - FGCR data array.
 * @param[in] fgcr_data_num - FGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fgcr_set(sxd_emad_fgcr_data_t         *fgcr_data_arr,
                               uint32_t                      fgcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets FGCR register data.
 *
 * @param[in] fgcr_data_arr - FGCR data array.
 * @param[in] fgcr_data_num - FGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fgcr_get(sxd_emad_fgcr_data_t         *fgcr_data_arr,
                               uint32_t                      fgcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets FVET register data.
 *
 * @param[in] fvet_data_arr - FVET data array.
 * @param[in] fvet_data_num - FVET data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fvet_set(sxd_emad_fvet_data_t         *fvet_data_arr,
                               uint32_t                      fvet_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets FVET register data.
 *
 * @param[in] fvet_data_arr - FVET data array.
 * @param[in] fvet_data_num - FVET data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fvet_get(sxd_emad_fvet_data_t         *fvet_data_arr,
                               uint32_t                      fvet_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets FIPL register data.
 *
 * @param[in] fipl_data_arr - FIPL data array.
 * @param[in] fipl_data_num - FIPL data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fipl_set(sxd_emad_fipl_data_t         *fipl_data_arr,
                               uint32_t                      fipl_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets FIPL register data.
 *
 * @param[in] fipl_data_arr - FIPL data array.
 * @param[in] fipl_data_num - FIPL data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fipl_get(sxd_emad_fipl_data_t         *fipl_data_arr,
                               uint32_t                      fipl_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets FITR register data.
 *
 * @param[in] fitr_data_arr - FITR data array.
 * @param[in] fitr_data_num - FITR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fitr_set(sxd_emad_fitr_data_t         *fitr_data_arr,
                               uint32_t                      fitr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets FITR register data.
 *
 * @param[in] fitr_data_arr - FITR data array.
 * @param[in] fitr_data_num - FITR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fitr_get(sxd_emad_fitr_data_t         *fitr_data_arr,
                               uint32_t                      fitr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets FFAR register data.
 *
 * @param[in] ffar_data_arr - FFAR data array.
 * @param[in] ffar_data_num - FFAR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ffar_set(sxd_emad_ffar_data_t         *ffar_data_arr,
                               uint32_t                      ffar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets FFAR register data.
 *
 * @param[in] ffar_data_arr - FFAR data array.
 * @param[in] ffar_data_num - FFAR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ffar_get(sxd_emad_ffar_data_t         *ffar_data_arr,
                               uint32_t                      ffar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets FFTR register data.
 *
 * @param[in] fftr_data_arr - FFTR data array.
 * @param[in] fftr_data_num - FFTR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fftr_set(sxd_emad_fftr_data_t         *fftr_data_arr,
                               uint32_t                      fftr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets FFTR register data.
 *
 * @param[in] fftr_data_arr - FFTR data array.
 * @param[in] fftr_data_num - FFTR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_fftr_get(sxd_emad_fftr_data_t         *fftr_data_arr,
                               uint32_t                      fftr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

#endif /* __SXD_EMAD_FCF_H__ */
