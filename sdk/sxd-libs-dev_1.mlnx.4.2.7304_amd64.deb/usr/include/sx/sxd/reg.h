/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

/*
 * THIS FILE IS AUTO GENERATRED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 */

#ifndef _MLXSW_REG_H
#define _MLXSW_REG_H

#include <stdint.h>

/* peapbl
 * ------
 *
 */
#define MLXSW_PEAPBL_ID  0x3024
#define MLXSW_PEAPBL_LEN 0x580

uint32_t mlxsw_reg_peapbl_tcam_region_info_get(const char *buf, unsigned short index);

void mlxsw_reg_peapbl_tcam_region_info_set(char *buf, unsigned short index, uint32_t val);

uint8_t mlxsw_reg_peapbl_c_s_get(const char *buf);

void mlxsw_reg_peapbl_c_s_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_peapbl_pruning_ctcam_cs_get(const char *buf);

void mlxsw_reg_peapbl_pruning_ctcam_cs_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_peapbl_num_rec_get(const char *buf);

void mlxsw_reg_peapbl_num_rec_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_peapbl_erp_id_mask_get(const char *buf);

void mlxsw_reg_peapbl_erp_id_mask_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_peapbl_erp_id_get(const char *buf);

void mlxsw_reg_peapbl_erp_id_set(char *buf, uint8_t val);

uint16_t mlxsw_reg_peapbl_pruning_vector_cs_get(const char *buf);

void mlxsw_reg_peapbl_pruning_vector_cs_set(char *buf, uint16_t val);

void mlxsw_reg_peapbl_key_entry_memcpy_from(const char *buf, unsigned short index, char *dst);

void mlxsw_reg_peapbl_key_entry_memcpy_to(char *buf, unsigned short index, const char *src);

/* pecnrr
 * ------
 *
 */
#define MLXSW_PECNRR_ID  0x3031
#define MLXSW_PECNRR_LEN 0x20

uint8_t mlxsw_reg_pecnrr_clear_get(const char *buf);

void mlxsw_reg_pecnrr_clear_set(char *buf, uint8_t val);

uint32_t mlxsw_reg_pecnrr_tcam_trigger_high_get(const char *buf);

void mlxsw_reg_pecnrr_tcam_trigger_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecnrr_tcam_trigger_low_get(const char *buf);

void mlxsw_reg_pecnrr_tcam_trigger_low_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecnrr_tcam_full_lookup_high_get(const char *buf);

void mlxsw_reg_pecnrr_tcam_full_lookup_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecnrr_tcam_full_lookup_low_get(const char *buf);

void mlxsw_reg_pecnrr_tcam_full_lookup_low_set(char *buf, uint32_t val);

/* rips
 * ----
 *
 */
#define MLXSW_RIPS_ID  0x8021
#define MLXSW_RIPS_LEN 0x14

uint32_t mlxsw_reg_rips_index_get(const char *buf);

void mlxsw_reg_rips_index_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_rips_ipv6_get(const char *buf, unsigned short index);

void mlxsw_reg_rips_ipv6_set(char *buf, unsigned short index, uint32_t val);

/* pecnee
 * ------
 *
 */
#define MLXSW_PECNEE_ID  0x3032
#define MLXSW_PECNEE_LEN 0x18

uint16_t mlxsw_reg_pecnee_region_id_get(const char *buf);

void mlxsw_reg_pecnee_region_id_set(char *buf, uint16_t val);

uint16_t mlxsw_reg_pecnee_region_id_mask_get(const char *buf);

void mlxsw_reg_pecnee_region_id_mask_set(char *buf, uint16_t val);

uint16_t mlxsw_reg_pecnee_erp_index_bitwise_get(const char *buf);

void mlxsw_reg_pecnee_erp_index_bitwise_set(char *buf, uint16_t val);

uint8_t mlxsw_reg_pecnee_ctcam_get(const char *buf);

void mlxsw_reg_pecnee_ctcam_set(char *buf, uint8_t val);

/* pecnre
 * ------
 *
 */
#define MLXSW_PECNRE_ID  0x3030
#define MLXSW_PECNRE_LEN 0x10

uint16_t mlxsw_reg_pecnre_region_id_get(const char *buf);

void mlxsw_reg_pecnre_region_id_set(char *buf, uint16_t val);

uint16_t mlxsw_reg_pecnre_region_id_mask_get(const char *buf);

void mlxsw_reg_pecnre_region_id_mask_set(char *buf, uint16_t val);

/* peaps
 * -----
 *
 */
#define MLXSW_PEAPS_ID  0x3026
#define MLXSW_PEAPS_LEN 0x34

uint8_t mlxsw_reg_peaps_busy_get(const char *buf);

void mlxsw_reg_peaps_busy_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_peaps_ovf_get(const char *buf);

void mlxsw_reg_peaps_ovf_set(char *buf, uint8_t val);

uint32_t mlxsw_reg_peaps_tcam_region_info_get(const char *buf, unsigned short index);

void mlxsw_reg_peaps_tcam_region_info_set(char *buf, unsigned short index, uint32_t val);

uint32_t mlxsw_reg_peaps_priority_start_get(const char *buf);

void mlxsw_reg_peaps_priority_start_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_peaps_priority_end_get(const char *buf);

void mlxsw_reg_peaps_priority_end_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_peaps_priority_inc_get(const char *buf);

void mlxsw_reg_peaps_priority_inc_set(char *buf, uint32_t val);

/* rmftad
 * ------
 *
 */
#define MLXSW_RMFTAD_ID  0x8028
#define MLXSW_RMFTAD_LEN 0x220

uint8_t mlxsw_reg_rmftad_op_get(const char *buf);

void mlxsw_reg_rmftad_op_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_rmftad_type_get(const char *buf);

void mlxsw_reg_rmftad_type_set(char *buf, uint8_t val);

uint16_t mlxsw_reg_rmftad_offset_get(const char *buf);

void mlxsw_reg_rmftad_offset_set(char *buf, uint16_t val);

uint16_t mlxsw_reg_rmftad_num_rec_get(const char *buf);

void mlxsw_reg_rmftad_num_rec_set(char *buf, uint16_t val);

uint32_t mlxsw_reg_rmftad_activity_vector_get(const char *buf, unsigned short index);

void mlxsw_reg_rmftad_activity_vector_set(char *buf, unsigned short index, uint32_t val);

/* sfdb
 * ----
 *
 */
#define MLXSW_SFDB_ID  0x2028
#define MLXSW_SFDB_LEN 0x44

uint8_t mlxsw_reg_sfdb_update_type_get(const char *buf);

void mlxsw_reg_sfdb_update_type_set(char *buf, uint8_t val);

uint16_t mlxsw_reg_sfdb_entry_fid_get(const char *buf);

void mlxsw_reg_sfdb_entry_fid_set(char *buf, uint16_t val);

uint32_t mlxsw_reg_sfdb_parameter_get(const char *buf);

void mlxsw_reg_sfdb_parameter_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_sfdb_new_parameter_get(const char *buf);

void mlxsw_reg_sfdb_new_parameter_set(char *buf, uint32_t val);

/* pefaad
 * ------
 *
 */
#define MLXSW_PEFAAD_ID  0x3029
#define MLXSW_PEFAAD_LEN 0x420

uint8_t mlxsw_reg_pefaad_filter_fields_get(const char *buf);

void mlxsw_reg_pefaad_filter_fields_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_pefaad_op_get(const char *buf);

void mlxsw_reg_pefaad_op_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_pefaad_end_get(const char *buf);

void mlxsw_reg_pefaad_end_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_pefaad_num_rec_get(const char *buf);

void mlxsw_reg_pefaad_num_rec_set(char *buf, uint8_t val);

uint8_t mlxsw_reg_pefaad_entry_a_get(const char *buf);

void mlxsw_reg_pefaad_entry_a_set(char *buf, uint8_t val);

uint32_t mlxsw_reg_pefaad_entry_index_start_get(const char *buf);

void mlxsw_reg_pefaad_entry_index_start_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pefaad_entry_index_end_get(const char *buf);

void mlxsw_reg_pefaad_entry_index_end_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pefaad_index_dump_get(const char *buf, unsigned short index);

void mlxsw_reg_pefaad_index_dump_set(char *buf, unsigned short index, uint32_t val);

/* pemrbt
 * ------
 *
 */
#define MLXSW_PEMRBT_ID  0x3014
#define MLXSW_PEMRBT_LEN 0x14

uint8_t mlxsw_reg_pemrbt_protocol_get(const char *buf);

void mlxsw_reg_pemrbt_protocol_set(char *buf, uint8_t val);

uint16_t mlxsw_reg_pemrbt_group_id_get(const char *buf);

void mlxsw_reg_pemrbt_group_id_set(char *buf, uint16_t val);

/* ptcead
 * ------
 *
 */
#define MLXSW_PTCEAD_ID  0x3028
#define MLXSW_PTCEAD_LEN 0x220

uint8_t mlxsw_reg_ptcead_op_get(const char *buf);

void mlxsw_reg_ptcead_op_set(char *buf, uint8_t val);

uint16_t mlxsw_reg_ptcead_offset_get(const char *buf);

void mlxsw_reg_ptcead_offset_set(char *buf, uint16_t val);

uint16_t mlxsw_reg_ptcead_num_rec_get(const char *buf);

void mlxsw_reg_ptcead_num_rec_set(char *buf, uint16_t val);

void mlxsw_reg_ptcead_tcam_region_info_memcpy_from(const char *buf, char *dst);

void mlxsw_reg_ptcead_tcam_region_info_memcpy_to(char *buf, const char *src);

uint32_t mlxsw_reg_ptcead_activity_vector_get(const char *buf, unsigned short index);

void mlxsw_reg_ptcead_activity_vector_set(char *buf, unsigned short index, uint32_t val);

/* pecner
 * ------
 *
 */
#define MLXSW_PECNER_ID  0x3033
#define MLXSW_PECNER_LEN 0x40

uint8_t mlxsw_reg_pecner_clear_get(const char *buf);

void mlxsw_reg_pecner_clear_set(char *buf, uint8_t val);

uint32_t mlxsw_reg_pecner_erp_initial_high_get(const char *buf);

void mlxsw_reg_pecner_erp_initial_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_initial_low_get(const char *buf);

void mlxsw_reg_pecner_erp_initial_low_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_post_bf_high_get(const char *buf);

void mlxsw_reg_pecner_erp_post_bf_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_post_bf_low_get(const char *buf);

void mlxsw_reg_pecner_erp_post_bf_low_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_lookup_high_get(const char *buf);

void mlxsw_reg_pecner_erp_lookup_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_lookup_low_get(const char *buf);

void mlxsw_reg_pecner_erp_lookup_low_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_any_match_high_get(const char *buf);

void mlxsw_reg_pecner_erp_any_match_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_any_match_low_get(const char *buf);

void mlxsw_reg_pecner_erp_any_match_low_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_final_match_high_get(const char *buf);

void mlxsw_reg_pecner_erp_final_match_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_final_match_low_get(const char *buf);

void mlxsw_reg_pecner_erp_final_match_low_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_prune_high_get(const char *buf);

void mlxsw_reg_pecner_erp_prune_high_set(char *buf, uint32_t val);

uint32_t mlxsw_reg_pecner_erp_prune_low_get(const char *buf);

void mlxsw_reg_pecner_erp_prune_low_set(char *buf, uint32_t val);


#endif /* _MLXSW_REG_H */
