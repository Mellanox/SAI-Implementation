/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_MC_CONTAINER_H__
#define __SX_MC_CONTAINER_H__

#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_status.h>
#include <sx/sdk/sx_router.h>
#include <sx/sdk/sx_flow_counter.h>
#include <resource_manager/resource_manager.h>

/************************************************
 *  Type definitions
 ***********************************************/

/** Defines the type of a multicast next hop */
typedef enum sx_mc_next_hop_type {
    SX_MC_NEXT_HOP_TYPE_VIF = 1,        /**< A router's endpoint such as RIF or tunnel */
    SX_MC_NEXT_HOP_TYPE_LOG_PORT,       /**< A physical or logical port */
    SX_MC_NEXT_HOP_TYPE_ECMP,           /**< An ECMP container */
    SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP,   /**< A nexthop for tunnel encapsulation */
    SX_MC_NEXT_HOP_TYPE_MIN = SX_MC_NEXT_HOP_TYPE_VIF,
    SX_MC_NEXT_HOP_TYPE_MAX = SX_MC_NEXT_HOP_TYPE_TUNNEL_ENCAP_IP
} sx_mc_next_hop_type_t;

#define SX_MC_NEXT_HOP_TYPE_NUM (SX_MC_NEXT_HOP_TYPE_MAX + 1)

#define SX_MC_NEXT_HOP_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_MC_NEXT_HOP_TYPE_MIN, (TYPE), SX_MC_NEXT_HOP_TYPE_MAX))

static __attribute__((__used__)) const char* sx_mc_next_hop_type_str[] = {
    "N/A",
    "VIF",
    "Logical Port",
    "ECMP",
    "Tunnel ENCAP IP",
};

#define SX_MC_NEXT_HOP_TYPE_STR_LEN (sizeof(sx_mc_next_hop_type_str) / sizeof(sx_mc_next_hop_type_str[0]))

#define SX_MC_NEXT_HOP_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_MC_NEXT_HOP_TYPE_STR_LEN - 1) ? \
     sx_mc_next_hop_type_str[index] : "UNKNOWN")

typedef union {
    sx_router_vinterface_t     vif;
    sx_port_log_id_t           log_port;
    sx_ecmp_id_t               ecmp_id;
    sx_ip_next_hop_ip_tunnel_t tunnel_ip;
} sx_mc_next_hop_data_t;

/** Defines a multicast next hop which may be used inside a multicast container */
typedef struct sx_mc_next_hop {
    sx_mc_next_hop_type_t type; /**< Type of next hop */
    sx_mc_next_hop_data_t data; /**< Per-type additional identifier(s) for the next hop */
} sx_mc_next_hop_t;

/** Defines the type of a multicast next hop */
typedef enum sx_mc_container_type {
    SX_MC_CONTAINER_TYPE_ERIF = 1,
    SX_MC_CONTAINER_TYPE_NVE_FLOOD,
    SX_MC_CONTAINER_TYPE_BRIDGE_MC,
    SX_MC_CONTAINER_TYPE_MIN = SX_MC_CONTAINER_TYPE_ERIF,
    SX_MC_CONTAINER_TYPE_MAX = SX_MC_CONTAINER_TYPE_BRIDGE_MC
} sx_mc_container_type_t;

#define SX_MC_CONTAINER_TYPE_CHECK_RANGE(TYPE) \
    (SX_CHECK_RANGE(SX_MC_CONTAINER_TYPE_MIN, (TYPE), SX_MC_CONTAINER_TYPE_MAX))

static __attribute__((__used__)) const char* sx_mc_container_type_str[] = {
    "N/A",
    "ERIF",
    "NVE FLOOD",
    "BRIDGE MC"
};

#define SX_MC_CONTAINER_TYPE_STR_LEN (sizeof(sx_mc_container_type_str) / sizeof(sx_mc_container_type_str[0]))

#define SX_MC_CONTAINER_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_MC_CONTAINER_TYPE_STR_LEN - 1) ? \
     sx_mc_container_type_str[index] : "UNKNOWN")

/** Defines attributes of a multicast container */
typedef struct sx_mc_container_attributes {
    sx_mc_container_type_t type;
    uint32_t               min_mtu; /**< Minimum MTU of all next hops within the container */
    sx_fid_t               fid;
} sx_mc_container_attributes_t;

#endif /* __SX_MC_CONTAINER_H__ */
