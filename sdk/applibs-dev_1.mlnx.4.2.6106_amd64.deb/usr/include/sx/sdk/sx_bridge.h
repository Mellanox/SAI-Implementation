/*
 *  Copyright (C) 2010-2017. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_BRIDGE_H_
#define SX_BRIDGE_H_

#include <sx/sdk/sx_tunnel_id.h>

/************************************************
 *  Type definitions
 ***********************************************/
typedef uint16_t sx_bridge_id_t;

/*********
* ENUMS *
*********/

typedef enum sx_bridge_mode {
    SX_MODE_802_1Q = 0, /**< traffic class group 0 */
    SX_MODE_802_1D = 1, /**< traffic class group 1 */
    SX_MODE_HYBRID = 2, /** Supported devices: Spectrum */
    SX_MODE_MAX = SX_MODE_HYBRID
} sx_bridge_mode_t;

static __attribute__((__used__)) const char* sx_bridge_mode_str[] = {
    "SX_MODE_802_1Q",
    "SX_MODE_802_1D",
    "SX_MODE_HYBRID",
};

#define SX_BRIDGE_MODE_STR_LEN (sizeof(sx_bridge_mode_str) / sizeof(char*))
#define SX_BRIDGE_MODE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_BRIDGE_MODE_STR_LEN - 1) ? \
     sx_bridge_mode_str[index] : "UNKNOWN")

static __attribute__((__used__)) const char* sx_bridge_multiple_vlan_mode_str[] = {
    "HOMOGENEOUS MODE",
    "NON HOMOGENEOUS MODE",
};

#define SX_BRIDGE_MULTIPLE_VLAN_MODE_STR_LEN (sizeof(sx_bridge_multiple_vlan_mode_str) / sizeof(char*))
#define SX_BRIDGE_MULTIPLE_VLAN_MODE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_BRIDGE_MULTIPLE_VLAN_MODE_STR_LEN - 1) ? \
     sx_bridge_multiple_vlan_mode_str[index] : "UNKNOWN")


typedef enum sx_bridge_multiple_vlan_mode {
    SX_BRIDGE_MULTIPLE_VLAN_MODE_HOMOGENOUS = 0,
    SX_BRIDGE_MULTIPLE_VLAN_MODE_NON_HOMOGENOUS = 1,
    SX_BRIDGE_MULTIPLE_VLAN_MODE_MAX = SX_BRIDGE_MULTIPLE_VLAN_MODE_NON_HOMOGENOUS
} sx_bridge_multiple_vlan_mode_t;

typedef enum sx_bridge_tunnel_counter_type {
    SX_BRIDGE_COUNTER_TUNNEL_DECAP_E = 0,
    SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E = 1,
    SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E = 2,

    SX_BRIDGE_COUNTER_TUNNEL_TYPE_MIN = SX_BRIDGE_COUNTER_TUNNEL_DECAP_E,
    SX_BRIDGE_COUNTER_TUNNEL_TYPE_MAX = SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E
} sx_bridge_tunnel_counter_type_t;

static __attribute__((__used__)) const char* sx_bridge_tunnel_counter_type_str[] = {
    "SX_BRIDGE_COUNTER_TUNNEL_DECAP_E",
    "SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E",
    "SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E",
};

#define SX_BRIDGE_TUNNEL_COUNTER_TYPE_STR_LEN (sizeof(sx_bridge_tunnel_counter_type_str) / sizeof(char*))
#define SX_BRIDGE_TUNNEL_COUNTER_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_BRIDGE_TUNNEL_COUNTER_TYPE_STR_LEN - 1) ? \
     sx_bridge_tunnel_counter_type_str[index] : "UNKNOWN")

/**********************************************
 *  DEFINITIONS
 ***********************************************/

typedef boolean_t sx_mode_802_1Q_t;

#define SX_BRIDGE_ID_INVALID 0xffff

typedef struct sx_mode_802_1D {
    uint32_t                       max_bridge_num;
    uint32_t                       max_virtual_ports_num;
    sx_bridge_multiple_vlan_mode_t multiple_vlan_bridge_mode;
} sx_mode_802_1D_t;

typedef struct sx_mode_hybrid {
    uint32_t max_bridge_num;
} sx_mode_hybrid_t;

typedef union sx_bridge_mode_params {
    sx_mode_802_1Q_t mode_1Q;
    sx_mode_802_1D_t mode_1D;
    sx_mode_hybrid_t mode_hybrid; /** Supported devices: Spectrum */
} sx_bridge_mode_params_t;

typedef struct sx_bridge_params {
    sx_bridge_mode_t        sdk_mode;
    sx_bridge_mode_params_t sdk_mode_params;
} sx_bridge_params_t;

typedef struct sx_bridge_port {
    sx_port_log_id_t           log_port;
    sx_vlan_id_t               vlan;
    sx_untagged_member_state_t egress_mode;
} sx_bridge_port_t;

typedef struct sx_bridge_tunnel_counter_attr {
    sx_bridge_tunnel_counter_type_t type;       /* type of bridge_tunnel flow counter*/
    sx_tunnel_id_t                  tunnel_id;  /* tunnel which is mapped to bridge */
} sx_bridge_tunnel_counter_attr_t;

typedef struct sx_bridge_filter {
    /* Reserved for future expansion*/
} sx_bridge_filter_t;


#endif /* SX_BRIDGE_H_ */
