/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 */

#ifndef __SXD_EMAD_AUTO_REG_H__
#define __SXD_EMAD_AUTO_REG_H__


#include <sx/sxd/sxd_types.h>
#include <sx/sxd/auto_registers/reg.h>

#include <complib/cl_packon.h>
/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_pecnrr_reg_t structure is used to store PECNRR register layout.
 */
typedef struct sxd_emad_pecnrr_reg {
    char reg[MLXSW_PECNRR_LEN];
} PACK_SUFFIX sxd_emad_pecnrr_reg_t;

/**
 * sxd_emad_pecnee_reg_t structure is used to store PECNEE register layout.
 */
typedef struct sxd_emad_pecnee_reg {
    char reg[MLXSW_PECNEE_LEN];
} PACK_SUFFIX sxd_emad_pecnee_reg_t;

/**
 * sxd_emad_paos_reg_t structure is used to store PAOS register layout.
 */
typedef struct sxd_emad_paos_reg {
    char reg[MLXSW_PAOS_LEN];
} PACK_SUFFIX sxd_emad_paos_reg_t;

/**
 * sxd_emad_sfdb_reg_t structure is used to store SFDB register layout.
 */
typedef struct sxd_emad_sfdb_reg {
    char reg[MLXSW_SFDB_LEN];
} PACK_SUFFIX sxd_emad_sfdb_reg_t;

/**
 * sxd_emad_rips_reg_t structure is used to store RIPS register layout.
 */
typedef struct sxd_emad_rips_reg {
    char reg[MLXSW_RIPS_LEN];
} PACK_SUFFIX sxd_emad_rips_reg_t;

/**
 * sxd_emad_pecner_reg_t structure is used to store PECNER register layout.
 */
typedef struct sxd_emad_pecner_reg {
    char reg[MLXSW_PECNER_LEN];
} PACK_SUFFIX sxd_emad_pecner_reg_t;

/**
 * sxd_emad_pecnre_reg_t structure is used to store PECNRE register layout.
 */
typedef struct sxd_emad_pecnre_reg {
    char reg[MLXSW_PECNRE_LEN];
} PACK_SUFFIX sxd_emad_pecnre_reg_t;

/**
 * sxd_emad_pemrbt_reg_t structure is used to store PEMRBT register layout.
 */
typedef struct sxd_emad_pemrbt_reg {
    char reg[MLXSW_PEMRBT_LEN];
} PACK_SUFFIX sxd_emad_pemrbt_reg_t;

/**
 * sxd_emad_pefaad_reg_t structure is used to store PEFAAD register layout.
 */
typedef struct sxd_emad_pefaad_reg {
    char reg[MLXSW_PEFAAD_LEN];
} PACK_SUFFIX sxd_emad_pefaad_reg_t;

/**
 * sxd_emad_pmtps_reg_t structure is used to store PMTPS register layout.
 */
typedef struct sxd_emad_pmtps_reg {
    char reg[MLXSW_PMTPS_LEN];
} PACK_SUFFIX sxd_emad_pmtps_reg_t;


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_AUTO_REG_H__ */
