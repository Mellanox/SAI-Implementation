/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 */

CTRL_CMD_ACCESS_REG_PECNRR, /**< Run access register PECNRR command */
CTRL_CMD_ACCESS_REG_PECNEE, /**< Run access register PECNEE command */
CTRL_CMD_ACCESS_REG_PAOS, /**< Run access register PAOS command */
CTRL_CMD_ACCESS_REG_SFDB, /**< Run access register SFDB command */
CTRL_CMD_ACCESS_REG_RIPS, /**< Run access register RIPS command */
CTRL_CMD_ACCESS_REG_PECNER, /**< Run access register PECNER command */
CTRL_CMD_ACCESS_REG_PECNRE, /**< Run access register PECNRE command */
CTRL_CMD_ACCESS_REG_PEMRBT, /**< Run access register PEMRBT command */
CTRL_CMD_ACCESS_REG_PEFAAD, /**< Run access register PEFAAD command */
CTRL_CMD_ACCESS_REG_PMTPS, /**< Run access register PMTPS command */
