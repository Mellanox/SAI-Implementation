/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 */

SXD_REG_ID_PECNRR_E    = MLXSW_PECNRR_ID,
SXD_REG_ID_PECNEE_E    = MLXSW_PECNEE_ID,
SXD_REG_ID_PAOS_E      = MLXSW_PAOS_ID,
SXD_REG_ID_SFDB_E      = MLXSW_SFDB_ID,
SXD_REG_ID_RIPS_E      = MLXSW_RIPS_ID,
SXD_REG_ID_PECNER_E    = MLXSW_PECNER_ID,
SXD_REG_ID_PECNRE_E    = MLXSW_PECNRE_ID,
SXD_REG_ID_PEMRBT_E    = MLXSW_PEMRBT_ID,
SXD_REG_ID_PEFAAD_E    = MLXSW_PEFAAD_ID,
SXD_REG_ID_PMTPS_E     = MLXSW_PMTPS_ID,
