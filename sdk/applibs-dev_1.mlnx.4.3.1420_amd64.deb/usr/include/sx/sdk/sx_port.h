/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_PORT_H__
#define __SX_PORT_H__

#include <complib/cl_packon.h>
#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_passivelock.h>

#include <sx/sdk/sx_policer.h>
#include <sx/sdk/sx_cos.h>
#include <sx/sxd/sxd_port.h>

#include <sx/sdk/sx_dev.h>

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * Split ports numbers:
 ******************************************************************************
 * 1 - QSFP/ SFP+
 * 2 - Splitter cable * 2
 * 4 - Splitter cable * 4
 */
typedef enum sx_port_split_num {
    SX_PORT_QSFP_MAP_NUM_PORTS = 1,
    SX_PORT_SPLIT_2_MAP_NUM_PORTS = 2,
    SX_PORT_SPLIT_4_MAP_NUM_PORTS = 4,
    SX_PORT_SPLIT_NUM_MIN = SX_PORT_QSFP_MAP_NUM_PORTS,
    SX_PORT_SPLIT_NUM_MAX = SX_PORT_SPLIT_4_MAP_NUM_PORTS,
} sx_port_split_num_t;

#define FOREACH_PORT_MODULE_STATE(F)                                                                            \
    F(SX_PORT_MODULE_STATUS_INITIALIZING = 0, "Initializing")                                                   \
    F(SX_PORT_MODULE_STATUS_PLUGGED = SXD_PORT_MODULE_STATUS_PLUGGED, "Plugged")                                \
    F(SX_PORT_MODULE_STATUS_UNPLUGGED = SXD_PORT_MODULE_STATUS_UNPLUGGED, "Unplugged")                          \
    F(SX_PORT_MODULE_STATUS_PLUGGED_WITH_ERROR = SXD_PORT_MODULE_STATUS_PLUGGED_WITH_ERROR, "PluggedWithError") \
    F(SX_PORT_MODULE_STATUS_PLUGGED_DISABLED = SXD_PORT_MODULE_STATUS_PLUGGED_DISABLED, "PluggedDisabled")      \
    F(SX_PORT_MODULE_STATUS_MIN = SX_PORT_MODULE_STATUS_INITIALIZING, "")                                       \
    F(SX_PORT_MODULE_STATUS_MAX = SX_PORT_MODULE_STATUS_PLUGGED_DISABLED, "")
/**
 * Port module (operational) state:
 ******************************************************************************
 * 000 - Initializing
 * 001 - Plugged.
 * 010 - Unplugged (Default)
 * 011 - PluggedWithError
 */
typedef enum sx_port_module_state {
    FOREACH_PORT_MODULE_STATE(SX_GENERATE_ENUM)
} sx_port_module_state_t;

typedef enum sx_port_module_error_type {
    SX_PORT_MODULE_ERROR_TYPE_POWER_BUDGET_EXCEEDED = 0,
    SX_PORT_MODULE_ERROR_TYPE_LONG_RANGE = 1,
    SX_PORT_MODULE_ERROR_TYPE_BUS_STUCK = 2,
    SX_PORT_MODULE_ERROR_TYPE_BAD_UNSUPPORTED_EEPROM = 3,
    SX_PORT_MODULE_ERROR_TYPE_ENFORCE_PART_NUMBER_LIST = 4,
    SX_PORT_MODULE_ERROR_TYPE_UNSUPPORTED_CABLE = 5,
    SX_PORT_MODULE_ERROR_TYPE_HIGH_TEMPERATURE = 6,
    SX_PORT_MODULE_ERROR_TYPE_BAD_CABLE = 7,
} sx_port_module_error_type_t;

#define SX_PORT_SFLOW_DEVIATION_MAX   50
#define SX_PORT_MODULE_STATUS_DEFAULT SX_PORT_MODULE_STATUS_UNPLUGGED
#define SX_PORT_MODULE_STATUS_MIN_MAX SX_PORT_MODULE_STATUS_MIN, SX_PORT_MODULE_STATUS_MAX
#define SX_PORT_MODULE_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_MODULE_STATUS_MIN,     \
                   (int)status,                   \
                   SX_PORT_MODULE_STATUS_MAX)
#define SX_PORT_MODULE_INDICES_DB_SIZE (1024 * 1024)

#define FOREACH_PORT_ADMIN_STATE(F)                                            \
    F(SX_PORT_ADMIN_STATUS_NONE = 0, "N/A")                                    \
    F(SX_PORT_ADMIN_STATUS_UP = SXD_PORT_ADMIN_STATUS_UP, "Up")                \
    F(SX_PORT_ADMIN_STATUS_DOWN = SXD_PORT_ADMIN_STATUS_DOWN_BY_CONF, "Down")  \
    F(SX_PORT_ADMIN_STATUS_UP_ONCE = SXD_PORT_ADMIN_STATUS_UP_ONCE, "Up Once") \
    F(SX_PORT_ADMIN_STATUS_CONFIGURABLE = SX_PORT_ADMIN_STATUS_DOWN, "")       \
    F(SX_PORT_ADMIN_STATUS_MIN = SX_PORT_ADMIN_STATUS_UP, "")                  \
    F(SX_PORT_ADMIN_STATUS_MAX = SX_PORT_ADMIN_STATUS_DOWN, "")
/**
 * Port administrative state (the desired state of the interface):
 ******************************************************************************
 * 0001 - Up.
 * 0010 - Down by configuration (default).
 *
 * Up once state is for internal use only.
 */
typedef enum sx_port_admin_state {
    FOREACH_PORT_ADMIN_STATE(SX_GENERATE_ENUM)
} sx_port_admin_state_t;

#define SX_PORT_ADMIN_STATUS_DEFAULT SX_PORT_ADMIN_STATUS_DOWN
#define SX_PORT_ADMIN_STATUS_MIN_MAX SX_PORT_ADMIN_STATUS_MIN, SX_PORT_ADMIN_STATUS_MAX
#define SX_PORT_ADMIN_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_ADMIN_STATUS_MIN,     \
                   (int)status,                  \
                   SX_PORT_ADMIN_STATUS_MAX)


#define FOREACH_PORT_OPER_STATE(F)                                         \
    F(SX_PORT_OPER_STATUS_NONE = 0, "N/A")                                 \
    F(SX_PORT_OPER_STATUS_UP = 0x1 << 0, "Up")                             \
    F(SX_PORT_OPER_STATUS_DOWN = 0x1 << 1, "Down")                         \
    F(SX_PORT_OPER_STATUS_INVALID = 3, "N/A")                              \
    F(SX_PORT_OPER_STATUS_DOWN_BY_FAIL = 0x1 << 2, "Down by Port Failure") \
    F(SX_PORT_OPER_STATUS_MIN = SX_PORT_OPER_STATUS_UP, "")                \
    F(SX_PORT_OPER_STATUS_MAX = SX_PORT_OPER_STATUS_DOWN_BY_FAIL, "")
/**
 * Port operational state:
 ******************************************************************************
 * 0001 - Up.
 * 0010 - Down.
 * 0100 - Down by port failure (transitioned by the hardware).
 */
typedef enum sx_port_oper_state {
    FOREACH_PORT_OPER_STATE(SX_GENERATE_ENUM)
} sx_port_oper_state_t;

#define SX_PORT_OPER_STATUS_DEFAULT SX_PORT_OPER_STATUS_DOWN
#define SX_PORT_OPER_STATUS_MIN_MAX SX_PORT_OPER_STATUS_MIN, SX_PORT_OPER_STATUS_MAX
#define SX_PORT_OPER_STATUS_CHECK_RANGE(status) \
    SX_CHECK_RANGE(SX_PORT_OPER_STATUS_MIN,     \
                   (int)status,                 \
                   SX_PORT_OPER_STATUS_MAX)

#define FOREACH_PORT_TYPE(F)                       \
    F(SX_PORT_TYPE_NETWORK = 0, "Network")         \
    F(SX_PORT_TYPE_LAG = 1, "LAG")                 \
    F(SX_PORT_TYPE_VPORT = 2, "Vport")             \
    F(SX_PORT_TYPE_VLAG = 3, "VLAG")               \
    F(SX_PORT_TYPE_INVALID = 4, "N/A")             \
    F(SX_PORT_TYPE_INVALID2 = 5, "N/A")            \
    F(SX_PORT_TYPE_INVALID3 = 6, "N/A")            \
    F(SX_PORT_TYPE_INVALID4 = 7, "N/A")            \
    F(SX_PORT_TYPE_NVE = 8, "NVE")                 \
    F(SX_PORT_TYPE_MIN = SX_PORT_TYPE_NETWORK, "") \
    F(SX_PORT_TYPE_MAX = SX_PORT_TYPE_NVE, "")

/** This enum defines bitmask values for combinations of port types */
typedef enum sx_port_type {
    FOREACH_PORT_TYPE(SX_GENERATE_ENUM)
} sx_port_type_t;

#define SX_PORT_TYPE_DEFAULT SX_PORT_TYPE_NETWORK
#define SX_PORT_TYPE_MIN_MAX SX_PORT_TYPE_MIN, SX_PORT_TYPE_MAX
#define SX_PORT_TYPE_CHECK_RANGE(type) SX_CHECK_RANGE(SX_PORT_TYPE_MIN, (int)type, SX_PORT_TYPE_MAX)

typedef enum sx_port_lag_member {
    SX_PORT_LAG_NOT_MEMBER = 0,
    SX_PORT_LAG_MEMBER
} sx_port_lag_member_t;

#define FOREACH_PORT_MODE(F)                        \
    F(SX_PORT_MODE_EXTERNAL, "External")            \
    F(SX_PORT_MODE_STACKING, "Stacking")            \
    F(SX_PORT_MODE_TCA_CONNECTOR, "TCA Connector")  \
    F(SX_PORT_MODE_CPU, "CPU")                      \
    F(SX_PORT_MODE_NVE, "NVE")                      \
    F(SX_PORT_MODE_MIN = SX_PORT_MODE_EXTERNAL, "") \
    F(SX_PORT_MODE_MAX = SX_PORT_MODE_NVE, "")

typedef enum sx_port_mode {
    FOREACH_PORT_MODE(SX_GENERATE_ENUM)
} sx_port_mode_t;

typedef enum sx_port_fec_mode_field_bit {
    SX_PORT_FEC_MODE_AUTO = 0,
    SX_PORT_FEC_MODE_NONE = 1,
    SX_PORT_FEC_MODE_FC = 2,
    SX_PORT_FEC_MODE_RS = 4,
    SX_PORT_FEC_MODE_MIN = SX_PORT_FEC_MODE_AUTO,
    SX_PORT_FEC_MODE_MAX = SX_PORT_FEC_MODE_RS,
} sx_port_fec_mode_field_bit_e;

#define SX_PORT_FEC_MODE_STR(val) \
    #val

typedef struct sx_port_phy_mode {
    sx_port_fec_mode_field_bit_e fec_mode;
} sx_port_phy_mode_t;

#define FOREACH_PORT_PHY_SPEED(F)                         \
    F(SX_PORT_PHY_SPEED_10GB = 0, "10Gb")                 \
    F(SX_PORT_PHY_SPEED_40GB = 1, "40Gb")                 \
    F(SX_PORT_PHY_SPEED_25GB = 2, "25Gb")                 \
    F(SX_PORT_PHY_SPEED_50GB = 3, "50Gb")                 \
    F(SX_PORT_PHY_SPEED_100GB = 4, "100Gb")               \
    F(SX_PORT_PHY_SPEED_56GB = 5, "56Gb")                 \
    F(SX_PORT_PHY_SPEED_MIN = SX_PORT_PHY_SPEED_10GB, "") \
    F(SX_PORT_PHY_SPEED_MAX = SX_PORT_PHY_SPEED_56GB, "")

typedef enum sx_port_phy_speed {
    FOREACH_PORT_PHY_SPEED(SX_GENERATE_ENUM)
} sx_port_phy_speed_t;

#define NUM_OF_SPEEDS (SX_PORT_PHY_SPEED_MAX - SX_PORT_PHY_SPEED_MIN + 1)

#define SX_PORT_PHY_SPEED_CHECK_RANGE(speed) SX_CHECK_RANGE(SX_PORT_PHY_SPEED_MIN, (int)speed, SX_PORT_PHY_SPEED_MAX)

#define SX_PORT_MODE_DEFAULT SX_PORT_MODE_EXTERNAL

#define SX_PORT_MODE_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_MODE_MIN, (int)mode, SX_PORT_MODE_MAX)

#define FOREACH_PORT_MAPPING_MODE(F)                               \
    F(SX_PORT_MAPPING_MODE_DISABLE = 0, "Disable")                 \
    F(SX_PORT_MAPPING_MODE_ENABLE, "Enable")                       \
    F(SX_PORT_MAPPING_MODE_MIN = SX_PORT_MAPPING_MODE_DISABLE, "") \
    F(SX_PORT_MAPPING_MODE_MAX = SX_PORT_MAPPING_MODE_ENABLE, "")

typedef enum sx_port_mapping_mode {
    FOREACH_PORT_MAPPING_MODE(SX_GENERATE_ENUM)
} sx_port_mapping_mode_t;

#define SX_PORT_MAPPING_MODE_DEFAULT SX_PORT_MAPPING_MODE_DISABLE
#define SX_PORT_MAPPING_MODE_MIN_MAX SX_PORT_MAPPING_MODE_MIN, SX_PORT_MAPPING_MODE_MAX
#define SX_PORT_MAPPING_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_MAPPING_MODE_MIN,   \
                   (int)mode,                  \
                   SX_PORT_MAPPING_MODE_MAX)

#define FOREACH_PORT_PHYS_LOOPBACK(F)                                     \
    F(SX_PORT_PHYS_LOOPBACK_DISABLE = 0, "LOOPBACK_DISABLED")             \
    F(SX_PORT_PHYS_LOOPBACK_ENABLE_EXTERNAL, "EXTERNAL_LOOPBACK_ENABLED") \
    F(SX_PORT_PHYS_LOOPBACK_ENABLE_INTERNAL, "INTERNAL_LOOPBACK_ENABLED") \
    F(SX_PORT_PHYS_LOOPBACK_ENABLE_BOTH, "INTERNAL_LOOPBACK_ENABLED")     \
    F(SX_PORT_PHYS_LOOPBACK_MIN = SX_PORT_PHYS_LOOPBACK_DISABLE, "")      \
    F(SX_PORT_PHYS_LOOPBACK_MAX = SX_PORT_PHYS_LOOPBACK_ENABLE_BOTH, "")

typedef enum sx_port_phys_loopback {
    FOREACH_PORT_PHYS_LOOPBACK(SX_GENERATE_ENUM)
} sx_port_phys_loopback_t;

#define SX_PORT_PHYS_LOOPBACK_CHECK_RANGE(phys) \
    SX_CHECK_RANGE(SX_PORT_PHYS_LOOPBACK_MIN,   \
                   (int)phys,                   \
                   SX_PORT_PHYS_LOOPBACK_MAX)


typedef uint16_t sx_port_mtu_t;

#define SX_PORT_MTU_DEFAULT (1522)
#define SX_PORT_MTU_MIN     (68)
#define SX_PORT_MTU_MAX     (10000)
#define SX_L2_HEADER_BYTES  (22)

#define SX_PORT_MTU_CHECK_RANGE(MTU) \
    SX_CHECK_RANGE(SX_PORT_MTU_MIN, MTU, SX_PORT_MTU_MAX)


typedef uint32_t sx_port_speed_t;
typedef uint32_t sx_port_fec_t;


/**
 * This struct stores port's enabled mode(s).
 * Each speed mode can be set to Enabled/Disabled.
 * It is possible to enable several speed modes.
 * if mode_auto = TRUE, SDK will enable all speeds and auto-negotiation will
 * select the highest possible speed
 * if force bit is TRUE, than only a single speed mode will be
 * allowed and auto-negotiation will be disabled.
 * Enabling force and more than one speed will return an error.
 * Enabling force and mode_auto will return an error.
 *
 */
typedef struct sx_port_speed_capability {
    boolean_t mode_1GB_CX_SGMII;
    boolean_t mode_1GB_KX;
    boolean_t mode_10GB_CX4_XAUI;
    boolean_t mode_10GB_KX4;
    boolean_t mode_10GB_KR;
    boolean_t mode_20GB_KR2;
    boolean_t mode_40GB_CR4;
    boolean_t mode_40GB_KR4;
    boolean_t mode_56GB_KR4;
    boolean_t mode_56GB_KX4;
    boolean_t mode_10GB_CR;
    boolean_t mode_10GB_SR;
    boolean_t mode_10GB_ER_LR;
    boolean_t mode_40GB_SR4;
    boolean_t mode_40GB_LR4_ER4;
    boolean_t mode_100GB_CR4;
    boolean_t mode_100GB_SR4;
    boolean_t mode_100GB_KR4;
    boolean_t mode_100GB_LR4_ER4;
    boolean_t mode_25GB_CR;
    boolean_t mode_25GB_KR;
    boolean_t mode_25GB_SR;
    boolean_t mode_50GB_CR2;
    boolean_t mode_50GB_KR2;
    boolean_t mode_50GB_SR2;
    boolean_t mode_auto;
    boolean_t force;
} sx_port_speed_capability_t;

typedef struct sx_port_capability {
    sx_port_speed_capability_t speed_capability;
} sx_port_capability_t;

/* This boolean array lists the supported FEC capabilities
 * it is possible to support several capabilities */
typedef struct sx_fec_capability {
    boolean_t no_FEC;
    boolean_t firecode_FEC;
    boolean_t RS_FEC;
    boolean_t LL_RS_FEC;
} sx_fec_capability_t;

typedef struct sx_port_fec_capability {
    sx_fec_capability_t fec_capability;
    sx_port_phy_speed_t speed;
} sx_port_fec_capability_t;

typedef enum sx_port_oper_speed {
    SX_PORT_SPEED_NA = 0,
    SX_PORT_SPEED_1GB_CX_SGMII = 1,
    SX_PORT_SPEED_1GB_KX = 2,
    SX_PORT_SPEED_10GB_CX4_XAUI = 3,
    SX_PORT_SPEED_10GB_KX4 = 4,
    SX_PORT_SPEED_10GB_KR = 5,
    SX_PORT_SPEED_20GB_KR2 = 6,
    SX_PORT_SPEED_40GB_CR4 = 7,
    SX_PORT_SPEED_40GB_KR4 = 8,
    SX_PORT_SPEED_56GB_KR4 = 9,
    SX_PORT_SPEED_56GB_KX4 = 10,
    SX_PORT_SPEED_10GB_CR = 11,
    SX_PORT_SPEED_10GB_SR = 12,
    SX_PORT_SPEED_10GB_ER_LR = 13,
    SX_PORT_SPEED_40GB_SR4 = 14,
    SX_PORT_SPEED_40GB_LR4_ER4 = 15,
    SX_PORT_SPEED_100GB_CR4 = 16,
    SX_PORT_SPEED_100GB_SR4 = 17,
    SX_PORT_SPEED_100GB_KR4 = 18,
    SX_PORT_SPEED_100GB_LR4_ER4 = 19,
    SX_PORT_SPEED_25GB_CR = 20,
    SX_PORT_SPEED_25GB_KR = 21,
    SX_PORT_SPEED_25GB_SR = 22,
    SX_PORT_SPEED_50GB_CR2 = 23,
    SX_PORT_SPEED_50GB_KR2 = 24,
    SX_PORT_SPEED_50GB_SR2 = 25,
    SX_PORT_SPEED_NOT_SUPPORTED = 26
} sx_port_oper_speed_t;

/**
 * This struct stores port's rate values which can be configured
 * on it. Each rate value can be set to separately.
 * It is possible to enable several rate values.
 * If rate_auto = TRUE, SDK will enable all rate values and
 * auto-negotiation will select the best value.
 * If force bit is TRUE, then only a single value is allowed,
 * auto-negotiation won't be involved.
 * Enabling force and more than one speed will return an error.
 * Enabling force and mode_auto will return an error.
 */
typedef struct sx_port_rate_bitmask {
    boolean_t rate_100M;
    boolean_t rate_1G;
    boolean_t rate_10G;
    boolean_t rate_25G;
    boolean_t rate_40G;
    boolean_t rate_50G;
    boolean_t rate_100G;
    boolean_t rate_200G;
    boolean_t rate_400G;
    boolean_t rate_auto;
    boolean_t force;
} sx_port_rate_bitmask_t;

/**
 * This struct stores Physical Medium Depended (PMD) module
 * values which can be configured.
 */
typedef struct sx_port_phy_module_type_bitmask {
    boolean_t module_smf_up_500m;      /**< Single Mode Fiber up to 500 meters */
    boolean_t module_smf_up_2km;       /**< Single Mode Fiber form 500 to 2000 meters */
    boolean_t module_smf_above_2km;    /**< Single Mode Fiber above 2000 meters */
    boolean_t module_mmf_up_100m;      /**< Multi Mode Fiber up to 100 meters */
    boolean_t module_mmf_above_100m;   /**< Multi Mode Fiber above 100 meters */
    boolean_t module_aoc_acc_up_30m;   /**< Active Optical/Copper Cable up to 30 meters */
    boolean_t module_aoc_acc_above_30m;
    boolean_t module_base_cr;          /**< Passive copper */
    boolean_t module_base_tp;          /**< Twisted pair (up to 100 meters) */
} sx_port_phy_module_type_bitmask_t;

#define SX_PORT_INFO_FIELD_BIT_NONE                        (0x0LL)
#define SX_PORT_INFO_FIELD_BIT_ID                          (0x1LL << 0)
#define SX_PORT_INFO_FIELD_BIT_TYPE                        (0x1LL << 1)
#define SX_PORT_INFO_FIELD_BIT_SWID_ID                     (0x1LL << 2)
#define SX_PORT_INFO_FIELD_BIT_DEVICE_ID                   (0x1LL << 3)
#define SX_PORT_INFO_FIELD_BIT_MAPPING                     (0x1LL << 4)
#define SX_PORT_INFO_FIELD_BIT_PORT_MODE                   (0x1LL << 5)
#define SX_PORT_INFO_FIELD_BIT_MTU                         (0x1LL << 6)
#define SX_PORT_INFO_FIELD_BIT_SPEED                       (0x1LL << 7)
#define SX_PORT_INFO_FIELD_BIT_MAC_ADDR                    (0x1LL << 8)
#define SX_PORT_INFO_FIELD_BIT_STATUS                      (0x1LL << 9)
#define SX_PORT_INFO_FIELD_BIT_MULTI_CHANNEL               (0x1LL << 10)
#define SX_PORT_INFO_FIELD_BIT_FLOW_CTRL_CONF              (0x1LL << 11)
#define SX_PORT_INFO_FIELD_BIT_OPER_EVENT_MODE             (0x1LL << 12)
#define SX_PORT_INFO_FIELD_BIT_MODULE_EVENT_MODE           (0x1LL << 13)
#define SX_PORT_INFO_FIELD_BIT_INGRESS_FILTER_MODE         (0x1LL << 14)
#define SX_PORT_INFO_FIELD_BIT_LAG_MEMBER_MODE             (0x1LL << 15)
#define SX_PORT_INFO_FIELD_BIT_MAC_LEARN_DISABLED_BY_USER  (0x1LL << 16)
#define SX_PORT_INFO_FIELD_BIT_MAC_LEARN_DISABLED_BY_LIMIT (0x1LL << 17)
#define SX_PORT_INFO_FIELD_BIT_LOOPBACK_FILTER_MODE        (0x1LL << 18)
#define SX_PORT_INFO_FIELD_BIT_PVID                        (0x1LL << 19)
#define SX_PORT_INFO_FIELD_BIT_ROUTER_MODE                 (0x1LL << 20)
#define SX_PORT_INFO_FIELD_BIT_BUFF_CONF_MODE              (0x1LL << 21)
#define SX_PORT_INFO_FIELD_BIT_QCN_PROFILE_ID              (0x1LL << 22)
#define SX_PORT_INFO_FIELD_BIT_QCN_MODE                    (0x1LL << 23)
#define SX_PORT_INFO_FIELD_BIT_QCN_ENABLE                  (0x1LL << 24)
#define SX_PORT_INFO_FIELD_BIT_LAG_LOG_PORT                (0x1LL << 25)
#define SX_PORT_INFO_FIELD_BIT_FLOW_COUNTER                (0x1LL << 26)
#define SX_PORT_INFO_FIELD_BIT_MIRROR                      (0x1LL << 27)
#define SX_PORT_INFO_FIELD_BIT_FDB_PROTECT_MODE            (0x1LL << 28)
#define SX_PORT_INFO_FIELD_BIT_SPAN_MODE                   (0x1LL << 29)
#define SX_PORT_INFO_FIELD_SHARED_BUFFERS                  (0x1LL << 30)
#define SX_PORT_INFO_FIELD_UNTAGGED_PRIO_STATE             (0x1LL << 31)
#define SX_PORT_INFO_FIELD_BIT_SFLOW_PORT                  (0x1LL << 32)
#define SX_PORT_INFO_FIELD_BIT_CONFIG_STATE                (0x1LL << 33)
#define SX_PORT_INFO_FIELD_BIT_EGRESS_MIRROR_SIZE          (0x1LL << 34)
#define SX_PORT_INFO_FIELD_BIT_HEADROOM_SIZE               (0x1LL << 35)
#define SX_PORT_INFO_FIELD_BIT_EGRESS_MIRROR_REF_COUNT     (0x1LL << 36)
#define SX_PORT_INFO_FIELD_BIT_FORWARDING_MODE             (0x1LL << 37)
#define SX_PORT_INFO_FIELD_BIT_PUSH_ETHERTYPE              (0x1LL << 38)
#define SX_PORT_INFO_FIELD_BIT_PARSE_ETHERTYPE             (0x1LL << 39)
#define SX_PORT_INFO_FIELD_BIT_BER_PROFILE                 (0x1LL << 40)
#define SX_PORT_INFO_FIELD_BIT_BER_MONITOR_CONFIG          (0x1LL << 41)
#define SX_PORT_INFO_FIELD_BIT_GC_HANDLE                   (0x1LL << 42)
#define SX_PORT_INFO_FIELD_BIT_API_TYPE                    (0x1LL << 43)
#define SX_PORT_INFO_FIELD_BIT_RIF_ID                      (0x1LL << 44)
#define SX_PORT_INFO_FIELD_BIT_MIN                         SX_PORT_INFO_FIELD_BIT_ID
#define SX_PORT_INFO_FIELD_BIT_MAX                         SX_PORT_INFO_FIELD_BIT_API_TYPE


#define SX_PORT_INFO_FIELD_BIT_MIN_MAX SX_PORT_INFO_FIELD_BIT_MIN, SX_PORT_INFO_FIELD_BIT_MAX
#define SX_PORT_INFO_FIELD_BIT_CHECK_RANGE(bit) \
    SX_CHECK_RANGE(SX_PORT_INFO_FIELD_BIT_MIN,  \
                   (uint64_t)bit,               \
                   SX_PORT_INFO_FIELD_BIT_MAX)

static const char *sx_port_info_field_bit_str[] = {
    "NONE",
    "ID",
    "TYPE",
    "SWITCH ID",
    "DEVICE ID",
    "MAPPING",
    "STACKING MODE",
    "MTU",
    "TYPE SPEED",
    "MAC ADDR",
    "STATUS",
    "MULTI CHANNEL",
    "FLOW CONTROL CONFIGURATION",
    "OPER EVENT MODE",
    "MODULE EVENT MODE",
    "INGRESS FILTER MODE",
    "LAG MEMBER MODE",
    "MAC_LEARN_DISABLED_BY_USER",
    "MAC_LEARN_DISABLED_BY_LIMIT",
    "LOOPBACK_FILTER_MODE",
    "PVID",
    "ROUTER_MODE",
    "BUFF_CONF_MODE",
    "QCN_PROFILE_ID",
    "QCN_MODE",
    "QCN_ENABLE",
    "LAG_LOG_PORT",
    "FDB_PROTECT_MODE",
    "SPAN_MODE",
    "SHARED_BUFFERS",
    "UNTAGGED_PRIO_STATE",
    "SFLOW_PORT",
    "CONFIG_STATE",
    "EGRESS_MIRROR_SIZE",
    "HEADROOM_SIZE",
    "EGRESS_MIRROR_REF_COUNT",
    "FORWARDING_MODE",
    "BER PROFILE",
    "BER MONITOR CONFIG",
    "GC HANDLE",
    "API TYPE",
    "RIF_ID",
};
static const int   sx_port_info_field_bit_str_len = sizeof(sx_port_info_field_bit_str) / sizeof(char*);

#define SX_PORT_INFO_FIELD_BIT_STR(bit) \
    (SX_CHECK_RANGE(0, ffsl(bit),       \
                    sx_port_info_field_bit_str_len - 1) ? sx_port_info_field_bit_str[ffsl(bit)] : "UNKNOWN")

typedef enum sx_port_speed_bit {
    SX_PORT_SPEED_BIT_NONE = 0,
    SX_PORT_SPEED_BIT_1GB_CX = 0x1 << 0,
        SX_PORT_SPEED_BIT_SGMII = 0x1 << 0,
        SX_PORT_SPEED_BIT_1GB_KX = 0x1 << 1,
        SX_PORT_SPEED_BIT_XAUI = 0x1 << 2,
        SX_PORT_SPEED_BIT_10GB_CX4 = 0x1 << 2,
        SX_PORT_SPEED_BIT_10GB_KX4 = 0x1 << 3,
        SX_PORT_SPEED_BIT_10GB_KR = 0x1 << 4,
        SX_PORT_SPEED_BIT_20GB_KR2 = 0x1 << 5,      /* ! UNSUPPORTED ! */
        SX_PORT_SPEED_BIT_40GB_CR4 = 0x1 << 6,
        SX_PORT_SPEED_BIT_40GB_KR4 = 0x1 << 7,
        SX_PORT_SPEED_BIT_56GB_KR4 = 0x1 << 8,      /* ! UNSUPPORTED ! */
        SX_PORT_SPEED_BIT_56GB_KX4 = 0x1 << 9,      /* ! UNSUPPORTED ! */
        SX_PORT_SPEED_BIT_MIN = SX_PORT_SPEED_BIT_SGMII,
        SX_PORT_SPEED_BIT_MAX = SX_PORT_SPEED_BIT_40GB_KR4,
} sx_port_speed_bit_t;

#define SX_PORT_SPEED_BIT_DEFAULT SX_PORT_SPEED_BIT_NONE
#define SX_PORT_SPEED_BIT_MIN_MAX SX_PORT_SPEED_BIT_MIN, SX_PORT_SPEED_BIT_MAX
#define SX_PORT_SPEED_BIT_CHECK_RANGE(bit) SX_CHECK_RANGE(SX_PORT_SPEED_BIT_MIN, (int)bit, SX_PORT_SPEED_BIT_MAX)

static const char *sx_port_speed_bit_str[] = {
    "NONE",
    "SGMII",
    "XAUI",
    "1GB KX",
    "10GB CX4",
    "10GB KX4",
    "10GB KR",
    "10GB KR FEC",
    "10GB KR2",
    "10GB KR2 FEC",
    "40GB KR4",
    "40GB KR4 FEC",
};
static const int   sx_port_speed_bit_str_len = sizeof(sx_port_speed_bit_str) / sizeof(char*);

#define SX_PORT_SPEED_BIT_STR(bit)    \
    (SX_CHECK_RANGE(0, ffs((int)bit), \
                    sx_port_speed_bit_str_len - 1) ? sx_port_speed_bit_str[ffs((int)bit)] : "UNKNOWN")
/*********************************************************************************************************************/
#define FOREACH_PORT_PAUSE_POLICY_RX(F)                                  \
    F(SX_PORT_PAUSE_POLICY_RX_DISABLE = 0, "DISABLE")                    \
    F(SX_PORT_PAUSE_POLICY_RX_ENABLE, "ENABLE")                          \
    F(SX_PORT_PAUSE_POLICY_RX_MIN = SX_PORT_PAUSE_POLICY_RX_DISABLE, "") \
    F(SX_PORT_PAUSE_POLICY_RX_MAX = SX_PORT_PAUSE_POLICY_RX_ENABLE, "")

typedef enum sx_port_pause_policy_rx {
    FOREACH_PORT_PAUSE_POLICY_RX(SX_GENERATE_ENUM)
} sx_port_pause_policy_rx_t;

#define SX_PORT_PAUSE_POLICY_RX_DEFAULT SX_PORT_PAUSE_POLICY_RX_DISABLE
#define SX_PORT_PAUSE_POLICY_RX_MIN_MAX SX_PORT_PAUSE_POLICY_RX_MIN, SX_PORT_PAUSE_POLICY_RX_MAX
#define SX_PORT_PAUSE_POLICY_RX_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PAUSE_POLICY_RX_MIN,   \
                   (int)mode,                     \
                   SX_PORT_PAUSE_POLICY_RX_MAX)


typedef uint8_t sx_port_prio_base_flow_conf_policy_rx_t;

#define SX_PORT_PRIO_BASE_FLOW_CONF_POLICY_RX_DEFAULT (0)
/*********************************************************************************************************************/
#define FOREACH_PORT_PAUSE_POLICY_TX(F)                                  \
    F(SX_PORT_PAUSE_POLICY_TX_DISABLE = 0, "DISABLE")                    \
    F(SX_PORT_PAUSE_POLICY_TX_ENABLE, "ENABLE")                          \
    F(SX_PORT_PAUSE_POLICY_TX_MIN = SX_PORT_PAUSE_POLICY_TX_DISABLE, "") \
    F(SX_PORT_PAUSE_POLICY_TX_MAX = SX_PORT_PAUSE_POLICY_TX_ENABLE, "")

typedef enum sx_port_pause_policy_tx {
    FOREACH_PORT_PAUSE_POLICY_TX(SX_GENERATE_ENUM)
} sx_port_pause_policy_tx_t;

#define SX_PORT_PAUSE_POLICY_TX_DEFAULT SX_PORT_PAUSE_POLICY_TX_DISABLE
#define SX_PORT_PAUSE_POLICY_TX_MIN_MAX SX_PORT_PAUSE_POLICY_TX_MIN, SX_PORT_PAUSE_POLICY_TX_MAX
#define SX_PORT_PAUSE_POLICY_TX_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PAUSE_POLICY_TX_MIN,   \
                   (int)mode,                     \
                   SX_PORT_PAUSE_POLICY_TX_MAX)

typedef uint8_t sx_port_prio_base_flow_conf_policy_tx_t;

#define SX_PORT_PRIO_BASE_FLOW_CONF_POLICY_TX_DEFAULT (0)

typedef uint8_t sx_port_credit_base_flow_conf_policy_tx_t;
typedef uint8_t sx_port_credit_base_flow_conf_policy_rx_t;

typedef uint8_t sx_port_flow_conf_mask_tx_t;
typedef uint8_t sx_port_flow_conf_mask_rx_t;

#define SX_PORT_FLOW_CTRL_PRIO_FULL_MASK 0xFF
#define SX_PORT_FLOW_CTRL_PRIO_NO_MASK   0x00


#define FOREACH_PORT_FLOW_CTRL_MODE(F)                                       \
    F(SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS = 0, "TX_DIS_RX_DIS")             \
    F(SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_DIS, "TX_EN_RX_DIS")                   \
    F(SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_EN, "TX_DIS_RX_EN")                   \
    F(SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN, "TX_EN_RX_EN")                     \
    F(SX_PORT_FLOW_CTRL_MODE_MIN = SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS, "") \
    F(SX_PORT_FLOW_CTRL_MODE_MAX = SX_PORT_FLOW_CTRL_MODE_TX_EN_RX_EN, "")

typedef enum sx_port_flow_ctrl_mode {
    FOREACH_PORT_FLOW_CTRL_MODE(SX_GENERATE_ENUM)
} sx_port_flow_ctrl_mode_t;

#define SX_PORT_FLOW_CTRL_MODE_DEFAULT SX_PORT_FLOW_CTRL_MODE_TX_DIS_RX_DIS
#define SX_PORT_FLOW_CTRL_MODE_MIN_MAX SX_PORT_FLOW_CTRL_MODE_MIN, SX_PORT_FLOW_CTRL_MODE_MAX
#define SX_PORT_FLOW_CTRL_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_FLOW_CTRL_MODE_MIN,   \
                   (int)mode,                    \
                   SX_PORT_FLOW_CTRL_MODE_MAX)

#define FOREACH_PORT_FLOW_CTRL_PRIO(F)                           \
    F(SX_PORT_FLOW_CTRL_PRIO_0 = 0, "PRIO_0")                    \
    F(SX_PORT_FLOW_CTRL_PRIO_1, "PRIO_1")                        \
    F(SX_PORT_FLOW_CTRL_PRIO_2, "PRIO_2")                        \
    F(SX_PORT_FLOW_CTRL_PRIO_3, "PRIO_3")                        \
    F(SX_PORT_FLOW_CTRL_PRIO_4, "PRIO_4")                        \
    F(SX_PORT_FLOW_CTRL_PRIO_5, "PRIO_5")                        \
    F(SX_PORT_FLOW_CTRL_PRIO_6, "PRIO_6")                        \
    F(SX_PORT_FLOW_CTRL_PRIO_7, "PRIO_7")                        \
    F(SX_PORT_FLOW_CTRL_PRIO_MIN = SX_PORT_FLOW_CTRL_PRIO_0, "") \
    F(SX_PORT_FLOW_CTRL_PRIO_MAX = SX_PORT_FLOW_CTRL_PRIO_7, "") \

typedef enum sx_port_flow_ctrl_prio {
    FOREACH_PORT_FLOW_CTRL_PRIO(SX_GENERATE_ENUM)
} sx_port_flow_ctrl_prio_t;

#define SX_PORT_FLOW_CTRL_PRIO_DEFAULT SX_PORT_FLOW_CTRL_PRIO_0
#define SX_PORT_FLOW_CTRL_PRIO_MIN_MAX SX_PORT_FLOW_CTRL_PRIO_MIN, SX_PORT_FLOW_CTRL_PRIO_MAX
#define SX_PORT_FLOW_CTRL_PRIO_CHECK_RANGE(prio) \
    SX_CHECK_RANGE(SX_PORT_FLOW_CTRL_PRIO_MIN,   \
                   (int)prio,                    \
                   SX_PORT_FLOW_CTRL_PRIO_MAX)


typedef enum sx_port_flow_ctrl_type {
    SX_PORT_FLOW_CTRL_GLOBAL = 0,
    SX_PORT_FLOW_CTRL_PER_PRIO = 1,
    SX_PORT_FLOW_CTRL_DISABLE = 2,
} sx_port_flow_ctrl_type_t;

typedef enum sx_flow_id {
    SX_PORT_FLOW_ID_PORT_INIT = 0,
    SX_PORT_FLOW_ID_FC_PFC = 1,
    SX_PORT_FLOW_ID_COS_INIT = 2,
    SX_PORT_FLOW_ID_DEV_READY = 3,
    SX_PORT_FLOW_ID_PORT_DE_INIT = 4,
} sx_flow_id_t;

typedef enum sx_port_flow_ctrl_pbmc_mode {
    SX_PORT_FLOW_CTRL_PBMC_MODE_UNREGISTERED = 0,
    SX_PORT_FLOW_CTRL_PBMC_MODE_DISABLE = 1,
    SX_PORT_FLOW_CTRL_PBMC_MODE_GLOBAL = 2,
    SX_PORT_FLOW_CTRL_PBMC_MODE_PER_PRIO = 3,
} sx_port_flow_ctrl_pbmc_mode_t;


/**
 * sx_port_storm_control_id_t structure is used to note port storm control ID.
 */
typedef uint32_t sx_port_storm_control_id_t;

#define SX_PORT_STORM_CONTROL_ID_MAX (4)

/**
 * sx_port_packet_types_t structure is used to note packet types used for storm control configuration.
 * Per packet type, use TRUE to enable storm control configuration or FALSE otherwise.
 */
typedef struct sx_port_packet_types {
    boolean_t uc;   /**< Meter Ingress Unicast Packets */
    boolean_t mc;   /**< Meter Ingress Multicast Packets */
    boolean_t bc;   /**< Meter Ingress Broadcast Packets */
    boolean_t uuc;  /**< Meter Ingress Unknown Unicast Packets */
    boolean_t umc;  /**< Meter Ingress Unregister Multicast Packets */
} sx_port_packet_types_t;

/**
 * sx_port_storm_control_params_t structure is used to store storm control configuration.
 */
typedef struct sx_port_storm_control_params {
    sx_port_packet_types_t  packet_types;       /**< Packet types */
    sx_policer_attributes_t policer_params;     /**< Policer attributes */
} sx_port_storm_control_params_t;

/**
 * sx_port_sflow_params_t structure is used to store per port
 * sflow parameters
 */
typedef struct sx_port_sflow_params {
    uint32_t               ratio;           /**< one packet is sampled every ratio +/- (deviation ) */
    uint32_t               deviation;       /**< deviation in percent */
    sx_port_packet_types_t packet_types;    /**< packet types for SFLOW configuration */
} sx_port_sflow_params_t;

/**
 * sx_port_loopback_filter_mode_t structure is used to store per
 * port loopback filter mode
 */
typedef enum sx_port_loopback_filter_mode {
    SX_LOOPBACK_FILTER_MODE_DISABLED = 1,
    SX_LOOPBACK_FILTER_MODE_ENABLED = 2,
    SX_LOOPBACK_FILTER_MODE_MIN = SX_LOOPBACK_FILTER_MODE_DISABLED,
    SX_LOOPBACK_FILTER_MODE_MAX = SX_LOOPBACK_FILTER_MODE_ENABLED,
} sx_port_loopback_filter_mode_t;

#define SX_PORT_LOOPBACK_FILTER_MODE_CHECK_RANGE(LOOPBACK_FILTER_MODE) \
    SX_CHECK_RANGE(SX_LOOPBACK_FILTER_MODE_MIN,                        \
                   LOOPBACK_FILTER_MODE,                               \
                   SX_LOOPBACK_FILTER_MODE_MAX)

#define SX_PORT_PACKET_TYPE_DEFAULT 0
#define SX_PORT_PACKET_TYPE_MIN     0
#define SX_PORT_PACKET_TYPE_MAX     1
#define SX_PORT_PACKET_TYPE_DISABLE 0
#define SX_PORT_PACKET_TYPE_ENABLE  1
#define SX_PORT_PACKET_TYPE_MIN_MAX SX_PORT_PACKET_TYPE_MIN, SX_PORT_PACKET_TYPE_MAX
#define SX_PORT_PACKET_TYPE_CHECK_RANGE(type) \
    SX_CHECK_RANGE(SX_PORT_PACKET_TYPE_MIN,   \
                   (int)type,                 \
                   SX_PORT_PACKET_TYPE_MAX)

/*********************************************************************************************************************/
typedef enum sx_port_cntr_grp {
    SX_PORT_CNTR_GRP_IEEE_802_DOT_3 = 0,
    SX_PORT_CNTR_GRP_RFC_2863 = 1,
    SX_PORT_CNTR_GRP_RFC_2819 = 2,
    SX_PORT_CNTR_GRP_RFC_3635 = 3,
    SX_PORT_CNTR_GRP_CLI = 4,
    SX_PORT_CNTR_GRP_PERFORMANCE = 5,
    SX_PORT_CNTR_GRP_DISCARD = 6,
    SX_PORT_CNTR_GRP_PER_PRIO = 0x10,
    SX_PORT_CNTR_GRP_PER_TC = 0x11,
    SX_PORT_CNTR_GRP_PHY_LAYER = 0x12,
    SX_PORT_CNTR_GRP_CONGESTION_PER_TC = 0x13,
    SX_PORT_CNTR_GRP_PER_BUFF = 0x15,
    SX_PORT_CNTR_GRP_PER_TC_0 = 0x22,
    SX_PORT_CNTR_GRP_PER_TC_1 = 0x23,
    SX_PORT_CNTR_GRP_PER_TC_2 = 0x24,
    SX_PORT_CNTR_GRP_PER_TC_3 = 0x25,
    SX_PORT_CNTR_GRP_PER_TC_4 = 0x26,
    SX_PORT_CNTR_GRP_PER_TC_5 = 0x27,
    SX_PORT_CNTR_GRP_PER_TC_6 = 0x28,
    SX_PORT_CNTR_GRP_PER_TC_7 = 0x29,
    SX_PORT_CNTR_GRP_PER_PRIO_0 = 0x31,
    SX_PORT_CNTR_GRP_PER_PRIO_1 = 0x32,
    SX_PORT_CNTR_GRP_PER_PRIO_2 = 0x33,
    SX_PORT_CNTR_GRP_PER_PRIO_3 = 0x34,
    SX_PORT_CNTR_GRP_PER_PRIO_4 = 0x35,
    SX_PORT_CNTR_GRP_PER_PRIO_5 = 0x36,
    SX_PORT_CNTR_GRP_PER_PRIO_6 = 0x37,
    SX_PORT_CNTR_GRP_PER_PRIO_7 = 0x38,
    SX_PORT_CNTR_GRP_PER_BUFF_0 = 0x41,
    SX_PORT_CNTR_GRP_PER_BUFF_1 = 0x42,
    SX_PORT_CNTR_GRP_PER_BUFF_2 = 0x43,
    SX_PORT_CNTR_GRP_PER_BUFF_3 = 0x44,
    SX_PORT_CNTR_GRP_PER_BUFF_4 = 0x45,
    SX_PORT_CNTR_GRP_PER_BUFF_5 = 0x46,
    SX_PORT_CNTR_GRP_PER_BUFF_6 = 0x47,
    SX_PORT_CNTR_GRP_PER_BUFF_7 = 0x48,
    SX_PORT_CNTR_GRP_ALL = 63,
    SX_PORT_CNTR_GRP_MIN = SX_PORT_CNTR_GRP_IEEE_802_DOT_3,
    SX_PORT_CNTR_GRP_MAX = SX_PORT_CNTR_GRP_ALL,
    SX_PORT_CNTR_GRP_NULL = 0xFF,
} sx_port_cntr_grp_t;

#define SX_PORT_CNTR_GRP_DEFAULT SX_PORT_CNTR_GRP_IEEE_802_DOT_3
#define SX_PORT_CNTR_GRP_MIN_MAX SX_PORT_CNTR_GRP_MIN, SX_PORT_CNTR_GRP_MAX
#define SX_PORT_CNTR_GRP_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_CNTR_GRP_MIN, (int)mode, SX_PORT_CNTR_GRP_MAX)

static const char *sx_port_cntr_grp_str[] = {
    "IEEE 802.3",
    "RFC 2863",
    "RFC 2819",
    "RFC 3635",
    "CLI",
    "EXTENDED",
    "DISCARD",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
#ifndef     __SX_PORT_CNTR_GRP_PER_PRIO__
    "PER PRIO",
    "PER TC",
    "N/A",
    "N/A",
    "N/A",
    "PER BUFF",
    "N/A",
    "N/A",
#else /*	__SX_PORT_CNTR_GRP_PER_PRIO__   */
    "PER PRIO 0",
    "PER PRIO 1",
    "PER PRIO 2",
    "PER PRIO 3",
    "PER PRIO 4",
    "PER PRIO 5",
    "PER PRIO 6",
    "PER PRIO 7",
#endif /*       __SX_PORT_CNTR_GRP_PER_PRIO__   */
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "PER TC 0",
    "PER TC 1",
    "PER TC 2",
    "PER TC 3",
    "PER TC 4",
    "PER TC 5",
    "PER TC 6",
    "PER TC 7",
    "PER PRIO 0",
    "PER PRIO 1",
    "PER PRIO 2",
    "PER PRIO 3",
    "PER PRIO 4",
    "PER PRIO 5",
    "PER PRIO 6",
    "PER PRIO 7",
    "PER BUFF 0",
    "PER BUFF 1",
    "PER BUFF 2",
    "PER BUFF 3",
    "PER BUFF 4",
    "PER BUFF 5",
    "PER BUFF 6",
    "PER BUFF 7",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "N/A",
    "ALL GROUPS"
};
static const int   sx_port_cntr_grp_str_len = sizeof(sx_port_cntr_grp_str) / sizeof(char*);

#define SX_PORT_CNTR_GRP_STR(index) \
    (SX_CHECK_RANGE(0, (int)index,  \
                    sx_port_cntr_grp_str_len - 1) ? sx_port_cntr_grp_str[index] : "UNKNOWN")

typedef enum sx_port_prio_id {
    SX_PORT_PRIO_ID_0,
    SX_PORT_PRIO_ID_1,
    SX_PORT_PRIO_ID_2,
    SX_PORT_PRIO_ID_3,
    SX_PORT_PRIO_ID_4,
    SX_PORT_PRIO_ID_5,
    SX_PORT_PRIO_ID_6,
    SX_PORT_PRIO_ID_7,
    SX_PORT_PRIO_ID_MIN = SX_PORT_PRIO_ID_0,
    SX_PORT_PRIO_ID_MAX = SX_PORT_PRIO_ID_7,
} sx_port_prio_id_t;

#define FOREACH_PORT_TC_ID(F)                  \
    F(SX_PORT_TC_ID_0 = 0, "PRIORITY 0")       \
    F(SX_PORT_TC_ID_1 = 1, "PRIORITY 1")       \
    F(SX_PORT_TC_ID_2 = 2, "PRIORITY 2")       \
    F(SX_PORT_TC_ID_3 = 3, "PRIORITY 3")       \
    F(SX_PORT_TC_ID_4 = 4, "PRIORITY 4")       \
    F(SX_PORT_TC_ID_5 = 5, "PRIORITY 5")       \
    F(SX_PORT_TC_ID_6 = 6, "PRIORITY 6")       \
    F(SX_PORT_TC_ID_7 = 7, "PRIORITY 7")       \
    F(SX_PORT_TC_ID_8 = 8, "PRIORITY 8")       \
    F(SX_PORT_TC_ID_9 = 9, "PRIORITY 9")       \
    F(SX_PORT_TC_ID_10 = 10, "PRIORITY 10")    \
    F(SX_PORT_TC_ID_11 = 11, "PRIORITY 11")    \
    F(SX_PORT_TC_ID_12 = 12, "PRIORITY 12")    \
    F(SX_PORT_TC_ID_13 = 13, "PRIORITY 13")    \
    F(SX_PORT_TC_ID_14 = 14, "PRIORITY 14")    \
    F(SX_PORT_TC_ID_15 = 15, "PRIORITY 15")    \
    F(SX_PORT_TC_ID_16 = 16, "PRIORITY 16")    \
    F(SX_PORT_TC_ID_MIN = SX_PORT_TC_ID_0, "") \
    F(SX_PORT_TC_ID_MAX = SX_PORT_TC_ID_16, "")


typedef enum sx_port_tc_id {
    FOREACH_PORT_TC_ID(SX_GENERATE_ENUM)
} sx_port_tc_id_t;

#define SX_PORT_PRIO_ID_DEFAULT SX_PORT_PRIO_ID_0
#define SX_PORT_PRIO_ID_MIN_MAX SX_PORT_PRIO_ID_MIN, SX_PORT_PRIO_ID_MAX
#define SX_PORT_PRIO_ID_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_PORT_PRIO_ID_MIN, (int)mode, SX_PORT_PRIO_ID_MAX)
#define SX_PORT_TC_ID_CHECK_RANGE(mode)   SX_CHECK_RANGE(SX_PORT_TC_ID_MIN, (int)mode, SX_PORT_TC_ID_MAX)


#define SX_PORT_CNTR_NUM (0xF8)

typedef uint64_t sx_port_cntr_t;
typedef uint32_t sx_port_cntr32_t;

typedef struct sx_port_cntr_ieee_802_dot_3 {
    sx_port_cntr_t a_frames_transmitted_ok;
    sx_port_cntr_t a_frames_received_ok;
    sx_port_cntr_t a_frame_check_sequence_errors;
    sx_port_cntr_t a_alignment_errors;
    sx_port_cntr_t a_octets_transmitted_ok;
    sx_port_cntr_t a_octets_received_ok;
    sx_port_cntr_t a_multicast_frames_xmitted_ok;
    sx_port_cntr_t a_broadcast_frames_xmitted_ok;
    sx_port_cntr_t a_multicast_frames_received_ok;
    sx_port_cntr_t a_broadcast_frames_recieved_ok;
    sx_port_cntr_t a_in_range_length_errors;
    sx_port_cntr_t a_out_of_range_length_field;
    sx_port_cntr_t a_frame_too_long_errors;
    sx_port_cntr_t a_symbol_error_during_carrier;
    sx_port_cntr_t a_mac_control_frames_transmitted;
    sx_port_cntr_t a_mac_control_frames_received;
    sx_port_cntr_t a_unsupported_opcodes_received;
    sx_port_cntr_t a_pause_mac_ctrl_frames_received;
    sx_port_cntr_t a_pause_mac_ctrl_frames_transmitted;
} PACK_SUFFIX sx_port_cntr_ieee_802_dot_3_t;

static const char* sx_port_cntr_ieee_802_dot_3_str[] = {
    "frames_transmitted_ok",
    "frames_received_ok",
    "frame_check_sequence_errors",
    "alignment_errors",
    "octets_transmitted_ok",
    "octets_received_ok",
    "multicast_frames_xmitted_ok",
    "broadcast_frames_xmitted_ok",
    "multicast_frames_received_ok",
    "broadcast_frames_received_ok",
    "in_range_length_errors",
    "out_of_range_length_field",
    "frame_too_long_errors",
    "symbol_error_during_carrier",
    "mac_control_frames_transmitted",
    "mac_control_frames_received",
    "unsupported_opcodes_received",
    "pause_mac_ctrl_frames_received",
    "pause_mac_ctrl_frames_transmitted",
};
static const int   sx_port_cntr_ieee_802_dot_3_str_len = sizeof(sx_port_cntr_ieee_802_dot_3_str) / sizeof(char*);

#define SX_PORT_CNTR_IEEE_802_DOT_3_NUM sx_port_cntr_ieee_802_dot_3_str_len
#define SX_PORT_CNTR_IEEE_802_DOT_3_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_ieee_802_dot_3_str_len - 1) ? \
     sx_port_cntr_ieee_802_dot_3_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

typedef struct sx_port_cntr_rfc_2863 {
    sx_port_cntr_t if_in_octets;
    sx_port_cntr_t if_in_ucast_pkts;
    sx_port_cntr_t if_in_discards;
    sx_port_cntr_t if_in_errors;
    sx_port_cntr_t if_in_unknown_protos;
    sx_port_cntr_t if_out_octets;
    sx_port_cntr_t if_out_ucast_pkts;
    sx_port_cntr_t if_out_discards;
    sx_port_cntr_t if_out_errors;
    sx_port_cntr_t if_in_multicast_pkts;
    sx_port_cntr_t if_in_broadcast_pkts;
    sx_port_cntr_t if_out_multicast_pkts;
    sx_port_cntr_t if_out_broadcast_pkts;
} PACK_SUFFIX sx_port_cntr_rfc_2863_t;

static const char* sx_port_cntr_rfc_2863_str[] = {
    "if_in_octets",
    "if_in_ucast_pkts",
    "if_in_discards",
    "if_in_errors",
    "if_in_unknown_protos",
    "if_out_octets",
    "if_out_ucast_pkts",
    "if_out_discards",
    "if_out_errors",
    "if_in_multicast_pkts",
    "if_in_broadcast_pkts",
    "if_out_multicast_pkts",
    "if_out_broadcast_pkts",
};
static const int   sx_port_cntr_rfc_2863_str_len = sizeof(sx_port_cntr_rfc_2863_str) / sizeof(char*);
#define SX_PORT_CNTR_RFC_2863_NUM sx_port_cntr_rfc_2863_str_len
#define SX_PORT_CNTR_RFC_2863_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_rfc_2863_str_len - 1) ? \
     sx_port_cntr_rfc_2863_str[index] : "UNKNOWN")


/*********************************************************************************************************************/

typedef struct sx_port_cntr_rfc_2819 {
    sx_port_cntr_t ether_stats_drop_events;
    sx_port_cntr_t ether_stats_octets;
    sx_port_cntr_t ether_stats_pkts;
    sx_port_cntr_t ether_stats_broadcast_pkts;
    sx_port_cntr_t ether_stats_multicast_pkts;
    sx_port_cntr_t ether_stats_crc_align_errors;
    sx_port_cntr_t ether_stats_undersize_pkts;
    sx_port_cntr_t ether_stats_oversize_pkts;
    sx_port_cntr_t ether_stats_fragments;
    sx_port_cntr_t ether_stats_jabbers;
    sx_port_cntr_t ether_stats_collisions;
    sx_port_cntr_t ether_stats_pkts64octets;
    sx_port_cntr_t ether_stats_pkts65to127octets;
    sx_port_cntr_t ether_stats_pkts128to255octets;
    sx_port_cntr_t ether_stats_pkts256to511octets;
    sx_port_cntr_t ether_stats_pkts512to1023octets;
    sx_port_cntr_t ether_stats_pkts1024to1518octets;
    sx_port_cntr_t ether_stats_pkts1519to2047octets;
    sx_port_cntr_t ether_stats_pkts2048to4095octets;
    sx_port_cntr_t ether_stats_pkts4096to8191octets;
    sx_port_cntr_t ether_stats_pkts8192to10239octets;
} PACK_SUFFIX sx_port_cntr_rfc_2819_t;

static const char* sx_port_cntr_rfc_2819_str[] = {
    "ether_stats_drop_events",
    "ether_stats_octets",
    "ether_stats_pkts",
    "ether_stats_broadcast_pkts",
    "ether_stats_multicast_pkts",
    "ether_stats_crc_align_errors",
    "ether_stats_undersize_pkts",
    "ether_stats_oversize_pkts",
    "ether_stats_fragments",
    "ether_stats_jabbers",
    "ether_stats_collisions",
    "ether_stats_pkts64octets",
    "ether_stats_pkts65to127octets",
    "ether_stats_pkts128to255octets",
    "ether_stats_pkts256to511octets",
    "ether_stats_pkts512to1023octets",
    "ether_stats_pkts1024to1518octets",
    "ether_stats_pkts1519to2047octets",
    "ether_stats_pkts2048to4095octets",
    "ether_stats_pkts4096to8191octets",
    "ether_stats_pkts8192to10239octets"
};
static const int   sx_port_cntr_rfc_2819_str_len = sizeof(sx_port_cntr_rfc_2819_str) / sizeof(char*);
#define SX_PORT_CNTR_RFC_2819_NUM sx_port_cntr_rfc_2819_str_len
#define SX_PORT_CNTR_RFC_2819_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_rfc_2819_str_len - 1) ? \
     sx_port_cntr_rfc_2819_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

typedef struct sx_port_cntr_phy_layer {
    sx_port_cntr_t   time_since_last_clear;
    sx_port_cntr_t   symbol_errors;
    sx_port_cntr_t   sync_headers_errors;
    sx_port_cntr_t   edpl_bip_errors_lane0;
    sx_port_cntr_t   edpl_bip_errors_lane1;
    sx_port_cntr_t   edpl_bip_errors_lane2;
    sx_port_cntr_t   edpl_bip_errors_lane3;
    sx_port_cntr_t   fc_fec_corrected_blocks_lane0;
    sx_port_cntr_t   fc_fec_corrected_blocks_lane1;
    sx_port_cntr_t   fc_fec_corrected_blocks_lane2;
    sx_port_cntr_t   fc_fec_corrected_blocks_lane3;
    sx_port_cntr_t   fc_fec_uncorrectable_blocks_lane0;
    sx_port_cntr_t   fc_fec_uncorrectable_blocks_lane1;
    sx_port_cntr_t   fc_fec_uncorrectable_blocks_lane2;
    sx_port_cntr_t   fc_fec_uncorrectable_blocks_lane3;
    sx_port_cntr_t   rs_fec_corrected_blocks;
    sx_port_cntr_t   rs_fec_uncorrectable_blocks;
    sx_port_cntr_t   rs_fec_no_errors_blocks;
    sx_port_cntr_t   rs_fec_single_error_blocks;
    sx_port_cntr_t   rs_fec_corrected_symbols_total;
    sx_port_cntr_t   rs_fec_corrected_symbols_lane0;
    sx_port_cntr_t   rs_fec_corrected_symbols_lane1;
    sx_port_cntr_t   rs_fec_corrected_symbols_lane2;
    sx_port_cntr_t   rs_fec_corrected_symbols_lane3;
    sx_port_cntr32_t link_down_events;
    sx_port_cntr32_t successful_recovery_events;
} PACK_SUFFIX sx_port_cntr_phy_layer_t;

static const char* sx_port_cntr_phy_layer_str[] = {
    "time_since_last_clear",
    "symbol_errors",
    "sync_headers_errors",
    "edpl_bip_errors_lane0",
    "edpl_bip_errors_lane1",
    "edpl_bip_errors_lane2",
    "edpl_bip_errors_lane3",
    "fc_fec_corrected_blocks_lane0",
    "fc_fec_corrected_blocks_lane1",
    "fc_fec_corrected_blocks_lane2",
    "fc_fec_corrected_blocks_lane3",
    "fc_fec_uncorrectable_blocks_lane0",
    "fc_fec_uncorrectable_blocks_lane1",
    "fc_fec_uncorrectable_blocks_lane2",
    "fc_fec_uncorrectable_blocks_lane3",
    "rs_fec_corrected_blocks",
    "rs_fec_uncorrectable_blocks",
    "rs_fec_no_errors_blocks",
    "rs_fec_single_error_blocks",
    "rs_fec_corrected_symbols_total",
    "rs_fec_corrected_symbols_lane0",
    "rs_fec_corrected_symbols_lane1",
    "rs_fec_corrected_symbols_lane2",
    "rs_fec_corrected_symbols_lane3",
    "link_down_events",
    "successful_recovery_events"
};
static const int   sx_port_cntr_phy_layer_str_len = sizeof(sx_port_cntr_phy_layer_str) / sizeof(char*);
#define SX_PORT_CNTR_PHY_LAYER_NUM sx_port_cntr_phy_layer_str_len
#define SX_PORT_CNTR_PHY_LAYER_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_phy_layer_str_len - 1) ? \
     sx_port_cntr_phy_layer_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

typedef struct sx_port_cntr_rfc_3635 {
    sx_port_cntr_t dot3stats_alignment_errors;
    sx_port_cntr_t dot3stats_fcs_errors;
    sx_port_cntr_t dot3stats_single_collision_frames;
    sx_port_cntr_t dot3stats_multiple_collision_frames;
    sx_port_cntr_t dot3stats_sqe_test_errors;
    sx_port_cntr_t dot3stats_deferred_transmissions;
    sx_port_cntr_t dot3stats_late_collisions;
    sx_port_cntr_t dot3stats_excessive_collisions;
    sx_port_cntr_t dot3stats_internal_mac_transmit_errors;
    sx_port_cntr_t dot3stats_carrier_sense_errors;
    sx_port_cntr_t dot3stats_frame_too_longs;
    sx_port_cntr_t dot3stats_internal_mac_receive_errors;
    sx_port_cntr_t dot3stats_symbol_errors;
    sx_port_cntr_t dot3control_in_unknown_opcodes;
    sx_port_cntr_t dot3in_pause_frames;
    sx_port_cntr_t dot3out_pause_frames;
} PACK_SUFFIX sx_port_cntr_rfc_3635_t;

static const char* sx_port_cntr_rfc_3635_str[] = {
    "dot3stats_alignment_errors",
    "dot3stats_fcs_errors",
    "dot3stats_single_collision_frames",
    "dot3stats_multiple_collision_frames",
    "dot3stats_sqe_test_errors",
    "dot3stats_deferred_transmissions",
    "dot3stats_late_collisions",
    "dot3stats_excessive_collisions",
    "dot3stats_internal_mac_transmit_errors",
    "dot3stats_carrier_sense_errors",
    "dot3stats_frame_too_longs",
    "dot3stats_internal_mac_receive_errors",
    "dot3stats_symbol_errors",
    "dot3control_in_unknown_opcodes",
    "dot3in_pause_frames",
    "dot3out_pause_frames",
};
static const int   sx_port_cntr_rfc_3635_str_len = sizeof(sx_port_cntr_rfc_3635_str) / sizeof(char*);
#define SX_PORT_CNTR_RFC_3635_NUM sx_port_cntr_rfc_3635_str_len
#define SX_PORT_CNTR_RFC_3635_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_rfc_3635_str_len - 1) ? \
     sx_port_cntr_rfc_3635_str[index] : "UNKNOWN")
/*********************************************************************************************************************/

typedef struct sx_port_cntr_discard {
    sx_port_cntr_t ingress_general;
    sx_port_cntr_t ingress_policy_engine;
    sx_port_cntr_t ingress_vlan_membership;
    sx_port_cntr_t ingress_tag_frame_type;
    sx_port_cntr_t egress_vlan_membership;
    sx_port_cntr_t loopback_filter;
    sx_port_cntr_t egress_general;
    sx_port_cntr_t egress_link_down;
    sx_port_cntr_t egress_hoq;
    sx_port_cntr_t port_isolation;
    sx_port_cntr_t egress_policy_engine;
    sx_port_cntr_t ingress_tx_link_down;
    sx_port_cntr_t egress_stp_filter;
    sx_port_cntr_t egress_hoq_stall;
    sx_port_cntr_t egress_sll;
} PACK_SUFFIX sx_port_cntr_discard_t;

static const char* sx_port_cntr_discard_str[] = {
    "ingress_general",
    "ingress_policy_engine",
    "ingress_vlan_membership",
    "ingress_tag_frame_type",
    "egress_vlan_membership",
    "loopback_filter",
    "egress_general",
    "egress_link_down",
    "egress_hoq",
    "port_isolation",
    "egress_policy_engine",
    "ingress_tx_link_down",
    "egress_stp_filter",
    "egress_hoq_stall",
    "egress_sll",
};
static const int   sx_port_cntr_discard_str_len = sizeof(sx_port_cntr_discard_str) / sizeof(char*);
#define SX_PORT_CNTR_DISCARD_NUM sx_port_cntr_discard_str_len
#define SX_PORT_CNTR_DISCARD_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_discard_str_len - 1) ? \
     sx_port_cntr_discard_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

typedef struct sx_port_cntr_cli {
    sx_port_cntr_t port_rx_octets;
    sx_port_cntr_t port_rx_frames;
    sx_port_cntr_t port_rx_jumbo;
    sx_port_cntr_t port_rx_unicast;
    sx_port_cntr_t port_rx_multicast;
    sx_port_cntr_t port_rx_broadcast;
    sx_port_cntr_t port_rx_no_buffer;
    sx_port_cntr_t port_rx_fcs_errors;
    sx_port_cntr_t port_rx_runt;
    sx_port_cntr_t port_rx_other_errors;
    sx_port_cntr_t port_tx_octets;
    sx_port_cntr_t port_tx_frames;
    sx_port_cntr_t port_tx_jumbo;
    sx_port_cntr_t port_tx_unicast;
    sx_port_cntr_t port_tx_multicast;
    sx_port_cntr_t port_tx_broadcast;
    sx_port_cntr_t port_tx_errors;
} PACK_SUFFIX sx_port_cntr_cli_t;

static const char* sx_port_cntr_cli_str[] = {
    "port_rx_octets",
    "port_rx_frames",
    "port_rx_jumbo",
    "port_rx_unicast",
    "port_rx_multicast",
    "port_rx_broadcast",
    "port_rx_no_buffer",
    "port_rx_fcs_errors",
    "port_rx_runt",
    "port_rx_other_errors",
    "port_tx_octets",
    "port_tx_frames",
    "port_tx_jumbo",
    "port_tx_unicast",
    "port_tx_multicast",
    "port_tx_broadcast",
    "port_tx_errors",
};
static const int   sx_port_cntr_cli_str_len = sizeof(sx_port_cntr_cli_str) / sizeof(char*);
#define SX_PORT_CNTR_CLI_NUM sx_port_cntr_cli_str_len
#define SX_PORT_CNTR_CLI_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_cli_str_len - 1) ? \
     sx_port_cntr_cli_str[index] : "UNKNOWN")


/*********************************************************************************************************************/

typedef struct sx_port_traffic_cntr {
    sx_port_cntr_t tx_octet;
    sx_port_cntr_t tx_uc_frames;
    sx_port_cntr_t tx_mc_frames;
    sx_port_cntr_t tx_bc_frames;
    sx_port_cntr_t tx_frames;
    sx_port_cntr_t tx_queue;
    sx_port_cntr_t tx_no_buffer_discard_uc;
    sx_port_cntr_t tx_wred_discard;
} sx_port_traffic_cntr_t;

static const char* sx_port_traffic_cntr_str[] = {
    "tx_octet",
    "tx_uc_frames",
    "tx_mc_frames",
    "tx_bc_frames",
    "tx_frames",
    "tx_queue",
    "tx_no_buffer_discard_uc",
    "tx_wred_discard",
};
static const int   sx_port_traffic_cntr_str_len = sizeof(sx_port_traffic_cntr_str) / sizeof(char*);
#define SX_PORT_CNTR_TRAFFIC_NUM sx_port_traffic_cntr_str_len
#define SX_PORT_CNTR_TRAFFIC_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_traffic_cntr_str_len - 1) ? \
     sx_port_traffic_cntr_str[index] : "UNKNOWN")

/*********************************************************************************************************************/

typedef struct sx_port_cntr_prio {
    sx_port_cntr_t rx_octets;
    sx_port_cntr_t rx_uc_frames;
    sx_port_cntr_t rx_mc_frames;
    sx_port_cntr_t rx_bc_frames;
    sx_port_cntr_t rx_frames;
    sx_port_cntr_t tx_octets;
    sx_port_cntr_t tx_uc_frames;
    sx_port_cntr_t tx_mc_frames;
    sx_port_cntr_t tx_bc_frames;
    sx_port_cntr_t tx_frames;
    sx_port_cntr_t rx_pause;
    sx_port_cntr_t rx_pause_duration;
    sx_port_cntr_t tx_pause;
    sx_port_cntr_t tx_pause_duration;
    sx_port_cntr_t rx_pause_transition;
    sx_port_cntr_t rx_discard;
} PACK_SUFFIX sx_port_cntr_prio_t;

static const char*sx_port_cntr_prio_str[] = {
    "rx_octets",
    "rx_uc_frames",
    "rx_mc_frames",
    "rx_bc_frames",
    "rx_frames",
    "tx_octets",
    "tx_uc_frames",
    "tx_mc_frames",
    "tx_bc_frames",
    "tx_frames",
    "rx_pause",
    "rx_pause_duration",
    "tx_pause",
    "tx_pause_duration",
    "rx_pause_transition",
    "rx_discard",
};
static const int  sx_port_cntr_prio_str_len = sizeof(sx_port_cntr_prio_str) / sizeof(char*);
#define SX_PORT_CNTR_PRIO_NUM sx_port_cntr_prio_str_len
#define SX_PORT_CNTR_PRIO_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_prio_str_len - 1) ? \
     sx_port_cntr_prio_str[index] : "UNKNOWN")
/*********************************************************************************************************************/

typedef struct sx_port_cntr_buff {
    sx_port_cntr_t rx_octet;
    sx_port_cntr_t rx_frames;
    sx_port_cntr_t rx_buffer_discard;
    sx_port_cntr_t rx_shared_buffer_discard;
} PACK_SUFFIX sx_port_cntr_buff_t;

static const char *sx_port_cntr_buff_str[] = {
    "rx_octets",
    "rx_frames",
    "rx_buffer_discard",
    "rx_shared_buffer_discard",
};
static const int   sx_port_cntr_buff_str_len = sizeof(sx_port_cntr_buff_str) / sizeof(char *);
#define SX_PORT_CNTR_BUFF_NUM sx_port_cntr_buff_str_len
#define SX_PORT_CNTR_BUFF_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_buff_str_len - 1) ? \
     sx_port_cntr_buff_str[index] : "UNKNOWN")

/*****************************************************************************************************************************/
typedef struct sx_port_cntr_tc_congestion {
    sx_port_cntr_t wred_discard;
} PACK_SUFFIX sx_port_cntr_tc_congestion_t;

static const char*sx_port_cntr_tc_congestion_str[] = {
    "wred_discard"
};
static const int  sx_port_cntr_tc_congestion_len = sizeof(sx_port_cntr_tc_congestion_str) / sizeof(char*);
#define SX_PORT_CNTR_TC_CONGESTION_NUM sx_port_cntr_tc_congestion_len
#define SX_PORT_CNTR_TC_CONGESTION_STR(index)                            \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_tc_congestion_len - 1) ? \
     sx_port_cntr_tc_congestion_str[index] : "UNKNOWN")
/*****************************************************************************************************************************/
typedef struct sx_port_cntr_perf {
    sx_port_cntr_t tx_wait;
    sx_port_cntr_t ecn_marked;
    sx_port_cntr_t no_buffer_discard_mc;
    sx_port_cntr_t rx_ebp;
    sx_port_cntr_t tx_ebp;
    sx_port_cntr_t rx_buffer_almost_full;
    sx_port_cntr_t rx_buffer_full;
    sx_port_cntr_t tx_stats_pkts64octets;
    sx_port_cntr_t tx_stats_pkts65to127octets;
    sx_port_cntr_t tx_stats_pkts128to255octets;
    sx_port_cntr_t tx_stats_pkts256to511octets;
    sx_port_cntr_t tx_stats_pkts512to1023octets;
    sx_port_cntr_t tx_stats_pkts1024to1518octets;
    sx_port_cntr_t tx_stats_pkts1519to2047octets;
    sx_port_cntr_t tx_stats_pkts2048to4095octets;
    sx_port_cntr_t tx_stats_pkts4096to8191octets;
    sx_port_cntr_t tx_stats_pkts8192to10239octets;
} PACK_SUFFIX sx_port_cntr_perf_t;

static const char*sx_port_cntr_perf_str[] = {
    "tx_wait",
    "ecn_marked",
    "no_buffer_discard_mc",
    "rx_ebp",
    "tx_ebp",
    "rx_buffer_almost_full",
    "rx_buffer_full",
    "tx_stats_pkts64octets",
    "tx_stats_pkts65to127octets",
    "tx_stats_pkts128to255octets",
    "tx_stats_pkts256to511octets",
    "tx_stats_pkts512to1023octets",
    "tx_stats_pkts1024to1518octets",
    "tx_stats_pkts1519to2047octets",
    "tx_stats_pkts2048to4095octets",
    "tx_stats_pkts4096to8191octets",
    "tx_stats_pkts8192to10239octets"
};
static const int  sx_port_cntr_perf_str_len = sizeof(sx_port_cntr_perf_str) / sizeof(char*);
#define SX_PORT_CNTR_PERF_NUM sx_port_cntr_perf_str_len
#define SX_PORT_CNTR_PERF_STR(index)                                \
    (SX_CHECK_RANGE(0, (int)index, sx_port_cntr_perf_str_len - 1) ? \
     sx_port_cntr_perf_str[index] : "UNKNOWN")
/*****************************************************************************************************************************/

#define SX_PORT_CNTR_GRP_PHY_LAYER_SIZE         (sizeof(sx_port_cntr_phy_layer_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_IEEE_802_DOT_3_SIZE    (sizeof(sx_port_cntr_ieee_802_dot_3_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_2863_SIZE          (sizeof(sx_port_cntr_rfc_2863_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_2819_SIZE          (sizeof(sx_port_cntr_rfc_2819_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_RFC_3635_SIZE          (sizeof(sx_port_cntr_rfc_3635_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_DISCARD_SIZE           (sizeof(sx_port_cntr_discard_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_CLI_SIZE               (sizeof(sx_port_cntr_cli_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PER_PRIO_SIZE          (sizeof(sx_port_cntr_prio_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PER_TC_CONGESTION_SIZE (sizeof(sx_port_cntr_tc_congestion_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_PERF_SIZE              (sizeof(sx_port_cntr_perf_t) / sizeof(sx_port_cntr_t))
#define SX_PORT_CNTR_GRP_MAX_SIZE               (31)

/*********************************************************************************************************************/
/*PBMC EMAD*/
#define SX_PORT_BUFF_NUM 9


/* Inside the SDK we use double, while the user of SX API will use uint16_t */
typedef double sx_port_buff_size_t;
typedef double sx_port_pbmc_t;

/* Single MC logical port for shared buffers multicast configuration */
#define SX_MC_PORT_LOG_ID (0x0FFFFF1F)

/* All values are in KB */
typedef struct sx_port_buff {
    sx_port_buff_size_t size;
    sx_port_buff_size_t xof_threshold;
    sx_port_buff_size_t xon_threshold;
    boolean_t           is_lossy;
} sx_port_buff_t;

#define SX_MAP_BITMAP_MAX     0xF
#define SX_MAP_BITMAP_MIN     0x1
#define SX_MAP_BITMAP_MIN_MAX SX_MAP_BITMAP_MIN, SX_MAP_BITMAP_MAX
#define SX_MAP_BITMAP_CHECK_RANGE(mode) SX_CHECK_RANGE(SX_MAP_BITMAP_MIN, (int)mode, SX_MAP_BITMAP_MAX)


/*********************************************************************************************************************/

typedef struct sx_port_mapping {
    sx_port_phy_id_t       local_port;       /*1,    2,      3,      4,      5,      6,      7,      ...,    62,     63,     64;*/
    sx_port_mapping_mode_t mapping_mode;     /*EN,   DIS,    EN,     DIS,    EN,     EN,     DIS,    ...,    EN,     DIS,    EN;*/
    sx_port_mod_id_t       module_port;      /*1,    0,      2,      0,      3,      4,      0,      ...,    31,     0,      32;*/
    sx_port_width_t        width;            /*4,    0,      4,      0,      4,      4,      0,      ...,    4,      0,      4;*/
    sx_port_lane_bmap_t    lane_bmap;        /*0xF   0x0     0xF     0x0     0xF     0xF     0x0     ...,    0xF     0x0     0xF;*/
    boolean_t              config_hw;  /**< Currently not supported, use only FALSE */
} sx_port_mapping_t;

typedef struct sx_port_attributes {
    sx_port_mode_t    port_mode;
    sx_port_mapping_t port_mapping;
    sx_port_log_id_t  log_port;
} sx_port_attributes_t;

/*********************************************************************************************************************/

typedef enum sx_port_discard_family {
    SX_PORT_DISCARD_FAMILY_GLOBAL = 0,
    SX_PORT_DISCARD_FAMILY_PORT = 1, /* Unsupported port discard_family */
    SX_PORT_DISCARD_FAMILY_BUFFER = 2, /* Unsupported buffer discard_family */
    SX_PORT_DISCARD_FAMILY_ETHERNET = 3,
    SX_PORT_DISCARD_FAMILY_IP = 4,
    SX_PORT_DISCARD_FAMILY_TUNNEL = 5,
    SX_PORT_DISCARD_FAMILY_MPLS = 6,
    SX_PORT_DISCARD_FAMILY_MIN = SX_PORT_DISCARD_FAMILY_GLOBAL,
    SX_PORT_DISCARD_FAMILY_MAX = SX_PORT_DISCARD_FAMILY_MPLS,
} sx_port_discard_family_e;

typedef struct sx_port_cause {
    boolean_t cause;
} sx_port_cause_t;

typedef struct sx_port_global_reasons {
    sx_port_cause_t no_egress_port;
} sx_port_global_reasons_t;

typedef struct sx_port_eth_reasons {
    sx_port_cause_t smac_is_mc;
    sx_port_cause_t smac_equal_dmac;
    sx_port_cause_t invalid_ethertype;
    sx_port_cause_t ingress_spanning_tree;
    sx_port_cause_t fdb_miss;
    sx_port_cause_t fdb_mismatch;
    sx_port_cause_t fid_miss;
} sx_port_eth_reasons_t;

typedef struct sx_port_ip_reasons {
    sx_port_cause_t packet_to_router_is_not_ip; /**< Will be supported in the future */
    sx_port_cause_t disabled_irif;
    sx_port_cause_t uc_dip_over_mc_or_bc_mac;
    sx_port_cause_t dip_is_loopback; /**< Will be supported in the future */
    sx_port_cause_t sip_is_mc;
    sx_port_cause_t sip_is_in_class; /**< Will be supported in the future */
    sx_port_cause_t sip_is_loopback; /**< Will be supported in the future */
    sx_port_cause_t sip_is_unspecified;
    sx_port_cause_t ip_header_not_okay; /**< Will be supported in the future */
    sx_port_cause_t mc_mac_mismatch;
    sx_port_cause_t sip_equal_dip;
    sx_port_cause_t ipv4_sip_is_limited_broadcast; /**< Will be supported in the future */
    sx_port_cause_t lpm_ipv4_miss; /**< UC only */
    sx_port_cause_t lpm_ipv6_miss; /**< Will be supported in the future */
    sx_port_cause_t uc_dip_is_link_local;
    sx_port_cause_t sip_is_link_local;
    sx_port_cause_t mc_egress_mtu_aggregated;
    sx_port_cause_t mc_RPF;
    sx_port_cause_t uc_RPF;
    sx_port_cause_t uc_hoplimit;
    sx_port_cause_t IPv4_dip_is_limited_broadcast; /**< Will be supported in the future */
    sx_port_cause_t IPv4_dip_is_local; /**< Will be supported in the future */
    sx_port_cause_t NVE_packet_to_overlay_router; /**< Will be supported in the future */
    sx_port_cause_t ttl_error;
    sx_port_cause_t disabled_erif;
    sx_port_cause_t host_miss_ipv4;
    sx_port_cause_t host_miss_ipv6;
    sx_port_cause_t loopback_error;
} sx_port_ip_reasons_t;

typedef struct sx_port_tunnel_reasons {
    sx_port_cause_t decap_encap_prevention;
    sx_port_cause_t ipip_tunnel_loop;
    sx_port_cause_t ipip_nested_tunnel;
    sx_port_cause_t ipip_decap_error;
    sx_port_cause_t overlay_port_isolation;
    sx_port_cause_t nve_decap_frag_error;
    sx_port_cause_t nve_decap_error;
    sx_port_cause_t decap_ecn; /**< Will be supported in the future */
    sx_port_cause_t ipip_error;
} sx_port_tunnel_reasons_t;

typedef struct sx_port_mpls_reasons {
    sx_port_cause_t outer_label_is_not_valid; /**< Will be supported in the future */
    sx_port_cause_t no_IP_after_decap; /**< Will be supported in the future */
    sx_port_cause_t expected_Bos_but_pop_did_not_expose_BoS; /**< Will be supported in the future */
    sx_port_cause_t mpls_uc_ethertype_over_mc_or_bc_mac;
    sx_port_cause_t mpls_min_ingress_label_allowed;
    sx_port_cause_t mpls_max_ingress_label_allowed;
    sx_port_cause_t php_decap_and_no_ip_header_or_ip_header_is_not_okay; /**< Will be supported in the future */
    sx_port_cause_t mpls_loopback_filter;
    sx_port_cause_t ilm_miss;
} sx_port_mpls_reasons_t;

typedef struct sx_port_discard_reason {
    sx_port_discard_family_e discard_family;
    union {
        sx_port_global_reasons_t global_reasons;
        sx_port_eth_reasons_t    ethernet_discard;
        sx_port_ip_reasons_t     ip_discard;
        sx_port_tunnel_reasons_t tunnel_discard;
        sx_port_mpls_reasons_t   mpls_discard;
    } data;
} sx_port_discard_reason_t;


/*********************************************************************************************************************/


/*********************************************************************************************************************/

/**
 * sx_port_params_t structure is used to store initialization parameters of
 * Port Library.
 */
typedef struct sx_port_params {
    sx_dev_id_t max_dev_id;     /**< Max device ID */
    uint8_t     port_phy_bits_num; /**< Port represents: PHY width */
    uint8_t     port_pth_bits_num; /**< Port represents: PTH width */
    uint8_t     port_sub_bits_num; /**< Port represents: SUB width */
    uint64_t    sup_revs_by_type[SX_CHIP_TYPES_MAX];
} sx_port_params_t;

typedef enum sx_port_isolate_direction {
    ISOLATE_RX = 0,
    ISOLATE_TX = 1,
} sx_port_isolate_direction_t;

/**
 * sx_port_isolate_mode_t defines port isolate mode
 */
typedef struct sx_port_isolate_mode {
    boolean_t pass_routed_frames;       /**< Whether pass (True) or filter (False) frames,
                                         * which passed the router                         */
} sx_port_isolate_mode_t;

typedef enum sx_port_router_bind_mode {
    SX_PORT_NOT_BOUND_TO_ROUTER = 0,
    SX_PORT_BOUND_TO_ROUTER = 1
} sx_port_router_bind_mode_t;

typedef enum sx_port_buffer_configuration_mode {
    SX_PORT_BUFFER_CONFIGURATION_DEFAULT = 0,
    SX_PORT_BUFFER_CONFIGURATION_PBMC_CONFIGURED_BY_USER = 1
} sx_port_buffer_configuration_mode_t;

typedef enum sx_cos_port_buffer_max_mode {
    SX_COS_PORT_BUFFER_MAX_MODE_STATIC = 0,
    SX_COS_PORT_BUFFER_MAX_MODE_DYNAMIC = 1
} sx_cos_port_buffer_max_mode_t;

typedef struct sx_headroom_buff_ing {
    sx_cos_timer_value_t       xof_timer_value;
    sx_cos_timer_value_t       xof_refresh;
    sx_cos_port_buff_params_t *buffer_list;       /*headroom_num_port_buff*/
} sx_headroom_buff_ing_t;

typedef sxd_port_prio_id_buff_t sx_port_prio_id_buff_t;

typedef struct sx_port_sflow {
    boolean_t enabled;               /**< 1 - sflow enabled in HW on port, 0 - disabled */
    uint32_t  rate;                  /**< one packet is sampled every ratio */
} sx_port_sflow_t;

typedef struct sx_port_sflow_statistics {
    uint64_t count_sample_drop; /**< discard after sampling (high, low) */
} sx_port_sflow_statistics_t;

/**
 * Define minimum sampling rate allowed on port
 * (total packets / sampled packets)
 */
#define SX_PORT_SFLOW_SAMPLING_RATE_MIN (1)

/**
 * Define maximum sampling rate allowed on port
 * (total packets / sampled packets)
 */
#define SX_PORT_SFLOW_SAMPLING_RATE_MAX (3500000000u)

#define SX_PORT_SFLOW_SAMPLING_RATE_VALIDATE(rate) \
    (((rate >= SX_PORT_SFLOW_SAMPLING_RATE_MIN) && \
      (rate <= SX_PORT_SFLOW_SAMPLING_RATE_MAX)) ? TRUE : FALSE)

typedef enum sx_port_packet_storing_mode {
    SX_PORT_PACKET_STORING_MODE_CUT_THROUGH = 0,
    SX_PORT_PACKET_STORING_MODE_STORE_AND_FORWARD,
    SX_PORT_PACKET_STORING_MODE_MIN = SX_PORT_PACKET_STORING_MODE_CUT_THROUGH,
    SX_PORT_PACKET_STORING_MODE_MAX = SX_PORT_PACKET_STORING_MODE_STORE_AND_FORWARD
} sx_port_packet_storing_mode_t;

#define SX_PORT_PACKET_STORING_MODE_DEFAULT SX_PORT_PACKET_STORING_MODE_CUT_THROUGH
#define SX_PORT_PACKET_STORING_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_PACKET_STORING_MODE_MIN,   \
                   (int)mode,                         \
                   SX_PORT_PACKET_STORING_MODE_MAX)

typedef struct sx_port_forwarding_mode {
    sx_port_packet_storing_mode_t packet_store;
} sx_port_forwarding_mode_t;

typedef struct sx_port_ber_level {
    uint32_t mantissa; /**< Mantissa or the port BER monitor */
    int32_t  exponent; /**< Exponent or the port BER monitor */
} sx_port_ber_level_t;

#define FOREACH_PORT_BER_FEC_PROFILE(F)                                                     \
    F(SX_PORT_BER_FEC_PROFILE_PRE_RS_FEC_E = 0 /**< Pre RS FEC */, "Pre RS-FEC")            \
    F(SX_PORT_BER_FEC_PROFILE_PRE_FC_FEC_E /**< Pre FC FEC */, "Pre FC-FEC")                \
    F(SX_PORT_BER_FEC_PROFILE_NO_FEC_POST_FEC_E /**< No FEC/Post FEC */, "No FEC/Post FEC") \
    F(SX_PORT_BER_FEC_PROFILE_MIN_E = SX_PORT_BER_FEC_PROFILE_PRE_RS_FEC_E, "")             \
    F(SX_PORT_BER_FEC_PROFILE_MAX_E = SX_PORT_BER_FEC_PROFILE_NO_FEC_POST_FEC_E, "")        \
    F(SX_PORT_BER_FEC_PROFILE_COUNT_E = SX_PORT_BER_FEC_PROFILE_MAX_E + 1, "")

typedef enum sx_port_ber_fec_profile {
    FOREACH_PORT_BER_FEC_PROFILE(SX_GENERATE_ENUM)
} sx_port_ber_fec_profile_e;

typedef enum sx_port_ber_alarm_conf_status {
    SX_PORT_BER_ALARM_CONF_STATUS_DISABLED_E = 0, /**< BER monitor disabled */
    SX_PORT_BER_ALARM_CONF_STATUS_ENABLED_E /**< BER monitor enabled */
} sx_port_ber_alarm_conf_status_e;

typedef struct sx_port_ber_alarm_types {
    sx_port_ber_alarm_conf_status_e normal; /**< normal threshold */
    sx_port_ber_alarm_conf_status_e warning; /**< warning threshold */
    sx_port_ber_alarm_conf_status_e alarm; /**< alarm threshold */
} sx_port_ber_alarm_types_t;


#define FOREACH_PORT_BER_ALARM_STATE(F)                                      \
    F(SX_PORT_BER_ALARM_STATE_NOT_ARMED_E = 0 /**< Disabled */, "Not Armed") \
    F(SX_PORT_BER_ALARM_STATE_NORMAL_E /**< Normal level */, "Normal")       \
    F(SX_PORT_BER_ALARM_STATE_WARNING_E /**< Warning level */, "Warning")    \
    F(SX_PORT_BER_ALARM_STATE_ALARM_E /**< Alarm level */, "Alarm")          \
    F(SX_PORT_BER_ALARM_CLEAR_E /**< Clear the level on port state down */, "Clear")

typedef enum sx_port_ber_alarm_state {
    FOREACH_PORT_BER_ALARM_STATE(SX_GENERATE_ENUM)
} sx_port_ber_alarm_state_e;

typedef enum sx_port_ber_pre_fec {
    SX_PORT_BER_PRE_FEC_DISABLE_E = 0, /**< Pre FEC disabled */
    SX_PORT_BER_PRE_FEC_ENABLE_E = 1, /**< Pre FEC enabled */
} sx_port_ber_pre_fec_e;

typedef struct sx_port_ber_fec_profile_threshold_data {
    sx_port_ber_level_t normal; /**< Normal threshold values */
    sx_port_ber_level_t warning; /**< warning threshold values */
    sx_port_ber_level_t alarm; /**< alarm threshold values */
} sx_port_ber_fec_profile_threshold_data_t;

typedef struct sx_port_ber_port_ber_monitor_conf_data {
    sx_port_ber_alarm_types_t alarm_types;   /**< Alarm types to configure */
    sx_port_ber_pre_fec_e     pre_fec;   /**< Is pre-FEC */
} sx_port_ber_monitor_data_t;

typedef struct sx_port_ber_port_ber_monitor_oper_data {
    sx_port_ber_alarm_state_e alarm_state;   /**< Current alarm state */
    sx_port_ber_pre_fec_e     pre_fec;   /**< Is pre-FEC */
} sx_port_ber_monitor_oper_data_t;

/**
 * Specify how to handle packets with bad CRC on ingress.
 */
typedef enum sx_port_bad_crc_ingress_mode {
    SX_PORT_BAD_CRC_INGRESS_MODE_DROP = 0,
    SX_PORT_BAD_CRC_INGRESS_MODE_FORWARD,
    SX_PORT_BAD_CRC_INGRESS_MODE_MIN = SX_PORT_BAD_CRC_INGRESS_MODE_DROP,
    SX_PORT_BAD_CRC_INGRESS_MODE_MAX = SX_PORT_BAD_CRC_INGRESS_MODE_FORWARD
} sx_port_bad_crc_ingress_mode_e;

#define SX_PORT_BAD_CRC_INGRESS_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_BAD_CRC_INGRESS_MODE_MIN,   \
                   (int)mode,                          \
                   SX_PORT_BAD_CRC_INGRESS_MODE_MAX)

/**
 * Specify whether to allow recalculation of CRC on egress.
 */
typedef enum sx_port_crc_egress_recalc_mode {
    SX_PORT_CRC_EGRESS_RECALC_MODE_ALLOW = 0,
    SX_PORT_CRC_EGRESS_RECALC_MODE_PREVENT,
    SX_PORT_CRC_EGRESS_RECALC_MODE_MIN = SX_PORT_CRC_EGRESS_RECALC_MODE_ALLOW,
    SX_PORT_CRC_EGRESS_RECALC_MODE_MAX = SX_PORT_CRC_EGRESS_RECALC_MODE_PREVENT
} sx_port_crc_egress_recalc_mode_e;

#define SX_PORT_CRC_EGRESS_RECALC_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_PORT_CRC_EGRESS_RECALC_MODE_MIN,   \
                   (int)mode,                            \
                   SX_PORT_CRC_EGRESS_RECALC_MODE_MAX)

typedef struct sx_port_crc_params {
    sx_port_bad_crc_ingress_mode_e   bad_crc_ingress_mode;
    sx_port_crc_egress_recalc_mode_e crc_egress_recalc_mode;
} sx_port_crc_params_t;

typedef enum sx_port_ptp_low_speed_rx_role {
    SX_PORT_PTP_LOW_SPEED_RX_ROLE_PRIMARY = 0,
    SX_PORT_PTP_LOW_SPEED_RX_ROLE_SECONDARY,
    SX_PORT_PTP_LOW_SPEED_RX_ROLE_NONE,
    SX_PORT_PTP_LOW_SPEED_RX_CONFIGURABLE_ROLE_MAX = SX_PORT_PTP_LOW_SPEED_RX_ROLE_SECONDARY,
    SX_PORT_PTP_LOW_SPEED_RX_ROLE_MAX = SX_PORT_PTP_LOW_SPEED_RX_ROLE_NONE,
} sx_port_ptp_low_speed_rx_role_e;

typedef enum sx_port_ptp_role_cmd {
    SX_PORT_PTP_ROLE_CMD_DISABLE = 0,
    SX_PORT_PTP_ROLE_CMD_ENABLE,
    SX_PORT_PTP_ROLE_CMD_MAX = SX_PORT_PTP_ROLE_CMD_DISABLE,
} sx_port_ptp_role_cmd_e;

#define FOREACH_PORT_RATE(F)                              \
    F(SX_PORT_RATE_NA_E = 0 /**< N/A */, "Not connected") \
    F(SX_PORT_RATE_100M_E /**< 100M */, "100M")           \
    F(SX_PORT_RATE_1G_E /**< 1G */, "1G")                 \
    F(SX_PORT_RATE_10G_E /**< 10G */, "10G")              \
    F(SX_PORT_RATE_25G_E /**< 25G */, "25G")              \
    F(SX_PORT_RATE_40G_E /**< 40G */, "40G")              \
    F(SX_PORT_RATE_50G_E /**< 50G */, "50G")              \
    F(SX_PORT_RATE_100G_E /**< 100G */, "100G")           \
    F(SX_PORT_RATE_200G_E /**< 200G */, "200G")           \
    F(SX_PORT_RATE_400G_E /**< 400G */, "400G")

typedef enum sx_port_rate {
    FOREACH_PORT_RATE(SX_GENERATE_ENUM)
} sx_port_rate_e;

typedef sx_port_rate_e sx_port_rate_t;

typedef enum sx_port_phy_module_type {
    SX_PORT_PHY_MODULE_NOT_CONNECTED = 0x00,     /**< unknown or not connected*/
    SX_PORT_PHY_MODULE_SMF_UP_500M_E = 0x01,
    SX_PORT_PHY_MODULE_SMF_UP_2KM_E = 0x02,
    SX_PORT_PHY_MODULE_SMF_ABOVE_2KM_E = 0x04,
    SX_PORT_PHY_MODULE_MMF_UP_100M_E = 0x08,
    SX_PORT_PHY_MODULE_MMF_ABOVE_100M_E = 0x10,
    SX_PORT_PHY_MODULE_AOC_ACC_UP_30M_E = 0x20,
    SX_PORT_PHY_MODULE_AOC_ACC_ABOVE_30M_E = 0x40,
    SX_PORT_PHY_MODULE_BASE_CR_E = 0x80,
    SX_PORT_PHY_MODULE_BASE_TP_E = 0x100
} sx_port_phy_module_type_e;

typedef struct sx_port_ptp_params {
    sx_port_ptp_low_speed_rx_role_e low_speed_rx_role;
    sx_port_ptp_role_cmd_e          cmd;
} sx_port_ptp_params_t;

#endif /* __SX_PORT_H__ */
