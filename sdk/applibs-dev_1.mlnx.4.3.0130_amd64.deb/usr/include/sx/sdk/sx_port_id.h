/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_PORT_ID_H__
#define __SX_PORT_ID_H__

#include <sx/sxd/sxd_port.h>

#include <sx/sdk/sx_check.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * SX_INVALID_PORT defines value for invalid log port
 */
#define SX_INVALID_PORT 0

#define SX_PORT_LOG_ID_MAX (0xFFFFFFFF)
#define SX_PORT_PHY_ID_MIN (0x00000000)
#define SX_PORT_PHY_ID_MAX (0x00000080)
#define SX_PORT_SUB_ID_MIN (0x00000000)
#define SX_PORT_SUB_ID_MAX (0x0000000F)
#define SX_PORT_LAG_ID_MIN (0x00000000)
#define SX_PORT_LAG_ID_MAX (0x000000FF)

#define SX_PORT_MAP_CHUNK_NUM_MAX (4)

#define SX_PORT_LCL_CPU_ID_DEFAULT (0)
#define SX_PORT_SUB_CPU_ID_DEFAULT (0)
#define SX_PORT_PTH_CPU_ID_DEFAULT (0)

#define SX_PORT_DEV_ID_CHECK_RANGE(id) SX_CHECK_RANGE(SX_PORT_DEV_ID_MIN, id, SX_PORT_DEV_ID_MAX)
#define SX_PORT_LCL_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_LCL_ID_MAX)
#define SX_PORT_PHY_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_PHY_ID_MAX)
#define SX_PORT_SUB_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_SUB_ID_MAX)
#define SX_PORT_LOG_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_LOG_ID_MAX)
#define SX_PORT_UCR_ID_CHECK_RANGE(id) SX_CHECK_MAX(id, SX_PORT_UCR_ID_MAX)

#define SX_PORT_PHY_ID_MIN_MAX SX_PORT_PHY_ID_MIN, SX_PORT_PHY_ID_MAX
#define SX_PORT_SUB_ID_MIN_MAX SX_PORT_SUB_ID_MIN, SX_PORT_PHY_ID_MAX


#define SX_PORT_TYPE_ID_MASK (0xF0000000)
#define SX_PORT_DEV_ID_MASK  (0x0FFF0000)
#define SX_PORT_PHY_ID_MASK  (0x0000FF00)
#define SX_PORT_SUB_ID_MASK  (0x0000000F)
#define SX_PORT_LAG_ID_MASK  (0x0000FF00)
#define SX_PORT_VLAN_ID_MASK (0x0FFF0000)

#define SX_PORT_TYPE_ID_OFFS (28)
#define SX_PORT_DEV_ID_OFFS  (16)
#define SX_PORT_LCL_ID_OFFS  (0)
#define SX_PORT_PHY_ID_OFFS  (8)
#define SX_PORT_SUB_ID_OFFS  (0)
#define SX_PORT_LAG_ID_OFFS  (8)
#define SX_PORT_VLAN_ID_OFFS (16)

#define SX_PORT_TYPE_ID_ISO(id) ((id) & (SX_PORT_TYPE_ID_MASK))
#define SX_PORT_DEV_ID_ISO(id)  ((id) & (SX_PORT_DEV_ID_MASK))
#define SX_PORT_LCL_ID_ISO(id)  ((id) & (SX_PORT_PHY_ID_MASK))
#define SX_PORT_PHY_ID_ISO(id)  ((id) & (SX_PORT_PHY_ID_MASK))
#define SX_PORT_SUB_ID_ISO(id)  ((id) & (SX_PORT_SUB_ID_MASK))
#define SX_PORT_LAG_ID_ISO(id)  ((id) & (SX_PORT_LAG_ID_MASK))
#define SX_PORT_VLAN_ID_ISO(id) ((id) & (SX_PORT_VLAN_ID_MASK))

#define SX_PORT_TYPE_ID_GET(id) (SX_PORT_TYPE_ID_ISO(id) >> SX_PORT_TYPE_ID_OFFS)
#define SX_PORT_DEV_ID_GET(id)  (SX_PORT_DEV_ID_ISO(id) >> SX_PORT_DEV_ID_OFFS)
#define SX_PORT_LCL_ID_GET(id)  (SX_PORT_LCL_ID_ISO(id) >> SX_PORT_LCL_ID_OFFS)
#define SX_PORT_PHY_ID_GET(id)  (SX_PORT_PHY_ID_ISO(id) >> SX_PORT_PHY_ID_OFFS)
#define SX_PORT_SUB_ID_GET(id)  (SX_PORT_SUB_ID_ISO(id) >> SX_PORT_SUB_ID_OFFS)
#define SX_PORT_LAG_ID_GET(id)  (SX_PORT_LAG_ID_ISO(id) >> SX_PORT_LAG_ID_OFFS)
#define SX_PORT_VLAN_ID_GET(id) (SX_PORT_VLAN_ID_ISO(id) >> SX_PORT_VLAN_ID_OFFS)

#define SX_PORT_TYPE_ID_CLR(id) ((id) &= ~(SX_PORT_TYPE_ID_MASK))
#define SX_PORT_DEV_ID_CLR(id)  ((id) &= ~(SX_PORT_DEV_ID_MASK))
#define SX_PORT_LCL_ID_CLR(id)  ((id) &= ~(SX_PORT_LCL_ID_MASK))
#define SX_PORT_PHY_ID_CLR(id)  ((id) &= ~(SX_PORT_PHY_ID_MASK))
#define SX_PORT_SUB_ID_CLR(id)  ((id) &= ~(SX_PORT_SUB_ID_MASK))
#define SX_PORT_LAG_ID_CLR(id)  ((id) &= ~(SX_PORT_LAG_ID_MASK))
#define SX_PORT_VLAN_ID_CLR(id) ((id) &= ~(SX_PORT_VLAN_ID_MASK))

#define SX_PORT_TYPE_ID_SET(id, TYPE_ID) ((id) |= SX_PORT_TYPE_ID_ISO((TYPE_ID) << (SX_PORT_TYPE_ID_OFFS)))
#define SX_PORT_DEV_ID_SET(id, DEV_ID)   ((id) |= SX_PORT_DEV_ID_ISO((DEV_ID) << (SX_PORT_DEV_ID_OFFS)))
#define SX_PORT_LCL_ID_SET(id, LCL_ID)   ((id) |= SX_PORT_LCL_ID_ISO((LCL_ID) << (SX_PORT_LCL_ID_OFFS)))
#define SX_PORT_PHY_ID_SET(id, PHY_ID)   ((id) |= SX_PORT_PHY_ID_ISO((PHY_ID) << (SX_PORT_PHY_ID_OFFS)))
#define SX_PORT_SUB_ID_SET(id, SUB_ID)   ((id) |= SX_PORT_SUB_ID_ISO((SUB_ID) << (SX_PORT_SUB_ID_OFFS)))
#define SX_PORT_LAG_ID_SET(id, LAG_ID)   ((id) |= SX_PORT_LAG_ID_ISO((LAG_ID) << (SX_PORT_LAG_ID_OFFS)))
#define SX_PORT_VLAN_ID_SET(id, VLAN_ID) ((id) |= SX_PORT_VLAN_ID_ISO((VLAN_ID) << (SX_PORT_VLAN_ID_OFFS)))

#define M_PRINT_PORT_LOG_ID_MEMBERS(log_port_id)                                                          \
    {                                                                                                     \
        SX_LOG_DBG("Logical port: 0x%08X, Type: 0x%01X, Device: 0x%03X, Phy id: 0x%02X,Sub id: 0x%02X\n", \
                   log_port_id,                                                                           \
                   SX_PORT_TYPE_ID_GET(log_port_id),                                                      \
                   SX_PORT_DEV_ID_GET(log_port_id),                                                       \
                   SX_PORT_PHY_ID_GET(log_port_id),                                                       \
                   SX_PORT_SUB_ID_GET(log_port_id));                                                      \
    }

#define M_PRINT_LCL_PORT_ID_MEMBERS(lcl_port_id)                \
    {                                                           \
        SX_LOG_DBG("Logical port: %u, Phy id: %d,Sub id: %d\n", \
                   lcl_port_id,                                 \
                   SX_PORT_PHY_ID_GET(lcl_port_id),             \
                   SX_PORT_SUB_ID_GET(lcl_port_id));            \
    }

#define SX_PORT_TYPE_ID_NUM_OF_BITS (4)
#define SX_PORT_DEV_ID_NUM_OF_BITS  (12)
#define SX_PORT_PHY_ID_NUM_OF_BITS  (8)
#define SX_PORT_SUB_ID_NUM_OF_BITS  (8)
#define SX_PORT_VLAN_ID_NUM_OF_BITS (12)
#define SX_PORT_LAG_ID_NUM_OF_BITS  (SX_PORT_PHY_ID_NUM_OF_BITS)

#define SX_PORT_UCR_ID_PHY_NUM_OF_BITS (6)

#define SX_PORT_VPORT_BUILD(vport, vlan, phy_port)  \
    SX_PORT_TYPE_ID_SET(vport, SX_PORT_TYPE_VPORT); \
    SX_PORT_VLAN_ID_SET(vport, vlan);               \
    SX_PORT_PHY_ID_SET(vport, phy_port)

#define SX_PORT_VPORT_LAG_BUILD(vport, vlan, lag_id) \
    SX_PORT_TYPE_ID_SET(vport, SX_PORT_TYPE_VPORT);  \
    SX_PORT_TYPE_ID_SET(vport, SX_PORT_TYPE_LAG);    \
    SX_PORT_VLAN_ID_SET(vport, vlan);                \
    SX_PORT_PHY_ID_SET(vport, lag_id)
/* Port Logic ID:
 ****************
 * Logical entity, that represents the format of a virtual port or the classical
 * format of a LAG in the GLOBAL system:
 *********************************************************************************************
 * +-----------+----------------------------+----------------------------+-------------------+
 * |Type[31:28]|      Device-ID[27:16]      | Port-Phy-ID[15:8]          | Port-Sub-ID[7:0]  |
 * +-----------+----------------------------+----------------------------+-------------------+
 *********************************************************************************************
 * +-----------+----------------------------+----------------------------+-------------------+
 * |Type[31:28]|      Reserved[27:16]       |       LAG-ID[15:8]         | Port-Sub-ID[7:0]  |
 * +-----------+----------------------------+----------------------------+-------------------+
 *********************************************************************************************
 * +-----------+----------------------------+----------------------------+-------------------+
 * |Type[31:28]|      Vlan-ID[27:16]        | Port-Phy-ID / LAG-ID[15:8] | Port-Sub-ID[7:0]  |
 * +-----------+----------------------------+----------------------------+-------------------+
 *********************************************************************************************
 */
typedef uint32_t sx_port_log_id_t;
typedef sx_port_log_id_t sx_port_id_t;


/* Port UC Route ID:
 *******************
 * Logical entity, that represents the format of a port UC route in the GLOBAL system
 ************************************************************************************
 * +----------------------------------------+--------------------+------------------+
 * | UC-Route-ID[15:W]                      |  Port-Pth-ID[X:Y]  | Port-Sub-ID[Z:0] |
 * +----------------------------------------+--------------------+------------------+
 ************************************************************************************
 * #_of_bits(Port-Sub-ID) = Z
 * #_of_bits(Port-Pth-ID) = X - Y + 1
 * W = #_of_bits(Port-Pth-ID) + #_of_bits(Port-Sub-ID)
 */
typedef sxd_port_sys_id_t sx_port_ucroute_id_t;

/* Port Virtual ID:
 ******************
 * Virtual entity, that represents the format of a port in the LOCAL (device) system:
 ************************************************************************************
 * +----------------------------------------+---------------------------------------+
 * |             Port-Phy-ID[15:8]          |            Port-Sub-ID[7:0]           |
 * +----------------------------------------+---------------------------------------+
 ************************************************************************************
 */
typedef uint16_t sx_port_vrt_id_t;

typedef struct sx_port_vrt_id_bits {
    uint32_t phy_id : SX_PORT_PHY_ID_NUM_OF_BITS; /* Physical Port ID   */
    uint32_t sub_id : SX_PORT_SUB_ID_NUM_OF_BITS; /* Sub Port ID		*/
} sx_port_vrt_id_bits_t;

typedef union sx_port_vrt_id_pkt {
    uint32_t              value;
    sx_port_vrt_id_bits_t bits;
} sx_port_vrt_id_pkt_t;

typedef sx_port_vrt_id_t sx_port_lcl_id_t;
typedef sx_port_vrt_id_bits_t sx_port_lcl_id_bits_t;
typedef sx_port_vrt_id_pkt_t sx_port_lcl_id_pkt_t;

/* Alias for a Sub (Virtual) Port ID
 **************************************************
 * VEPA channel on local port.
 * Valid only if local port is a non stacking port.
 * Must be 0 if Multi channel VEPA is not enabled.
 *************************************************/
typedef sxd_port_sub_id_t sx_port_sub_id_t;

/* Alias for a Physical Port ID
 *************************************************/
typedef sxd_port_phy_id_t sx_port_phy_id_t;
typedef sxd_port_phy_id_t sx_port_mod_id_t;

typedef uint16_t sx_port_dev_id_t;

typedef uint8_t sx_port_width_t;

typedef uint8_t sx_port_lane_bmap_t;

#endif /* __SX_PORT_ID_H__ */
