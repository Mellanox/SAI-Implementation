/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_ACL_H__
#define __SX_ACL_H__

#include <stdlib.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_policer.h>
#include <sx/sdk/sx_fcf.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_span.h>
#include <sx/sdk/sx_bridge.h>
#include <sx/sdk/sx_router.h>
#include <sx/sdk/sx_mpls_ilm.h>

/************************************************
 *  Type definitions
 ***********************************************/

typedef uint16_t sx_acl_vlan_group_t;
typedef uint16_t sx_acl_lookup_priority_t;
typedef uint32_t sx_acl_rule_offset_t;
typedef uint32_t sx_acl_size_t;
typedef uint32_t sx_flex_acl_rule_offset_t;
typedef uint32_t sx_rif_id_t;
typedef uint16_t sx_user_token_t;
typedef uint32_t sx_acl_port_list_id_t;
typedef uint32_t sx_acl_custom_bytes_offset_t;
typedef uint32_t sx_flex_acl_rule_priority_t;

/**
 * describes ACL group or ACL table
 */
typedef uint32_t sx_acl_region_id_t;
typedef uint32_t sx_acl_id_t;
typedef uint8_t sx_acl_port_range_id_t;
typedef uint32_t sx_acl_pbs_id_t;
typedef uint32_t sx_acl_pbilm_id_t;

/**
 * Placeholders for filter parameters
 */
typedef uint32_t sx_acl_port_range_filter_t;
typedef uint32_t sx_acl_filter_t;


#define SX_ACL_PBS_ID_INVALID        (0xFFFFFFFF)
#define KEY_HANDLE_MASK_OFFSET       16
#define FLEX_ACL_KEY_HANDLE_BIT_MASK (0xFF << KEY_HANDLE_MASK_OFFSET)
#define GET_NUM_OF_KEYS(key_handle) ((key_handle & FLEX_ACL_KEY_HANDLE_BIT_MASK) >> KEY_HANDLE_MASK_OFFSET)

#define SX_ACL_USER_ID_INVALID 0

#define FLEX_ACL_RULE_PRIORITY_MAX     16383
#define FLEX_ACL_RULE_PRIORITY_MIN     1
#define FLEX_ACL_INVALID_RULE_PRIORITY 0

/******************************
 *   DEFINITIONS
 *******************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_ACL_SEARCH_TYPE(F)                                        \
    F(SX_API_ACL_SEARCH_TYPE_SERIAL, "SX_API_ACL_SEARCH_TYPE_SERIAL")     \
    F(SX_API_ACL_SEARCH_TYPE_PARALLEL, "SX_API_ACL_SEARCH_TYPE_PARALLEL") \
    F(SX_API_ACL_SEARCH_TYPE_LAST, "SX_API_ACL_SEARCH_TYPE_LAST")

typedef enum {
    FOREACH_ACL_SEARCH_TYPE(SX_GENERATE_ENUM)
} sx_acl_search_type_t;

/**
 * sx_acl_params_t type is used to note ACL library
 * init parameters
 */
typedef struct {
    uint8_t              max_swid_id;
    uint8_t              max_acl_ingress_groups;
    uint8_t              max_acl_egress_groups;
    uint32_t             min_acl_rules;
    uint32_t             max_acl_rules;
    uint16_t             max_vlan_groups; /**< max_vlan_groups - Maximum number VLAN Groups for VLAN binding */
    uint16_t             max_rifs;
    sx_acl_search_type_t acl_search_type;
} sx_acl_params_t;

/**
 * sx_acl_dmac_type_t enumerated type is used to note
 * Destination MAC type used in ACL keys
 */
typedef enum {
    SX_ACL_DMAC_TYPE_UNICAST = 0,           /**< Unicast destination MAC  */
    SX_ACL_DMAC_TYPE_MULTICAST = 1,         /**< Multicast destination MAC  */
    SX_ACL_DMAC_TYPE_BROADCAST = 2          /**< Broadcast destination MAC  */
} sx_acl_dmac_type_t;

/**
 * sx_acl_action_learning_mode_t enumerated type is used
 * to change learn mode for a specific packet
 */
typedef enum {
    SX_ACL_ACTION_FDB_LEARNING_ENABLED = 0,       /**< Treat this packet as a regular packet */
    SX_ACL_ACTION_FDB_LEARNING_DISABLED = 1       /**< disable FDB learning for the packet */
} sx_acl_action_learning_mode_t;

/**
 * sx_acl_action_routing_mode_t enumerated type is used
 * to let a packet bypass the router module.
 */
typedef enum {
    SX_ACL_ACTION_ROUTING_ENABLED = 0,            /**< Treat this packet as a regular packet */
    SX_ACL_ACTION_ROUTING_DISABLED = 1            /**< disable IP routing for the packet */
} sx_acl_action_routing_mode_t;

/**
 * sx_acl_dmac_type_t enumerated type is used to note
 * Vlan type used in ACL keys
 */
typedef enum {
    SX_ACL_VLAN_TYPE_UNTAGGED = 0,          /**< Packet is untagged  */
    SX_ACL_VLAN_TYPE_TAGGED = 2             /**< Packet has 802.1Q vlan tag  */
} sx_acl_vlan_type_t;


/**
 * sx_acl_key_type_t enumerated type is used to note key type
 * used in ACL region block
 */
typedef enum {
    SX_ACL_KEY_TYPE_IPV4_FULL = 0,          /**< Key with IPv4 fields  */
    SX_ACL_KEY_TYPE_IPV6_FULL = 1,          /**< Key with IPv6 fields  */
    SX_ACL_KEY_TYPE_MAC_FULL = 2,           /**< Key with MAC fields   */
    SX_ACL_KEY_TYPE_MAC_IPV4_FULL = 3,      /**< Key with IPv4 and MAC fields */
    SX_ACL_KEY_TYPE_FCOE_FULL = 4,          /**< Key with FCoE fields */
    SX_ACL_KEY_TYPE_MAC_SHORT = 5,          /**< Key with short MAC fields   */
    SX_ACL_KEY_TYPE_MAX = SX_ACL_KEY_TYPE_MAC_SHORT,
    SX_ACL_KEY_TYPE_LAST
} sx_acl_key_type_t;


/**
 * sx_acl_type_t enumerated type is used to note ACL types
 * used for ACL creation
 */
typedef enum sx_acl_type {
    SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC = 0,          /**< ACL type for all packet types */
    SX_ACL_TYPE_PACKET_TYPES_SENSITIVE = 1,         /**< ACL type with bound ACL regions per packet type */
    SX_ACL_TYPE_MAX = SX_ACL_TYPE_PACKET_TYPES_SENSITIVE,
    SX_ACL_TYPE_LAST
} sx_acl_type_t;

/**
 * sx_acl_region_packet_type_t enumerated type is used to note
 * ACL region packet types for packet type sensitive ACLs.
 */
typedef enum {
    SX_ACL_REGION_PKT_TYPE_IPV4 = 0,                /**< ACL region packet type IPv4  */
    SX_ACL_REGION_PKT_TYPE_IPV6 = 1,                /**< ACL region packet type IPv6  */
    SX_ACL_REGION_PKT_TYPE_NON_IP = 2,              /**< ACL region packet type reserved  */
    SX_ACL_REGION_PKT_TYPE_MAX = SX_ACL_REGION_PKT_TYPE_NON_IP,
    SX_ACL_REGION_PKT_TYPE_LAST
} sx_acl_region_packet_type_t;

typedef struct sx_acl_packet_agnostic_regions {
    sx_acl_region_id_t region;
} sx_acl_packet_agnostic_regions_t;

typedef struct sx_acl_packet_sensitive_regions {
    sx_acl_region_id_t non_ip_region;
    sx_acl_region_id_t ipv4_region;
    sx_acl_region_id_t ipv6_region;
} sx_acl_packet_sensitive_regions_t;

/**
 * sx_acl_region_group_t structure is used to note
 * ACL region group for all ACL types.
 */
typedef struct sx_acl_region_group {
    sx_acl_type_t acl_type;
    union {
        sx_acl_packet_agnostic_regions_t  acl_packet_agnostic;
        sx_acl_packet_sensitive_regions_t acl_packet_sensitive;
    } regions;
} sx_acl_region_group_t;

/**
 * sx_acl_action_type_t enumerated type is used to note Action
 * type used in ACL block
 */
typedef enum sx_acl_action_type {
    SX_ACL_ACTION_TYPE_BASIC = 0,           /**< Basic action set  */
    SX_ACL_ACTION_TYPE_EXTENDED = 1,        /**< Extended action set  */
    SX_ACL_ACTION_TYPE_MAX = SX_ACL_ACTION_TYPE_EXTENDED,
    SX_ACL_ACTION_TYPE_LAST
} sx_acl_action_type_t;

/**
 * sx_acl_direction_t enumerated type is used to note ACL bind
 * direction
 */
typedef enum {
    SX_ACL_DIRECTION_INGRESS = 0,        /**< bind to ingress direction  */
    SX_ACL_DIRECTION_EGRESS = 1,         /**< bind to egress direction  */
    SX_ACL_DIRECTION_RIF_INGRESS = 2,    /**< SPC only */
    SX_ACL_DIRECTION_RIF_EGRESS = 3,     /**< SPC only */
    SX_ACL_DIRECTION_MAX = SX_ACL_DIRECTION_RIF_EGRESS,
    SX_ACL_DIRECTION_LAST
} sx_acl_direction_t;

/**
 * sx_acl_trap_action_t enumerated type is used to note
 * action trap action type
 */
typedef enum {
    SX_ACL_TRAP_ACTION_PERMIT = 0,           /**< Permit packets action  */
    SX_ACL_TRAP_ACTION_SOFT_DROP = 0x1,        /**< Soft-drop packets action  */
    SX_ACL_TRAP_ACTION_TRAP = 0x2,             /**< Trap packets action, trap group and trap ID should be stated  */
    SX_ACL_TRAP_ACTION_DROP_TRAP = 0x3,        /**< Trap & soft drop packets action  */
    SX_ACL_TRAP_ACTION_DENY = 0x4,              /**< Deny packets action  */
    SX_ACL_TRAP_ACTION_LAST
} sx_acl_trap_action_t;

typedef struct sx_acl_trap_info {
    uint8_t  trap_group;                  /**< trap group to use when trapping to CPU  */
    uint16_t trap_id;                     /**< trap ID to be reported to CPU: 0x2C9 - 0x1EF */
} sx_acl_trap_info_t;

/**
 * sx_acl_vlan_prio_action_t enumerated type is used to note
 * action vlan and priority action type
 */
typedef enum {
    SX_ACL_VLAN_PRIO_ACTION_NOP = 0,                                    /**< No action is done per VID and priority */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_ETCLASS_KEEP_RPRIO = 0x01,          /**< egress tclass will be replaced  (egress only) */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_RPRIO_KEEP_ETCLASS = 0x02,          /**< regenerated priority value will be replaced (egress only) */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_ETCLASS_RPRIO = 0x03,               /**< egress tclass and regenerated priority value will be replaced (egress only) */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_PRIO = 0x04,                        /**< priority value will be replaced */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_STCLASS = 0x06,                     /**< replace the stacking tclass with stclass */
    SX_ACL_VLAN_PRIO_ACTION_PUSH_VID_KEEP_PRIO = 0x08,                  /**< VID is pushed, priority is kept */
    SX_ACL_VLAN_PRIO_ACTION_PUSH_VID_PRIO = 0x0c,                       /**< VID and priority are pushed to packet*/
    SX_ACL_VLAN_PRIO_ACTION_POP_VID_PRIO = 0x10,                        /**< VID and priority popped */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_VID_KEEP_PRIO = 0x18,               /**< VID is replaced, priority is kept */
    SX_ACL_VLAN_PRIO_ACTION_REPLACE_VID_PRIO = 0x1c,                    /**< VID and priority are replaced */
    SX_ACL_VLAN_PRIO_ACTION_FWD_BY_VID = 0x20,                          /**< Forward by vid (packet not modified, ingress ACL only) */
} sx_acl_vlan_prio_action_t;

/**
 * sx_acl_port_range_direction_t enumerated type is used to note
 * port range direction type
 */
typedef enum {
    SX_ACL_PORT_DIRECTION_SOURCE = 0,   /**< Apply port range to source L4 ports  */
    SX_ACL_PORT_DIRECTION_DESTINATION,  /**< Apply port range to destination L4 ports  */
    SX_ACL_PORT_DIRECTION_BOTH,         /**< Apply port range to source and destination L4 ports  */
    SX_ACL_PORT_DIRECTION_MAX = SX_ACL_PORT_DIRECTION_BOTH,
} sx_acl_port_range_direction_t;

/**
 * sx_acl_port_range_ip_header_t
 */

typedef enum {
    SX_ACL_PORT_RANGE_IP_HEADER_OUTER = 0,    /**< Apply port range to outer IP header */
    SX_ACL_PORT_RANGE_IP_HEADER_INNER,        /**< Apply port range to inner IP header  */
    SX_ACL_PORT_RANGE_IP_HEADER_BOTH,         /**< Apply port range both outer and inner IP headers. Device supported : Spectrum. */
    SX_ACL_PORT_RANGE_IP_HEADER_MAX = SX_ACL_PORT_RANGE_IP_HEADER_BOTH,
} sx_acl_port_range_ip_header_t;

/**
 * sx_acl_port_range_entry_t struct is used when setting
 * ACL layer 4 port range entry. Match is defined when
 * port_range_min <= port <= port_range_max
 */
typedef struct {
    uint16_t                      port_range_min;   /**< Minimum port range for comparison  */
    uint16_t                      port_range_max;   /**< Maximum port range for comparison  */
    sx_acl_port_range_direction_t port_range_direction;      /**< Source/Destination/Both  */
    sx_acl_port_range_ip_header_t port_range_ip_header;      /**< outer/inner/both. Device supported : Spectrum. */
    boolean_t                     port_range_ip_length;      /* Device supported : Spectrum. When set the range_min and range_max applies to ip length field and not to l4 port */
} sx_acl_port_range_entry_t;

typedef enum {
    ACL_EXTRACTION_POINT_TYPE_NONE,
    ACL_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE,
    ACL_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_IPV4_START_OF_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_ARP_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_IPV6_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_IPV6_START_OF_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_MPLS_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_MPLS_START_OF_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_GRE_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_UDP_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_INNER_L2_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_INNER_L2_ETHER_TYPE,
    ACL_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_HEADER,
    ACL_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD,
    ACL_EXTRACTION_POINT_TYPE_LAST,
} acl_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_l2_extraction_point_type_e defines L2 extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_L2_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER = ACL_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE = ACL_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_L2_LAST,
} sx_acl_custom_bytes_l2_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_ipv4_extraction_point_type_e defines IPv4 extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV4_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER = ACL_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV4_START_OF_PAYLOAD = ACL_EXTRACTION_POINT_TYPE_IPV4_START_OF_PAYLOAD,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV4_LAST,
} sx_acl_custom_bytes_ipv4_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_ipv6_extraction_point_type_e defines IPv6 extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV6_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV6_START_OF_HEADER = ACL_EXTRACTION_POINT_TYPE_IPV6_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV6_START_OF_PAYLOAD = ACL_EXTRACTION_POINT_TYPE_IPV6_START_OF_PAYLOAD,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_IPV6_LAST,
} sx_acl_custom_bytes_ipv6_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_arp_extraction_point_type_e defines ARP extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_ARP_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_ARP_START_OF_HEADER = ACL_EXTRACTION_POINT_TYPE_ARP_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_ARP_LAST,
} sx_acl_custom_bytes_arp_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_mpls_extraction_point_type_e defines MPLS extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_MPLS_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_MPLS_START_OF_HEADER = ACL_EXTRACTION_POINT_TYPE_MPLS_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_MPLS_START_OF_PAYLOAD = ACL_EXTRACTION_POINT_TYPE_MPLS_START_OF_PAYLOAD,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_MPLS_LAST,
} sx_acl_custom_bytes_mpls_extraction_point_type_t;


/**
 * sx_acl_custom_bytes_gre_extraction_point_type_e defines GRE extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_GRE_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_GRE_PAYLOAD = ACL_EXTRACTION_POINT_TYPE_GRE_PAYLOAD,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_GRE_LAST,
} sx_acl_custom_bytes_gre_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_udp_extraction_point_type_e defines UDP extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_UDP_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_UDP_PAYLOAD = ACL_EXTRACTION_POINT_TYPE_UDP_PAYLOAD,
} sx_acl_custom_bytes_udp_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_inner_l2_extraction_point_type_e defines INNER L2 extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_L2_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_L2_START_OF_HEADER =
        ACL_EXTRACTION_POINT_TYPE_INNER_L2_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_L2_ETHER_TYPE = ACL_EXTRACTION_POINT_TYPE_INNER_L2_ETHER_TYPE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_L2_LAST,
} sx_acl_custom_bytes_inner_l2_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_inner_ipv4_extraction_point_type_e defines INNER IPv4 extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV4_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_HEADER =
        ACL_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_PAYLOAD =
        ACL_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_PAYLOAD,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV4_LAST,
} sx_acl_custom_bytes_inner_ipv4_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_inner_ipv6_extraction_point_type_e defines INNER IPv6 extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV6_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_HEADER =
        ACL_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_HEADER,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_PAYLOAD =
        ACL_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_PAYLOAD,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_IPV6_LAST,
} sx_acl_custom_bytes_inner_ipv6_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_inner_udp_extraction_point_type_e defines INNER UDP extraction point types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_UDP_NONE = ACL_EXTRACTION_POINT_TYPE_NONE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD = ACL_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_POINT_TYPE_INNER_UDP_LAST,
} sx_acl_custom_bytes_inner_udp_extraction_point_type_t;

/**
 * sx_acl_custom_bytes_extraction_group_type_e defines extraction point group types
 */
typedef enum {
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_L2,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_L3,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_L4,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_MPLS,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_GRE,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_INNER_L2,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_INNER_L3,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_INNER_L4,
    SX_ACL_CUSTOM_BYTES_EXTRACTION_GROUP_LAST,
} sx_acl_custom_bytes_extraction_group_type_t;

/**
 * The common extraction point structure
 * TODO: move all the lower extraction points to work with single format
 */
typedef struct sx_acl_custom_bytes_extraction_point {
    acl_extraction_point_type_t  extraction_point_type;
    sx_acl_custom_bytes_offset_t offset;
} sx_acl_custom_bytes_extraction_point_info_t;

/**
 * sx_acl_custom_bytes_extraction_l2_t defines L2 extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_l2 {
    sx_acl_custom_bytes_l2_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                   offset;
} sx_acl_custom_bytes_extraction_l2_t;

/**
 * sx_acl_custom_bytes_extraction_l2_group_t defines L2 extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_l2_group {
    sx_acl_custom_bytes_extraction_l2_t extraction_l2;
} sx_acl_custom_bytes_extraction_l2_group_t;

/**
 * sx_acl_custom_bytes_extraction_ipv4_t defines IPv4 extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_ipv4 {
    sx_acl_custom_bytes_ipv4_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                     offset;
} sx_acl_custom_bytes_extraction_ipv4_t;

/**
 * sx_acl_custom_bytes_extraction_ipv6_t defines IPv6 extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_ipv6 {
    sx_acl_custom_bytes_ipv6_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                     offset;
} sx_acl_custom_bytes_extraction_ipv6_t;

/**
 * sx_acl_custom_bytes_extraction_arp_t defines ARP extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_arp {
    sx_acl_custom_bytes_arp_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                    offset;
} sx_acl_custom_bytes_extraction_arp_t;


/**
 * sx_acl_custom_bytes_extraction_l3_group_t defines L3 extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_l3_group {
    sx_acl_custom_bytes_extraction_ipv4_t extraction_ipv4;
    sx_acl_custom_bytes_extraction_ipv6_t extraction_ipv6;
    sx_acl_custom_bytes_extraction_arp_t  extraction_arp;
} sx_acl_custom_bytes_extraction_l3_group_t;

/**
 * sx_acl_custom_bytes_extraction_udp_t defines UDP extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_udp {
    sx_acl_custom_bytes_udp_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                    offset;
} sx_acl_custom_bytes_extraction_udp_t;

/**
 * sx_acl_custom_bytes_extraction_l4_group_t defines L4 extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_l4_group {
    sx_acl_custom_bytes_extraction_udp_t extraction_udp;
} sx_acl_custom_bytes_extraction_l4_group_t;

/**
 * sx_acl_custom_bytes_extraction_mpls_t defines MPLS extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_mpls {
    sx_acl_custom_bytes_mpls_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                     offset;
} sx_acl_custom_bytes_extraction_mpls_t;

/**
 * sx_acl_custom_bytes_extraction_mpls_group_t defines MPLS extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_mpls_group {
    sx_acl_custom_bytes_extraction_mpls_t custom_bytes_extraction_mpls;
} sx_acl_custom_bytes_extraction_mpls_group_t;

/**
 * sx_acl_custom_bytes_extraction_gre_t defines GRE extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_gre {
    sx_acl_custom_bytes_gre_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                    offset;
} sx_acl_custom_bytes_extraction_gre_t;

/**
 * sx_acl_custom_bytes_extraction_gre_group_t defines GRE extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_gre_group {
    sx_acl_custom_bytes_extraction_gre_t custom_bytes_extraction_gre;
} sx_acl_custom_bytes_extraction_gre_group_t;

/**
 * sx_acl_custom_bytes_extraction_inner_l2_t defines INNER L2 extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_inner_l2 {
    sx_acl_custom_bytes_inner_l2_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                         offset;
} sx_acl_custom_bytes_extraction_inner_l2_t;

/**
 * sx_acl_custom_bytes_extraction_inner_l2_group_t defines INNER L2 extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_inner_l2_group {
    sx_acl_custom_bytes_extraction_inner_l2_t custom_bytes_extraction_inner_l2;
} sx_acl_custom_bytes_extraction_inner_l2_group_t;

/**
 * sx_acl_custom_bytes_extraction_inner_ipv4_t defines INNER IPv4 extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_inner_ipv4 {
    sx_acl_custom_bytes_inner_ipv4_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                           offset;
} sx_acl_custom_bytes_extraction_inner_ipv4_t;

/**
 * sx_acl_custom_bytes_extraction_inner_ipv6_t defines INNER IPv6 extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_inner_ipv6 {
    sx_acl_custom_bytes_inner_ipv6_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                           offset;
} sx_acl_custom_bytes_extraction_inner_ipv6_t;

/**
 * sx_acl_custom_bytes_extraction_inner_l3_group_t defines INNER L3 extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_inner_l3_group {
    sx_acl_custom_bytes_extraction_inner_ipv4_t extraction_inner_ipv4;
    sx_acl_custom_bytes_extraction_inner_ipv6_t extraction_inner_ipv6;
} sx_acl_custom_bytes_extraction_inner_l3_group_t;

/**
 * sx_acl_custom_bytes_extraction_inner_udp_t defines INNER UDP extraction point parameters
 */
typedef struct sx_acl_custom_bytes_extraction_inner_udp {
    sx_acl_custom_bytes_inner_udp_extraction_point_type_t extraction_point_type;
    sx_acl_custom_bytes_offset_t                          offset;
} sx_acl_custom_bytes_extraction_inner_udp_t;

/**
 * sx_acl_custom_bytes_extraction_inner_l4_group_t defines INNER L4 extraction point group
 */
typedef struct sx_acl_custom_bytes_extraction_inner_l4_group {
    sx_acl_custom_bytes_extraction_inner_udp_t extraction_inner_udp;
} sx_acl_custom_bytes_extraction_inner_l4_group_t;

/**
 * sx_acl_custom_bytes_extraction_point_t defines one single extraction point
 */
typedef struct {
    sx_acl_custom_bytes_extraction_group_type_t extraction_group_type;
    union {
        sx_acl_custom_bytes_extraction_l2_group_t       extraction_l2_group;
        sx_acl_custom_bytes_extraction_l3_group_t       extraction_l3_group;
        sx_acl_custom_bytes_extraction_l4_group_t       extraction_l4_group;
        sx_acl_custom_bytes_extraction_mpls_group_t     extraction_mpls_group;
        sx_acl_custom_bytes_extraction_gre_group_t      extraction_gre_group;
        sx_acl_custom_bytes_extraction_inner_l2_group_t extraction_inner_l2_group;
        sx_acl_custom_bytes_extraction_inner_l3_group_t extraction_inner_l3_group;
        sx_acl_custom_bytes_extraction_inner_l4_group_t extraction_inner_l4_group;
    } params;
} sx_acl_custom_bytes_extraction_point_t;

/**
 * sx_acl_custom_bytes_set_attributes_t defines the attributes of the custom bytes set
 */
typedef struct {
    uint32_t                               extraction_points_count;
    sx_acl_custom_bytes_extraction_point_t extraction_point;
} sx_acl_custom_bytes_set_attributes_t;

/**
 * sx_acl_pbs_entry_type_t enumerated type is used to note PBS
 * entry type
 */
typedef enum {
    SX_ACL_PBS_ENTRY_TYPE_UNICAST = 0,      /**< Policy-based switching: unicast entry (performs
                                             * learning and security; only one action per rule is effective) */
    SX_ACL_PBS_ENTRY_TYPE_ROUTING,          /**< Policy-based switching: forward packet to router */
    SX_ACL_PBS_ENTRY_TYPE_MULTICAST,        /**< Policy-based switching: multicast entry (performs
                                             *  learning and security; one action per rule is effective) */
    SX_ACL_PBS_ENTRY_TYPE_FCF,              /**< Policy-based switching: forward to FCF block */
    SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST,   /**< Openflow Output action: unicast entry - Spectrum, Spectrum2
                                             *  (duplicates the packet and sends it immediately; the original
                                             *  packet continues; multiple actions per rule are supported). */
    SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST, /**< Openflow Output action: multicast entry - Spectrum, Spectrum2
                                             *  (duplicates the packet and sends it immediately; the original
                                             *  packet continues; multiple actions per rule are supported). */
    SX_ACL_PBS_ENTRY_TYPE_MAX = SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST,
    SX_ACL_PBS_ENTRY_TYPE_LAST
} sx_acl_pbs_entry_type_t;


/**
 * sx_acl_pbs_entry_t struct type is used to note PBS entry
 * fields
 */
typedef struct {
    sx_acl_pbs_entry_type_t entry_type;         /**< entry type  */
    uint32_t                port_num;           /**< Port number, user is required to allocate enough memory for log_ports  */
    sx_port_id_t          * log_ports;          /**< Variable-length ports list, it's size according to port_num */
} sx_acl_pbs_entry_t;

/**
 * sx_acl_pbilm_entry_t struct type is used to note PBILM entry fields
 */
typedef struct {
    sx_mpls_in_segment_params_t pbilm_params;
} sx_acl_pbilm_entry_t;

/**
 * sx_acl_rule_ipv4_ipv6_full_key_t struct type is used to
 * note ipv4 and ipv6 full key fields
 */
typedef struct {
    uint32_t         dst_ip[4];      /**< Destination IP, IPv6 or IPv4. For ARP, Target protocol address */
    uint32_t         src_ip[4];      /**< Source IP, IPv6 or IPv4. For ARP, Sender protocol address */
    uint16_t         src_l4_port;    /**< source L4 port - for ICMP contains type[7:0], code{7:0] */
    uint16_t         dst_l4_port;    /**< Destination L4 port  */
    uint8_t          ttl;            /**< TTL field  */
    uint8_t          tcp_flags;      /**< TCP flags  */
    uint8_t          ip_proto;       /**< IP next protocol  */
    uint8_t          ip_tos;         /**< IP Type of Service  */
    uint8_t          ip_ok;          /**< IP Header is OK bit flag  */
    uint8_t          l4_ok;          /**< Layer 4 header is OK bit flag  */
    uint8_t          is_ipv4;        /**< Packet is IPv4 bit flag */
    uint8_t          is_ipv6;        /**< Packet is IPv6 bit flag */
    uint8_t          ip_opt;         /**< Packet contains IPv4 options bit flag  */
    uint8_t          ip_frg;         /**< IP non-first fragment bit flag  */
    uint8_t          tcp;            /**< Packet is TCP bit flag  */
    uint8_t          udp;            /**< Packet is UDP bit flag  */
    uint8_t          arp;            /**< Packet is ARP/Neighbor discovery packet bit flag  */
    uint8_t          ipv6_ext;       /**< IPv6 extended headers present  */
    sx_port_log_id_t dst_port;       /**< Destination port. MUST be 0 for Ingress ACL */
    sx_port_log_id_t src_port;       /**< Source port / LAG ID  */
    boolean_t        port_range_apply_arr[RM_API_ACL_PORT_RANGES_MAX]; /**< Which port ranges to use - logical AND between them  */
    uint32_t         flow_label;     /**< IPv6 flow label  */
} sx_acl_rule_ipv4_ipv6_full_key_t;

/**
 * sx_acl_rule_mac_full_key_t struct type is used to note
 * mac full key fields
 */
typedef struct {
    sx_mac_addr_t      dmac;            /**< Destination MAC address */
    sx_mac_addr_t      smac;            /**< Source MAC address */
    uint16_t           ethertype;       /**< L2 Ethertype */
    uint8_t            priority;        /**< Packet priority from tag or default priority */
    uint8_t            cfi;             /**< 802.1Q tag CFI field */
    uint16_t           vid;             /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_dmac_type_t dmac_type;       /**< Destination MAC address type */
    uint8_t            vlan_tagged;     /**< Packet was received with Vlan tag (Prio-tagged are considered untagged) */
    uint8_t            vlan_valid;      /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    sx_port_log_id_t   dst_port;        /**< Destination port. MUST be 0 for Ingress ACL */
    sx_port_log_id_t   src_port;        /**< Source port / LAG ID  */
} sx_acl_rule_mac_full_key_t;

/**
 * sx_acl_rule_mac_short_key_t struct type is used to note
 * mac short key fields (18 bytes)
 */
typedef struct {
    sx_mac_addr_t      dmac;            /**< Destination MAC address */
    sx_mac_addr_t      smac;            /**< Source MAC address */
    uint8_t            priority;        /**< Packet priority from tag or default priority */
    uint8_t            cfi;             /**< 802.1Q tag CFI field */
    uint16_t           vid;             /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_dmac_type_t dmac_type;       /**< Destination MAC address type */
    uint8_t            vlan_tagged;     /**< Packet was received with Vlan tag (Prio-tagged are considered untagged) */
    uint8_t            vlan_valid;      /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    sx_port_log_id_t   src_port;        /**< Source port / LAG ID  */
} sx_acl_rule_mac_short_key_t;

/**
 * sx_acl_rule_mac_ipv4_full_key_t struct type is used to
 * note mac IPv4 full key fields
 */
typedef struct {
    sx_mac_addr_t      dmac;            /**< Destination MAC address */
    sx_mac_addr_t      smac;            /**< Source MAC address */
    uint16_t           ethertype;       /**< L2 Ethertype */
    uint8_t            priority;        /**< Packet priority from tag or default priority */
    uint16_t           vid;             /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_vlan_type_t vlan_type;       /**< Vlan type */
    uint8_t            vlan_valid;      /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    uint32_t           dst_ip;          /**< Destination IPv4  */
    uint32_t           src_ip;          /**< Source IPv4  */
    uint16_t           src_l4_port;     /**< source L4 port - for ICMP contains type[7:0], code{7:0] */
    uint16_t           dst_l4_port;     /**< Destination L4 port  */
    uint8_t            ip_proto;        /**< IP next protocol  */
    uint8_t            ip_tos;          /**< IP Type of Service  */
    uint8_t            ip_ok;           /**< IP Header is OK bit flag  */
    uint8_t            l4_ok;           /**< Layer 4 header is OK bit flag  */
    uint8_t            is_ipv4;         /**< Packet is IPv4 bit flag */
    uint8_t            ip_opt;          /**< Packet contains IPv4 options bit flag  */
    uint8_t            ip_frg;          /**< IP non-first fragment bit flag  */
    sx_port_log_id_t   src_port;        /**< Source port / LAG ID  */
} sx_acl_rule_mac_ipv4_full_key_t;


/**
 * sx_acl_rule_fcoe_full_key_t struct type is used to
 * note FCoE full key fields
 */
typedef struct {
    sx_mac_addr_t      dmac;          /**< Destination MAC address */
    sx_mac_addr_t      smac;          /**< Source MAC address */
    uint8_t            priority;      /**< Packet priority from tag or default priority */
    uint16_t           vid;           /**< Vlan ID from 802.1Q tag or default Vlan ID */
    sx_acl_vlan_type_t vlan_type;     /**< Vlan type */
    uint8_t            vlan_valid;    /**< Packet has a valid Vlan at this point (assigned or came with vlan, not popped)*/
    sx_fc_addr_t       d_id;          /**< Destination ID  */
    sx_fc_addr_t       s_id;          /**< Source ID  */
    uint16_t           ox_id;         /**< Originator eXchange ID  */
    uint16_t           rx_id;         /**< Responder eXchange ID  */
    uint8_t            is_fc;         /**< The packet is a fibre channel packet */
    uint8_t            r_ctl;         /**< Routing control flags  */
    uint8_t            type;          /**< TYPE of FC-4 upper layer protocol  */
    sx_port_log_id_t   src_port;      /**< Source port / LAG ID  */
} sx_acl_rule_fcoe_full_key_t;

/**
 * sx_acl_keys_t union contains set of possible keys to be used
 * within the rule
 */
typedef union {
    sx_acl_rule_ipv4_ipv6_full_key_t ipv4_ipv6_full;    /**< Use when IPv4 or IPv6 is the ACL key type  */
    sx_acl_rule_mac_full_key_t       mac_full;          /**< Use when MAC full is the ACL key type  */
    sx_acl_rule_mac_ipv4_full_key_t  mac_ipv4_full;     /**< Use when MAC and IPv4 full is the ACL key type */
    sx_acl_rule_mac_short_key_t      mac_short;         /**< Use for 18 byte key, (no Ethernet type or dest system port) */
    sx_acl_rule_fcoe_full_key_t      fcoe_full;         /**< Use when FCoE full is the ACL key type */
} sx_acl_keys_t;


/**
 * sx_acl_rule_key_t struct type is used to note mac IPv4 full
 * key fields
 */
typedef struct {
    sx_acl_key_type_t type;          /**< Key type used  */
    sx_acl_keys_t     fields;        /**< Key Fields  */
} sx_acl_rule_key_t;

/**
 * sx_acl_basic_action_set_t structure is used to note
 * basic action fields
 */
typedef struct sx_acl_basic_action_set {
    sx_acl_trap_action_t          trap_action;          /**< trap action  */
    uint8_t                       trap_group;           /**< trap group to use when trapping to CPU  */
    uint16_t                      trap_id;              /**< trap ID to be reported to CPU  */
    sx_acl_vlan_prio_action_t     vlan_prio_action;     /**< Operation to perform on VLAN, priority and TClass  */
    uint16_t                      vid;                  /**< VLAN to be used in accordance with vlan_prio_action  */
    uint8_t                       priority;             /**< priority to be used in accordance with vlan_prio_action  */
    uint8_t                       etclass;              /**< Egress TClass to be used in accordance with vlan_prio_action  */
    uint8_t                       stclass;              /**< Stacking TClass to be used in accordance with vlan_prio_action  */
    uint8_t                       terminate_lookup;     /**< When set to true, terminate lookup on this action  */
    sx_flow_counter_id_t          flow_counter_id;      /**< Counter ID or SX_FLOW_COUNTER_ID_INVALID */
    sx_policer_id_t               policer_id;           /**< Policer ID or SX_POLICER_ID_INVALID */
    sx_acl_action_routing_mode_t  no_ip_routing;        /**< disable IP routing for the packet */
    sx_acl_action_learning_mode_t dont_learn;           /**< disable FDB learning for the packet */
} sx_acl_basic_action_set_t;

/**
 * sx_acl_extended_action_set_t structure is used to note
 * extended action fields
 */
typedef struct sx_acl_extended_action_set {
    sx_acl_pbs_id_t pbs_id;                             /**< Policy Based Switching ID or SX_ACL_PBS_ID_INVALID */
} sx_acl_extended_action_set_t;

/**
 * sx_acl_action_set_t structure is used to note ACL action fields
 */
typedef struct sx_acl_action_set {
    sx_acl_action_type_t         action_type;           /**< Action type  */
    sx_acl_basic_action_set_t    basic_action;          /**< Basic action fields  */
    sx_acl_extended_action_set_t extended_action;       /**< Extended action fields  */
} sx_acl_action_set_t;

/**
 * sx_acl_rule_t struct type is used to note an ACL rule
 * combined of the triplet {key,mask,action}
 * CLR_SX_ACL_RULE_ACTION must be used before setting an ACL rule
 */
typedef struct {
    sx_acl_rule_offset_t offset;        /**<  rule's offset within ACL table */
    uint8_t              valid;         /**<  rule activated in HW  */
    sx_acl_rule_key_t    key;           /**<  Key type and fields used for this rule  */
    sx_acl_rule_key_t    mask;          /**<  Masking of fields in the key for this rule  */
    sx_acl_action_set_t  action;        /**<  Action set used for this rule  */
} sx_acl_rule_t;

/**
 * This Macro clears sx_acl_rule_t action to be a NOP
 */
#define CLR_SX_ACL_RULE_ACTION(rule)                                          \
    memset(&rule.action, 0, sizeof(rule.action));                             \
    rule.action.action_type = SX_ACL_ACTION_TYPE_BASIC;                       \
    rule.action.basic_action.terminate_lookup = FALSE;                        \
    rule.action.basic_action.priority = 0;                                    \
    rule.action.basic_action.trap_action = SX_ACL_TRAP_ACTION_PERMIT;         \
    rule.action.basic_action.vlan_prio_action = SX_ACL_VLAN_PRIO_ACTION_NOP;  \
    rule.action.basic_action.flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;    \
    rule.action.basic_action.policer_id = SX_POLICER_ID_INVALID;              \
    rule.action.basic_action.no_ip_routing = SX_ACL_ACTION_ROUTING_ENABLED;   \
    rule.action.basic_action.dont_learn = SX_ACL_ACTION_FDB_LEARNING_ENABLED; \
    rule.action.extended_action.pbs_id = SX_ACL_PBS_ID_INVALID;

#define CLR_SX_ACL_RULE_KEY(key_type, rule) \
    rule.key.type = key_type;               \
    memset(&rule.key.fields, 0, sizeof(rule.key.fields));

#define CLR_SX_ACL_RULE_MASK(key_type, rule) \
    rule.mask.type = key_type;               \
    memset(&rule.mask.fields, 0, sizeof(rule.mask.fields));


/**
 * sx_acl_bound_info_t struct type is used to note an ACL rule
 *
 */
typedef struct sx_acl_bound_info {
    sx_acl_region_id_t   acl_region_id;
    sx_acl_rule_offset_t acl_rule_offset;
} sx_acl_bound_info_t;

typedef enum {
    SX_API_FLEX_ACL_SEARCH_TYPE_SERIAL,
    SX_API_FLEX_ACL_SEARCH_TYPE_PARALLEL,
    SX_API_FLEX_ACL_SEARCH_TYPE_LAST,
} sx_flex_acl_search_type_t;

typedef enum {
    SX_ACL_L2_DMAC_TYPE_MULTICAST = 0,
    SX_ACL_L2_DMAC_TYPE_BROADCAST = 1,
    SX_ACL_L2_DMAC_TYPE_UNICAST = 2,
    SX_ACL_L2_DMAC_TYPE_MIN = SX_ACL_L2_DMAC_TYPE_MULTICAST,
    SX_ACL_L2_DMAC_TYPE_MAX = SX_ACL_L2_DMAC_TYPE_UNICAST,
    SX_ACL_L2_DMAC_TYPE_LAST,
} sx_flex_acl_l2_dmac_type_t;

typedef enum {
    SX_ACL_L3_TYPE_IPV4 = 0,
    SX_ACL_L3_TYPE_IPV6 = 1,
    SX_ACL_L3_TYPE_ARP = 2,
    SX_ACL_L3_TYPE_OTHER = 3,
    SX_ACL_L3_TYPE_MIN = SX_ACL_L3_TYPE_IPV4,
    SX_ACL_L3_TYPE_MAX = SX_ACL_L3_TYPE_OTHER,
    SX_ACL_L3_TYPE_LAST,
} sx_flex_acl_l3_type_t;

typedef enum {
    SX_ACL_L4_TYPE_INVALID = 0,
    SX_ACL_L4_TYPE_TCP = 0x1 << 0,
        SX_ACL_L4_TYPE_UDP = 0x1 << 1,
        SX_ACL_L4_TYPE_TCP_UDP = SX_ACL_L4_TYPE_TCP | SX_ACL_L4_TYPE_UDP,
        SX_ACL_L4_TYPE_OTHER = 0x1 << 2,
        SX_ACL_L4_TYPE_MIN = SX_ACL_L4_TYPE_TCP,
        SX_ACL_L4_TYPE_MAX = SX_ACL_L4_TYPE_TCP | SX_ACL_L4_TYPE_UDP | SX_ACL_L4_TYPE_OTHER,
        SX_ACL_L4_TYPE_LAST,
} sx_flex_acl_l4_type_t;

typedef enum {
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_PUSH = 0,
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_POP,
    SX_ACL_FLEX_SET_VLAN_CMD_TYPE_LAST,
} sx_flex_acl_flex_action_set_vlan_type_t;

typedef enum {
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_UNIFORM = 0,
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_PIPE = 1,
    SX_ACL_FLEX_QINQ_TUNNEL_QOS_LAST,
} sx_flex_acl_flex_action_qinq_tunnel_qos_t;

typedef enum {
    SX_ACL_FLEX_COLOR_GREEN = 0,
    SX_ACL_FLEX_COLOR_YELLOW = 1,
    SX_ACL_FLEX_COLOR_RED = 2,
    SX_ACL_FLEX_COLOR_LAST,
} sx_flex_acl_flex_action_color_type_t;

typedef struct sx_flex_acl_qinq_tunnel_qos_pipe {
    sx_cos_pcp_t pcp;
    sx_cos_dei_t dei;
} sx_flex_acl_qinq_tunnel_qos_pipe_t;

/**
 * sx_flex_acl_flex_action_set_vlan_t is used to set vlan;
 */
typedef struct sx_flex_acl_flex_action_set_vlan {
    sx_flex_acl_flex_action_set_vlan_type_t   cmd;
    sx_vlan_id_t                              vlan_id;
    sx_flex_acl_flex_action_qinq_tunnel_qos_t qinq_tunnel_qos;
    union {
        sx_flex_acl_qinq_tunnel_qos_pipe_t pipe;
    } qinq_tunnel_qos_fields;
} sx_flex_acl_flex_action_set_vlan_t;

/**
 * sx_flex_acl_flex_action_set_vlan_t is used to set inner vlan id;
 */
typedef struct sx_flex_acl_flex_action_set_vlan_id {
    sx_vlan_id_t vlan_id;
} sx_flex_acl_flex_action_set_vlan_id_t;

/**
 *  sx_flex_acl_flex_action_set_vlan_prio_t is used to set inner vlan priority;
 */
typedef struct sx_flex_acl_flex_action_set_vlan_prio {
    sx_cos_pcp_t pcp;
    sx_cos_dei_t dei;
} sx_flex_acl_flex_action_set_vlan_prio_t;

/**
 * sx_flex_acl_trap_action_t enum  type is used to note an trap ACL flexible action
 */
typedef enum {
    SX_ACL_TRAP_ACTION_TYPE_TRAP = 0,
    SX_ACL_TRAP_ACTION_TYPE_DISCARD,
    SX_ACL_TRAP_ACTION_TYPE_SOFT_DISCARD,
    SX_ACL_TRAP_ACTION_TYPE_LAST,
} sx_flex_acl_trap_action_t;

typedef enum {
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD = 0,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT,
    SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST,
} sx_flex_acl_forward_action_t;

typedef enum {
    SX_ACL_PORT_LIST_MATCH_NEGATIVE = 0,     /* Match if packet is not received from this port */
    SX_ACL_PORT_LIST_MATCH_POSITIVE = 1,     /* Match if packet is received from this port */
    SX_ACL_PORT_LIST_MATCH_LAST,
} sx_acl_port_list_match_t;

/**
 * sx_acl_port_list_entry_t used do define port list key
 */
typedef struct sx_acl_port_list_entry {
    sx_port_log_id_t         log_port;
    sx_acl_port_list_match_t port_match;
} sx_acl_port_list_entry_t;


/**
 * sx_flex_acl_action_trap_t use to Control the packet CPU  copy
 */
typedef struct sx_flex_acl_action_trap {
    sx_flex_acl_trap_action_t action;
    sx_trap_id_t              trap_id;
} sx_flex_acl_action_trap_t;

/**
 * sx_flex_acl_action_trap_w_user_id_t use to control the packet CPU copy with user-defined value
 */
typedef struct sx_flex_acl_action_trap_w_user_id {
    sx_flex_acl_trap_action_t action;
    sx_trap_id_t              trap_id;
    uint32_t                  user_id;  /** Max value 2**20. Value 0 means - no user id */
} sx_flex_acl_action_trap_w_user_id_t;


/**
 * sx_flex_acl_flex_action_forward_t enum  type is used to note an Forward ACL flexible action
 */
typedef struct sx_acl_flex_action_forward {
    sx_flex_acl_forward_action_t action;
} sx_flex_acl_flex_action_forward_t;

/**
 * sx_flex_acl_flex_action_policer_t is used to note an policing ACL flexible action;
 */
typedef struct sx_acl_flex_action_policing {
    sx_policer_id_t policer_id;
} sx_flex_acl_flex_action_policer_t;

/**
 * sx_flex_acl_flex_action_counter_t is used to note an counting ACL flexible action;
 */
typedef struct sx_acl_flex_action_counting {
    sx_flow_counter_id_t counter_id;
} sx_flex_acl_flex_action_counter_t;


/**
 * sx_flex_acl_flex_action_mirror_t is used to note an mirror ACL flexible action;
 */
typedef struct sx_acl_flex_action_mirror {
    sx_span_session_id_t session_id;
} sx_flex_acl_flex_action_mirror_t;

/**
 * sx_flex_acl_flex_action_set_mac_t is used to set source mac;
 */
typedef struct sx_flex_acl_flex_action_set_mac {
    sx_mac_addr_t mac;
} sx_flex_acl_flex_action_set_mac_t;

/**
 * sx_flex_acl_flex_action_set_dscp_t is used to set dscp;
 */
typedef struct sx_flex_acl_flex_action_set_dscp {
    sx_cos_dscp_t dscp_val;
} sx_flex_acl_flex_action_set_dscp_t;

/**
 * sx_flex_acl_flex_action_set_color_t is used to set color;
 */
typedef struct sx_flex_acl_flex_action_set_color {
    sx_flex_acl_flex_action_color_type_t color_val;
} sx_flex_acl_flex_action_set_color_t;

/**
 * sx_flex_acl_flex_action_set_ecn_t is used to set ecn;
 */
typedef struct sx_flex_acl_flex_action_set_ecn {
    uint8_t ecn_val;
} sx_flex_acl_flex_action_set_ecn_t;

/**
 * sx_flex_acl_flex_action_set_user_token_t is used to set user token;
 */
typedef struct sx_flex_acl_flex_action_set_user_token {
    uint16_t user_token; /* Size : 12 bits */
    uint16_t mask; /* Size : 12 bits */
} sx_flex_acl_flex_action_set_user_token_t;
/**
 * sx_flex_acl_flex_action_set_tc_t is used to set tc;
 */
typedef struct sx_flex_acl_flex_action_set_tc {
    uint8_t tc_val;
} sx_flex_acl_flex_action_set_tc_t;

/**
 * sx_flex_acl_flex_action_dec_ttl_t is used to decrement ttl;
 */
typedef struct sx_flex_acl_flex_action_dec_ttl {
    uint8_t ttl_val;
} sx_flex_acl_flex_action_dec_ttl_t;

/**
 * sx_flex_acl_flex_action_set_ttl_t is used to set ttl;
 */
typedef struct sx_flex_acl_flex_action_set_ttl {
    uint8_t ttl_val;
} sx_flex_acl_flex_action_set_ttl_t;

/**
 * sx_flex_acl_flex_action_set_prio_t is used to set prio;
 */
typedef struct sx_flex_acl_flex_action_set_prio {
    sx_cos_priority_t prio_val;
} sx_flex_acl_flex_action_set_prio_t;

/**
 * sx_flex_acl_flex_action_set_bridge_t is used to set bridge;
 */
typedef struct sx_flex_acl_flex_action_set_bridge {
    sx_bridge_id_t bridge_id;
} sx_flex_acl_flex_action_set_bridge_t;

/**
 * sx_flex_acl_flex_action_set_vrid_t is used to set virtual router;
 */
typedef struct sx_flex_acl_flex_action_set_vrid {
    sx_router_id_t virtual_router;
} sx_flex_acl_flex_action_set_vrid_t;

/**
 * sx_flex_acl_flex_action_set_pbs_t is used to set pbs;
 */
typedef struct sx_flex_acl_flex_action_set_pbs {
    sx_acl_pbs_id_t pbs_id;
} sx_flex_acl_flex_action_set_pbs_t;

typedef enum sx_flex_acl_rpf_action {
    SX_ACL_RPF_ACTION_TYPE_DISABLED = 0,  /**< No RPF check */
    SX_ACL_RPF_ACTION_TYPE_DROP, /**< Drop if RPF check fails*/
    SX_ACL_RPF_ACTION_TYPE_TRAP, /**< Trap with RPF trap ID if RPF check fails */
    SX_ACL_RPF_ACTION_TYPE_LAST,
} sx_flex_acl_rpf_action_t;

typedef enum sx_flex_acl_flex_rpf_param_type {
    SX_ACL_FLEX_RPF_PARAM_TYPE_IRIF = 0,
    SX_ACL_FLEX_RPF_PARAM_TYPE_RPF_GROUP,
    SX_ACL_FLEX_RPF_PARAM_TYPE_LAST,
} sx_flex_acl_flex_rpf_param_type_t;

typedef struct sx_flex_acl_rpf_param {
    sx_flex_acl_flex_rpf_param_type_t rpf_param_type;
    union {
        sx_router_interface_t rpf_rif;
        sx_rpf_group_id_t     rpf_group;
    } rpf_param_value;
} sx_flex_acl_rpf_param_t;

/**
 * sx_flex_acl_flex_action_mc_route_t;
 */
typedef struct sx_flex_acl_flex_action_mc_route {
    sx_mc_container_id_t egress_mc_container;
} sx_flex_acl_flex_action_mc_route_t;

/**
 * sx_flex_acl_flex_action_rpf_t;
 */
typedef struct sx_flex_acl_flex_action_rpf {
    sx_flex_acl_rpf_action_t rpf_action;
    sx_flex_acl_rpf_param_t  rpf_param;  /**< Not applicable for SX_ACL_RPF_ACTION_TYPE_DISABLED */
} sx_flex_acl_flex_action_rpf_t;

/**
 * sx_flex_acl_flex_action_uc_route_ip_remote_t;
 */
typedef struct sx_flex_acl_flex_action_uc_route_ip_remote {
    sx_ecmp_id_t ecmp_id;
} sx_flex_acl_flex_action_uc_route_ip_remote_t;

/**
 * sx_flex_acl_flex_action_uc_route_ip_local_t;
 */
typedef struct sx_flex_acl_flex_action_uc_route_ip_local {
    sx_router_interface_t erif;
} sx_flex_acl_flex_action_uc_route_ip_local_t;

/**+
 * sx_flex_acl_flex_action_tunnel_decap_t;
 */
typedef struct sx_flex_acl_flex_action_uc_tunnel_decap {
    sx_tunnel_id_t tunnel_id;
} sx_flex_acl_flex_action_tunnel_decap_t;


/*
 * sx_flex_acl_flex_action_nve_tunnel_encap_t is used to set NVE Encap
 * parameters. Note that the action will fail if a valid Tunnel does not
 * exist. Additionally the user should ensure that a valid FID to VNI
 * mapping exists. If the mapping does not exist, the packet will be
 * encapsulated with a default VNI
 */
typedef struct sx_flex_acl_flex_action_nve_tunnel_encap {
    sx_ip_addr_t   underlay_dip;       /**< The IP of the Underlay Destination IP */
    sx_tunnel_id_t tunnel_id;         /**< The tunnel id for tunnel encapsulation */
} sx_flex_acl_flex_action_nve_tunnel_encap_t;

/**
 * sx_flex_acl_flex_action_nve_mc_tunnel_encap_t;
 */
typedef struct sx_flex_acl_flex_action_nve_mc_tunnel_encap {
    sx_mc_container_id_t mc_container_id;
} sx_flex_acl_flex_action_nve_mc_tunnel_encap_t;

/**
 * sx_flex_acl_flex_action_goto_cmd_t;
 */
typedef enum sx_flex_acl_flex_action_goto_cmd {
    SX_ACL_ACTION_GOTO_JUMP,
    SX_ACL_ACTION_GOTO_CALL,
    SX_ACL_ACTION_GOTO_BREAK,
    SX_ACL_ACTION_GOTO_TERMINATE,
    SX_ACL_ACTION_GOTO_LAST,
} sx_flex_acl_flex_action_goto_cmd_t;

/**
 * sx_flex_acl_flex_action_goto_t;
 */
typedef struct sx_flex_acl_flex_action_goto {
    sx_flex_acl_flex_action_goto_cmd_t goto_action_cmd;
    sx_acl_id_t                        acl_group_id;
} sx_flex_acl_flex_action_goto_t;

/**
 * sx_acl_flex_action_set_router_t;
 */
typedef struct sx_flex_acl_flex_action_set_router {
    sx_router_id_t vrid;
} sx_acl_flex_action_set_router_t;

/**
 * sx_acl_flex_action_mc_t;
 */
typedef struct sx_flex_acl_flex_action_mc {
    sx_mc_container_id_t mc_container_id;
} sx_acl_flex_action_mc_t;

/**
 * sx_acl_flex_action_uc_route_t;
 */
typedef struct sx_acl_flex_action_uc_route {
    sx_uc_route_type_e uc_route_type;  /* SX_UC_ROUTE_TYPE_NEXT_HOP - remote, SX_UC_ROUTE_TYPE_LOCAL = local */
    union {
        sx_router_interface_t local_egress_rif; /* Only valid for LOCAL route type*/
        sx_ecmp_id_t          ecmp_id; /* The ECMP container which specifies the set of next-hops. Only valid for NEXT_HOP route type.*/
    } uc_route_param;
} sx_acl_flex_action_uc_route_t;

/**
 * sx_acl_flex_action_rewrite_cmd_t;
 */
typedef enum sx_acl_flex_action_rewrite_cmd {
    SX_ACL_ACTION_REWRITE_ENABLE,
    SX_ACL_ACTION_REWRITE_DISABLE,
    SX_ACL_ACTION_REWRITE_LAST,
} sx_acl_flex_action_rewrite_cmd_t;

/**
 * sx_acl_flex_action_set_rewrite_t;
 */
typedef struct sx_acl_flex_action_set_rewrite {
    sx_acl_flex_action_rewrite_cmd_t set_rewrite_cmd;
} sx_acl_flex_action_set_rewrite_t;

/**
 * sx_acl_flex_action_port_filter_t;
 */
typedef struct sx_acl_flex_action_port_filter {
    sx_mc_container_id_t mc_container_id;
} sx_acl_flex_action_port_filter_t;

/**
 * sx_flex_acl_flex_action_set_exp_t is used to set mpls exp;
 */
typedef struct sx_flex_acl_flex_action_set_exp {
    sx_cos_exp_t exp_val;
} sx_flex_acl_flex_action_set_exp_t;

/**
 * sx_flex_acl_flex_action_set_pbilm_t is used to set pbilm;
 */
typedef struct sx_flex_acl_flex_action_set_pbilm {
    sx_acl_pbilm_id_t pbilm_id;
} sx_flex_acl_flex_action_set_pbilm_t;

/**
 * sx_flex_acl_flex_action_set_ip_addr_t is used to set ip address;
 */
typedef struct sx_flex_acl_flex_action_set_ip_addr {
    sx_ip_addr_t ip_addr;
} sx_flex_acl_flex_action_set_ip_addr_t;

/**
 * sx_flex_acl_flex_action_set_l4_port_t is used to set L4 port;
 */
typedef struct sx_flex_acl_flex_action_set_l4_port {
    uint16_t l4_port;
} sx_flex_acl_flex_action_set_l4_port_t;

/**
 * sx_flex_acl_mpls_labels_valid_bitmask_t values are bitmask that should be ORed
 * in order to specify which of the mpls labels should be checked for validity.
 */
typedef enum  {
    SX_ACL_MPLS_LABEL_ID_1_VALID_BIT = (0x1 << 0),
    SX_ACL_MPLS_LABEL_ID_2_VALID_BIT = (0x1 << 1),
    SX_ACL_MPLS_LABEL_ID_3_VALID_BIT = (0x1 << 2),
    SX_ACL_MPLS_LABEL_ID_4_VALID_BIT = (0x1 << 3),
    SX_ACL_MPLS_LABEL_ID_5_VALID_BIT = (0x1 << 4),
    SX_ACL_MPLS_LABEL_ID_6_VALID_BIT = (0x1 << 5),
} sx_flex_acl_mpls_labels_valid_bitmask_t;

/**
 * sx_flex_acl_action_hash_command_t type is used for ACL HASH action command field
 */
typedef enum {
    SX_ACL_ACTION_HASH_COMMAND_NONE = 0,
    SX_ACL_ACTION_HASH_COMMAND_SET = 1,
    SX_ACL_ACTION_HASH_COMMAND_XOR = 2,
    SX_ACL_ACTION_HASH_COMMAND_RANDOM = 3,
    SX_ACL_ACTION_HASH_COMMAND_COPY = 4,
    SX_ACL_ACTION_HASH_COMMAND_SWAP = 5,
    SX_ACL_ACTION_HASH_COMMAND_LAST,
} sx_flex_acl_action_hash_command_t;

/**
 * sx_flex_acl_action_hash_type_t type is used for ACL HASH action type field
 */
typedef enum {
    SX_ACL_ACTION_HASH_TYPE_LAG = 0,
    SX_ACL_ACTION_HASH_TYPE_ECMP = 1,
    SX_ACL_ACTION_HASH_TYPE_LAST,
} sx_flex_acl_action_hash_type_t;

/**
 * sx_flex_acl_action_hash_value_t type is used for ACL HASH action hash value
 */
typedef uint16_t sx_flex_acl_action_hash_value_t;

/**
 * sx_flex_acl_flex_action_hash_t is used to set parameters of ACL action HASH
 */
typedef struct sx_acl_flex_action_hash {
    sx_flex_acl_action_hash_command_t command;
    sx_flex_acl_action_hash_type_t    type;
    sx_flex_acl_action_hash_value_t   hash_value;
} sx_flex_acl_flex_action_hash_t;

/**
 * sx_flex_acl_flex_action_fields_t struct type is used to note an ACL flexible action fields
 */
typedef union sx_flex_acl_flex_action_fields {
    sx_flex_acl_flex_action_forward_t             action_forward;
    sx_flex_acl_action_trap_t                     action_trap;
    sx_flex_acl_flex_action_counter_t             action_counter;
    sx_flex_acl_flex_action_policer_t             action_policer;
    sx_flex_acl_flex_action_mirror_t              action_mirror;
    sx_flex_acl_flex_action_mirror_t              action_egress_mirror;
    sx_flex_acl_flex_action_set_vlan_t            action_set_vlan;
    sx_flex_acl_flex_action_set_vlan_prio_t       action_set_inner_vlan_prio;
    sx_flex_acl_flex_action_set_vlan_prio_t       action_set_outer_vlan_prio;
    sx_flex_acl_flex_action_set_vlan_id_t         action_set_inner_vlan_id;
    sx_flex_acl_flex_action_set_vlan_id_t         action_set_outer_vlan_id;
    sx_flex_acl_flex_action_set_mac_t             action_set_src_mac;
    sx_flex_acl_flex_action_set_mac_t             action_set_dst_mac;
    sx_flex_acl_flex_action_set_dscp_t            action_set_dscp;
    sx_flex_acl_flex_action_set_prio_t            action_set_prio;
    sx_flex_acl_flex_action_set_bridge_t          action_set_bridge;
    sx_flex_acl_flex_action_set_pbs_t             action_pbs;
    sx_flex_acl_flex_action_set_tc_t              action_set_tc;
    sx_flex_acl_flex_action_set_ttl_t             action_set_ttl;
    sx_flex_acl_flex_action_dec_ttl_t             action_dec_ttl;
    sx_flex_acl_flex_action_set_color_t           action_set_color;
    sx_flex_acl_flex_action_set_ecn_t             action_set_ecn;
    sx_flex_acl_flex_action_set_user_token_t      action_set_user_token;
    sx_flex_acl_flex_action_rpf_t                 action_rpf;
    sx_flex_acl_flex_action_mc_route_t            action_mc_route;
    sx_flex_acl_flex_action_tunnel_decap_t        action_tunnel_decap;
    sx_flex_acl_flex_action_goto_t                action_goto;
    sx_acl_flex_action_set_router_t               action_set_router;
    sx_acl_flex_action_mc_t                       action_mc;
    sx_acl_flex_action_uc_route_t                 action_uc_route;
    sx_acl_flex_action_set_rewrite_t              action_set_dscp_rewrite;
    sx_acl_flex_action_set_rewrite_t              action_set_pcp_rewrite;
    sx_acl_flex_action_port_filter_t              action_port_filter;
    sx_flex_acl_flex_action_set_ttl_t             action_set_mpls_ttl;
    sx_flex_acl_flex_action_dec_ttl_t             action_dec_mpls_ttl;
    sx_flex_acl_flex_action_set_exp_t             action_set_exp;
    sx_acl_flex_action_set_rewrite_t              action_set_exp_rewrite;
    sx_flex_acl_flex_action_set_pbilm_t           action_pbilm;
    sx_flex_acl_flex_action_nve_tunnel_encap_t    action_nve_tunnel_encap;
    sx_flex_acl_flex_action_nve_mc_tunnel_encap_t action_nve_mc_tunnel_encap;
    sx_flex_acl_action_trap_w_user_id_t           action_trap_w_user_id;
    sx_flex_acl_flex_action_set_ip_addr_t         action_set_sip;
    sx_flex_acl_flex_action_set_ip_addr_t         action_set_dip;
    sx_flex_acl_flex_action_set_ip_addr_t         action_set_sipv6;
    sx_flex_acl_flex_action_set_ip_addr_t         action_set_dipv6;
    sx_flex_acl_flex_action_set_l4_port_t         action_set_l4_src_port;
    sx_flex_acl_flex_action_set_l4_port_t         action_set_l4_dst_port;
    sx_flex_acl_flex_action_hash_t                action_hash;
} sx_flex_acl_flex_action_fields_t;

typedef enum {
    SX_FLEX_ACL_ACTION_FORWARD, /**< Handles packet forwarding and discarding */
    SX_FLEX_ACL_ACTION_TRAP, /**< Handles trapping to CPU (original packet continues) */
    SX_FLEX_ACL_ACTION_COUNTER, /**< Counts packets */
    SX_FLEX_ACL_ACTION_MIRROR, /**< Mirrors ingress packets to analyzer */
    SX_FLEX_ACL_ACTION_POLICER, /**< Sets policer for packets */
    SX_FLEX_ACL_ACTION_SET_PRIO, /**< Sets switch priority for the packet */
    SX_FLEX_ACL_ACTION_SET_VLAN, /**< Sets VLAN ID of the packet */
    SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI, /**< Sets PRI of the inner VLAN tag */
    SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI, /**< Sets PRI of the outer VLAN tag */
    SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID, /**< Sets VID of the inner VLAN tag */
    SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID, /**< Sets VID of the outer VLAN tag */
    SX_FLEX_ACL_ACTION_SET_SRC_MAC, /**< Sets SMAC of the Ethernet frame */
    SX_FLEX_ACL_ACTION_SET_DST_MAC, /**< Sets DMAC of the Ethernet frame */
    SX_FLEX_ACL_ACTION_SET_DSCP, /**< Sets DSCP field of the packet's IP header */
    SX_FLEX_ACL_ACTION_SET_BRIDGE, /**< Sends packet to specific 802.1D bridge */
    SX_FLEX_ACL_ACTION_PBS, /**< Policy-based switching. Replaces UC or MC FDB forwarding of the packet. */
    SX_FLEX_ACL_ACTION_SET_TC, /**< Sets packet traffic class */
    SX_FLEX_ACL_ACTION_SET_TTL, /**< Sets TTL of the outermost IP header */
    SX_FLEX_ACL_ACTION_DEC_TTL, /**< Decrements TTL of the outermost IP header */
    SX_FLEX_ACL_ACTION_SET_COLOR, /**< Sets an explicit color for the packet: G/Y/R */
    SX_FLEX_ACL_ACTION_SET_ECN, /**< Sets the ECN value of the packet's IP header */
    SX_FLEX_ACL_ACTION_SET_USER_TOKEN, /**< Sets user token to be matched by user token key */
    SX_FLEX_ACL_ACTION_DONT_LEARN, /**< Disables packet learning in FDB */
    SX_FLEX_ACL_ACTION_RPF, /**< Sets RPF action for MC policy routing */
    SX_FLEX_ACL_ACTION_MC_ROUTE,  /**< Policy-based MC routing (PBR). This action is not supported
                                   *   for IP unicast and MPLS packets. */
    SX_FLEX_ACL_ACTION_TUNNEL_DECAP, /**< Sets tunnel ID for L2 or L3 tunnel termination */
    SX_FLEX_ACL_ACTION_GOTO, /**< Sets ACL group to be looked up after matching this rule */
    SX_FLEX_ACL_ACTION_SET_ROUTER, /**< Sets VRID or MPLS label space of the packet */
    SX_FLEX_ACL_ACTION_MC, /**< MC Policy-based switching with MC container */
    SX_FLEX_ACL_ACTION_UC_ROUTE,  /**< Policy-based UC routing (PBR).  This action is not supported
                                   *   for MPLS and IP multicast packets. */
    SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE, /**< Enables/disables/preserves DSCP rewrite based on switch prio */
    SX_FLEX_ACL_ACTION_SET_PCP_REWRITE, /**< Enables/disables/preserves PCP rewrite based on switch prio */
    SX_FLEX_ACL_ACTION_EGRESS_MIRROR,  /**< Mirror packets on egress port (egress port mirroring takes 20KB
                                        *   of shared buffers for each port) */
    SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER, /**< Disables egress VLAN filter for current packet */
    SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER, /**< Disables egress STP filter for current packet */
    SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING, /**< Disables learning in overlay switch for current packet */
    SX_FLEX_ACL_ACTION_PORT_FILTER, /**< Sets filtering on specific egress ports */
    SX_FLEX_ACL_ACTION_SET_MPLS_TTL, /**< Sets MPLS TTL value of the packet */
    SX_FLEX_ACL_ACTION_DEC_MPLS_TTL, /**< Decrements MPLS TTL of the packet */
    SX_FLEX_ACL_ACTION_SET_EXP, /**< Sets MPLS EXP value for current packet */
    SX_FLEX_ACL_ACTION_SET_EXP_REWRITE, /**< Handles EXP rewrite based on ACN and ECN */
    SX_FLEX_ACL_ACTION_PBILM, /**< Policy-based MPLS ILM. This action is not supported for IP packets. */
    SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP, /**< Policy-based switching - unicast tunnel encap */
    SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP, /**< Policy-based switching - multicast tunnel encap */
    SX_FLEX_ACL_ACTION_TRAP_W_USER_ID, /**< Traps packets to CPU with User-Id parameter */
    SX_FLEX_ACL_ACTION_SET_SIP_ADDR, /**< Sets the source IP address of the packet */
    SX_FLEX_ACL_ACTION_SET_DIP_ADDR, /**< Sets the destination IP address of the packet */
    SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR, /**< Sets the source IPv6 address of the packet */
    SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR, /**< Sets the destination IPv6 address of the packet */
    SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT, /**< Sets the L4 source port */
    SX_FLEX_ACL_ACTION_SET_L4_DST_PORT, /**< Sets the L4 destination port */
    SX_FLEX_ACL_ACTION_HASH, /**< Set LAG/ECMP hash */
    SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST,
    SX_FLEX_ACL_FLEX_ACTION_TYPE_MIN = SX_FLEX_ACL_ACTION_FORWARD,
    SX_FLEX_ACL_FLEX_ACTION_TYPE_MAX = SX_FLEX_ACL_ACTION_HASH,
} sx_flex_acl_flex_action_type_t;

/**
 * sx_flex_acl_flex_action_t struct type is used to note an ACL flexible action
 */
typedef struct sx_flex_acl_flex_action {
    sx_flex_acl_flex_action_type_t   type;
    sx_flex_acl_flex_action_fields_t fields;
} sx_flex_acl_flex_action_t;

typedef enum sx_flex_acl_ipv6_extension_header {
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_NONE = 0,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ROUTING,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_FRAGMENT,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_AUTHENTICATION,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ESP,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MOBILITY,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MIN = SX_FLEX_ACL_IPV6_EXTENSION_HEADER_NONE,
    SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MAX = SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH,
} sx_flex_acl_ipv6_extension_header_t;

typedef struct sx_flex_acl_extension_headrs_list {
    sx_flex_acl_ipv6_extension_header_t extension_headers_list[SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST];
    uint32_t                            extension_headers_cnt;
} sx_flex_acl_extension_headrs_list_t;

typedef struct sx_flex_acl_port_range {
    sx_acl_port_range_id_t port_range_list[RM_API_ACL_PORT_RANGES_MAX];
    uint32_t               port_range_cnt;
} sx_flex_acl_port_range_t;

typedef struct sx_flex_acl_port_list {
    sx_acl_port_list_match_t match_type;
    sx_mc_container_id_t     mc_container_id;
} sx_flex_acl_port_list_container_t;


/* sx_flex_acl_l4_type_extended_t
 * */
typedef enum {
    SX_ACL_L4_TYPE_EXTENDED_TCP = 0,
    SX_ACL_L4_TYPE_EXTENDED_UDP = 1,
    SX_ACL_L4_TYPE_EXTENDED_BTH = 2,
    SX_ACL_L4_TYPE_EXTENDED_BTHOUDP = 3,
    SX_ACL_L4_TYPE_EXTENDED_ICMP = 4, /* Both V4 and V6 */
    SX_ACL_L4_TYPE_EXTENDED_IGMP = 5,
    SX_ACL_L4_TYPE_EXTENDED_AH = 6,
    SX_ACL_L4_TYPE_EXTENDED_ESP = 7,
    SX_ACL_L4_TYPE_EXTENDED_OTHERS = 8, /* None of the above */
    SX_ACL_L4_TYPE_EXTENDED_LAST,
} sx_flex_acl_l4_type_extended_t;

typedef union {
    /* L2 keys */
    sx_mac_addr_t dmac;
    sx_mac_addr_t smac;
    uint16_t      ethertype;
    sx_cos_dei_t  dei;
    sx_cos_pcp_t  pcp;
    sx_vlan_id_t  vlan_id;
    sx_mac_addr_t inner_dmac;
    sx_mac_addr_t inner_smac;
    sx_cos_dei_t  inner_dei;
    sx_cos_pcp_t  inner_pcp;
    uint16_t      inner_ethertype;

    /* L3 keys */
    sx_ip_addr_t  dip;
    sx_ip_addr_t  sip;
    sx_cos_dscp_t dscp;
    uint8_t       ecn;
    uint16_t      ip_packet_length;
    uint8_t       ip_proto;
    uint8_t       ttl;
    sx_ip_addr_t  dipv6;
    sx_ip_addr_t  sipv6;
    sx_ip_addr_t  inner_sip;
    sx_ip_addr_t  inner_dip;
    sx_cos_dscp_t inner_dscp;
    uint8_t       inner_ecn;
    uint8_t       inner_ip_proto;
    sx_ip_addr_t  inner_sipv6;
    sx_ip_addr_t  inner_dipv6;

    /* L4 keys */
    uint16_t l4_destination_port;
    uint16_t l4_source_port;
    uint8_t  tcp_control;
    uint8_t  tcp_ecn;
    uint16_t inner_l4_destination_port;
    uint16_t inner_l4_source_port;

    /* RoCE group */
    uint32_t dest_qp;
    uint16_t pkey;
    uint8_t  bth_opcode;

    /* Tunnel keys */
    sx_tunnel_gre_key_t gre_key;
    sx_tunnel_vni_t     vni_key;
    uint16_t            gre_protocol;

    /* MPLS keys */
    sx_mpls_label_t mpls_label_id_1;
    sx_mpls_label_t mpls_label_id_2;
    sx_mpls_label_t mpls_label_id_3;
    sx_mpls_label_t mpls_label_id_4;
    sx_mpls_label_t mpls_label_id_5;
    sx_mpls_label_t mpls_label_id_6;
    sx_cos_exp_t    exp;
    boolean_t       bos;
    uint8_t         mpls_ttl;
    uint32_t        mpls_control_word;

    /* Control keys */
    boolean_t                               rw_pcp;
    sx_flex_acl_l2_dmac_type_t              l2_dmac_type;
    boolean_t                               dmac_is_uc;
    boolean_t                               vlan_tagged;
    boolean_t                               vlan_valid;
    sx_port_log_id_t                        dst_port;
    sx_port_log_id_t                        src_port;
    boolean_t                               rw_dscp;
    boolean_t                               ip_fragmented;
    boolean_t                               ip_dont_fragment;
    boolean_t                               ip_fragment_not_first;
    boolean_t                               ip_ok;
    boolean_t                               is_arp;
    boolean_t                               ip_opt;
    boolean_t                               is_ip_v4;
    sx_flex_acl_l3_type_t                   l3_type;
    boolean_t                               ttl_ok;
    boolean_t                               l4_ok;
    sx_flex_acl_l4_type_t                   l4_type;
    sx_cos_priority_t                       switch_prio;
    sx_cos_color_t                          color;
    uint8_t                                 buff;
    sx_flex_acl_port_range_t                l4_port_range;
    sx_flex_acl_forward_action_t            discard_state;
    boolean_t                               is_trapped;
    sx_acl_port_list_id_t                   rx_list;
    sx_router_interface_t                   irif;
    sx_router_interface_t                   erif;
    sx_router_id_t                          virtual_router;
    sx_flex_acl_extension_headrs_list_t     ipv6_extension_headers;
    boolean_t                               ipv6_extension_header_exists;
    sx_user_token_t                         user_token;
    boolean_t                               inner_vlan_valid;
    boolean_t                               inner_ip_ok;
    sx_flex_acl_l3_type_t                   inner_l3_type;
    boolean_t                               inner_l4_ok;
    boolean_t                               inner_ttl_ok;
    sx_tunnel_type_e                        tunnel_type;
    boolean_t                               gre_key_exists;
    sx_tunnel_type_e                        tunnel_nve_type;
    sx_flex_acl_l4_type_extended_t          l4_type_extended;
    boolean_t                               is_mpls;
    sx_flex_acl_mpls_labels_valid_bitmask_t mpls_labels_valid;
    boolean_t                               rw_exp;
    sx_flex_acl_port_list_container_t       rx_port_list;
    sx_flex_acl_port_list_container_t       tx_port_list;
    boolean_t                               is_routed;
    uint8_t                                 custom_byte;
    sx_ip_addr_t                            dipv6_lsb;
    sx_ip_addr_t                            dipv6_msb;
    boolean_t                               dword_valid;
    boolean_t                               mpls_control_word_valid;
    uint32_t                                ethernet_payload_dword; /**< Given in host-order */
} sx_acl_key_fields_t;

typedef union {
    /* L2 keys */
    sx_mac_addr_t dmac;
    sx_mac_addr_t smac;
    uint16_t      ethertype;
    sx_cos_dei_t  dei;
    sx_cos_pcp_t  pcp;
    sx_vlan_id_t  vlan_id;
    sx_cos_dei_t  inner_dei;
    sx_cos_pcp_t  inner_pcp;
    sx_mac_addr_t inner_dmac;
    sx_mac_addr_t inner_smac;
    uint16_t      inner_ethertype;

    /* L3 keys */
    sx_ip_addr_t  dip;
    sx_ip_addr_t  sip;
    sx_cos_dscp_t dscp;
    uint8_t       ecn;
    uint16_t      ip_packet_length;
    uint8_t       ip_proto;
    uint8_t       ttl;
    sx_ip_addr_t  dipv6;
    sx_ip_addr_t  sipv6;
    sx_ip_addr_t  inner_sip;
    sx_ip_addr_t  inner_dip;
    sx_cos_dscp_t inner_dscp;
    uint8_t       inner_ecn;
    uint8_t       inner_ip_proto;
    sx_ip_addr_t  inner_sipv6;
    sx_ip_addr_t  inner_dipv6;

    /* L4 keys */
    uint16_t l4_destination_port;
    uint16_t l4_source_port;
    uint8_t  tcp_control;
    uint8_t  tcp_ecn;
    uint16_t inner_l4_destination_port;
    uint16_t inner_l4_source_port;

    /* RoCE group */
    uint32_t dest_qp;
    uint16_t pkey;
    uint8_t  bth_opcode;

    /* Tunnel keys */
    sx_tunnel_gre_key_t gre_key;
    sx_tunnel_vni_t     vni_key;
    uint16_t            gre_protocol;

    /* MPLS keys */
    sx_mpls_label_t mpls_label_id_1;
    sx_mpls_label_t mpls_label_id_2;
    sx_mpls_label_t mpls_label_id_3;
    sx_mpls_label_t mpls_label_id_4;
    sx_mpls_label_t mpls_label_id_5;
    sx_mpls_label_t mpls_label_id_6;
    sx_cos_exp_t    exp;
    boolean_t       bos;
    uint8_t         mpls_ttl;
    uint32_t        mpls_control_word;

    /* Control keys */
    boolean_t                               rw_pcp;
    boolean_t                               l2_dmac_type;
    boolean_t                               dmac_is_uc;
    boolean_t                               vlan_tagged;
    boolean_t                               vlan_valid;
    boolean_t                               dst_port;
    boolean_t                               src_port;
    boolean_t                               rw_dscp;
    boolean_t                               ip_fragmented;
    boolean_t                               ip_dont_fragment;
    boolean_t                               ip_fragment_not_first;
    boolean_t                               ip_ok;
    boolean_t                               is_arp;
    boolean_t                               ip_opt;
    boolean_t                               is_ip_v4;
    boolean_t                               l3_type;
    boolean_t                               ttl_ok;
    boolean_t                               l4_ok;
    boolean_t                               l4_type;
    boolean_t                               switch_prio;
    boolean_t                               color;
    boolean_t                               buff;
    boolean_t                               l4_port_range;
    boolean_t                               discard_state;
    boolean_t                               is_trapped;
    boolean_t                               rx_list;
    boolean_t                               irif;
    boolean_t                               erif;
    boolean_t                               virtual_router;
    boolean_t                               ipv6_extension_headers;
    boolean_t                               ipv6_extension_header_exists;
    sx_user_token_t                         user_token;
    boolean_t                               inner_vlan_valid;
    boolean_t                               inner_ip_ok;
    boolean_t                               inner_l3_type;
    boolean_t                               inner_l4_ok;
    boolean_t                               inner_ttl_ok;
    boolean_t                               tunnel_type;
    boolean_t                               gre_key_exists;
    boolean_t                               tunnel_nve_type;
    boolean_t                               l4_type_extended;
    boolean_t                               is_mpls;
    sx_flex_acl_mpls_labels_valid_bitmask_t mpls_labels_valid;
    boolean_t                               rw_exp;
    boolean_t                               rx_port_list;
    boolean_t                               tx_port_list;
    boolean_t                               is_routed;
    uint8_t                                 custom_byte;
    sx_ip_addr_t                            dipv6_lsb;
    sx_ip_addr_t                            dipv6_msb;
    boolean_t                               dword_valid;
    boolean_t                               mpls_control_word_valid;
    uint32_t                                ethernet_payload_dword; /**< Given in host-order */
} sx_acl_mask_fields_t;

typedef enum {
    FLEX_ACL_KEY_INVALID = 0,

    /* L2 keys */
    FLEX_ACL_KEY_DMAC = 1, /**< size:48, Destination MAC address */
    FLEX_ACL_KEY_SMAC = 2, /**< size:48, Source MAC address. Not relevant for egress RIF.  */
    FLEX_ACL_KEY_ETHERTYPE = 3, /**< size:16  */
    FLEX_ACL_KEY_DEI = 4, /**< size:1  */
    FLEX_ACL_KEY_PCP = 5, /**< size:3,  */
    FLEX_ACL_KEY_VLAN_ID = 6, /**< size:12. Relevant only for ingress binding. */
    FLEX_ACL_KEY_INNER_DMAC = 7, /**< size:48, Destination MAC address */
    FLEX_ACL_KEY_INNER_SMAC = 9, /**< size:48, Destination MAC address */
    FLEX_ACL_KEY_INNER_DEI = 10, /**< size:1  */
    FLEX_ACL_KEY_INNER_PCP = 11, /**< size:3,  */
    FLEX_ACL_KEY_INNER_ETHERTYPE = 12, /**< size:16  */

    FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0 = 13, /**< Size: 32, Bytes 0..1 are ethertype, bytes 2,3 are the following payload bytes, qualified with FLEX_ACL_KEY_DWORD_0_VALID*/
    FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1 = FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0 + 1, /**< Size: 32, Bytes 4..7, qualified with FLEX_ACL_KEY_DWORD_1_VALID */
    FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2 = FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0 + 2, /**< Size: 32, Bytes 8..11, qualified with FLEX_ACL_KEY_DWORD_2_VALID */
    FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3 = FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0 + 3, /**< Size: 32, Bytes 12..15, qualified with FLEX_ACL_KEY_DWORD_3_VALID */
    FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4 = FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0 + 4, /**< Size: 32, Bytes 16..19, qualified with FLEX_ACL_KEY_DWORD_4_VALID */
    FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5 = FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0 + 5, /**< Size: 32, Bytes 20..23, qualified with FLEX_ACL_KEY_DWORD_5_VALID */

    /* L3 Keys */
    FLEX_ACL_KEY_DIP = 500, /**< size:32, IPV4 destination IP address*/
    FLEX_ACL_KEY_SIP = 501, /**< size:32, IPV4 source IP address*/
    FLEX_ACL_KEY_DSCP = 502, /**< size:6, DSCP */
    FLEX_ACL_KEY_ECN = 503, /**< size:2, ECN bits from IP header */
    FLEX_ACL_KEY_IP_PACKET_LENGTH = 504, /**< size:16, IPV4/6 packet length field. */
    FLEX_ACL_KEY_IP_PROTO = 505, /**< size:8, IPV4 - Next protocol, IPV6 - Next header */
    FLEX_ACL_KEY_TTL = 506, /**< size:8,  */
    FLEX_ACL_KEY_DIPV6 = 507, /**< size:128, IPV6 destination IP address */
    FLEX_ACL_KEY_SIPV6 = 508, /**< size:128, IPV6 source IP address */
    FLEX_ACL_KEY_INNER_SIP = 509, /**< size:32, IPV4 source IP address*/
    FLEX_ACL_KEY_INNER_DIP = 510, /**< size:32, IPV4 source IP address*/
    FLEX_ACL_KEY_INNER_DSCP = 511, /**< size:6, DSCP */
    FLEX_ACL_KEY_INNER_ECN = 512, /**< size:2, ECN bits from IP header */
    FLEX_ACL_KEY_INNER_IP_PROTO = 513, /**< size:8, IPV4 - Next protocol, IPV6 - Next header */
    FLEX_ACL_KEY_INNER_SIPV6 = 514, /**< size:128, IPV6 source inner IP address*/
    FLEX_ACL_KEY_INNER_DIPV6 = 515, /**< size:128, IPV6 dest inner IP address*/

    /* L4 keys */
    FLEX_ACL_KEY_L4_DESTINATION_PORT = 1000, /**< size:16  */
    FLEX_ACL_KEY_L4_SOURCE_PORT = 1001, /**< size:16 */
    FLEX_ACL_KEY_TCP_CONTROL = 1002, /**< size:6 TCP control bits from header without the ECN bits */
    FLEX_ACL_KEY_TCP_ECN = 1003, /**< size:3 TCP ECN bits from TCP header */
    FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT = 1004, /**< size:16  */
    FLEX_ACL_KEY_INNER_L4_SOURCE_PORT = 1005, /**< size:16  */

    /* RoCE keys */
    FLEX_ACL_KEY_ROCE_DEST_QP = 1200,
    FLEX_ACL_KEY_ROCE_PKEY = 1201,
    FLEX_ACL_KEY_ROCE_BTH_OPCODE = 1202,

    /* Tunnel keys */
    FLEX_ACL_KEY_GRE_KEY = 1301,
    FLEX_ACL_KEY_VNI_KEY = 1302,
    FLEX_ACL_KEY_GRE_PROTOCOL = 1303,

    /* MPLS keys */
    FLEX_ACL_KEY_MPLS_LABEL_ID_1 = 1400, /**< size:20. Outermost MPLS label. */
    FLEX_ACL_KEY_MPLS_LABEL_ID_2 = 1401, /**< size:20. MPLS label. */
    FLEX_ACL_KEY_MPLS_LABEL_ID_3 = 1402, /**< size:20. MPLS label. */
    FLEX_ACL_KEY_MPLS_LABEL_ID_4 = 1403, /**< size:20. MPLS label. */
    FLEX_ACL_KEY_MPLS_LABEL_ID_5 = 1404, /**< size:20. MPLS label. */
    FLEX_ACL_KEY_MPLS_LABEL_ID_6 = 1405, /**< size:20. Innermost MPLS label. */
    FLEX_ACL_KEY_EXP = 1406, /**< size:3 Outermost EXP bits. */
    FLEX_ACL_KEY_BOS = 1407, /**< size:1 BoS bit exists in one of the 6 outermost labels. */
    FLEX_ACL_KEY_MPLS_TTL = 1408, /**< size:8 Outermost TTL. */
    FLEX_ACL_KEY_MPLS_CONTROL_WORD = 1409, /**< size:32 MPLS control word. */

    /* Control keys */
    FLEX_ACL_KEY_RW_PCP = 1500, /**<  0 - The packet gets transmitted with VLAN.PCP and VALN.DEI, 1 - Rewrite PCP and DEI based on switch prio and color. */
    FLEX_ACL_KEY_L2_DMAC_TYPE = 1501, /**< 0 - Multicast, 1 - Broadcast, 2 - Unicast. Relevant only for Ingress.*/
    FLEX_ACL_KEY_DMAC_IS_UC = 1502, /**<  0 - Non unicast ,  1 - Unicast */
    FLEX_ACL_KEY_VLAN_TAGGED = 1503, /**< Indicates whether the packet enter the chip with or without VLAN tag */
    FLEX_ACL_KEY_VLAN_VALID = 1504, /**<  Packet has valid VLAN at this point (assigned or come with a vlan and the vlan was not popped) */
    FLEX_ACL_KEY_DST_PORT = 1505, /**< Destination logical port. Relevant only for egress. */
    FLEX_ACL_KEY_SRC_PORT = 1506, /**< Source logical port or LAG. */
    FLEX_ACL_KEY_RW_DSCP = 1507, /**< 0 packet is transmitted with the original DSCP, 1 - Rewrite DSCP based on switch prio and color. */
    FLEX_ACL_KEY_IP_FRAGMENTED = 1508, /**< When set means that the packet is segment of a fragmented packets. */
    FLEX_ACL_KEY_IP_DONT_FRAGMENT = 1509, /**< Dont fragment flag of IP packet. */
    FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST = 1510, /**< When set means that the segment is not first segment of fragmented packets.    */
    FLEX_ACL_KEY_IP_OK = 1511, /**< IP checksum id OK. */
    FLEX_ACL_KEY_IS_ARP = 1512, /**< According to Ether type - does not include RARP.    */
    FLEX_ACL_KEY_IP_OPT = 1513, /**< Indicates for IPV4 if the header contains options.*/
    FLEX_ACL_KEY_IS_IP_V4 = 1514, /**<  Packet is IPV4 */
    FLEX_ACL_KEY_L3_TYPE = 1515, /**< 0 - IPV4, 1 - IPV6, 2 - ARP, 3 - OTHER */
    FLEX_ACL_KEY_TTL_OK = 1516, /**<  TTL != 0 && TTL != 1  */
    FLEX_ACL_KEY_L4_OK = 1517, /**< TCP/UDP entire header is present, checksum is not verified.*/
    FLEX_ACL_KEY_L4_TYPE = 1518, /**< Bit 0 - TCP, Bit 1 - UDP, Bit3 - reserved. */
    FLEX_ACL_KEY_SWITCH_PRIO = 1519, /**< Key of QOS indicator */
    FLEX_ACL_KEY_COLOR = 1520, /**< 0 - Green, 1 - Yellow, 2 - Red. */
    FLEX_ACL_KEY_BUFF = 1521, /**< The priority group of the packet as classified when entered/enqueued the chip */
    FLEX_ACL_KEY_L4_PORT_RANGE = 1522, /**< array of sx_acl_port_range_id_t, see sx_api_acl_l4_port_range_set */
    FLEX_ACL_KEY_DISCARD_STATE = 1523, /**< Soft discard/hard discard */
    FLEX_ACL_KEY_IS_TRAPPED = 1524, /**< */
    FLEX_ACL_KEY_RX_LIST = 1525, /**< List of logical ports/LAGs */
    FLEX_ACL_KEY_IRIF = 1526, /**< Ingress RIF*/
    FLEX_ACL_KEY_ERIF = 1527, /**< Egress RIF */
    FLEX_ACL_KEY_VIRTUAL_ROUTER = 1528, /**< virtual router */
    FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS = 1529, /**< IPV6 extension headers.*/
    FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS = 1530, /**< IPV6 extension header exists.*/
    FLEX_ACL_KEY_USER_TOKEN = 1531, /**< Size: 12 bits. */
    FLEX_ACL_KEY_INNER_VLAN_VALID = 1532, /**< Packet has valid VLAN at this point (assigned or come with a vlan and the vlan was not popped) */
    FLEX_ACL_KEY_INNER_IP_OK = 1533, /**< IP checksum id OK. */
    FLEX_ACL_KEY_INNER_L3_TYPE = 1534, /**< 0 - IPV4, 1 - IPV6, 2 - ARP, 3 - OTHER */
    FLEX_ACL_KEY_INNER_L4_OK = 1535, /**< TCP/UDP entire header is present, checksum is not verified.*/
    FLEX_ACL_KEY_INNER_TTL_OK = 1536, /**<  TTL != 0 && TTL != 1  */
    FLEX_ACL_KEY_TUNNEL_TYPE = 1537,
    FLEX_ACL_KEY_GRE_KEY_EXISTS = 1538,
    FLEX_ACL_KEY_TUNNEL_NVE_TYPE = 1539, /**< VXLAN, GENEVE, GRE or NVGRE */
    FLEX_ACL_KEY_L4_TYPE_EXTENDED = 1540,
    FLEX_ACL_KEY_IS_MPLS = 1541, /**<  Packet is MPLS */
    FLEX_ACL_KEY_MPLS_LABELS_VALID = 1542, /**< 6 bit bitmask indicating which mpls labels are valid. */
    FLEX_ACL_KEY_RW_EXP = 1543, /**< 0 - Packet retains its original exp bits. 1 - EXP bits are set according to switch prio and color. */
    FLEX_ACL_KEY_RX_PORT_LIST = 1544, /**< List of logical ports/LAGs */
    FLEX_ACL_KEY_TX_PORT_LIST = 1545, /**< List of logical ports/LAGs. Relevant only for SX_ACL_DIRECTION_EGRESS. */
    FLEX_ACL_KEY_IS_ROUTED = 1546,
    FLEX_ACL_KEY_DWORD_0_VALID = 1547, /**< Qualifier for FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0. */
    FLEX_ACL_KEY_DWORD_1_VALID = FLEX_ACL_KEY_DWORD_0_VALID + 1, /**< Qualifier for FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1. */
    FLEX_ACL_KEY_DWORD_2_VALID = FLEX_ACL_KEY_DWORD_0_VALID + 2, /**< Qualifier for FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2. */
    FLEX_ACL_KEY_DWORD_3_VALID = FLEX_ACL_KEY_DWORD_0_VALID + 3, /**< Qualifier for FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3. */
    FLEX_ACL_KEY_DWORD_4_VALID = FLEX_ACL_KEY_DWORD_0_VALID + 4, /**< Qualifier for FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4. */
    FLEX_ACL_KEY_DWORD_5_VALID = FLEX_ACL_KEY_DWORD_0_VALID + 5, /**< Qualifier for FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5. */
    FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID = 1553, /**<Qualifier for FLEX_ACL_KEY_MPLS_CONTROL_WORD. */

    FLEX_ACL_KEY_COMMON_LAST = FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID, /* End of common ACL keys */

    /* Start of CUSTOM BYTES area */
    /* Custom bytes enumerations is synchronized with sx_router_ecmp_hash_field_t */
    FLEX_ACL_KEY_CUSTOM_BYTES_START = RM_COMMON_CUSTOM_BYTES_ENUM_START,
    FLEX_ACL_KEY_CUSTOM_BYTE_0 = FLEX_ACL_KEY_CUSTOM_BYTES_START,
    FLEX_ACL_KEY_CUSTOM_BYTE_1 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 1),
    FLEX_ACL_KEY_CUSTOM_BYTE_2 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 2),
    FLEX_ACL_KEY_CUSTOM_BYTE_3 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 3),
    FLEX_ACL_KEY_CUSTOM_BYTE_4 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 4),
    FLEX_ACL_KEY_CUSTOM_BYTE_5 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 5),
    FLEX_ACL_KEY_CUSTOM_BYTE_6 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 6),
    FLEX_ACL_KEY_CUSTOM_BYTE_7 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 7),
    FLEX_ACL_KEY_CUSTOM_BYTE_8 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 8),
    FLEX_ACL_KEY_CUSTOM_BYTE_9 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 9),
    FLEX_ACL_KEY_CUSTOM_BYTE_10 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 10),
    FLEX_ACL_KEY_CUSTOM_BYTE_11 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 11),
    FLEX_ACL_KEY_CUSTOM_BYTE_12 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 12),
    FLEX_ACL_KEY_CUSTOM_BYTE_13 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 13),
    FLEX_ACL_KEY_CUSTOM_BYTE_14 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 14),
    FLEX_ACL_KEY_CUSTOM_BYTE_15 = (FLEX_ACL_KEY_CUSTOM_BYTES_START + 15),
    FLEX_ACL_KEY_CUSTOM_BYTES_LAST = FLEX_ACL_KEY_CUSTOM_BYTE_15,

    FLEX_ACL_KEY_LAST,
} sx_acl_key_t;

/**
 * sx_flex_acl_key_desc_t struct type is used to note an ACL flexible key
 */
typedef struct sx_flex_acl_key_desc {
    sx_acl_key_t         key_id;
    sx_acl_key_fields_t  key;
    sx_acl_mask_fields_t mask;
} sx_flex_acl_key_desc_t;

/**
 * sx_flex_acl_flex_rule_t struct type is used to note an ACL rule
 * combined of the triplet {key_desc(key value and mask value),action }
 *
 * Priority field is valid only for Spectrum-2, and its range should be
 * within FLEX_ACL_RULE_PRIORITY_MIN..FLEX_ACL_RULE_PRIORITY_MAX
 * for rules with no explicit priority (priority = 0), actual priority
 * will be calculated from offset field to maintain the priority as before.
 */
typedef struct sx_flex_acl_flexible_rule {
    uint8_t                     valid;                  /**<Rules validity flag*/
    sx_flex_acl_key_desc_t     *key_desc_list_p;         /**<Array of structures describing a set of basic keys in the rule*/
    uint32_t                    key_desc_count;         /**<Number of elements in array of basic keys descriptors*/
    sx_flex_acl_flex_action_t  *action_list_p;           /**<Array of rule actions*/
    uint32_t                    action_count;           /**<Number of elements in array of actions*/
    sx_flex_acl_rule_priority_t priority;               /**<Rule priority. Valid for Spectrum-2. Higher value wins */
} sx_flex_acl_flex_rule_t;

/**
 * sx_acl_flex_key_width_t is used to define ACL flexible key width in bytes
 */
typedef enum {
    SX_ACL_FLEX_KEY_WIDTH_NONE_E = 0,
    SX_ACL_FLEX_KEY_WIDTH_9_E = 9,             /**< TCAM width 9  */
    SX_ACL_FLEX_KEY_WIDTH_18_E = 18,           /**< TCAM width 18 */
    SX_ACL_FLEX_KEY_WIDTH_36_E = 36,           /**< TCAM width 36 */
    SX_ACL_FLEX_KEY_WIDTH_54_E = 54,            /**< TCAM width 54 */
    SX_ACL_FLEX_KEY_WIDTH_MIN_E = SX_ACL_FLEX_KEY_WIDTH_9_E
} sx_acl_flex_key_width_t;

/**
 * sx_acl_flex_key_attr_t contains ACL flexible key attribute
 */
typedef struct sx_acl_flex_key_attr {
    sx_acl_flex_key_width_t key_width;
} sx_acl_flex_key_attr_t;

/**
 * sx_acl_range_type_e enumerated type is used to note range type.
 */
typedef enum {
    SX_ACL_RANGE_TYPE_L4_PORT_E = 0,        /**< Apply range to L4 port */
    SX_ACL_RANGE_TYPE_IP_LENGTH_E,          /**< Apply range to IP length */
    SX_ACL_RANGE_TYPE_TTL_E,                /**< Apply range to outer TTL (outer_inner field should be outer) */
    SX_ACL_RANGE_TYPE_CUSTOM_BYTE_SET_E,    /**< Apply range to custom byte set (outer_inner field should be outer) */
    SX_ACL_RANGE_TYPE_UTC_29_14_E,          /**< Apply range to UTC bits [29:14] (outer_inner field should be outer) */
    SX_ACL_RANGE_TYPE_MAX_E = SX_ACL_RANGE_TYPE_UTC_29_14_E,
} sx_acl_range_type_e;

/**
 * sx_acl_range_limits_t struct is used when setting min/max values for ACL Range entry.
 */
typedef struct {
    uint16_t min;       /**< Minimum range value for comparison */
    uint16_t max;       /**< Maximum range value for comparison */
} sx_acl_range_limits_t;

/**
 * sx_custom_bytes_range_attr_t struct is used when setting additional parameters for CUSTOM_BYTE_SET range type.
 */
typedef struct {
    sx_acl_key_t custom_bytes_set_key_id;       /**< One of the ACL keys which are mapped on appropriate Custom Bytes set. */
} sx_custom_bytes_range_attr_t;

/**
 * sx_acl_range_attr_t union is used when setting additional parameters for ACL Range entry.
 */
typedef union {
    sx_custom_bytes_range_attr_t custom_bytes_range_attr;       /**< Additional parameters for Custom Byte range */
} sx_acl_range_attr_t;

/**
 * sx_acl_range_entry_t struct is used when setting ACL Range entry.
 * Match is defined when:
 *     range_limits.range_min <= value <= range_limits.range_max
 */
typedef struct {
    sx_ip_version_t               ip_version;        /**< None/IPv4/IPv6/IPv4_IPv6 */
    sx_acl_port_range_direction_t direction;         /**< Source/Destination/Both */
    sx_flex_acl_l4_type_t         l4_protocol;       /**< None/TCP/UDP/TCP_UDP */
    sx_acl_port_range_ip_header_t outer_inner;       /**< Outer/Inner (Both isn't supported on Spectrum2) */
    sx_acl_range_type_e           range_type;        /**< L4_PORT/IP_LENGTH/TTL/CUSTOM_BYTE_SET/UTC_29_14 */
    sx_acl_range_limits_t         range_limits;      /**< Min & Max values for the range */
    sx_acl_range_attr_t           range_attr;        /**< Additional range attributes */
} sx_acl_range_entry_t;

#endif /* __SX_ACL_H__ */
