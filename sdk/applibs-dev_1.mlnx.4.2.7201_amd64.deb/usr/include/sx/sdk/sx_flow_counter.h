/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_FLOW_COUNTER_H_
#define SX_FLOW_COUNTER_H_

/**
 * describes Flow counter id
 */
typedef uint32_t sx_flow_counter_id_t;


/*
 * Filter for sx_api_flow_counter_iter_get
 */
typedef uint32_t sx_flow_counter_filter_t;


/**
 * SX_FLOW_COUNTER_ID_INVALID define Invalid Flow Counter ID
 */
#define SX_FLOW_COUNTER_ID_INVALID ((sx_flow_counter_id_t)0)

/**
 *  describes to which entity the flow_counter is bound to
 */
typedef enum sx_flow_counter_bridge_type {
    SX_FLOW_COUNTER_INVALID_TYPE = 0,          /**< flow counter not bound */
    SX_FLOW_COUNTER_BRIDGE_TYPE = 1,        /**< flow counter bound to bridge  */
    SX_FLOW_COUNTER_VPORT_TYPE = 2,          /**< flow counter bound to vport  */
} sx_flow_counter_bridge_type_t;


/**
 * describes Flow counter value
 */
typedef uint64_t sx_flow_counter_val_t;


/**
 * sx_flow_counter_type_t enumerated type is used to note counter type
 * used in create Flow counter
 */
typedef enum sx_flow_counter_type {
    SX_FLOW_COUNTER_TYPE_BYTES = 0,          /**< Bytes counter  */
    SX_FLOW_COUNTER_TYPE_PACKETS = 1,        /**< Packets counter  */
    SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES = 2,        /**< Packets and bytes counter  */
    SX_FLOW_COUNTER_TYPE_MIN = SX_FLOW_COUNTER_TYPE_BYTES,
    SX_FLOW_COUNTER_TYPE_MAX = SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES,
} sx_flow_counter_type_t;


/**
 * sx_flow_counter_params_t enumerated type is used to note Flow Counter library
 * init parameters
 */
typedef struct {
    uint16_t flow_counter_byte_type_min_number;
    uint16_t flow_counter_packet_type_min_number;
    uint16_t flow_counter_byte_type_max_number;
    uint16_t flow_counter_packet_type_max_number;
} sx_flow_counter_params_t;

/**
 *  * Flow Counter Set.
 *   */
typedef struct sx_flow_counter_set {
    uint64_t flow_counter_packets;
    uint64_t flow_counter_bytes;
} sx_flow_counter_set_t;

typedef struct sx_flow_counter_obj {
    sx_flow_counter_id_t          flow_counter_id;
    sx_flow_counter_bridge_type_t flow_counter_bound_entity;
} sx_flow_counter_obj_t;

#define SX_FLOW_COUNTER_CHECK_TYPE(counter_type) SX_CHECK_MAX(counter_type, SX_FLOW_COUNTER_TYPE_MAX)

#endif /* SX_FLOW_COUNTER_H_ */
