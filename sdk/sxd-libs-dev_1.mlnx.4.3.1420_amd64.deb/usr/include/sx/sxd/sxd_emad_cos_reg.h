/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_COS_REG_H__
#define __SXD_EMAD_COS_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_qpdp_reg_t structure is used to store QPDP register
 * layout.
 */
typedef struct sxd_emad_qpdp_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t reserved2[3];
    uint8_t color;
    uint8_t pprio;
} PACK_SUFFIX sxd_emad_qpdp_reg_t;

/**
 * sxd_emad_qprt_reg_t structure is used to store QPRT register
 * layout.
 */
typedef struct sxd_emad_qprt_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t dei_pcp;
    uint8_t reserved2[3];
    uint8_t color;
    uint8_t rprio;
} PACK_SUFFIX sxd_emad_qprt_reg_t;

/**
 * sxd_emad_qsptc_reg_t structure is used to store QSPTC register
 * layout.
 */
typedef struct sxd_emad_qsptc_reg {
    uint8_t local_iport;
    uint8_t local_eport;
    uint8_t itclass;
    uint8_t reserved2[4];
    uint8_t tclass;
} PACK_SUFFIX sxd_emad_qsptc_reg_t;

/**
 * sxd_emad_qtct_reg_t structure is used to store QTCT register
 * layout.
 */
typedef struct sxd_emad_qtct_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t prio;
    uint8_t reserved2[3];
    uint8_t tclass;
} PACK_SUFFIX sxd_emad_qtct_reg_t;

/**
 * sxd_emad_qstct_reg_t structure is used to store QSTCT register
 * layout.
 */
typedef struct sxd_emad_qstct_reg {
    uint8_t swid;
    uint8_t reserved1;
    uint8_t prio;
    uint8_t reserved2[4];
    uint8_t utclass;
    uint8_t reserved3[3];
    uint8_t mtclass;
    net32_t reserved4;
} PACK_SUFFIX sxd_emad_qstct_reg_t;

/**
 * sxd_emad_qcap_reg_t structure is used to store QCAP register
 * layout.
 */
typedef struct sxd_emad_qcap_reg {
    net32_t reserved1[2];
    uint8_t reserved2[3];
    uint8_t max_policers_per_port;
    uint8_t reserved3[3];
    uint8_t max_policers_global;
    net32_t reserved4[4];
} PACK_SUFFIX sxd_emad_qcap_reg_t;

/**
 * sxd_emad_qpts_reg_t structure is used to store QPTS register
 * layout.
 */
typedef struct sxd_emad_qpts_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[5];
    uint8_t trust_level;
} PACK_SUFFIX sxd_emad_qpts_reg_t;

/**
 * sxd_emad_qdpm_reg_t structure is used to store QDPM register
 * layout.
 */
typedef struct sxd_emad_qdpm_reg {
    uint8_t priority_update[64];
} PACK_SUFFIX sxd_emad_qdpm_reg_t;

/**
 * sxd_emad_qetcr_tc_configuration_t structure is used to store
 * TCLASS configuration layout.
 */
typedef struct sxd_emad_qetcr_tc_conf {
    uint8_t gbr_update;
    uint8_t group;
    uint8_t reserved1;
    uint8_t bw_allocation;
    uint8_t reserved2;
    uint8_t max_bw_units;
    uint8_t reserved3;
    uint8_t max_bw_value;
} PACK_SUFFIX sxd_emad_qetcr_tc_conf_t;

typedef struct sxd_emad_qetcr_glbl_shaper {
    uint8_t r_update;
    uint8_t reserved1[4];
    uint8_t max_bw_units;
    uint8_t reserved2;
    uint8_t max_bw_value;
} PACK_SUFFIX sxd_emad_qetcr_glbl_shaper_t;

/**
 * sxd_emad_qets_reg_t structure is used to store QETCR register
 * layout.
 */
typedef struct sxd_emad_qetcr_reg {
    uint8_t                      reserved1;
    uint8_t                      local_port;
    uint8_t                      reserved2[6];
    sxd_emad_qetcr_tc_conf_t     tc_conf[8];
    sxd_emad_qetcr_glbl_shaper_t glbl_shaper;
} PACK_SUFFIX sxd_emad_qetcr_reg_t;

/**
 * sxd_emad_qegcs_reg_t structure is used to store QEGCS register
 * layout.
 */
typedef struct sxd_emad_qegcs_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[5];
    uint8_t gr07_gr15_global_arbiters;
    net32_t reserved3[2];
} PACK_SUFFIX sxd_emad_qegcs_reg_t;

/**
 * sxd_emad_cnct_reg_t structure is used to store CNCT register
 * layout.
 */
typedef struct sxd_emad_cnct_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t prio;
    uint8_t reserved2;
    uint8_t e_r;
    uint8_t reserved3;
    uint8_t ee_re;
    uint8_t reserved4;
} PACK_SUFFIX sxd_emad_cnct_reg_t;

/**
 * sxd_emad_cpid_reg_t structure is used to store CPID
 * layout.
 */
typedef struct sxd_emad_cpid_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  prio;
    uint8_t  reserved2;
    uint32_t reserved3;
    net64_t  cpid;
} PACK_SUFFIX sxd_emad_cpid_reg_t;

/**
 * sxd_emad_cpcs_reg_t structure is used to store CPCS
 * layout.
 */
typedef struct sxd_emad_cpcs_reg {
    uint8_t  reserved1[2];
    uint8_t  tclass;
    uint8_t  reserved2;
    uint8_t  cpqspe_log2_cpwe_cpsbe_cpmhoe;
    uint8_t  reserved3[3];
    uint32_t cpqsp;
    uint32_t log2_cpw;
    uint32_t cp_sample_base;
    uint32_t cp_min_header_octets;
} PACK_SUFFIX sxd_emad_cpcs_reg_t;

/**
 * sxd_emad_cnmc_reg_t structure is used to store CNMC
 * layout.
 */
typedef struct sxd_emad_cnmc_reg {
    uint8_t reserved1[2];
    uint8_t prio;
    uint8_t reserved2;
} PACK_SUFFIX sxd_emad_cnmc_reg_t;

/**
 * sxd_emad_sbmm_reg_t structure is used to store SBMM register
 * layout.
 */
typedef struct sxd_emad_sbmm_reg {
    uint8_t reserved1[2];
    uint8_t prio;
    uint8_t reserved2[13];
    net32_t buff_occupancy;
    net32_t clr_max_buff_occupancy;
    net32_t min_buff;
    net32_t infinite_size_max_buff;
    uint8_t reserved3[7];
    uint8_t pool;
} PACK_SUFFIX sxd_emad_sbmm_reg_t;

/** sxd_emad_statistics_t structure is used to store PER BUFFER
 * register layout.
 */
typedef struct sxd_emad_statistics_t {
    uint32_t buff_occupancy;
    uint32_t max_buff_occupancy;
} PACK_SUFFIX sxd_emad_statistics_t;

/**
 * sxd_emad_sbsr_reg_t structure is used to store SBSR register
 * layout.
 */
typedef struct sxd_emad_sbsr_reg {
    uint8_t               clr;
    uint8_t               reserved1[3];
    uint8_t               desc;
    uint8_t               reserved2[11];
    uint32_t              ingress_port_mask[SXD_EMAD_SBSR_PORT_MASK_SIZE];
    uint16_t              reserved3;
    uint16_t              pg_buff_mask;
    uint32_t              egress_port_mask[SXD_EMAD_SBSR_PORT_MASK_SIZE];
    uint32_t              tclass_mask[SXD_EMAD_SBSR_TC_MASK_SIZE];
    sxd_emad_statistics_t sbstatus[SXD_EMAD_SBSR_MAX_RET_SIZE];
} PACK_SUFFIX sxd_emad_sbsr_reg_t;

/**
 * sxd_emad_qpdpm_reg_t structure is used to store QPDPM register
 * layout.
 */
typedef struct sxd_emad_qpdpm_reg {
    uint8_t reserved1;
    uint8_t port;
    uint8_t reserved2[2];
    net16_t priority_update[64];
} PACK_SUFFIX sxd_emad_qpdpm_reg_t;

/**
 * sxd_emad_qepm_reg_t structure is used to store QEPM register
 * layout.
 */
typedef struct sxd_emad_qepm_reg {
    uint8_t reserved1;
    uint8_t port;
    uint8_t reserved2[2];
    net16_t exp[8];
} PACK_SUFFIX sxd_emad_qepm_reg_t;

/**
 * sxd_emad_qeec_reg_t structure is used to store QEEC register
 * layout.
 */
typedef struct sxd_emad_qeec_reg {
    uint8_t reserved1;
    uint8_t port;
    uint8_t reserved2;
    uint8_t port_rate;
    uint8_t reserved3;
    uint8_t element_hierarchy;
    uint8_t reserved4;
    uint8_t element_index;
    uint8_t reserved5[3];
    uint8_t next_element_index;
    net32_t min_shaper_conf;
    net32_t max_shaper_conf;
    net32_t phantom_queue_conf;
    net32_t dwrr_conf;
    uint8_t reserved6;
    uint8_t min_shaper_bs;
    uint8_t reserved7;
    uint8_t max_shaper_bs;
} PACK_SUFFIX sxd_emad_qeec_reg_t;

/**
 * sxd_emad_qpdpc_reg_t structure is used to store QPDPC register
 * layout.
 */
typedef struct sxd_emad_qpdpc_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t reserved2[3];
    uint8_t dei;
    uint8_t pcp;
} PACK_SUFFIX sxd_emad_qpdpc_reg_t;

/**
 * sxd_emad_qtctm_reg_t structure is used to store QTCTM register
 * layout.
 */
typedef struct sxd_emad_qtctm_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[5];
    uint8_t mc_aware;
} PACK_SUFFIX sxd_emad_qtctm_reg_t;

/**
 * sxd_emad_qspip_reg_t structure is used to store QSPIP register
 * layout.
 */
typedef struct sxd_emad_qspip_reg {
    uint8_t reserved1[3];
    uint8_t switch_prio;
    uint8_t reserved2[3];
    uint8_t ieee_prio;
} PACK_SUFFIX sxd_emad_qspip_reg_t;

/**
 * sxd_emad_qspcp_reg_t structure is used to store QSPCP register
 * layout.
 */
typedef struct sxd_emad_qspcp_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t switch_prio;
    uint8_t reserved3[3];
    uint8_t rx_prio;
    uint8_t reserved4[3];
    uint8_t tx_prio;
} PACK_SUFFIX sxd_emad_qspcp_reg_t;

/**
 * sxd_emad_qrwe_reg_t structure is used to store QRWE register
 * layout.
 */
typedef struct sxd_emad_qrwe_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[5];
    uint8_t rewrite;
} PACK_SUFFIX sxd_emad_qrwe_reg_t;

/**
 * sxd_emad_qpem_ecn structure is used to store color data for QPEM register
 */
typedef struct sxd_emad_qpem_ecn {
    uint8_t color[3];
    uint8_t reserved1;
} PACK_SUFFIX sxd_emad_qpem_ecn_t;

/**
 * sxd_emad_qpem_switch_prio structure is used to store switch_prio data for QPEM register
 */
typedef struct sxd_emad_qpem_switch_prio {
    sxd_emad_qpem_ecn_t ecn[4];
} PACK_SUFFIX sxd_emad_qpem_switch_prio_t;

/**
 * sxd_emad_qpem_reg_t structure is used to store QPEM register
 * layout.
 */
typedef struct sxd_emad_qpem_reg {
    uint8_t                     reserved1;
    uint8_t                     local_port;
    uint8_t                     reserved2[2];
    sxd_emad_qpem_switch_prio_t switch_prio[16];
} PACK_SUFFIX sxd_emad_qpem_reg_t;

/**
 * sxd_emad_qpdsm_switch_prio structure is used to store switch_prio data for QPDSM register
 */
typedef struct sxd_emad_qpdsm_switch_prio {
    uint8_t color[3];
    uint8_t reserved1;
} PACK_SUFFIX sxd_emad_qpdsm_switch_prio_t;

/**
 * sxd_emad_qpdsm_reg_t structure is used to store QPDSM register
 * layout.
 */
typedef struct sxd_emad_qpdsm_reg {
    uint8_t                      reserved1;
    uint8_t                      local_port;
    uint8_t                      reserved2[2];
    sxd_emad_qpdsm_switch_prio_t switch_prio[16];
} PACK_SUFFIX sxd_emad_qpdsm_reg_t;

/**
 * sxd_emad_qppmm_switch_prio structure is used to store switch_prio data for QPPM register
 */
typedef struct sxd_emad_qppm_switch_prio {
    uint8_t color[3];
    uint8_t reserved1;
} PACK_SUFFIX sxd_emad_qppm_switch_prio_t;

/**
 * sxd_emad_qppm_reg_t structure is used to store QPPM register
 * layout.
 */
typedef struct sxd_emad_qppm_reg {
    uint8_t                     reserved1;
    uint8_t                     local_port;
    uint8_t                     reserved2[2];
    sxd_emad_qppm_switch_prio_t switch_prio[16];
} PACK_SUFFIX sxd_emad_qppm_reg_t;

/**
 * sxd_emad_sbhbr_hist_patams_t is used to store hist_parameters data for SBHBR register
 */
typedef struct sxd_emad_sbhbr_hist_params {
    uint8_t reserved1[3];
    uint8_t tclass;
} PACK_SUFFIX sxd_emad_sbhbr_hist_params_t;

/**
 * sxd_emad_sbhbr_reg_t structure is used to store SBHBR register
 * layout.
 */
typedef struct sxd_emad_sbhbr_reg {
    uint8_t                      opcode;
    uint8_t                      local_port;
    uint8_t                      reserved1[5];
    uint8_t                      hist_id;
    uint8_t                      reserved2[2];
    net16_t                      hist_type;
    sxd_emad_sbhbr_hist_params_t hist_params;
    net32_t                      hist_min;
    net32_t                      hist_max;
    uint8_t                      reserved3[3];
    uint8_t                      sample_time;
} PACK_SUFFIX sxd_emad_sbhbr_reg_t;

/**
 * sxd_emad_sbhrr_reg_t structure is used to store SBHRR register
 * layout.
 */
typedef struct sxd_emad_sbhrr_reg {
    uint8_t clr;
    uint8_t reserved1[6];
    uint8_t hist_id;
    uint8_t reserved2[8];
    net64_t bin[NUM_BINS_SBHRR];
} PACK_SUFFIX sxd_emad_sbhrr_reg_t;

/**
 * sxd_emad_sbdcc_reg_t structure is used to store SBDCC register
 * layout.
 */
typedef struct sxd_emad_sbdcc_reg {
    uint8_t  clr;
    uint8_t  reserved1[15];
    uint64_t tclass[NUM_COUNTERS_SBDCC];
} PACK_SUFFIX sxd_emad_sbdcc_reg_t;

/**
 * sxd_emad_sbdcm_reg_t structure is used to store SBDCM register
 * layout.
 */
typedef struct sxd_emad_sbdcm_reg {
    uint8_t  reserved1[16];
    uint32_t ctr_index_set_type;
} PACK_SUFFIX sxd_emad_sbdcm_reg_t;

/**
 * sxd_emad_sbctc_reg_t structure is used to store SBCTC register
 * layout.
 */
typedef struct sxd_emad_sbctc_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  reserved2[2];
    uint8_t  en_config;
    uint8_t  reverved3[2];
    uint8_t  event;
    net64_t  tclass_en;
    uint32_t thr_max;
} PACK_SUFFIX sxd_emad_sbctc_reg_t;

/**
 * sxd_emad_sbctr_reg_t structure is used to store SBCTR register
 * layout.
 */
typedef struct sxd_emad_sbctr_reg {
    uint8_t ievent;
    uint8_t local_port;
    uint8_t reserved1;
    uint8_t fp_entity;
    uint8_t reserved2[4];
    net64_t tclass_vec;
} PACK_SUFFIX sxd_emad_sbctr_reg_t;

/**
 * sxd_emad_sbgcr_reg_t structure is used to store SBGCR register
 * layout.
 */
typedef struct sxd_emad_sbgcr_reg {
    net16_t reserved1;
    uint8_t reserved2;
    uint8_t cong_fp_tele_entity;
    net32_t reserved3;
} PACK_SUFFIX sxd_emad_sbgcr_reg_t;

/**
 * sxd_emad_qsll_reg_t structure is used to store QSLL register
 * layout.
 */
typedef struct sxd_emad_qsll_reg {
    net32_t reserved1;
    uint8_t reserved2[3];
    uint8_t sll_time;
} PACK_SUFFIX sxd_emad_qsll_reg_t;

/**
 * sxd_emad_qhll_reg_t structure is used to store QHLL register
 * layout.
 */
typedef struct sxd_emad_qhll_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[2];
    uint8_t reserved3[3];
    uint8_t hll_time;
    uint8_t stall_en;
    uint8_t reserved4[2];
    uint8_t stall_cnt;
} PACK_SUFFIX sxd_emad_qhll_reg_t;

/**
 * MTPPTR timestamp record for sxd_emad_mtpptr_reg structure
 */
struct mtpptr_reg_record {
    net16_t reserved1;
    uint8_t message_type;
    uint8_t domain_number;
    net16_t reserved2;
    net16_t sequence_id;
    net64_t timestamp;
};

/**
 * sxd_emad_mtpptr_reg_t structure is used to store QHLL register
 * layout.
 */
typedef struct sxd_emad_mtpptr_reg {
    uint8_t                  reserved1;
    uint8_t                  local_port;
    uint8_t                  reserved2;
    uint8_t                  dir;
    uint8_t                  clr_read_one;
    uint8_t                  reserved3[2];
    uint8_t                  ovf;
    uint8_t                  reserved4[3];
    uint8_t                  num_record;
    net32_t                  reserved5;
    struct mtpptr_reg_record records[4];
} PACK_SUFFIX sxd_emad_mtpptr_reg_t;

/**
 * sxd_emad_qpsc_reg_t structure is used to store QPSC register
 * layout.
 */
typedef struct sxd_emad_qpsc_reg {
    uint8_t reserved1[3];
    uint8_t port_speed;
    uint8_t reserved2;
    uint8_t time_exp;
    uint8_t reserved3;
    uint8_t time_mantissa;
    uint8_t reserved4[3];
    uint8_t shaper_inc;
    uint8_t reserved5[3];
    uint8_t shaper_bs;
    uint8_t ptsc_we;
    uint8_t reserved6[2];
    uint8_t port_to_shaper_credits;
    uint8_t reserved[12];
    net32_t ing_timestamp_inc;
    net32_t egr_timestamp_inc;
} PACK_SUFFIX sxd_emad_qpsc_reg_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_COS_REG_H__ */
