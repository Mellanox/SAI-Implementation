/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_TUNNEL_REG_H__
#define __SXD_EMAD_TUNNEL_REG_H__

#include <sx/sxd/sxd_types.h>
#include <complib/cl_packon.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_tngcr_reg_t structure is used to store TNGCR register layout.
 */
typedef struct sxd_emad_tngcr_reg {
    net16_t reserved1;
    uint8_t reserved2;
    uint8_t type;
    uint8_t nve_valid;
    net16_t reserved3;
    uint8_t nve_ttl_uc;
    net16_t reserved4;
    uint8_t reserved5;
    uint8_t nve_ttl_mc;
    uint8_t nve_flc_flh;
    net16_t nve_fl_prefix;
    uint8_t reserved6;
    uint8_t nve_enc_orig_we_udp_sport_type;
    uint8_t et_vlan;
    uint8_t nve_udp_sport_prefix;
    uint8_t reserved8;
    net16_t reserved9;
    net16_t nve_udp_dport;
    net16_t reserved10;
    uint8_t reserved11;
    uint8_t nve_group_size_mc;
    net16_t reserved12;
    uint8_t reserved13;
    uint8_t nve_group_size_flood;
    uint8_t learn_enable;
    uint8_t reserved14;
    net16_t underlay_virtual_router;
    net16_t reserved15;
    net16_t underlay_rif;
    net32_t usipv4;
    net32_t reserved16;
    net32_t usipv6[4];
} PACK_SUFFIX sxd_emad_tngcr_reg_t;

/**
 * sxd_emad_tncr_reg_t structure is used to store TNCR register layout.
 */
typedef struct sxd_emad_tncr_reg {
    uint8_t  clear_counters;
    net16_t  reserved1;
    uint8_t  reserved2;
    net32_t  reserved3;
    net32_t  reserved4;
    net32_t  reserved5;
    uint32_t count_encap_high;
    uint32_t count_encap_low;
    uint32_t count_decap_high;
    uint32_t count_decap_low;
    uint32_t count_decap_errors_high;
    uint32_t count_decap_errors_low;
    uint32_t count_decap_discards_high;
    uint32_t count_decap_discards_low;
} PACK_SUFFIX sxd_emad_tncr_reg_t;

/**
 * sxd_emad_tnumt_reg_t structure is used to store TNUMT register layout.
 */
typedef struct sxd_emad_tnumt_reg {
    net32_t record_type_underlay_mc_ptr;
    net32_t vnext_next_underlay_mc_ptr;
    net32_t record[6];
} PACK_SUFFIX sxd_emad_tnumt_reg_t;

/**
 * sxd_emad_tnqcr_reg_t structure is used to store TNQCR register layout.
 */
typedef struct sxd_emad_tnqcr_reg {
    net32_t reserved1;
    uint8_t enc_set_dscp_sp;
    net16_t reserved2;
    uint8_t enc_dscp_rw_pcp_rw;
    uint8_t dec_set_dscp_sp;
    net16_t reserved3;
    uint8_t dec_dscp_rw_pcp_rw;
} PACK_SUFFIX sxd_emad_tnqcr_reg_t;

/**
 * sxd_emad_tnqdr_reg_t structure is used to store TNQDR register layout.
 */
typedef struct sxd_emad_tnqdr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    uint8_t color;
    uint8_t switch_prio;
    uint8_t reserved3;
    uint8_t dscp;
} PACK_SUFFIX sxd_emad_tnqdr_reg_t;

/**
 * sxd_emad_tigcr_reg_t structure is used to store TIGCR register layout.
 */
typedef struct sxd_emad_tigcr_reg {
    net32_t reserved1;
    net16_t reserved2;
    uint8_t ipip_ttlc;
    uint8_t ipip_ttl_uc;
    net32_t reserved3;
    uint8_t ipip_flc_flh;
    net16_t ipip_fl_prefix;
    uint8_t reserved4;
    net32_t reserved5;
    net32_t ipip_gre_key_for_hash;
} PACK_SUFFIX sxd_emad_tigcr_reg_t;

/**
 * sxd_emad_tiqdr_reg_t structure is used to store TIQDR register layout.
 */
typedef struct sxd_emad_tiqdr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    uint8_t color;
    uint8_t switch_prio;
    uint8_t reserved3;
    uint8_t dscp;
} PACK_SUFFIX sxd_emad_tiqdr_reg_t;

/**
 * sxd_emad_tiqcr_reg_t structure is used to store TIQCR register layout.
 */
typedef struct sxd_emad_tiqcr_reg {
    net32_t reserved1;
    uint8_t enc_set_dscp_sp;
    net16_t reserved2;
    uint8_t enc_rw_dscp_pcp;
    uint8_t dec_set_dscp_sp;
    net16_t reserved3;
    uint8_t dec_rw_dscp_pcp;
} PACK_SUFFIX sxd_emad_tiqcr_reg_t;

/**
 * sxd_emad_tieem_reg_t structure is used to store TIEEM register layout.
 */
typedef struct sxd_emad_tieem_reg {
    net32_t reserved1;
    uint8_t overlay_ecn;
    uint8_t underlay_ecn;
    net16_t reserved2;
    net32_t reserved3;
} PACK_SUFFIX sxd_emad_tieem_reg_t;

/**
 * sxd_emad_tidem_reg_t structure is used to store TIDEM register layout.
 */
typedef struct sxd_emad_tidem_reg {
    net32_t reserved1;
    uint8_t underlay_ecn;
    uint8_t overlay_ecn;
    uint8_t eip_ecn;
    uint8_t reserved2;
    uint8_t trap_en;
    net16_t reserved3;
    uint8_t trap_id;
} PACK_SUFFIX sxd_emad_tidem_reg_t;

/**
 * sxd_emad_tneem_reg_t structure is used to store TNEEM register layout.
 */
typedef struct sxd_emad_tneem_reg {
    net32_t reserved1;
    uint8_t overlay_ecn;
    uint8_t underlay_ecn;
    net16_t reserved2;
    net32_t reserved3;
} PACK_SUFFIX sxd_emad_tneem_reg_t;

/**
 * sxd_emad_tndem_reg_t structure is used to store TNDEM register layout.
 */
typedef struct sxd_emad_tndem_reg {
    net32_t reserved1;
    uint8_t underlay_ecn;
    uint8_t overlay_ecn;
    uint8_t eip_ecn;
    uint8_t reserved2;
    uint8_t trap_en;
    net16_t reserved3;
    uint8_t trap_id;
} PACK_SUFFIX sxd_emad_tndem_reg_t;

/**
 * sxd_emad_tnifr_reg_t structure is used to store TNIFR register layout.
 */
typedef struct sxd_emad_tnifr_reg {
    net32_t reserved[8];
    net32_t port_filter[8];
    net32_t port_filter_update_en[8];
} PACK_SUFFIX sxd_emad_tnifr_reg_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/


#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_TUNNEL_REG_H__ */
