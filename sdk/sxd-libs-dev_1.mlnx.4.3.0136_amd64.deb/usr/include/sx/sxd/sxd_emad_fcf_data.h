/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_FCF_DATA_H__
#define __SXD_EMAD_FCF_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/sxd_vlan.h>
/* #include <sx/sxd/sxd_fcf.h> */
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_fgcr_data_t structure is used to store FGCR register data.
 */
typedef struct sxd_emad_fgcr_data {
    sxd_emad_common_data_t common;
    struct ku_fgcr_reg    *reg_data;
} sxd_emad_fgcr_data_t;

/**
 * sxd_emad_fitr_data_t structure is used to store FITR register data.
 */
typedef struct sxd_emad_fitr_data {
    sxd_emad_common_data_t common;
    struct ku_fitr_reg    *reg_data;
} sxd_emad_fitr_data_t;

/**
 * sxd_emad_ffar_data_t structure is used to store FFAR register data.
 */
typedef struct sxd_emad_ffar_data {
    sxd_emad_common_data_t common;
    struct ku_ffar_reg    *reg_data;
} sxd_emad_ffar_data_t;

/**
 * sxd_emad_fipl_data_t structure is used to store FIPL register data.
 */
typedef struct sxd_emad_fipl_data {
    sxd_emad_common_data_t common;
    struct ku_fipl_reg    *reg_data;
} sxd_emad_fipl_data_t;

/**
 * sxd_emad_fvet_data_t structure is used to store FVET register data.
 */
typedef struct sxd_emad_fvet_data {
    sxd_emad_common_data_t common;
    struct ku_fvet_reg    *reg_data;
} sxd_emad_fvet_data_t;

/**
 * sxd_emad_fftr_data_t structure is used to store FFTR register data.
 */
typedef struct sxd_emad_fftr_data {
    sxd_emad_common_data_t common;
    struct ku_fftr_reg    *reg_data;
} sxd_emad_fftr_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_FCF_DATA_H__ */
