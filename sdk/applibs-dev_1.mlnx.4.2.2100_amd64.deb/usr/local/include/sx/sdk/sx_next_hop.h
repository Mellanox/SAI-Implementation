/*
 *  Copyright (C) 2010-2016. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_NEXT_HOP_H__
#define __SX_NEXT_HOP_H__

#include <sx/sdk/sx_tunnel_id.h>
#include <sx/sdk/sx_mc_container_id.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_trap_id.h>

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Router Interface ID.
 */
typedef uint16_t sx_router_interface_t;

/**
 * sx_router_action_t enumerated type is used to note the route action.
 */
typedef enum sx_router_action {
    SX_ROUTER_ACTION_DROP,
    SX_ROUTER_ACTION_TRAP,
    SX_ROUTER_ACTION_FORWARD,
    SX_ROUTER_ACTION_MIRROR, /**< This value is deprecated, please use SX_ROUTER_ACTION_TRAP_FORWARD instead */
    SX_ROUTER_ACTION_TRAP_FORWARD = SX_ROUTER_ACTION_MIRROR,
    SX_ROUTER_ACTION_SPAN,
    SX_ROUTER_ACTION_MIN = SX_ROUTER_ACTION_DROP,
    SX_ROUTER_ACTION_MAX = SX_ROUTER_ACTION_SPAN,
} sx_router_action_t;

#define SX_ROUTER_ACTION_CHECK_RANGE(ROUTER_ACTION) \
    SX_CHECK_MAX(ROUTER_ACTION, SX_ROUTER_ACTION_MAX)

static __attribute__((__used__)) const char* sx_router_action_str[] = {
    "DROP",
    "TRAP",
    "FORWARD",
    "TRAP AND FORWARD",
    "SPAN",
};

#define SX_ROUTER_ACTION_STR_LEN (sizeof(sx_router_action_str) / sizeof(char*))

#define SX_ROUTER_ACTION_STR(index)                      \
    (SX_CHECK_MAX(index, SX_ROUTER_ACTION_STR_LEN - 1) ? \
     sx_router_action_str[index] : "UNKNOWN")

/**
 * sx_trap_attributes_t structure is used to store router trap attributes.
 */
typedef struct sx_trap_attributes {
    sx_trap_priority_t prio;
} sx_trap_attributes_t;

/**
 * Next hop weight.
 */
typedef uint32_t sx_next_hop_weight_t;

/*next hop offset as defined in next_hop_list given in sx_api_router_ecmp_set */
#define INVALID_NEXT_HOP_OFFSET 0xFFFFFFFF

/**
 * sx_next_hop_t is used to store a next hop data.
 */
typedef enum sx_next_hop_type {
    SX_NEXT_HOP_TYPE_IP = 1,
    SX_NEXT_HOP_TYPE_TUNNEL_ENCAP, /**< Next hop is through tunnel encapsulation **/
    SX_NEXT_HOP_TYPE_MC_CONTAINER, /**< Next hop is through multicast container **/
    SX_NEXT_HOP_TYPE_MIN = SX_NEXT_HOP_TYPE_IP,
    SX_NEXT_HOP_TYPE_MAX = SX_NEXT_HOP_TYPE_MC_CONTAINER,
} sx_next_hop_type_t;

static __attribute__((__used__)) const char* sx_next_hop_type_str[] = {
    "UNKNOWN",
    "IP",
    "Tunnel Encapsulation",
    "MC Container",
};

#define SX_NEXT_HOP_TYPE_STR_LEN (sizeof(sx_next_hop_type_str) / sizeof(sx_next_hop_type_str[0]))

#define SX_NEXT_HOP_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_NEXT_HOP_TYPE_STR_LEN - 1) ? \
     sx_next_hop_type_str[index] : "UNKNOWN")

typedef struct sx_ip_next_hop {
    sx_ip_addr_t          address;
    sx_router_interface_t rif;
} sx_ip_next_hop_t;

/**
 * sx_ip_next_hop_ip_tunnel_t is used to store tunnel_encap data.
 */
typedef struct sx_ip_next_hop_ip_tunnel {
    sx_ip_addr_t   underlay_dip;   /**< The IP of the Underlay Destination IP */
    sx_tunnel_id_t tunnel_id;     /**< The tunnel id for tunnel encapsulation */
} sx_ip_next_hop_ip_tunnel_t;

typedef struct sx_next_hop_key {
    sx_next_hop_type_t type;
    union {
        sx_ip_next_hop_t           ip_next_hop;
        sx_ip_next_hop_ip_tunnel_t ip_tunnel;
        sx_mc_container_id_t       mc_container;
    } next_hop_key_entry;
} sx_next_hop_key_t;

typedef struct sx_next_hop_data {
    sx_next_hop_weight_t weight; /**< Must not be zero */
    sx_router_action_t   action;
    sx_flow_counter_id_t counter_id;
    sx_trap_attributes_t trap_attr;
} sx_next_hop_data_t;

/* NOTE: SX_API_MESSAGE_SIZE_LIMIT is defined according to a 4k(4096) container of sx_next_hop_t,
 * changing sx_next_hop_t size, will cause SX_API_MESSAGE_SIZE_LIMIT update!
 */
typedef struct sx_next_hop {
    sx_next_hop_key_t  next_hop_key;
    sx_next_hop_data_t next_hop_data;
} sx_next_hop_t;

#endif /* __SX_NEXT_HOP_H__ */
