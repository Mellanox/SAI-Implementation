/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_COS_H__
#define __SXD_COS_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define SXD_COS_PORT_PRIO_MIN        (0x00000000)
#define SXD_COS_PORT_PRIO_MAX        (0x00000007)
#define SXD_COS_PORT_TRUST_LEVEL_MIN (0x00000000)
#define SXD_COS_PORT_TRUST_LEVEL_MAX (0x00000003)
#define SXD_COS_PORT_DSCP_MIN        (0x00000000)
#define SXD_COS_PORT_DSCP_MAX        (0x0000003F)
#define SXD_COS_TCLASS_MIN           (0x00000000)
#define SXD_COS_TCLASS_MAX           (0x00000007)
#define SXD_COS_TCLASS_GROUP_MIN     (0x00000000)
#define SXD_COS_TCLASS_GROUP_MAX     (0x0000000F)
#define SXD_COS_CBS_MIN              (0x00000000)
#define SXD_COS_CBS_MAX              (0x0000001E)
#define SXD_COS_EBS_MIN              (0x00000000)
#define SXD_COS_EBS_MAX              (0x0000001E)
#define SXD_COS_CIR_MIN              (0x00000000)
#define SXD_COS_CIR_MAX              (0x00FFFFFF)
#define SXD_COS_BW_ALLOCATION_MIN    (0x00000000)
#define SXD_COS_BW_ALLOCATION_MAX    (0x00000064)
#define SXD_COS_BW_VALUE_MIN         (0x00000000)
#define SXD_COS_BW_VALUE_MAX         (0x000000FF)


#define SXD_COS_MAX_POLICERS_PER_PORT (5)
#define SXD_COS_MAX_POLICERS_GLOBAL   (9)

/************************************************
 *  Macros
 ***********************************************/

#define SXD_COS_PORT_PRIO_CHECK_RANGE(PORT_PRIO) \
    SXD_CHECK_RANGE(SXD_COS_PORT_PRIO_MIN,       \
                    PORT_PRIO,                   \
                    SXD_COS_PORT_PRIO_MAX)

#define SXD_COS_PORT_TRUST_ID_CHECK_RANGE(PORT_TRUST_LEVEL) \
    SXD_CHECK_RANGE(SXD_COS_PORT_TRUST_LEVEL_MIN,           \
                    PORT_TRUST_LEVEL,                       \
                    SXD_COS_PORT_TRUST_LEVEL_MAX)

#define SXD_COS_PORT_DSCP_CHECK_RANGE(PORT_DSCP) \
    SXD_CHECK_RANGE(SXD_COS_PORT_DSCP_MIN,       \
                    PORT_DSCP,                   \
                    SXD_COS_PORT_DSCD_MAX)

#define SXD_COS_TCLASS_CHECK_RANGE(TCLASS) \
    SXD_CHECK_RANGE(SXD_COS_TCLASS_MIN,    \
                    TCLASS,                \
                    SXD_COS_TCLASS_MAX)

#define SXD_COS_TCLASS_GROUP_CHECK_RANGE(TCLASS_GROUP) \
    SXD_CHECK_RANGE(SXD_COS_TCLASS_GROUP_MIN,          \
                    TCLASS_GROUP,                      \
                    SXD_COS_TCLASS_GROUP_MAX)

#define SXD_COS_CBS_CHECK_RANGE(CBS) \
    SXD_CHECK_RANGE(SXD_COS_CBS_MIN, \
                    CBS,             \
                    SXD_COS_CBS_MAX)

#define SXD_COS_EBS_CHECK_RANGE(EBS) \
    SXD_CHECK_RANGE(SXD_COS_EBS_MIN, \
                    EBS,             \
                    SXD_COS_EBS_MAX)

#define SXD_COS_CIR_CHECK_RANGE(CIR) \
    SXD_CHECK_RANGE(SXD_COS_CIR_MIN, \
                    CIR,             \
                    SXD_COS_CIR_MAX)

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Port priority.
 */
typedef uint8_t sxd_cos_port_priority_t;

/**
 * sxd_cos_trust_level_t enumerated type is used to store port
 * trust level.
 */
typedef enum sxd_cos_trust_level {
    SXD_COS_TRUST_LEVEL_PORT_E = 0,
    SXD_COS_TRUST_LEVEL_USER_E,
    SXD_COS_TRUST_LEVEL_DSCP_E,
    SXD_COS_TRUST_LEVEL_BOTH_E,
    SXD_COS_TRUST_LEVEL_MIN_E = SXD_COS_TRUST_LEVEL_PORT_E,
    SXD_COS_TRUST_LEVEL_MAX_E = SXD_COS_TRUST_LEVEL_BOTH_E,
} sxd_cos_trust_level_e;

/**
 * DSCP.
 */
typedef uint8_t sxd_cos_dscp_t;

/**
 * sxd_cos_prio_dscp_table_t structure is used to store priority
 * regeneration table.
 */
typedef struct sxd_cos_prio_dscp_table {
    /*<! map between dscp and priority */
    sxd_cos_port_priority_t port_priority[SXD_COS_PORT_DSCP_MAX + 1];
} sxd_cos_prio_dscp_table_t;

/**
 * Traffic class.
 */
typedef uint8_t sxd_cos_traffic_class_t;

/**
 * Traffic class group.
 */
typedef uint8_t sxd_cos_traffic_class_group_t;

/**
 * sxd_cos_tclass_prio_regen_table_t structure is used to store
 * traffic class regeneration table.
 */
typedef struct sxd_cos_tclass_prio_regen_table {
    /*<! map between priority and regenerated traffic class */
    sxd_cos_traffic_class_t traffic_class[SXD_COS_PORT_PRIO_MAX + 1];
} sxd_cos_tclass_prio_regen_table_t;

/**
 * sxd_cos_tclass_prio_regen_table_t structure is used to store
 * traffic class regeneration table.
 */
typedef struct sxd_cos_stacking_tclass_regen_table {
    /*<! map between traffic class i and regenerated traffic class */
    sxd_cos_traffic_class_t traffic_class[SXD_COS_TCLASS_MAX + 1];
} sxd_cos_stacking_tclass_regen_table_t;

/**
 * sxd_cos_tc_group_id_t enumerated type is used to store
 * traffic class groups.
 */
typedef enum sxd_cos_tc_group_id {
    SXD_COS_TC_GROUP_ID_0_E = 0,
    SXD_COS_TC_GROUP_ID_1_E = 1,
    SXD_COS_TC_GROUP_ID_2_E = 2,
    SXD_COS_TC_GROUP_ID_3_E = 3,
    SXD_COS_TC_GROUP_ID_4_E = 4,
    SXD_COS_TC_GROUP_ID_5_E = 5,
    SXD_COS_TC_GROUP_ID_6_E = 6,
    SXD_COS_TC_GROUP_ID_7_E = 7,
    SXD_COS_TC_GROUP_ID_8_E = 8,
    SXD_COS_TC_GROUP_ID_9_E = 9,
    SXD_COS_TC_GROUP_ID_10_E = 10,
    SXD_COS_TC_GROUP_ID_11_E = 11,
    SXD_COS_TC_GROUP_ID_12_E = 12,
    SXD_COS_TC_GROUP_ID_13_E = 13,
    SXD_COS_TC_GROUP_ID_14_E = 14,
    SXD_COS_TC_GROUP_ID_15_E = 15,
    SXD_COS_TC_GROUP_ID_16_E = 16,
    SXD_COS_TC_GROUP_ID_MIN_E = SXD_COS_TC_GROUP_ID_0_E,
    SXD_COS_TC_GROUP_ID_MAX_E = SXD_COS_TC_GROUP_ID_16_E
} sxd_cos_tc_group_id_e;


/**
 * sxd_cos_ets_sub_group_id_t enumerated type is used to store
 * sub group id.
 */
typedef enum sxd_cos_ets_sub_group_id {
    SXD_COS_ETS_SUB_GROUP_ID_0_E = 0, /**< sub group id 0 */
    SXD_COS_ETS_SUB_GROUP_ID_1_E = 1, /**< sub group id 1 */
    SXD_COS_ETS_SUB_GROUP_ID_2_E = 2, /**< sub group id 2 */
    SXD_COS_ETS_SUB_GROUP_ID_3_E = 3, /**< sub group id 3 */
    SXD_COS_ETS_SUB_GROUP_ID_4_E = 4, /**< sub group id 4 */
    SXD_COS_ETS_SUB_GROUP_ID_5_E = 5, /**< sub group id 5 */
    SXD_COS_ETS_SUB_GROUP_ID_6_E = 6, /**< sub group id 6 */
    SXD_COS_ETS_SUB_GROUP_ID_7_E = 7, /**< sub group id 7 */
    SXD_COS_ETS_SUB_GROUP_ID_15_E = 15, /**< sub group id 15 */
    SXD_COS_ETS_SUB_GROUP_ID_MIN_E = SXD_COS_ETS_SUB_GROUP_ID_0_E, /**< minimum sub group id  */
    SXD_COS_ETS_SUB_GROUP_ID_MAX_E = SXD_COS_ETS_SUB_GROUP_ID_15_E /**< maximum sub group id */
} sxd_cos_ets_sub_group_id_e;

/**
 * sxd_cos_ets_group_id_t enumerated type is used to store
 * group id.
 */
typedef enum sxd_cos_ets_group_id {
    SXD_COS_ETS_GROUP_ID_0_E = 0, /**< group id 0 */
    SXD_COS_ETS_GROUP_ID_1_E = 1, /**< group id 1 */
    SXD_COS_ETS_GROUP_ID_2_E = 2, /**< group id 2 */
    SXD_COS_ETS_GROUP_ID_3_E = 3, /**< group id 3 */
    SXD_COS_ETS_GROUP_ID_4_E = 4, /**< group id 4 */
    SXD_COS_ETS_GROUP_ID_5_E = 5, /**< group id 5 */
    SXD_COS_ETS_GROUP_ID_6_E = 6, /**< group id 6 */
    SXD_COS_ETS_GROUP_ID_7_E = 7, /**< group id 7 */
    SXD_COS_ETS_GROUP_ID_MIN_E = SXD_COS_ETS_GROUP_ID_0_E, /**< minimum group id  */
    SXD_COS_ETS_GROUP_ID_MAX_E = SXD_COS_ETS_GROUP_ID_7_E /**< maximum group id */
} sxd_cos_ets_group_id_e;

/**
 * sxd_cos_bw_units_t enumerated type is used to store bandwidth
 * units.
 */
typedef enum sxd_cos_bw_units {
    SXD_COS_BW_UNITS_DISABLED_E = 0,
    SXD_COS_BW_UNITS_100_MBPS_E = 3,
    SXD_COS_BW_UNITS_1_GBPS_E = 4
} sxd_cos_bw_units_e;

/**
 * sxd_cos_ets_tc_data_t structure is used to store ETS data per
 * traffic class.
 */
typedef struct sxd_cos_ets_tc_data {
    uint8_t                       group_update;
    uint8_t                       bw_update;
    uint8_t                       rate_update;
    sxd_cos_traffic_class_group_t group;
    uint8_t                       bw_allocation;
    sxd_cos_bw_units_e            max_bw_units;
    uint8_t                       max_bw_value;
} sxd_cos_ets_tc_data_t;

/**
 * Policer ID.
 */
typedef uint8_t sxd_cos_policer_id_t;

/**
 * sxd_cos_policer_type_t enumerated type is used to store
 * policer type.
 */
typedef enum sxd_cos_policer_type {
    SXD_COS_POLICER_TYPE_UNICAST_E = (1 << 0),
    SXD_COS_POLICER_TYPE_MULTICAST_E = (1 << 1),
    SXD_COS_POLICER_TYPE_BROADCAST_E = (1 << 2),
    SXD_COS_POLICER_TYPE_UNKNOWN_UNICAST_E = (1 << 3),
    SXD_COS_POLICER_TYPE_UNKNOWN_MULTICAST_E = (1 << 4),
    SXD_COS_POLICER_TYPE_ACL_E = (1 << 5),
    SXD_COS_POLICER_TYPE_CPU_E = (1 << 6)
} sxd_cos_policer_type_e;

/**
 * sxd_cos_policer_operation_t enumerated type is used to store
 * policer operation.
 */
typedef enum sxd_cos_policer_operation {
    SXD_COS_POLICER_OPERATION_BIND_E = 0,
    SXD_COS_POLICER_OPERATION_UPDATE_E = 1,
    SXD_COS_POLICER_OPERATION_UNBIND_E = 2
} sxd_cos_policer_operation_e;

/**
 * sxd_cos_policer_operation_t enumerated type is used to store
 * policer operation.
 */
typedef enum sxd_cos_policer_meter {
    SXD_COS_POLICER_METER_BYTES_SEC_E = 1,
    SXD_COS_POLICER_METER_PACKETS_SEC_E = 0,
} sxd_cos_policer_meter_e;

/**
 * sxd_cos_policer_action_t enumerated type is used to store
 * policer action.
 */
typedef enum sxd_cos_policer_action {
    SXD_COS_POLICER_ACTION_FORWARD_E = 0,
    SXD_COS_POLICER_ACTION_INCREASE_DROP_PRECEDENCE_E = 1,
    SXD_COS_POLICER_ACTION_PACKET_DISCARD_E = 2
} sxd_cos_policer_action_e;

/**
 * sxd_cos_arbitration_t enumerated type is used to store
 * arbitration types.
 */
typedef enum sxd_cos_arbitration {
    SXD_COS_ARBITRATION_DWRR_E = 0,
    SXD_COS_ARBITRATION_SP_E = 1
} sxd_cos_arbitration_e;

/**
 * PFC thresholds.
 */
typedef uint8_t sxd_cos_pfc_threshold_t;

/**
 * sxd_cos_policer_bind_type_t enumerated type is used to store
 * policer bind types
 */
typedef enum sxd_cos_policer_bind_type {
    SXD_COS_POLICER_BIND_TYPE_PORT_E = 0,
    SXD_COS_POLICER_BIND_TYPE_GLOBAL_E = 1,

    SXD_COS_POLICER_BIND_TYPE_MIN_E = SXD_COS_POLICER_BIND_TYPE_PORT_E,
    SXD_COS_POLICER_BIND_TYPE_MAX_E = SXD_COS_POLICER_BIND_TYPE_GLOBAL_E
} sxd_cos_policer_bind_type_e;

/**
 * sxd_cos_pcp_t structure is used to store the PCP values.
 */
typedef uint8_t sxd_cos_pcp_t;

/**
 * sxd_cos_dei_t structure is used to store the DEI bit.
 */
typedef uint8_t sxd_cos_dei_t;

/**
 * sxd_cos_ieee_prio_t structure is used to store the IEEE priority values.
 */
typedef uint8_t sxd_cos_ieee_prio_t;

/**
 * sxd_cos_pcp_dei_t structure is used to store PCP and DEI values.
 */
typedef struct sxd_cos_pcp_dei {
    sxd_cos_pcp_t pcp;
    sxd_cos_dei_t dei;
} sxd_cos_pcp_dei_t;

/**
 * sxd_cos_rewrite_enable_t structure is used to store PCP/DEI,
 * DSCP and EXP rewrite enable values.
 */
typedef struct sxd_cos_rewrite_enable {
    boolean_t pcp_dei;
    boolean_t dscp;
    boolean_t exp;
} sxd_cos_rewrite_enable_t;

/**
 * sxd_cos_color_t structure is used to store the traffic color values.
 */
typedef uint8_t sxd_cos_color_t;

/**
 * sxd_cos_priority_color_t structure is used to store switch priority and color values.
 */
typedef struct sxd_cos_priority_color {
    sxd_cos_port_priority_t priority;
    sxd_cos_color_t         color;
} sxd_cos_priority_color_t;

/**
 * sxd_cos_exp_t structure is used to store the EXP values.
 */
typedef uint8_t sxd_cos_exp_t;

/**
 * sxd_cos_ecn_t structure is used to store the ECN values.
 */
typedef uint8_t sxd_cos_ecn_t;

typedef enum sxd_cos_pcp_dei_rewrite {
    SXD_COS_PCP_DEI_REWRITE_PRESERVE_E = 0,
    SXD_COS_PCP_DEI_REWRITE_DISABE_E = 2,
    SXD_COS_PCP_DEI_REWRITE_ENABLE_E = 3
} sxd_cos_pcp_dei_rewrite_e;

/**
 * sxd_cos_ets_ptp_shaper_port_speed enumerator is used to note port speed
 */
typedef enum sxd_cos_ets_ptp_port_speed {
    SXD_COS_ETS_PTP_PORT_SPEED_100M = 0,                              /**< 100M */
    SXD_COS_ETS_PTP_PORT_SPEED_1000M = 1,                             /**< 1G */
    SXD_COS_ETS_PTP_PORT_SPEED_10G = 2,                               /**< 10G */
    SXD_COS_ETS_PTP_PORT_SPEED_25G = 3,                               /**< 25G */
    SXD_COS_ETS_PTP_PORT_SPEED_40G = 4,                               /**< 40G */
    SXD_COS_ETS_PTP_PORT_SPEED_50G = 5,                               /**< 50G */
    SXD_COS_ETS_PTP_PORT_SPEED_100G = 6,                              /**< 100G */
    SXD_COS_ETS_PTP_PORT_SPEED_MAX = SXD_COS_ETS_PTP_PORT_SPEED_100G, /**< MAX */
    SXD_COS_ETS_PTP_PORT_SPEED_1G = SXD_COS_ETS_PTP_PORT_SPEED_1000M, /**< 1G */
} sxd_cos_ets_ptp_port_speed_e;
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* __SXD_COS_H__ */
