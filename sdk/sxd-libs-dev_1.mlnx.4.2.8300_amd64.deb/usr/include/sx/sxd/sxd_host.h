/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_HOST_H__
#define __SXD_HOST_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

#define SXD_EMAD_HOST_MAX_NUM_OF_DR_PATHS 64

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef enum sxd_host_interface_type {
    SXD_HOST_IF_PATH_TYPE_LOCAL_E = 0,
    SXD_HOST_IF_PATH_TYPE_STACKING_EN_E = 1,
    SXD_HOST_IF_PATH_TYPE_DIRECT_ROUTE_E = 2,
    SXD_HOST_IF_PATH_TYPE_ETHERNET_E = 3,

    SXD_HOST_IF_PATH_TYPE_NULL_E = 15,

    SXD_HOST_IF_TYPE_MIN_E = SXD_HOST_IF_PATH_TYPE_LOCAL_E,
    SXD_HOST_IF_TYPE_MAX_E = SXD_HOST_IF_PATH_TYPE_NULL_E
} sxd_host_interface_path_type_e;

/*
 * Mirror action field in HTGT
 */
typedef enum sxd_host_interface_mirror_action {
    SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_CPU = 0,
    SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_CPU_AND_MIRROR = 1,
    SXD_HOST_IF_MIRROR_ACTION_TRAP_TO_MIRROR = 2,
} sxd_host_interface_mirror_action_t;

/************************************************
 *  Defines
 ***********************************************/

#define SXD_HOST_MAX_NUM_OF_DR_PATHS 64

#define SXD_HOST_IF_TYPE_DEFAULT       SXD_HOST_IF_TYPE_LOCAL
#define SXD_HOST_IF_TYPE_LOCAL_MIN_MAX SXD_HOST_IF_TYPE_MIN_E, SXD_HOST_IF_TYPE_MAX_E
#define SXD_HOST_IF_TYPE_CHECK_RANGE(type) SXD_CHECK_RANGE(SXD_HOST_IF_TYPE_MIN, type, SXD_HOST_IF_TYPE_MAX)

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct sxd_host_interface_local_path {
    uint8_t cpu_tclass;
    uint8_t rdq;
} sxd_host_interface_local_path_t;

typedef struct sxd_host_interface_stacking_path {
    uint8_t  rdq;
    uint8_t  cpu_tclass;
    uint8_t  stacking_tclass;
    uint16_t cpu_system_port;
} sxd_host_interface_stacking_path_t;

typedef struct sxd_host_interface_direct_route_path {
    uint8_t direct_route_ptr;
} sxd_host_interface_direct_route_t;

typedef struct sxd_host_interface_ethernet_path {
    uint64_t dmac;
    uint16_t vid;
} sxd_host_interface_ethernet_path_t;

typedef union sxd_host_interface_path {
    sxd_host_interface_local_path_t    local_path;
    sxd_host_interface_stacking_path_t stacking_path;
    sxd_host_interface_direct_route_t  direct_route;
    sxd_host_interface_ethernet_path_t ethernet_path;
} sxd_host_interface_path_t;


#endif /* __SXD_HOST_H__ */
