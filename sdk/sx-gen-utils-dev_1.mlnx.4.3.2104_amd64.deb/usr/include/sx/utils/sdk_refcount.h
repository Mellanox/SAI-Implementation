/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __SDK_REFCOUNT_H__
#define __SDK_REFCOUNT_H__

#include <stdint.h>
#include "sx/utils/sx_utils_status.h"
#include "sx/utils/dbg_utils.h"

/************************************************
 *  Local Defines
 ***********************************************/

#define REFERENCED_NAME_MAX_LEN 65
#define REFERENCE_NAME_MAX_LEN  65
#define DELETE_ID_INVALID       0xFFFFFFFFFFFFFFFF

/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

/* This function will be used to print a reference name into a buffer. These functions will
 * be provided by the users of reference functions.
 * name_buf  - the buffer into which to print the reference name.
 * name_size - the size of the buffer pointed by name_buf.
 * data_p    - the data stored in the reference object that should be used for printing the reference name.
 *             usually a cast will be needed in order to work with the data within.
 * return    - pointer to a constant string containing the resulting name string. Usually,
 *             it should return name_buf.
 */
typedef const char *(*cl_ref_print_func_p)(char *name_buf, size_t name_size, void *data_p);

/* This function will be used to delete entities that support Garbage Collection. These functions will
 * be provided by the users of reference functions.
 * id        - The ID of the entity to be deleted.
 * return    - status
 */
typedef sx_utils_status_t (*cl_delete_func_p)(uint64_t id);

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/
typedef uint64_t sdk_refcount_t;
typedef uint64_t sdk_ref_t;

/* This structure will be used to transfer the info needed to print the reference name.
 * print_func_p - Pointer to the function created by the user that will actually print the reference name (mandatory).
 * ref_data_p -   Pointer to the data needed in order to print the correct name using the print_func_p.
 *                Any type of data is acceptable as long as it's not larger than MAX_REFERENCE_DATA_SIZE.
 *                The data will be copied into the ref object and will be transferred as a parameter to print_func_p.
 * data_size  -   The size of the data pointed by ref_data_p.
 * result_str -
 */
typedef struct reference_name_data {
    cl_ref_print_func_p print_func_p;
    void              * ref_data_p;
    size_t              data_size;
    char                result_str[REFERENCE_NAME_MAX_LEN * 2];
} ref_name_data_t;

/* This structure will be used to delete entities that reached a refcount of 0 and are pending deletion.
 * delete_func_p - Pointer to the function created by the user that will actually delete the entity.
 * id            - the ID of the entity to be deleted.
 */
typedef struct reference_delete_data {
    cl_delete_func_p delete_func_p;
    uint64_t         id;
} ref_delete_data_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes the refcount infrastructure.
 */
sx_utils_status_t sdk_refcount_system_init(void);

/**
 * Deinitialize the refcount infrastructure.
 *
 * @param[in] is_forced - whether the function should or should not fail
 *                    on open references.
 */
sx_utils_status_t sdk_refcount_system_deinit(boolean_t is_forced);

/**
 * debug dump function. Prints its internal data types, which includes:
 *  - All the referenced objects that are currently alive in the system.
 *  - All the objects referencing each referenced object.
 *
 * @param[in] stream - the output stream to which the output will be directed.
 */
void sdk_refcount_debug_dump(FILE* stream);

/**
 * The init refcount function.
 * This function is used to initialize a sdk_refcount_t object.
 *
 * Memory consumption: the memory consumption cost of that infrastructure is mainly the
 * REFERENCE_NAME_MAX_LEN bytes per reference of an object.
 *
 * @param[in] refcount_p- the refcount to initialize.
 * @param[in] referended_name - the name of the object that contain this refcount object.
 *                              the name is restricted to size of REFERENCED_NAME_MAX_LEN
 */
sx_utils_status_t sdk_refcount_init(sdk_refcount_t          *refcount_p,
                                    const ref_name_data_t   *ref_name_data,
                                    const ref_delete_data_t *delete_data_p);

/**
 * Deinitialize a sdk_refcount_t object, and free its memory.
 * If is_forced == FALSE, the function will fail deinitialize a refcount object if there are objects
 * referencing A.
 * it (refcount > 0).
 *
 * @param[in] refcount_p - the refcount to deinitialize.
 * @param[in] is_forced - whether to fail on open references
 */
sx_utils_status_t sdk_refcount_deinit(sdk_refcount_t *refcount_p, boolean_t is_forced);

/**
 * Add a reference to a refcount object.
 * This function will return the reference handle used to free that reference.
 *
 * @param[in]  refcount_p - the refcount object that should be increased
 * @param[in]  reference_name - the name of the reference that should be used.
 *                              the name is restricted to size of REFERENCE_NAME_MAX_LEN.
 *                              this name should be informative and represent the holding's object
 *                              name.
 * @param[out] reference - the newly created reference.
 */
sx_utils_status_t sdk_refcount_inc(sdk_refcount_t        *refcount_p,
                                   const ref_name_data_t *ref_name_data,
                                   sdk_ref_t             *reference);

/**
 * Removes a reference from a refcount object.
 * This function gets the reference handle got by the sdk_refcount_inc function.
 *
 * @param[in] refcount_p - the refcount object that should be increased
 * @param[in] reference - the reference handle that was returned by sdk_refcount_inc
 */
sx_utils_status_t sdk_refcount_dec(sdk_refcount_t *refcount_p, const sdk_ref_t* reference);

/**
 * Renames a reference.
 * This function will change the name of the specific reference, as was set by the sdk_refcount_inc function.
 *
 * @param[in] reference - the reference to rename.
 * @param[in] reference_name - the new name of the reference that should be used.
 *                             the name is restricted to size of REFERENCE_NAME_MAX_LEN
 */
sx_utils_status_t sdk_refcount_rename_ref(const sdk_ref_t *reference, const ref_name_data_t *ref_name_data);

/**
 * Return the reference count of a specific sdk_refcount_t object, as if the number of
 * objects that increased the reference or the number of reference handles given.
 *
 * @param[in]  refcount_p - the refcount object
 * @param[out] val - the output value.
 */
sx_utils_status_t sdk_refcount_get(sdk_refcount_t *refcount_p, int32_t* val);

/**
 * Return a name of all reference for refcount object.
 *
 * @param[in] refcount_p - the reference to rename.
 * @param[in] buf_size  - size of output buffer for reference
 *       name
 * @param[out] reference_name - the name of all references.
 *
 */
sx_utils_status_t sdk_refcount_getname_ref(sdk_refcount_t *refcount_p, uint32_t buf_size, char* references_name);


/**
 * Prints the resulting reference name the result_str buffer inside the structure itself.
 *
 * @param[in] ref_name_data - pointer to ref_name_data_t that contains the information to print.
 *
 * Returns a pointer to the result_str member of the ref_name_data which contains the results string.
 * NOTE: This functions does not check for parameters' validity.
 */
const char* print_reference_name(ref_name_data_t *ref_name_data);


#endif /* __SDK_REFCOUNT_H__ */
