/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

/*
 * NOTE:
 * sx_router_next_hop_base.h is a base file with common types and definitions used by router next hops.
 * The various next hops types are defined in sx_next_hop.h
 * Avoid from adding #include of additional sx h files that further includes sx_next_hop.h (it will cause cyclic dependency)
 *
 */
#ifndef __SX_ROUTER_NEXT_HOP_BASE_H__
#define __SX_ROUTER_NEXT_HOP_BASE_H__

#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_trap_id.h>


/** next hop offset as defined in next_hop_list given in sx_api_router_ecmp_set */
#define INVALID_NEXT_HOP_OFFSET 0xFFFFFFFF


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * Router Interface ID.
 */
typedef uint16_t sx_router_interface_t;

/**
 * ECMP Container ID.
 */
typedef uint32_t sx_ecmp_id_t;


#define FOREACH_ROUTER_ACTION(F)                                                                                  \
    F(SX_ROUTER_ACTION_DROP, "Drop")                                                                              \
    F(SX_ROUTER_ACTION_TRAP, "Trap")                                                                              \
    F(SX_ROUTER_ACTION_FORWARD, "Forward")                                                                        \
    F(SX_ROUTER_ACTION_MIRROR /**< This value is deprecated, please use SX_ROUTER_ACTION_TRAP_FORWARD instead */, \
      "Trap and Forward")                                                                                         \
    F(SX_ROUTER_ACTION_TRAP_FORWARD = SX_ROUTER_ACTION_MIRROR, "")                                                \
    F(SX_ROUTER_ACTION_SPAN, "Span")                                                                              \
    F(SX_ROUTER_ACTION_MIN = SX_ROUTER_ACTION_DROP, "")                                                           \
    F(SX_ROUTER_ACTION_MAX = SX_ROUTER_ACTION_SPAN, "")
/**
 * sx_router_action_t enumerated type is used to note the route action.
 */
typedef enum sx_router_action {
    FOREACH_ROUTER_ACTION(SX_GENERATE_ENUM)
} sx_router_action_t;

#define SX_ROUTER_ACTION_CHECK_RANGE(ROUTER_ACTION) \
    SX_CHECK_MAX(ROUTER_ACTION, SX_ROUTER_ACTION_MAX)

/**
 * sx_trap_attributes_t structure is used to store router trap attributes.
 */
typedef struct sx_trap_attributes {
    sx_trap_priority_t prio;
} sx_trap_attributes_t;

/**
 * Next hop weight.
 */
typedef uint32_t sx_next_hop_weight_t;

typedef struct sx_ip_next_hop {
    sx_ip_addr_t          address;
    sx_router_interface_t rif;
} sx_ip_next_hop_t;

#endif /* __SX_ROUTER_NEXT_HOP_BASE_H__ */
