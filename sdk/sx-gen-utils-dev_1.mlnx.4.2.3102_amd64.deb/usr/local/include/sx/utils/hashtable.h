/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef _HASHTABLE_H_
#define _HASHTABLE_H_

#include "complib/cl_qlist.h"

/** @file hashtable.h
 *  Defines a generic hashtable implementation in C
 *
 *  This implementation provides sub-implementations the freedom to define the table key and the contents of the table entry, through the hashtable_ops_t structure
 *  The only requirement is that entries may be referenced as cl_list_item_t* pointers (For example: an entry is a struct that contains a cl_list_item_t as a member)
 *  The hashtable holds on to any entry pointer which is added to it. When the entry is removed from the table and no longer referenced, free_func() is called to notify about this.
 */


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


/** Specific hashtable callbacks
 *  This struct defines a sub-implementation of the hashtable with specific key and entry definitions
 */
typedef struct {
    /** Number of buckets in the hashtable */
    uint32_t num_of_buckets;
    /** Hash the key part of a hashtable entry
     *  This function is expected to run in O(1), e.g. bound by constant time
     *  @param entry A hashtable entry
     *  @return A hash value (bucket number) between 0 and (num_of_buckets-1), inclusive
     */
    uint32_t (*hash_func)(cl_list_item_t* entry);
    /** Free a hashtable entry which is not needed (or referenced) anymore
     *  This function is expected to undo any resource allocation which is associated with an entry, before it was passed to hashtable_add()
     *  e.g., if you always malloc() entries before calling hashtable_add(), then this function should call free()
     *  @param entry A hashtable entry which is not needed (or referenced) anymore by the table
     */
    void (*free_func)(cl_list_item_t* entry);
    /** Compare the key parts of two entries
     *  This function is expected to run in O(1) time, and is *not* used for sorting, only for equality
     *  @param entry1 A pointer to a hashtable entry
     *  @param entry2 Another pointer to a hashtable entry. This pointer is different than entry1
     *  @return CL_SUCCESS if equal, Any other value otherwise
     */
    cl_status_t (*cmp_func)(cl_list_item_t* entry1, cl_list_item_t* entry2);
} hashtable_ops_t;

/** Forward declaration for an internal struct */
typedef struct hashtable hashtable_t;

/** Create a new initialized instance of an empty hashtable, with specific sub-implemenetation
 *  @param ops Definition of a sub-implemenetation
 *  @return A pointer to a new initialized empty hashtable
 */
hashtable_t* hashtable_alloc(hashtable_ops_t* ops);

/** Destroy and clean-up an existing hashtable
 *  This function also frees all entries in the table
 *  @param table A pointer to a hashtable to delete
 */
void hashtable_free(hashtable_t* table);

/** Add a new pre-allocated entry to the table
 *  The entry must have all of its key members filled prior to calling this function.
 *  After adding an entry to the table, its key members must *not* be modified!
 *  @param table An existing hashtable
 *  @param table_entry A new table entry
 *  @return CL_SUCCESS if successful, CL_DUPLICATE if an entry with the same key already exists in the table
 */
cl_status_t hashtable_add_entry(hashtable_t* table, cl_list_item_t* table_entry);

/** Delete an entry with a given key in the table
 *  The specified entry-key must have all of its key members filled prior to calling this function.
 *  The entry to delete is taken from the hashtable itself. It is by definition an entry pointer which was passed to hashtable_add().
 *  e.g. It might not be the same pointer as table_entry_key.
 *  @param table An existing hashtable
 *  @param table_entry A table_entry struct which specifies the key to delete
 *  @return CL_SUCCESS if successful, CL_NOT_FOUND if no entry with this key exists in the hashtable
 */
cl_status_t hashtable_delete_entry(hashtable_t* table, cl_list_item_t* table_entry_key);

/** Look-up an entry with a given key in the table
 *  The specified entry-key must have all of its key members filled prior to calling this function.
 *  The returned entry is taken from the hashtable itself. It is by definition an entry pointer which was passed to hashtable_add().
 *  e.g. It might not be the same pointer as table_entry_key.
 *  @param table An existing hashtable
 *  @param table_entry A table_entry struct which specifies the key to look-up
 *  @return if successful, non-NULL pointer to the entry in the table.  NULL if no entry with this key exists in the hashtable
 */
cl_list_item_t* hashtable_lookup(hashtable_t* table, cl_list_item_t* table_entry_key);

/** Retrieve the amount of items in the hashtable
 *  @param table An existing hashtable
 *  @return The amount of items in the hash table
 */
uint32_t hashtable_count(hashtable_t* table);

/** Callback function for hashtable entry enumeration
 *  This callback is called by hashtable_enum() for each an every entry in the hashtable
 *  Note: The order of entries passed to this function is unpredictable, and depends on both the hash function and the order of adding/removing entries in the table at runtime
 *  @param table_entry A hashtable entry
 *  @param cbparam The callback parameter which was passed to hashtable_enum()
 *  @return CL_NOT_DONE to continue, and eventaully return NULL from hashtable_enum if exhausted. Or any other value to abort enumeration and return the table_entry pointer from hashtable_enum()
 */
typedef cl_status_t (*hashtable_enum_cb)(cl_list_item_t* table_entry, void* cbparam);

/** Enumerate all entries in the hashtable
 *  @param table A hashtable
 *  @param cb A callback function which is called once for each entry in the table
 *  @param cbparam A callback parameter which is passed on to the callback function
 *  @return A non-NULL pointer to the entry for which the callback returned not CL_NOT_DONE. NULL if the callback returned CL_NOT_DONE every time.
 */
cl_list_item_t* hashtable_enum_entries(hashtable_t* table, hashtable_enum_cb cb, void* cbparam);

#endif /* _HASHTABLE_H_ */
