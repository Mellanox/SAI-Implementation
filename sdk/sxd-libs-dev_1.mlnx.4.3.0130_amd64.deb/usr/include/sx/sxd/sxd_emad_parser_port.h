/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_PORT_H__
#define __SXD_EMAD_PARSER_PORT_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_port_data.h>
#include <sx/sxd/sxd_emad_port_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_port_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                  IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_spmcr(sxd_emad_spmcr_data_t *spmcr_data,
                                  sxd_emad_spmcr_reg_t  *spmcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_spmcr(sxd_emad_spmcr_data_t *spmcr_data,
                                    sxd_emad_spmcr_reg_t  *spmcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pcap(sxd_emad_pcap_data_t *pcap_data,
                                 sxd_emad_pcap_reg_t  *pcap_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pcap(sxd_emad_pcap_data_t *pcap_data,
                                   sxd_emad_pcap_reg_t  *pcap_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pmlp(sxd_emad_pmlp_data_t *pmlp_data,
                                 sxd_emad_pmlp_reg_t  *pmlp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pmlp(sxd_emad_pmlp_data_t *pmlp_data,
                                   sxd_emad_pmlp_reg_t  *pmlp_reg);

/**
 * This function converts pmcr sxd structure to EMAD pmcr structure.
 *
 * @param[in] pmcr_data - pointer to sxd_emad_pmcr_data_t
 * @param[out] pmcr_reg - pointer to sxd_emad_pmcr_reg_t
 */
sxd_status_t sxd_emad_parse_pmcr(sxd_emad_pmcr_data_t *pmcr_data,
                                 sxd_emad_pmcr_reg_t  *pmcr_reg);

/**
 *  This function converts EMAD pmcr structure to pmcr sxd structure.
 *
 * @param[out] pmcr_data - pointer to sxd_emad_pmcr_data_t
 * @param[in] pmcr_reg - pointer to sxd_emad_pmcr_reg_t
 */
sxd_status_t sxd_emad_deparse_pmcr(sxd_emad_pmcr_data_t *pmcr_data,
                                   sxd_emad_pmcr_reg_t  *pmcr_reg);

/**
 * This function converts pfsc sxd structure to EMAD pfsc structure.
 *
 * @param[in] pfsc_data - pointer to sxd_emad_pfsc_data_t
 * @param[out] pfsc_reg - pointer to sxd_emad_pfsc_reg_t
 */
sxd_status_t sxd_emad_parse_pfsc(sxd_emad_pfsc_data_t *pfsc_data,
                                 sxd_emad_pfsc_reg_t  *pfsc_reg);

/**
 *  This function converts EMAD pfsc structure to pfsc sxd structure.
 *
 * @param[out] pfsc_data - pointer to sxd_emad_pfsc_data_t
 * @param[in] pfsc_reg - pointer to sxd_emad_pfsc_reg_t
 */
sxd_status_t sxd_emad_deparse_pfsc(sxd_emad_pfsc_data_t *pfsc_data,
                                   sxd_emad_pfsc_reg_t  *pfsc_reg);

/**
 * This function converts pmmp sxd structure to EMAD pmmp structure.
 *
 * @param[in] pmmp_data - pointer to sxd_emad_pmmp_data_t
 * @param[out] pmmp_reg - pointer to sxd_emad_pmmp_reg_t
 */
sxd_status_t sxd_emad_parse_pmmp(sxd_emad_pmmp_data_t *pmmp_data,
                                 sxd_emad_pmmp_reg_t  *pmmp_reg);

/**
 *  This function converts EMAD pmmp structure to pmmp sxd structure.
 *
 * @param[out] pmmp_data - pointer to sxd_emad_pmmp_data_t
 * @param[in] pmmp_reg - pointer to sxd_emad_pmmp_reg_t
 */
sxd_status_t sxd_emad_deparse_pmmp(sxd_emad_pmmp_data_t *pmmp_data,
                                   sxd_emad_pmmp_reg_t  *pmmp_reg);

/**
 *  This function converts EMAD sbcm structure to sbcm sxd structure.
 *
 * @param[out] sbcm_data - pointer to sxd_emad_sbcm_data_t
 * @param[in] sbcm_reg - pointer to sxd_emad_sbcm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sbcm(sxd_emad_sbcm_data_t *sbcm_data,
                                 sxd_emad_sbcm_reg_t  *sbcm_reg);

/**
 *  This function converts sbcm sxd structure to EMAD sbcm structure.
 *
 * @param[out] sbcm_data - pointer to sxd_emad_sbcm_data_t
 * @param[in] sbcm_reg - pointer to sxd_emad_sbcm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sbcm(sxd_emad_sbcm_data_t *sbcm_data,
                                   sxd_emad_sbcm_reg_t  *sbcm_reg);

/**
 *  This function converts EMAD sbpm structure to sbpm sxd structure.
 *
 * @param[out] sbpm_data - pointer to sxd_emad_sbpm_data_t
 * @param[in] sbpm_reg - pointer to sxd_emad_sbpm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sbpm(sxd_emad_sbpm_data_t *sbpm_data,
                                 sxd_emad_sbpm_reg_t  *sbpm_reg);

/**
 *  This function converts sbpm sxd structure to EMAD sbpm structure.
 *
 * @param[out] sbpm_data - pointer to sxd_emad_sbpm_data_t
 * @param[in] sbpm_reg - pointer to sxd_emad_sbpm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sbpm(sxd_emad_sbpm_data_t *sbpm_data,
                                   sxd_emad_sbpm_reg_t  *sbpm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pplr(sxd_emad_pplr_data_t *pplr_data,
                                 sxd_emad_pplr_reg_t  *pplr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pplr(sxd_emad_pplr_data_t *pplr_data,
                                   sxd_emad_pplr_reg_t  *pplr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pmpr(sxd_emad_pmpr_data_t *pmpr_data,
                                 sxd_emad_pmpr_reg_t  *pmpr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pmpr(sxd_emad_pmpr_data_t *pmpr_data,
                                   sxd_emad_pmpr_reg_t  *pmpr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ptys(sxd_emad_ptys_data_t *ptys_data,
                                 sxd_emad_ptys_reg_t  *ptys_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_ptys(sxd_emad_ptys_data_t *ptys_data,
                                   sxd_emad_ptys_reg_t  *ptys_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ppad(sxd_emad_ppad_data_t *ppad_data,
                                 sxd_emad_ppad_reg_t  *ppad_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_ppad(sxd_emad_ppad_data_t *ppad_data,
                                   sxd_emad_ppad_reg_t  *ppad_reg);

/**
 *  This function converts EMAD pplm structure to pplm sxd structure.
 *
 * @param[out] pplm_data - pointer to sxd_emad_pplm_data_t
 * @param[in] pplm_reg - pointer to sxd_emad_pplm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pplm(sxd_emad_pplm_data_t *pplm_data,
                                 sxd_emad_pplm_reg_t  *pplm_reg);

/**
 *  This function converts pplm sxd structure to EMAD pplm structure.
 *
 * @param[out] pplm_data - pointer to sxd_emad_pplm_data_t
 * @param[in] pplm_reg - pointer to sxd_emad_pplm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pplm(sxd_emad_pplm_data_t *pplm_data,
                                   sxd_emad_pplm_reg_t  *pplm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pmaos(sxd_emad_pmaos_data_t *pmaos_data,
                                  sxd_emad_pmaos_reg_t  *pmaos_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pmaos(sxd_emad_pmaos_data_t *pmaos_data,
                                    sxd_emad_pmaos_reg_t  *pmaos_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pfcc(sxd_emad_pfcc_data_t *pfcc_data,
                                 sxd_emad_pfcc_reg_t  *pfcc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pfcc(sxd_emad_pfcc_data_t *pfcc_data,
                                   sxd_emad_pfcc_reg_t  *pfcc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pelc(sxd_emad_pelc_data_t *pelc_data,
                                 sxd_emad_pelc_reg_t  *pelc_reg);
/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pelc(sxd_emad_pelc_data_t *pelc_data,
                                   sxd_emad_pelc_reg_t  *pelc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_ppcnt(sxd_emad_ppcnt_data_t *ppcnt_data,
                                  sxd_emad_ppcnt_reg_t  *ppcnt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_ppcnt(sxd_emad_ppcnt_data_t *ppcnt_data,
                                    sxd_emad_ppcnt_reg_t  *ppcnt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pude(sxd_emad_pude_data_t *pude_data,
                                 sxd_emad_pude_reg_t  *pude_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pude(sxd_emad_pude_data_t *pude_data,
                                   sxd_emad_pude_reg_t  *pude_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pmpe(sxd_emad_pmpe_data_t *pmpe_data,
                                 sxd_emad_pmpe_reg_t  *pmpe_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */

sxd_status_t sxd_emad_deparse_pmpe(sxd_emad_pmpe_data_t *pmpe_data,
                                   sxd_emad_pmpe_reg_t  *pmpe_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_plib(sxd_emad_plib_data_t *plib_data,
                                 sxd_emad_plib_reg_t  *plib_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_plib(sxd_emad_plib_data_t *plib_data,
                                   sxd_emad_plib_reg_t  *plib_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pptb(sxd_emad_pptb_data_t *pptb_data,
                                 sxd_emad_pptb_reg_t  *pptb_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pptb(sxd_emad_pptb_data_t *pptb_data,
                                   sxd_emad_pptb_reg_t  *pptb_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pbmc(sxd_emad_pbmc_data_t *pbmc_data,
                                 sxd_emad_pbmc_reg_t  *pbmc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pbmc(sxd_emad_pbmc_data_t *pbmc_data,
                                   sxd_emad_pbmc_reg_t  *pbmc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pspa(sxd_emad_pspa_data_t *pspa_data,
                                 sxd_emad_pspa_reg_t  *pspa_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pspa(sxd_emad_pspa_data_t *pspa_data,
                                   sxd_emad_pspa_reg_t  *pspa_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpbr(sxd_emad_qpbr_data_t *qpbr_data,
                                 sxd_emad_qpbr_reg_t  *qpbr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpbr(sxd_emad_qpbr_data_t *qpbr_data,
                                   sxd_emad_qpbr_reg_t  *qpbr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_plbf(sxd_emad_plbf_data_t *plbf_data,
                                 sxd_emad_plbf_reg_t  *plbf_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_plbf(sxd_emad_plbf_data_t *plbf_data,
                                   sxd_emad_plbf_reg_t  *plbf_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pifr(sxd_emad_pifr_data_t *pifr_data,
                                 sxd_emad_pifr_reg_t  *pifr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pifr(sxd_emad_pifr_data_t *pifr_data,
                                   sxd_emad_pifr_reg_t  *pifr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_pmpc(sxd_emad_pmpc_data_t *pmpc_data,
                                 sxd_emad_pmpc_reg_t  *pmpc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_pmpc(sxd_emad_pmpc_data_t *pmpc_data,
                                   sxd_emad_pmpc_reg_t  *pmpc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sbpr(sxd_emad_sbpr_data_t *sbpr_data,
                                 sxd_emad_sbpr_reg_t  *sbpr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sbpr(sxd_emad_sbpr_data_t *sbpr_data,
                                   sxd_emad_sbpr_reg_t  *sbpr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_mpsc(sxd_emad_mpsc_data_t *mpsc_data,
                                 sxd_emad_mpsc_reg_t  *mpsc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_mpsc(sxd_emad_mpsc_data_t *mpsc_data,
                                   sxd_emad_mpsc_reg_t  *mpsc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_mlcr(sxd_emad_mlcr_data_t *mlcr_data,
                                 sxd_emad_mlcr_reg_t  *mlcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_mlcr(sxd_emad_mlcr_data_t *mlcr_data,
                                   sxd_emad_mlcr_reg_t  *mlcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_mdri(sxd_emad_mdri_data_t *mdri_data,
                                 sxd_emad_mdri_reg_t  *mdri_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_mdri(sxd_emad_mdri_data_t *mdri_data,
                                   sxd_emad_mdri_reg_t  *mdri_reg);

#endif /* __SXD_EMAD_PARSER_PORT_H__ */
