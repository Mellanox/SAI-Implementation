/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_COMMON_DATA_H__
#define __SXD_EMAD_COMMON_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/kernel_user.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 *  The sxd_emad_completion_handler_t function type defines the
 *  prototype for functions used to handle EMADs completion.
 *
 * @param[in] context - context of completion handler
 *
 * @return void
 */
typedef void (*sxd_emad_completion_handler_t) (void *context);

typedef struct sxd_sys_port_route_info {
    uint16_t sys_port;
} sxd_sys_port_route_info_t;

typedef struct sxd_eth_route_info {
    uint64_t dmac;
} sxd_eth_route_info_t;

typedef struct sxd_isx_dr_route_info {
    uint16_t tbd;
} sxd_isx_dr_route_info_t;

typedef union sxd_emad_route_info {
    sxd_sys_port_route_info_t sys_port_route_info;
    sxd_eth_route_info_t      eth_route_info;
    sxd_isx_dr_route_info_t   isx_dr_route_info;
} sxd_emad_route_info_t;

typedef enum {
    SYS_PORT_ROUTE_E,
    ETH_ROUTE_E,
    ISX_DR_ROUTE_E
} sxd_emad_route_type_e;

/**
 * sxd_emad_commmon_data_t structure is used to store common emad
 * data.
 */
typedef struct sxd_emad_common_data {
    sxd_dev_id_t          dev_id; /**< Device identification*/
    sxd_access_cmd_t      access_cmd; /**< Access Command - */
    sxd_status_t          ret_status; /**< Return status*/
    sxd_emad_route_type_e route_type; /**< Route type*/
    sxd_emad_route_info_t route_info; /**< Route information*/
} sxd_emad_common_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_COMMON_DATA_H__ */
