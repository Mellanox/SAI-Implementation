/*
 *                  - Mellanox Confidential and Proprietary -
 *
 *  Copyright (C) January 2010, Mellanox Technologies Ltd.  ALL RIGHTS RESERVED.
 *
 *  Except as specifically permitted herein, no portion of the information,
 *  including but not limited to object code and source code, may be reproduced,
 *  modified, distributed, republished or otherwise exploited in any form or by
 *  any means for any purpose without the prior written permission of Mellanox
 *  Technologies Ltd. Use of software subject to the terms and conditions
 *  detailed in the file "LICENSE.txt".
 *
 */

#ifndef __SXD_EMAD_FLOW_COUNTER_DATA_H__
#define __SXD_EMAD_FLOW_COUNTER_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_pfca_data_t structure is used to store PFCA register
 * data.
 */
typedef struct sxd_emad_pfca_data {
    sxd_emad_common_data_t common;
    struct ku_pfca_reg    *reg_data;
} sxd_emad_pfca_data_t;

/**
 * sxd_emad_pfcnt_data_t structure is used to store PFCNT register
 * data.
 */
typedef struct sxd_emad_pfcnt_data {
    sxd_emad_common_data_t common;
    struct ku_pfcnt_reg   *reg_data;
} sxd_emad_pfcnt_data_t;

/**
 * sxd_emad_mgpc_data_t structure is used to store MGPC register
 * data.
 */
typedef struct sxd_emad_mgpc_data {
    sxd_emad_common_data_t common;
    struct ku_mgpc_reg    *reg_data;
} sxd_emad_mgpc_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_FLOW_COUNTER_DATA_H__ */
