/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_HOST_H__
#define __SXD_EMAD_PARSER_HOST_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_host_data.h>
#include <sx/sxd/sxd_emad_host_reg.h>


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

sxd_status_t emad_parser_host_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                  IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_hcap(sxd_emad_hcap_data_t *hcap_data,
                                 sxd_emad_hcap_reg_t  *hcap_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_hcap(sxd_emad_hcap_data_t *hcap_data,
                                   sxd_emad_hcap_reg_t  *hcap_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_htgt(sxd_emad_htgt_data_t *htgt_data,
                                 sxd_emad_htgt_reg_t  *htgt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_htgt(sxd_emad_htgt_data_t *htgt_data,
                                   sxd_emad_htgt_reg_t  *htgt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_hpkt(sxd_emad_hpkt_data_t *hpkt_data,
                                 sxd_emad_hpkt_reg_t  *hpkt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_hpkt(sxd_emad_hpkt_data_t *hpkt_data,
                                   sxd_emad_hpkt_reg_t  *hpkt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_hespr(sxd_emad_hespr_data_t *hespr_data,
                                  sxd_emad_hespr_reg_t  *hespr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_hespr(sxd_emad_hespr_data_t *hespr_data,
                                    sxd_emad_hespr_reg_t  *hespr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_hdrt(sxd_emad_hdrt_data_t *hdrt_data,
                                 sxd_emad_hdrt_reg_t  *hdrt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_hdrt(sxd_emad_hdrt_data_t *hdrt_data,
                                   sxd_emad_hdrt_reg_t  *hdrt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_hctr(sxd_emad_hctr_data_t *hctr_data,
                                 sxd_emad_hctr_reg_t  *hctr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_hctr(sxd_emad_hctr_data_t *hctr_data,
                                   sxd_emad_hctr_reg_t  *hctr_reg);

#endif /* __SXD_EMAD_PARSER_HOST_H__ */
