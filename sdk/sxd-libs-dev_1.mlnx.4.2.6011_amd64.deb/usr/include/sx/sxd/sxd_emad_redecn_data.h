/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_REDECN_DATA_H__
#define __SXD_EMAD_REDECN_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_qpdp_data_t structure is used to store QPDP register
 * data.
 */
typedef struct sxd_emad_cwgcr_data {
    sxd_emad_common_data_t common;
    struct ku_cwgcr_reg   *reg_data;
} sxd_emad_cwgcr_data_t;

typedef struct sxd_emad_cwtp_data {
    sxd_emad_common_data_t common;
    struct ku_cwtp_reg    *reg_data;
} sxd_emad_cwtp_data_t;

typedef struct sxd_emad_cwtpm_data {
    sxd_emad_common_data_t common;
    struct ku_cwtpm_reg   *reg_data;
} sxd_emad_cwtpm_data_t;

typedef struct sxd_emad_cwpp_data {
    sxd_emad_common_data_t common;
    struct ku_cwpp_reg    *reg_data;
} sxd_emad_cwpp_data_t;

typedef struct sxd_emad_cwppm_data {
    sxd_emad_common_data_t common;
    struct ku_cwppm_reg   *reg_data;
} sxd_emad_cwppm_data_t;

typedef struct sxd_emad_cpqe_data {
    sxd_emad_common_data_t common;
    struct ku_cpqe_reg    *reg_data;
} sxd_emad_cpqe_data_t;


#endif /* __SXD_EMAD_REDECN_DATA_H__ */
