/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_COS_H__
#define __SXD_EMAD_PARSER_COS_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_cos_data.h>
#include <sx/sxd/sxd_emad_cos_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_cos_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpdp(sxd_emad_qpdp_data_t *qpdp_data,
                                 sxd_emad_qpdp_reg_t  *qpdp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpdp(sxd_emad_qpdp_data_t *qpdp_data,
                                   sxd_emad_qpdp_reg_t  *qpdp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qprt(sxd_emad_qprt_data_t *qprt_data,
                                 sxd_emad_qprt_reg_t  *qprt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qprt(sxd_emad_qprt_data_t *qprt_data,
                                   sxd_emad_qprt_reg_t  *qprt_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qsptc(sxd_emad_qsptc_data_t *qsptc_data,
                                  sxd_emad_qsptc_reg_t  *qsptc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qsptc(sxd_emad_qsptc_data_t *qsptc_data,
                                    sxd_emad_qsptc_reg_t  *qsptc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qtct(sxd_emad_qtct_data_t *qtct_data,
                                 sxd_emad_qtct_reg_t  *qtct_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qtct(sxd_emad_qtct_data_t *qtct_data,
                                   sxd_emad_qtct_reg_t  *qtct_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qstct(sxd_emad_qstct_data_t *qstct_data,
                                  sxd_emad_qstct_reg_t  *qstct_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qstct(sxd_emad_qstct_data_t *qstct_data,
                                    sxd_emad_qstct_reg_t  *qstct_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qcap(sxd_emad_qcap_data_t *qcap_data,
                                 sxd_emad_qcap_reg_t  *qcap_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qcap(sxd_emad_qcap_data_t *qcap_data,
                                   sxd_emad_qcap_reg_t  *qcap_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpts(sxd_emad_qpts_data_t *qpts_data,
                                 sxd_emad_qpts_reg_t  *qpts_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpts(sxd_emad_qpts_data_t *qpts_data,
                                   sxd_emad_qpts_reg_t  *qpts_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qdpm(sxd_emad_qdpm_data_t *qdpm_data,
                                 sxd_emad_qdpm_reg_t  *qdpm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qdpm(sxd_emad_qdpm_data_t *qdpm_data,
                                   sxd_emad_qdpm_reg_t  *qdpm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qetcr(sxd_emad_qetcr_data_t *qetcr_data,
                                  sxd_emad_qetcr_reg_t  *qetcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qetcr(sxd_emad_qetcr_data_t *qetcr_data,
                                    sxd_emad_qetcr_reg_t  *qetcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qegcs(sxd_emad_qegcs_data_t *qegcs_data,
                                  sxd_emad_qegcs_reg_t  *qegcs_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qegcs(sxd_emad_qegcs_data_t *qegcs_data,
                                    sxd_emad_qegcs_reg_t  *qegcs_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cnct(sxd_emad_cnct_data_t *cnct_data,
                                 sxd_emad_cnct_reg_t  *cnct_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cnct(sxd_emad_cnct_data_t *cnct_data,
                                   sxd_emad_cnct_reg_t  *cnct_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cpid(sxd_emad_cpid_data_t *cpid_data,
                                 sxd_emad_cpid_reg_t  *cpid_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cpid(sxd_emad_cpid_data_t *cpid_data,
                                   sxd_emad_cpid_reg_t  *cpid_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cpcs(sxd_emad_cpcs_data_t *cpcs_data,
                                 sxd_emad_cpcs_reg_t  *cpcs_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cpcs(sxd_emad_cpcs_data_t *cpcs_data,
                                   sxd_emad_cpcs_reg_t  *cpcs_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cnmc(sxd_emad_cnmc_data_t *cnmc_data,
                                 sxd_emad_cnmc_reg_t  *cnmc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cnmc(sxd_emad_cnmc_data_t *cnmc_data,
                                   sxd_emad_cnmc_reg_t  *cnmc_reg);

/**
 *  This function converts EMAD sbmm structure to sbmm sxd structure.
 *
 * @param[out] sbmm_data - pointer to sxd_emad_sbmm_data_t
 * @param[in]  sbmm_reg  - pointer to sxd_emad_sbmm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sbmm(sxd_emad_sbmm_data_t *sbmm_data,
                                 sxd_emad_sbmm_reg_t  *sbmm_reg);

/**
 *  This function converts sbmm sxd structure to EMAD sbmm structure.
 *
 * @param[out] sbmm_data - pointer to sxd_emad_sbmm_data_t
 * @param[in] sbmm_reg - pointer to sxd_emad_sbmm_reg_t
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sbmm(sxd_emad_sbmm_data_t *sbmm_data,
                                   sxd_emad_sbmm_reg_t  *sbmm_reg);

/**  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sbsr(sxd_emad_sbsr_data_t *sbsr_data,
                                 sxd_emad_sbsr_reg_t  *sbsr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sbsr(sxd_emad_sbsr_data_t *sbsr_data,
                                   sxd_emad_sbsr_reg_t  *sbsr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpdpm(sxd_emad_qpdpm_data_t *qpdpm_data,
                                  sxd_emad_qpdpm_reg_t  *qpdpm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpdpm(sxd_emad_qpdpm_data_t *qpdpm_data,
                                    sxd_emad_qpdpm_reg_t  *qpdpm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qepm(sxd_emad_qepm_data_t *qepm_data,
                                 sxd_emad_qepm_reg_t  *qepm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qepm(sxd_emad_qepm_data_t *qepm_data,
                                   sxd_emad_qepm_reg_t  *qepm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qeec(sxd_emad_qeec_data_t *qeec_data,
                                 sxd_emad_qeec_reg_t  *qeec_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qeec(sxd_emad_qeec_data_t *qeec_data,
                                   sxd_emad_qeec_reg_t  *qeec_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpdpc(sxd_emad_qpdpc_data_t *qpdpc_data,
                                  sxd_emad_qpdpc_reg_t  *qpdpc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpdpc(sxd_emad_qpdpc_data_t *qpdpc_data,
                                    sxd_emad_qpdpc_reg_t  *qpdpc_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qtctm(sxd_emad_qtctm_data_t *qtctm_data,
                                  sxd_emad_qtctm_reg_t  *qtctm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qtctm(sxd_emad_qtctm_data_t *qtctm_data,
                                    sxd_emad_qtctm_reg_t  *qtctm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qspip(sxd_emad_qspip_data_t *qspip_data,
                                  sxd_emad_qspip_reg_t  *qspip_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qspip(sxd_emad_qspip_data_t *qspip_data,
                                    sxd_emad_qspip_reg_t  *qspip_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qspcp(sxd_emad_qspcp_data_t *qspcp_data,
                                  sxd_emad_qspcp_reg_t  *qspcp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qspcp(sxd_emad_qspcp_data_t *qspcp_data,
                                    sxd_emad_qspcp_reg_t  *qspcp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qrwe(sxd_emad_qrwe_data_t *qrwe_data,
                                 sxd_emad_qrwe_reg_t  *qrwe_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qrwe(sxd_emad_qrwe_data_t *qrwe_data,
                                   sxd_emad_qrwe_reg_t  *qrwe_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpem(sxd_emad_qpem_data_t *qpem_data,
                                 sxd_emad_qpem_reg_t  *qpem_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpem(sxd_emad_qpem_data_t *qpem_data,
                                   sxd_emad_qpem_reg_t  *qpem_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qpdsm(sxd_emad_qpdsm_data_t *qpdsm_data,
                                  sxd_emad_qpdsm_reg_t  *qpdsm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qpdsm(sxd_emad_qpdsm_data_t *qpdsm_data,
                                    sxd_emad_qpdsm_reg_t  *qpdsm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_qppm(sxd_emad_qppm_data_t *qppm_data,
                                 sxd_emad_qppm_reg_t  *qppm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_qppm(sxd_emad_qppm_data_t *qppm_data,
                                   sxd_emad_qppm_reg_t  *qppm_reg);

#endif /* __SXD_EMAD_PARSER_COS_H__ */
