/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_NEXT_HOP_H__
#define __SX_NEXT_HOP_H__

#include <sx/sdk/sx_tunnel_id.h>
#include <sx/sdk/sx_mc_container_id.h>
#include <sx/sdk/sx_flow_counter.h>
#include <sx/sdk/sx_ip.h>
#include <sx/sdk/sx_trap_id.h>
#include <sx/sdk/sx_router_next_hop_base.h>
#include <sx/sdk/sx_mpls_next_hop.h>

/************************************************
 *  Type definitions
 ***********************************************/

static __attribute__((__used__)) const char* sx_next_hop_type_str[] = {
    "UNKNOWN",
    "IP",
    "Tunnel Encapsulation",
    "MC Container",
    "MPLS",
    "MPLS Ingress LER",
};

#define SX_NEXT_HOP_TYPE_STR_LEN (sizeof(sx_next_hop_type_str) / sizeof(sx_next_hop_type_str[0]))

#define SX_NEXT_HOP_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_NEXT_HOP_TYPE_STR_LEN - 1) ? \
     sx_next_hop_type_str[index] : "UNKNOWN")

/**
 * sx_next_hop_t is used to store a next hop data.
 */
typedef enum sx_next_hop_type {
    SX_NEXT_HOP_TYPE_IP = 1,
    SX_NEXT_HOP_TYPE_TUNNEL_ENCAP,      /**< Next hop is through tunnel encapsulation **/
    SX_NEXT_HOP_TYPE_MC_CONTAINER,      /**< Next hop is through multicast container **/
    SX_NEXT_HOP_TYPE_MPLS,              /**< Next hop is through MPLS next hop **/
    SX_NEXT_HOP_TYPE_MPLS_INGRESS_LER,  /**< Next hop is through MPLS next hop with iRIF. Supported devices: Spectrum2 */
    SX_NEXT_HOP_TYPE_MIN = SX_NEXT_HOP_TYPE_IP,
    SX_NEXT_HOP_TYPE_MAX = SX_NEXT_HOP_TYPE_MPLS_INGRESS_LER,
} sx_next_hop_type_t;

/**
 * sx_ip_next_hop_ip_tunnel_t is used to store tunnel_encap data.
 */
typedef struct sx_ip_next_hop_ip_tunnel {
    sx_ip_addr_t   underlay_dip;   /**< The IP of the Underlay Destination IP */
    sx_tunnel_id_t tunnel_id;     /**< The tunnel id for tunnel encapsulation */
} sx_ip_next_hop_ip_tunnel_t;

typedef struct sx_next_hop_key {
    sx_next_hop_type_t type;
    union {
        sx_ip_next_hop_t               ip_next_hop;
        sx_ip_next_hop_ip_tunnel_t     ip_tunnel;
        sx_mc_container_id_t           mc_container;
        sx_mpls_next_hop_t             mpls_next_hop;
        sx_mpls_ingress_ler_next_hop_t mpls_ingress_ler_next_hop; /**< Supported devices: Spectrum2 */
    } next_hop_key_entry;
} sx_next_hop_key_t;

typedef struct sx_next_hop_data {
    sx_next_hop_weight_t weight; /**< Must not be zero */
    sx_router_action_t   action;
    sx_flow_counter_id_t counter_id;
    sx_trap_attributes_t trap_attr;
} sx_next_hop_data_t;

/* NOTE: SX_API_MESSAGE_SIZE_LIMIT is defined according to a 4k(4096) container of sx_next_hop_t,
 * changing sx_next_hop_t size, will cause SX_API_MESSAGE_SIZE_LIMIT update!
 */
typedef struct sx_next_hop {
    sx_next_hop_key_t  next_hop_key;
    sx_next_hop_data_t next_hop_data;
} sx_next_hop_t;

#endif /* __SX_NEXT_HOP_H__ */
