/*
 * Copyright (C) Mellanox Technologies, Ltd. 2008-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 */

/**
 *  This function performs access register PECNRR operations.
 *
 * @param[in] pecnrr_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecnrr(struct ku_pecnrr_reg     *pecnrr_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register PAOS operations.
 *
 * @param[in] paos_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_paos(struct ku_paos_reg       *paos_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register RIPS operations.
 *
 * @param[in] rips_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rips(struct ku_rips_reg       *rips_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PECNRE operations.
 *
 * @param[in] pecnre_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecnre(struct ku_pecnre_reg     *pecnre_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register PEMRBT operations.
 *
 * @param[in] pemrbt_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pemrbt(struct ku_pemrbt_reg     *pemrbt_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register PECNEE operations.
 *
 * @param[in] pecnee_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecnee(struct ku_pecnee_reg     *pecnee_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register IBFMR operations.
 *
 * @param[in] ibfmr_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ibfmr(struct ku_ibfmr_reg      *ibfmr_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register TNCR_V2 operations.
 *
 * @param[in] tncr_v2_reg_data - The registers data
 * @param[in] reg_meta         - The registers meta data
 * @param[in] data_num         - Number of access operations to perform
 * @param[in] handler          - Handler function for calling when the operation completes
 * @param[in] context          - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_tncr_v2(struct ku_tncr_v2_reg    *tncr_v2_reg_data,
                                    sxd_reg_meta_t           *reg_meta,
                                    uint32_t                  data_num,
                                    sxd_completion_handler_t  handler,
                                    void                     *context);

/**
 *  This function performs access register RTDP operations.
 *
 * @param[in] rtdp_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_rtdp(struct ku_rtdp_reg       *rtdp_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PECNER operations.
 *
 * @param[in] pecner_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pecner(struct ku_pecner_reg     *pecner_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register IICR operations.
 *
 * @param[in] iicr_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_iicr(struct ku_iicr_reg       *iicr_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register IBFMRC operations.
 *
 * @param[in] ibfmrc_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_ibfmrc(struct ku_ibfmrc_reg     *ibfmrc_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register IDDD operations.
 *
 * @param[in] iddd_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_iddd(struct ku_iddd_reg       *iddd_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PEFAAD operations.
 *
 * @param[in] pefaad_reg_data - The registers data
 * @param[in] reg_meta        - The registers meta data
 * @param[in] data_num        - Number of access operations to perform
 * @param[in] handler         - Handler function for calling when the operation completes
 * @param[in] context         - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pefaad(struct ku_pefaad_reg     *pefaad_reg_data,
                                   sxd_reg_meta_t           *reg_meta,
                                   uint32_t                  data_num,
                                   sxd_completion_handler_t  handler,
                                   void                     *context);

/**
 *  This function performs access register MPCIR operations.
 *
 * @param[in] mpcir_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_mpcir(struct ku_mpcir_reg      *mpcir_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);

/**
 *  This function performs access register SFDB operations.
 *
 * @param[in] sfdb_reg_data - The registers data
 * @param[in] reg_meta      - The registers meta data
 * @param[in] data_num      - Number of access operations to perform
 * @param[in] handler       - Handler function for calling when the operation completes
 * @param[in] context       - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_sfdb(struct ku_sfdb_reg       *sfdb_reg_data,
                                 sxd_reg_meta_t           *reg_meta,
                                 uint32_t                  data_num,
                                 sxd_completion_handler_t  handler,
                                 void                     *context);

/**
 *  This function performs access register PMTPS operations.
 *
 * @param[in] pmtps_reg_data - The registers data
 * @param[in] reg_meta       - The registers meta data
 * @param[in] data_num       - Number of access operations to perform
 * @param[in] handler        - Handler function for calling when the operation completes
 * @param[in] context        - The context to give to the handler
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_INVALID_ACCESS_CMD - Access command is not valid for this register
 * @return SXD_STATUS_NO_PATH_TO_DEVICE - There is no valid path to the device
 * @return SXD_STATUS_PARAM_ERROR - Error in one of the input parameters
 */
sxd_status_t sxd_access_reg_pmtps(struct ku_pmtps_reg      *pmtps_reg_data,
                                  sxd_reg_meta_t           *reg_meta,
                                  uint32_t                  data_num,
                                  sxd_completion_handler_t  handler,
                                  void                     *context);
