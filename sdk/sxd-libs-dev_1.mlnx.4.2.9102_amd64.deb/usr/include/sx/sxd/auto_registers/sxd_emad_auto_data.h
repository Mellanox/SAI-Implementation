/*
 * Copyright (C) Mellanox Technologies, Ltd. 2008-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 */

#ifndef __SXD_EMAD_AUTO_DATA_H__
#define __SXD_EMAD_AUTO_DATA_H__

#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_types.h>
#include <sx/sxd/auto_registers/reg.h>


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_pecnrr_data_t structure is used to store PECNRR register data.
 */
typedef struct sxd_emad_pecnrr_data {
    sxd_emad_common_data_t   common;
    struct ku_pecnrr_reg    *reg_data;
} sxd_emad_pecnrr_data_t;

/**
 * sxd_emad_paos_data_t structure is used to store PAOS register data.
 */
typedef struct sxd_emad_paos_data {
    sxd_emad_common_data_t   common;
    struct ku_paos_reg      *reg_data;
} sxd_emad_paos_data_t;

/**
 * sxd_emad_rips_data_t structure is used to store RIPS register data.
 */
typedef struct sxd_emad_rips_data {
    sxd_emad_common_data_t   common;
    struct ku_rips_reg      *reg_data;
} sxd_emad_rips_data_t;

/**
 * sxd_emad_pecnre_data_t structure is used to store PECNRE register data.
 */
typedef struct sxd_emad_pecnre_data {
    sxd_emad_common_data_t   common;
    struct ku_pecnre_reg    *reg_data;
} sxd_emad_pecnre_data_t;

/**
 * sxd_emad_pemrbt_data_t structure is used to store PEMRBT register data.
 */
typedef struct sxd_emad_pemrbt_data {
    sxd_emad_common_data_t   common;
    struct ku_pemrbt_reg    *reg_data;
} sxd_emad_pemrbt_data_t;

/**
 * sxd_emad_pecnee_data_t structure is used to store PECNEE register data.
 */
typedef struct sxd_emad_pecnee_data {
    sxd_emad_common_data_t   common;
    struct ku_pecnee_reg    *reg_data;
} sxd_emad_pecnee_data_t;

/**
 * sxd_emad_ibfmr_data_t structure is used to store IBFMR register data.
 */
typedef struct sxd_emad_ibfmr_data {
    sxd_emad_common_data_t   common;
    struct ku_ibfmr_reg     *reg_data;
} sxd_emad_ibfmr_data_t;

/**
 * sxd_emad_tncr_v2_data_t structure is used to store TNCR_V2 register data.
 */
typedef struct sxd_emad_tncr_v2_data {
    sxd_emad_common_data_t   common;
    struct ku_tncr_v2_reg   *reg_data;
} sxd_emad_tncr_v2_data_t;

/**
 * sxd_emad_rtdp_data_t structure is used to store RTDP register data.
 */
typedef struct sxd_emad_rtdp_data {
    sxd_emad_common_data_t   common;
    struct ku_rtdp_reg      *reg_data;
} sxd_emad_rtdp_data_t;

/**
 * sxd_emad_pecner_data_t structure is used to store PECNER register data.
 */
typedef struct sxd_emad_pecner_data {
    sxd_emad_common_data_t   common;
    struct ku_pecner_reg    *reg_data;
} sxd_emad_pecner_data_t;

/**
 * sxd_emad_iicr_data_t structure is used to store IICR register data.
 */
typedef struct sxd_emad_iicr_data {
    sxd_emad_common_data_t   common;
    struct ku_iicr_reg      *reg_data;
} sxd_emad_iicr_data_t;

/**
 * sxd_emad_ibfmrc_data_t structure is used to store IBFMRC register data.
 */
typedef struct sxd_emad_ibfmrc_data {
    sxd_emad_common_data_t   common;
    struct ku_ibfmrc_reg    *reg_data;
} sxd_emad_ibfmrc_data_t;

/**
 * sxd_emad_iddd_data_t structure is used to store IDDD register data.
 */
typedef struct sxd_emad_iddd_data {
    sxd_emad_common_data_t   common;
    struct ku_iddd_reg      *reg_data;
} sxd_emad_iddd_data_t;

/**
 * sxd_emad_pefaad_data_t structure is used to store PEFAAD register data.
 */
typedef struct sxd_emad_pefaad_data {
    sxd_emad_common_data_t   common;
    struct ku_pefaad_reg    *reg_data;
} sxd_emad_pefaad_data_t;

/**
 * sxd_emad_mpcir_data_t structure is used to store MPCIR register data.
 */
typedef struct sxd_emad_mpcir_data {
    sxd_emad_common_data_t   common;
    struct ku_mpcir_reg     *reg_data;
} sxd_emad_mpcir_data_t;

/**
 * sxd_emad_sfdb_data_t structure is used to store SFDB register data.
 */
typedef struct sxd_emad_sfdb_data {
    sxd_emad_common_data_t   common;
    struct ku_sfdb_reg      *reg_data;
} sxd_emad_sfdb_data_t;

/**
 * sxd_emad_pmtps_data_t structure is used to store PMTPS register data.
 */
typedef struct sxd_emad_pmtps_data {
    sxd_emad_common_data_t   common;
    struct ku_pmtps_reg     *reg_data;
} sxd_emad_pmtps_data_t;


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/



#endif /* __SXD_EMAD_AUTO_DATA_H__ */
