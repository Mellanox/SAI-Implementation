/*
 * Copyright (C) Mellanox Technologies, Ltd. 2008-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 */

/**
 * ku_pecnrr_reg structure is used to store the PECNRR register parameters
 */
struct ku_pecnrr_reg {
    uint8_t clear;
    uint32_t tcam_trigger_high;
    uint32_t tcam_trigger_low;
    uint32_t tcam_full_lookup_high;
    uint32_t tcam_full_lookup_low;
};

/**
 * ku_access_pecnrr_reg structure is used to store the access register PECNRR command parameters
 */
struct ku_access_pecnrr_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_pecnrr_reg    pecnrr_reg; /**< pecnrr_reg - pecnrr register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_paos_reg structure is used to store the PAOS register parameters
 */
struct ku_paos_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t admin_status;
    uint8_t oper_status;
    uint8_t ase;
    uint8_t ee;
    uint8_t e;
};

/**
 * ku_access_paos_reg structure is used to store the access register PAOS command parameters
 */
struct ku_access_paos_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_paos_reg      paos_reg; /**< paos_reg - paos register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

#define SXD_RIPS_IPV6_NUM 4

/**
 * ku_rips_reg structure is used to store the RIPS register parameters
 */
struct ku_rips_reg {
    uint32_t index;
    uint32_t ipv6[SXD_RIPS_IPV6_NUM];
};

/**
 * ku_access_rips_reg structure is used to store the access register RIPS command parameters
 */
struct ku_access_rips_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_rips_reg      rips_reg; /**< rips_reg - rips register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_pecnre_reg structure is used to store the PECNRE register parameters
 */
struct ku_pecnre_reg {
    uint16_t region_id;
    uint16_t region_id_mask;
};

/**
 * ku_access_pecnre_reg structure is used to store the access register PECNRE command parameters
 */
struct ku_access_pecnre_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_pecnre_reg    pecnre_reg; /**< pecnre_reg - pecnre register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_pemrbt_reg structure is used to store the PEMRBT register parameters
 */
struct ku_pemrbt_reg {
    uint8_t protocol;
    uint16_t group_id;
};

/**
 * ku_access_pemrbt_reg structure is used to store the access register PEMRBT command parameters
 */
struct ku_access_pemrbt_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_pemrbt_reg    pemrbt_reg; /**< pemrbt_reg - pemrbt register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_pecnee_reg structure is used to store the PECNEE register parameters
 */
struct ku_pecnee_reg {
    uint16_t region_id;
    uint16_t region_id_mask;
    uint16_t erp_id_bitwise;
    uint8_t ctcam;
};

/**
 * ku_access_pecnee_reg structure is used to store the access register PECNEE command parameters
 */
struct ku_access_pecnee_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_pecnee_reg    pecnee_reg; /**< pecnee_reg - pecnee register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_ibfmr_reg structure is used to store the IBFMR register parameters
 */
struct ku_ibfmr_reg {
    uint8_t atm_v;
    uint16_t attribute_id;
    uint32_t attribute_modifier;
};

/**
 * ku_access_ibfmr_reg structure is used to store the access register IBFMR command parameters
 */
struct ku_access_ibfmr_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_ibfmr_reg     ibfmr_reg; /**< ibfmr_reg - ibfmr register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_tncr_v2_reg structure is used to store the TNCR_V2 register parameters
 */
struct ku_tncr_v2_reg {
    uint8_t clear_counters;
    uint8_t tunnel_port;
    uint32_t count_decap_discards_high;
    uint32_t count_decap_discards_low;
    uint32_t count_encap_discards_high;
    uint32_t count_encap_discards_low;
};

/**
 * ku_access_tncr_v2_reg structure is used to store the access register TNCR_V2 command parameters
 */
struct ku_access_tncr_v2_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_tncr_v2_reg   tncr_v2_reg; /**< tncr_v2_reg - tncr_v2 register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};


typedef enum sxd_rtdp_type {
    SXD_RTDP_TYPE_NVE_E = 0x0,
    SXD_RTDP_TYPE_IPINIP_E = 0x1
} sxd_rtdp_type_t;

typedef struct sxd_rtdp_rtdp_nve_decap {
    uint32_t reserved;
} sxd_rtdp_rtdp_nve_decap_t;

typedef struct sxd_rtdp_rtdp_ipinip {
    uint16_t irif;
    uint8_t sip_check;
    uint8_t type_check;
    uint8_t gre_key_check;
    uint32_t ipv4_usip;
    uint32_t ipv6_usip_ptr;
    uint32_t expected_gre_key;
} sxd_rtdp_rtdp_ipinip_t;

/**
 * ku_rtdp_reg structure is used to store the RTDP register parameters
 */
struct ku_rtdp_reg {
    sxd_rtdp_type_t type;
    uint32_t tunnel_index;
    union {
        sxd_rtdp_rtdp_nve_decap_t rtdp_nve_decap;
        sxd_rtdp_rtdp_ipinip_t rtdp_ipinip;
    } rtdp_entry;
    uint16_t egress_router_interface;
};

/**
 * ku_access_rtdp_reg structure is used to store the access register RTDP command parameters
 */
struct ku_access_rtdp_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_rtdp_reg      rtdp_reg; /**< rtdp_reg - rtdp register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_pecner_reg structure is used to store the PECNER register parameters
 */
struct ku_pecner_reg {
    uint8_t clear;
    uint32_t erp_initial_high;
    uint32_t erp_initial_low;
    uint32_t erp_post_bf_high;
    uint32_t erp_post_bf_low;
    uint32_t erp_lookup_high;
    uint32_t erp_lookup_low;
    uint32_t erp_any_match_high;
    uint32_t erp_any_match_low;
    uint32_t erp_final_match_high;
    uint32_t erp_final_match_low;
    uint32_t erp_prune_high;
    uint32_t erp_prune_low;
};

/**
 * ku_access_pecner_reg structure is used to store the access register PECNER command parameters
 */
struct ku_access_pecner_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_pecner_reg    pecner_reg; /**< pecner_reg - pecner register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_iicr_reg structure is used to store the IICR register parameters
 */
struct ku_iicr_reg {
    uint8_t kvh_mark_clear;
    uint16_t clear_pe_regions_value;
    uint16_t clear_pe_regions_mask;
    uint16_t clear_rifs_value;
    uint16_t clear_rifs_mask;
};

/**
 * ku_access_iicr_reg structure is used to store the access register IICR command parameters
 */
struct ku_access_iicr_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_iicr_reg      iicr_reg; /**< iicr_reg - iicr register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_ibfmrc_reg structure is used to store the IBFMRC register parameters
 */
struct ku_ibfmrc_reg {
    uint32_t attr_id_en;
};

/**
 * ku_access_ibfmrc_reg structure is used to store the access register IBFMRC command parameters
 */
struct ku_access_ibfmrc_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_ibfmrc_reg    ibfmrc_reg; /**< ibfmrc_reg - ibfmrc register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_iddd_reg structure is used to store the IDDD register parameters
 */
struct ku_iddd_reg {
    uint8_t entry_type;
    uint8_t duplication;
};

/**
 * ku_access_iddd_reg structure is used to store the access register IDDD command parameters
 */
struct ku_access_iddd_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_iddd_reg      iddd_reg; /**< iddd_reg - iddd register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

#define SXD_PEFAAD_INDEX_DUMP_NUM 256

typedef struct sxd_pefaad_index_dump {
    uint32_t index_dump;
} sxd_pefaad_index_dump_t;

/**
 * ku_pefaad_reg structure is used to store the PEFAAD register parameters
 */
struct ku_pefaad_reg {
    uint8_t filter_fields;
    uint8_t op;
    uint16_t num_rec;
    uint8_t entry_a;
    uint16_t as_user_val;
    sxd_pefaad_index_dump_t index_dump[SXD_PEFAAD_INDEX_DUMP_NUM];
};

/**
 * ku_access_pefaad_reg structure is used to store the access register PEFAAD command parameters
 */
struct ku_access_pefaad_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_pefaad_reg    pefaad_reg; /**< pefaad_reg - pefaad register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_mpcir_reg structure is used to store the MPCIR register parameters
 */
struct ku_mpcir_reg {
    uint8_t all;
    uint8_t gearbox;
    uint8_t leds;
    uint8_t voltage_current;
    uint8_t power;
    uint8_t fans;
    uint8_t thermal;
    uint8_t module_mng;
    uint8_t cpld;
    uint8_t ports;
    uint8_t gearbox_stat;
    uint8_t leds_stat;
    uint8_t voltage_current_stat;
    uint8_t power_stat;
    uint8_t fans_stat;
    uint8_t thermal_stat;
    uint8_t module_mng_stat;
    uint8_t cpld_stat;
    uint8_t ports_stat;
};

/**
 * ku_access_mpcir_reg structure is used to store the access register MPCIR command parameters
 */
struct ku_access_mpcir_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_mpcir_reg     mpcir_reg; /**< mpcir_reg - mpcir register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_sfdb_reg structure is used to store the SFDB register parameters
 */
struct ku_sfdb_reg {
    uint8_t update_type;
    uint16_t entry_fid;
    uint32_t parameter;
    uint32_t new_parameter;
};

/**
 * ku_access_sfdb_reg structure is used to store the access register SFDB command parameters
 */
struct ku_access_sfdb_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_sfdb_reg      sfdb_reg; /**< sfdb_reg - sfdb register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};

/**
 * ku_pmtps_reg structure is used to store the PMTPS register parameters
 */
struct ku_pmtps_reg {
    uint8_t module;
    uint16_t module_type_admin;
    uint16_t module_type_connected;
    uint32_t eth_module_c2m;
};

/**
 * ku_access_pmtps_reg structure is used to store the access register PMTPS command parameters
 */
struct ku_access_pmtps_reg {
    struct ku_operation_tlv op_tlv; /**< op_tlv - operation tlv struct */
    struct ku_pmtps_reg     pmtps_reg; /**< pmtps_reg - pmtps register tlv */
    uint8_t                 dev_id; /**< dev_id - device id */
};
