/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_ROUTER_H__
#define __SXD_EMAD_PARSER_ROUTER_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_router_data.h>
#include <sx/sxd/sxd_emad_router_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_router_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function formats RCAP register layout from RCAP register data.
 *
 * @param[in] rcap_data - RCAP register data.
 * @param[out] rcap_reg - RCAP register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rcap(sxd_emad_rcap_data_t *rcap_data,
                                 sxd_emad_rcap_reg_t  *rcap_reg);

/**
 *  This function formats RCAP register data from RCAP register layout.
 *
 * @param[out] rcap_data - RCAP register data.
 * @param[in] rcap_reg - RCAP register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rcap(sxd_emad_rcap_data_t *rcap_data,
                                   sxd_emad_rcap_reg_t  *rcap_reg);

/**
 *  This function formats RGCR register layout from RGCR register data.
 *
 * @param[in] rgcr_data - RGCR register data.
 * @param[out] rgcr_reg - RGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rgcr(sxd_emad_rgcr_data_t *rgcr_data,
                                 sxd_emad_rgcr_reg_t  *rgcr_reg);

/**
 *  This function formats RGCR register data from RGCR register layout.
 *
 * @param[out] rgcr_data - RGCR register data.
 * @param[in] rgcr_reg - RGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rgcr(sxd_emad_rgcr_data_t *rgcr_data,
                                   sxd_emad_rgcr_reg_t  *rgcr_reg);

/**
 *  This function formats RITR register layout from RITR register data.
 *
 * @param[in] ritr_data - RITR register data.
 * @param[out] ritr_reg - RITR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ritr(sxd_emad_ritr_data_t *ritr_data,
                                 sxd_emad_ritr_reg_t  *ritr_reg);

/**
 *  This function formats RITR register data from RITR register layout.
 *
 * @param[out] ritr_data - RITR register data.
 * @param[in] ritr_reg - RITR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ritr(sxd_emad_ritr_data_t *ritr_data,
                                   sxd_emad_ritr_reg_t  *ritr_reg);

/**
 *  This function formats RIGR register layout from RIGR register data.
 *
 * @param[in] rigr_data - RIGR register data.
 * @param[out] rigr_reg - RIGR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rigr(sxd_emad_rigr_data_t *rigr_data,
                                 sxd_emad_rigr_reg_t  *rigr_reg);

/**
 *  This function formats RIGR register data from RIGR register layout.
 *
 * @param[out] rigr_data - RIGR register data.
 * @param[in] rigr_reg - RIGR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rigr(sxd_emad_rigr_data_t *rigr_data,
                                   sxd_emad_rigr_reg_t  *rigr_reg);

/**
 *  This function formats RIGRv2 register layout from RIGRv2 register data.
 *
 * @param[in] rigr_v2_data - RIGRv2 register data.
 * @param[out] rigr_v2_reg - RIGRv2 register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rigr_v2(sxd_emad_rigr_v2_data_t *rigr_v2_data,
                                    sxd_emad_rigr_v2_reg_t  *rigr_v2_reg);

/**
 *  This function formats RIGRv2 register data from RIGRv2 register layout.
 *
 * @param[out] rigr_v2_data - RIGRv2 register data.
 * @param[in] rigr_v2_reg - RIGRv2 register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rigr_v2(sxd_emad_rigr_v2_data_t *rigr_v2_data,
                                      sxd_emad_rigr_v2_reg_t  *rigr_v2_reg);

/**
 *  This function formats RTAR register layout from RTAR register data.
 *
 * @param[in] rtar_data - RTAR register data.
 * @param[out] rtar_reg - RTAR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rtar(sxd_emad_rtar_data_t *rtar_data,
                                 sxd_emad_rtar_reg_t  *rtar_reg);

/**
 *  This function formats RTAR register data from RTAR register layout.
 *
 * @param[out] rtar_data - RTAR register data.
 * @param[in] rtar_reg - RTAR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rtar(sxd_emad_rtar_data_t *rtar_data,
                                   sxd_emad_rtar_reg_t  *rtar_reg);

/**
 *  This function formats RTDP register layout from RTDP register data.
 *
 * @param[in] rtdp_data - RTDP register data.
 * @param[out] rtdp_reg - RTDP register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rtdp(sxd_emad_rtdp_data_t *rtdp_data,
                                 sxd_emad_rtdp_reg_t  *rtdp_reg);

/**
 *  This function formats RTDP register data from RTDP register layout.
 *
 * @param[out] rtdp_data - RTDP register data.
 * @param[in] rtdp_reg - RTDP register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rtdp(sxd_emad_rtdp_data_t *rtdp_data,
                                   sxd_emad_rtdp_reg_t  *rtdp_reg);

/**
 *  This function formats RECR register layout from RECR register data.
 *
 * @param[in] recr_data - RECR register data.
 * @param[out] recr_reg - RECR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_recr(sxd_emad_recr_data_t *recr_data,
                                 sxd_emad_recr_reg_t  *recr_reg);

/**
 *  This function formats RECR register data from RECR register layout.
 *
 * @param[out] recr_data - RECR register data.
 * @param[in] recr_reg - RECR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_recr(sxd_emad_recr_data_t *recr_data,
                                   sxd_emad_recr_reg_t  *recr_reg);

/**
 *  This function formats RECRv2 register layout from RECRv2 register data.
 *
 * @param[in] recr_v2_data - RECRv2 register data.
 * @param[out] recr_v2_reg - RECRv2 register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_recr_v2(sxd_emad_recr_v2_data_t * recr_v2_data,
                                    sxd_emad_recr_v2_reg_t  * recr_v2_reg);

/**
 *  This function formats RECRv2 register data from RECRv2 register layout.
 *
 * @param[out] recr_v2_data - RECRv2 register data.
 * @param[in] recr_v2_reg - RECRv2 register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_recr_v2(sxd_emad_recr_v2_data_t * recr_v2_data,
                                      sxd_emad_recr_v2_reg_t  * recr_v2_reg);

/**
 *  This function formats RUFT register layout from RUFT register data.
 *
 * @param[in] ruft_data - RUFT register data.
 * @param[out] ruft_reg - RUFT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ruft(sxd_emad_ruft_data_t *ruft_data,
                                 sxd_emad_ruft_reg_t  *ruft_reg);

/**
 *  This function formats RUFT register data from RUFT register layout.
 *
 * @param[out] ruft_data - RUFT register data.
 * @param[in] ruft_reg - RUFT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ruft(sxd_emad_ruft_data_t *ruft_data,
                                   sxd_emad_ruft_reg_t  *ruft_reg);

/**
 *  This function formats RUHT register layout from RUHT register data.
 *
 * @param[in] ruht_data - RUHT register data.
 * @param[out] ruht_reg - RUHT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ruht(sxd_emad_ruht_data_t *ruht_data,
                                 sxd_emad_ruht_reg_t  *ruht_reg);

/**
 *  This function formats RUHT register data from RUHT register layout.
 *
 * @param[out] ruht_data - RUHT register data.
 * @param[in] ruht_reg - RUHT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ruht(sxd_emad_ruht_data_t *ruht_data,
                                   sxd_emad_ruht_reg_t  *ruht_reg);

/**
 *  This function formats RAUHT register layout from RAUHT register data.
 *
 * @param[in] ruht_data - RAUHT register data.
 * @param[out] ruht_reg - RAUHT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rauht(sxd_emad_rauht_data_t *rauht_data,
                                  sxd_emad_rauht_reg_t  *rauht_reg);

/**
 *  This function formats RAUHT register data from RAUHT register layout.
 *
 * @param[out] ruht_data - RAUHT register data.
 * @param[in] ruht_reg - RAUHT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rauht(sxd_emad_rauht_data_t *rauht_data,
                                    sxd_emad_rauht_reg_t  *rauht_reg);

/**
 *  This function formats RAUHTD register layout from RAUHTD register data.
 *
 * @param[in] ruht_data - RAUHTD register data.
 * @param[out] ruht_reg - RAUHTD register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rauhtd(sxd_emad_rauhtd_data_t *rauhtd_data,
                                   sxd_emad_rauhtd_reg_t  *rauhtd_reg);

/**
 *  This function formats RAUHTD register data from RAUHTD register layout.
 *
 * @param[out] ruht_data - RAUHTD register data.
 * @param[in] ruht_reg - RAUHTD register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rauhtd(sxd_emad_rauhtd_data_t *rauhtd_data,
                                     sxd_emad_rauhtd_reg_t  *rauhtd_reg);

/**
 *  This function formats RMFT register layout from RMFT register data.
 *
 * @param[in] rmft_data - RMFT register data.
 * @param[out] rmft_reg - RMFT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rmft(sxd_emad_rmft_data_t *rmft_data,
                                 sxd_emad_rmft_reg_t  *rmft_reg);

/**
 *  This function formats RMFT register data from RMFT register layout.
 *
 * @param[out] rmft_data - RMFT register data.
 * @param[in] rmft_reg - RMFT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rmft(sxd_emad_rmft_data_t *rmft_data,
                                   sxd_emad_rmft_reg_t  *rmft_reg);

/**
 *  This function formats RMFTv2 register layout from RMFTv2 register data.
 *
 * @param[in] rmft_v2_data - RMFTv2 register data.
 * @param[out] rmft_v2_reg - RMFTv2 register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rmft_v2(sxd_emad_rmft_v2_data_t *rmft_v2_data,
                                    sxd_emad_rmft_v2_reg_t  *rmft_v2_reg);

/**
 *  This function formats RMFTv2 register data from RMFTv2 register layout.
 *
 * @param[out] rmft_v2_data - RMFTv2 register data.
 * @param[in] rmft_v2_reg - RMFTv2 register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rmft_v2(sxd_emad_rmft_v2_data_t *rmft_v2_data,
                                      sxd_emad_rmft_v2_reg_t  *rmft_v2_reg);

/**
 *  This function formats RATR register layout from RATR register data.
 *
 * @param[in] ratr_data - RATR register data.
 * @param[out] ratr_reg - RATR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ratr(sxd_emad_ratr_data_t *ratr_data,
                                 sxd_emad_ratr_reg_t  *ratr_reg);

/**
 *  This function formats RATR register data from RATR register layout.
 *
 * @param[out] ratr_data - RATR register data.
 * @param[in] ratr_reg - RATR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ratr(sxd_emad_ratr_data_t *ratr_data,
                                   sxd_emad_ratr_reg_t  *ratr_reg);

/**
 *  This function formats RATRAD register layout from RATRAD register data.
 *
 * @param[in] ratrad_data - RATRAD register data.
 * @param[out] ratrad_reg - RATRAD register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ratrad(sxd_emad_ratrad_data_t *ratrad_data,
                                   sxd_emad_ratrad_reg_t  *ratrad_reg);

/**
 *  This function formats RATRAD register data from RATRAD register layout.
 *
 * @param[out] ratrad_data - RATRAD register data.
 * @param[in] ratrad_reg - RATRAD register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ratrad(sxd_emad_ratrad_data_t *ratrad_data,
                                     sxd_emad_ratrad_reg_t  *ratrad_reg);

/**
 *  This function formats RDPM register layout from RDPM register data.
 *
 * @param[in] rdpm_data - RDPM register data.
 * @param[out] rdpm_reg - RDPM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rdpm(sxd_emad_rdpm_data_t *rdpm_data,
                                 sxd_emad_rdpm_reg_t  *rdpm_reg);

/**
 *  This function formats RDPM register data from RDPM register layout.
 *
 * @param[out] rdpm_data - RDPM register data.
 * @param[in] rdpm_reg - RDPM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rdpm(sxd_emad_rdpm_data_t *rdpm_data,
                                   sxd_emad_rdpm_reg_t  *rdpm_reg);

/**
 *  This function formats RRCR register layout from RRCR
 *  register data.
 *
 * @param[in] rrcr_data - RRCR register data.
 * @param[out] rrcr_reg - RRCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rrcr(sxd_emad_rrcr_data_t *rrcr_data,
                                 sxd_emad_rrcr_reg_t  *rrcr_reg);

/**
 *  This function formats RRCR register data from RRCR register
 *  layout.
 *
 * @param[out] rrcr_data - RRCR register data.
 * @param[in] rrcr_reg - RRCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rrcr(sxd_emad_rrcr_data_t *rrcr_data,
                                   sxd_emad_rrcr_reg_t  *rrcr_reg);

/**
 *  This function formats RICA register layout from RICA register data.
 *
 * @param[in] rica_data - RICA register data.
 * @param[out] rica_reg - RICA register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rica(sxd_emad_rica_data_t *rica_data,
                                 sxd_emad_rica_reg_t  *rica_reg);

/**
 *  This function formats RICA register data from RICA register layout.
 *
 * @param[out] rica_data - RICA register data.
 * @param[in] rica_reg - RICA register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rica(sxd_emad_rica_data_t *rica_data,
                                   sxd_emad_rica_reg_t  *rica_reg);

/**
 *  This function formats RICNT register layout from RICNT register data.
 *
 * @param[in] ricnt_data - RICNT register data.
 * @param[out] ricnt_reg - RICNT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ricnt(sxd_emad_ricnt_data_t *ricnt_data,
                                  sxd_emad_ricnt_reg_t  *ricnt_reg);

/**
 *  This function formats RICNT register data from RICNT register layout.
 *
 * @param[out] ricnt_data - RICNT register data.
 * @param[in] ricnt_reg - RICNT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ricnt(sxd_emad_ricnt_data_t *ricnt_data,
                                    sxd_emad_ricnt_reg_t  *ricnt_reg);

/**
 *  This function formats RTCA register layout from RTCA register data.
 *
 * @param[in] rtca_data - RTCA register data.
 * @param[out] rtca_reg - RTCA register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rtca(sxd_emad_rtca_data_t *rtca_data,
                                 sxd_emad_rtca_reg_t  *rtca_reg);

/**
 *  This function formats RTCA register data from RTCA register layout.
 *
 * @param[out] rtca_data - RTCA register data.
 * @param[in] rtca_reg - RTCA register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rtca(sxd_emad_rtca_data_t *rtca_data,
                                   sxd_emad_rtca_reg_t  *rtca_reg);

/**
 *  This function formats RTPS register layout from RTPS register data.
 *
 * @param[in] rtps_data - RTPS register data.
 * @param[out] rtps_reg - RTPS register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rtps(sxd_emad_rtps_data_t *rtps_data,
                                 sxd_emad_rtps_reg_t  *rtps_reg);

/**
 *  This function formats RTPS register data from RTPS register layout.
 *
 * @param[out] rtps_data - RTPS register data.
 * @param[in] rtps_reg - RTPS register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rtps(sxd_emad_rtps_data_t *rtps_data,
                                   sxd_emad_rtps_reg_t  *rtps_reg);

/**
 *  This function formats RMEIR register layout from RMEIR register data.
 *
 * @param[in] rmeir_data - RMEIR register data.
 * @param[out] rmeir_reg - RMEIR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rmeir(sxd_emad_rmeir_data_t *rmeir_data,
                                  sxd_emad_rmeir_reg_t  *rmeir_reg);

/**
 *  This function formats RMEIR register data from RMEIR register layout.
 *
 * @param[out] rmeir_data - RMEIR register data.
 * @param[in] rmeir_reg - RMEIR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rmeir(sxd_emad_rmeir_data_t *rmeir_data,
                                    sxd_emad_rmeir_reg_t  *rmeir_reg);

/**
 *  This function formats RMID register layout from RMID register data.
 *
 * @param[in] rmid_data - RMID register data.
 * @param[out] rmid_reg - RMID register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rmid(sxd_emad_rmid_data_t *rmid_data,
                                 sxd_emad_rmid_reg_t  *rmid_reg);

/**
 *  This function formats RMID register data from RMID register layout.
 *
 * @param[out] rmid_data - RMID register data.
 * @param[in] rmid_reg - RMID register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rmid(sxd_emad_rmid_data_t *rmid_data,
                                   sxd_emad_rmid_reg_t  *rmid_reg);

/**
 *  This function formats RMPE register layout from RMPE register data.
 *
 * @param[in] rmpe_data - RMPE register data.
 * @param[out] rmpe_reg - RMPE register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rmpe(sxd_emad_rmpe_data_t *rmpe_data,
                                 sxd_emad_rmpe_reg_t  *rmpe_reg);

/**
 *  This function formats RMPE register data from RMPE register layout.
 *
 * @param[out] rmpe_data - RMPE register data.
 * @param[in] rmpe_reg - RMPE register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rmpe(sxd_emad_rmpe_data_t *rmpe_data,
                                   sxd_emad_rmpe_reg_t  *rmpe_reg);

/**
 *  This function formats RMPU register layout from RMPU register data.
 *
 * @param[in] rmpu_data - RMPU register data.
 * @param[out] rmpu_reg - RMPU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_rmpu(sxd_emad_rmpu_data_t *rmpu_data,
                                 sxd_emad_rmpu_reg_t  *rmpu_reg);

/**
 *  This function formats RMPU register data from RMPU register layout.
 *
 * @param[out] rmpu_data - RMPU register data.
 * @param[in] rmpu_reg - RMPU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_rmpu(sxd_emad_rmpu_data_t *rmpu_data,
                                   sxd_emad_rmpu_reg_t  *rmpu_reg);

#endif /* __SXD_EMAD_PARSER_ROUTER_H__ */
