/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_H__
#define __SXD_EMAD_PARSER_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_data.h>
#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sxd/sxd_emad_buffer.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of SXD EMAD PARSER MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_parser_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse(sxd_emad_data_t *data,
                            sxd_emad_buff_t *emad_buff,
                            uint64_t         tid,
                            sxd_reg_id_e     reg_id,
                            uint32_t         reg_size);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse(sxd_emad_data_t *data,
                              sxd_emad_buff_t *emad_buff,
                              sxd_reg_id_e    *reg_id);

#endif /* __SXD_EMAD_PARSER_H__ */
