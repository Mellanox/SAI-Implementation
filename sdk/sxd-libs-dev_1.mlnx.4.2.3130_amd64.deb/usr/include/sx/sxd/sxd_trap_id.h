/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_TRAP_ID_H__
#define __SXD_TRAP_ID_H__

/************************************************
 *  Local Defines
 ***********************************************/
#define SXD_TRAPS_NUM 1024

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum sxd_trap_id {
    /* GENERAL */
    SXD_TRAP_ID_GENERAL_FDB = 0x01,
    SXD_TRAP_ID_GENERAL_DR_IPC = 0x02,
    SXD_TRAP_ID_GENERAL_DR_RES = 0x04,
    SXD_TRAP_ID_GENERAL_ETH_EMAD = 0x05,
    SXD_TRAP_ID_FDB = 0x06,

    /* EVENTS */
    SXD_TRAP_ID_PUDE = 0x08,
    SXD_TRAP_ID_PMPE = 0x09,
    SXD_TRAP_ID_FLAE = 0x0A,
    SXD_TRAP_ID_FORE = 0x0B,
    SXD_TRAP_ID_TMPW = 0x0C,
    SXD_TRAP_ID_CPUWD = 0x0D,

    /* ETHERNET L2 */
    SXD_TRAP_ID_ETH_L2_STP = 0x10,
    SXD_TRAP_ID_ETH_L2_LACP = 0x11,
    SXD_TRAP_ID_ETH_L2_EAPOL = 0x12,
    SXD_TRAP_ID_ETH_L2_LLDP = 0x13,
    SXD_TRAP_ID_ETH_L2_MMRP = 0x14,
    SXD_TRAP_ID_ETH_L2_MVRP = 0x15,
    SXD_TRAP_ID_ETH_L2_RPVST = 0x16,

    SXD_TRAP_ID_ETH_L2_IGMP_TYPE_QUERY = 0x30,
    SXD_TRAP_ID_ETH_L2_IGMP_TYPE_V1_REPORT = 0x31,
    SXD_TRAP_ID_ETH_L2_IGMP_TYPE_V2_REPORT = 0x32,
    SXD_TRAP_ID_ETH_L2_IGMP_TYPE_V3_REPORT = 0x34,
    SXD_TRAP_ID_ETH_L2_IGMP_TYPE_V2_LEAVE = 0x33,
    SXD_TRAP_ID_ETH_L2_UDLD = 0x18,
    SXD_TRAP_ID_ETH_L2_DHCP = 0x19,
    SXD_TRAP_ID_ETH_L2_PKT_SAMPLE = 0x38,
    SXD_TRAP_ID_FDB_MISS = 0x3a,
    SXD_TRAP_ID_FDB_MISMATCH = 0x3b,

    SXD_TRAP_ID_ETH_L2_PACKET_SAMPLING = 0x38,

    /* FCoE */
    SXD_TRAP_ID_FCOE_FIP = 0x20,

    /* ECN */
    SXD_TRAP_ID_DECAP_ECN0 = 0x40,
    SXD_TRAP_ID_DECAP_ECN1 = 0x41,

    /* Router */
    SXD_TRAP_ID_ARP_REQUEST = 0x50,
    SXD_TRAP_ID_ARP_RESPONSE = 0x51,
    SXD_TRAP_ID_ETH_L3_MTUERROR = 0x52,
    SXD_TRAP_ID_ETH_L3_TTLERROR = 0x53,
    SXD_TRAP_ID_ETH_L3_LBERROR = 0x54,
    SXD_TRAP_ID_OSPF = 0x55,
    SXD_TRAP_ID_RIP_V1 = 0x56,
    SXD_TRAP_ID_RIP_V2 = 0x57,
    SXD_TRAP_ID_PIM = 0x58,
    SXD_TRAP_ID_VRRP = 0x59,
    SXD_TRAP_ID_RESERVED_MC = 0x5A,
    SXD_TRAP_ID_IPBC = 0x5B,
    SXD_TRAP_ID_ETH_L3_RPF = 0x5C,
    SXD_TRAP_ID_ETH_L3_ASSERT = 0x5D,
    SXD_TRAP_ID_IP2ME = 0x5F,
    SXD_TRAP_ID_IPTRAP_MIN = 0x1c0,
    SXD_TRAP_ID_IPTRAP_MAX = 0x1ff,
    SXD_TRAP_ID_RTR_INGRESS0 = 0x70,
    SXD_TRAP_ID_RTR_INGRESS1 = 0x71,
    SXD_TRAP_ID_RTR_EGRESS0 = 0x80,
    SXD_TRAP_ID_RTR_EGRESS1 = 0x81,
    SXD_TRAP_ID_HOST_MISS_IPV4 = 0x90,
    SXD_TRAP_ID_HOST_MISS_IPV6 = 0x92,
    SXD_TRAP_ID_BFD_IPV4 = 0xd0,
    SXD_TRAP_ID_BFD_IPV6 = 0xd1,
    SXD_TRAP_ID_SSH_IPV4 = 0xd2,
    SXD_TRAP_ID_SSH_IPV6 = 0xd3,
    SXD_TRAP_ID_PING_IPV4 = 0xd4,
    SXD_TRAP_ID_PING_IPV6 = 0xd5,
    SXD_TRAP_ID_IPV4_DHCP = 0x8f,

    /*IPv6 L3*/
    SXD_TRAP_ID_IPV6_UNSPECIFIED_ADDRESS = 0x60,
    SXD_TRAP_ID_IPV6_LINK_LOCAL_DST = 0x61,
    SXD_TRAP_ID_IPV6_LINK_LOCAL_SRC = 0x62,
    SXD_TRAP_ID_IPV6_ALL_NODES_LINK = 0x63,
    SXD_TRAP_ID_IPV6_ROUTER_SOLICIATION = 0x6a,
    SXD_TRAP_ID_IPV6__ROUTER_ADVERTISEMENT = 0x6b,
    SXD_TRAP_ID_IPV6_NEIGHBOR_SOLICIATION = 0x6c,
    SXD_TRAP_ID_IPV6__NEIGHBOR_ADVERTISEMENT = 0x6d,
    SXD_TRAP_ID_IPV6__NEIGHBOR_DIRECTION = 0x6e,
    SXD_TRAP_ID_IPV6_ALL_ROUTERS_LINK = 0x6f,
    SXD_TRAP_ID_IPV6_OSPF = 0x64,
    SXD_TRAP_ID_IPV6_DHCP = 0x69,

    /*IPv6 L2*/
    SXD_TRAP_ID_IPV6_MLD_V1_V2 = 0x65,
    SXD_TRAP_ID_IPV6_MLD_V1_REPORT = 0x66,
    SXD_TRAP_ID_IPV6_MLD_V1_DONE = 0x67,
    SXD_TRAP_ID_IPV6_MLD_V2_REPORT = 0x68,

    /* InfiniBand */
    SXD_TRAP_ID_INFINIBAND_QP0 = 0xf0,
    SXD_TRAP_ID_INFINIBAND_QP1 = 0xf1,
    SXD_TRAP_ID_INFINIBAND_OTHER_QPS = 0xf2,
    SXD_TRAP_ID_INFINIBAND_EXTERNAL_SMA = 0x5e,

    /* ACL */
    SXD_TRAP_ID_ACL_MIN = 0x1c0,
    SXD_TRAP_ID_ACL_MAX = 0x1ef,

    /* MPLS - These Trap ID's number are only a placeholders. Should be changed when the numbers will be published.*/
    SXD_TRAP_ID_MPLS_LDP = 0x301,
    SXD_TRAP_ID_MPLS_ECHO_REQ = 0x302,
    SXD_TRAP_ID_MPLS_ECHO_REP = 0x303,
    SXD_TRAP_ID_MPLS_OAM = 0x304,
    SXD_TRAP_ID_MPLS_LABEL_OOR = 0x305,
    SXD_TRAP_ID_MPLS_MTU_ERROR = 0x306,
    SXD_TRAP_ID_MPLS_TTL_ERROR = 0x307,

    /* BGP */
    SXD_TRAP_ID_IPV4_BGP = 0x88,
    SXD_TRAP_ID_IPV6_BGP = 0x89,


    /* SPAN */
    SXD_TRAP_ID_MIRROR = 0x3f,

    /* Tunneling */
    SXD_TRAP_ID_DECAP_ENCAP = 0xb0,
    SXD_TRAP_ID_IPIP_DECAP_ERROR = 0xb1,
    SXD_TRAP_ID_IPIP_ERROR = 0xb2,
    SXD_TRAP_ID_NVE_DECAP_ARP = 0xb8,
    SXD_TRAP_ID_NVE_DECAP_TAG_ERROR = 0xb9,
    SXD_TRAP_ID_NVE_IPV4_DHCP = 0xba,
    SXD_TRAP_ID_NVE_IPV6_DHCP = 0xbb,
    SXD_TRAP_ID_NVE_DECAP_FRAG_ERROR = 0xbc,
    SXD_TRAP_ID_NVE_ENCAP_ARP = 0xbd,

    /* SW Generated Events */
    SXD_TRAP_ID_SIGNAL = 0x200,
    SXD_TRAP_ID_TRANSACTION_ERROR = 0x20b,

    /*User defined trap ID*/
    SXD_TRAP_ID_IP2ME_CUSTOM0 = 0xc0,
    SXD_TRAP_ID_IP2ME_CUSTOM1 = 0xc1,

    SXD_TRAP_ID_MIN = SXD_TRAP_ID_GENERAL_FDB,
    SXD_TRAP_ID_MAX = SXD_TRAP_ID_TRANSACTION_ERROR,
} sxd_trap_id_t;

typedef enum sxd_trap_action {
    SXD_TRAP_ACTION_IGNORE = 0,
    SXD_TRAP_ACTION_TRAP_2_CPU = 1,
    SXD_TRAP_ACTION_MIRROR_2_CPU = 2,
    SXD_TRAP_ACTION_DISCARD = 3,
    SXD_TRAP_ACTION_SOFT_DISCARD = 4,
    SXD_TRAP_ACTION_TRAP_SOFT_DISCARD = 5,
    SXD_TRAP_ACTION_EXCEPTION_TRAP = 6,

    SXD_TRAP_ACTION_MIN = SXD_TRAP_ACTION_IGNORE,
    SXD_TRAP_ACTION_MAX = SXD_TRAP_ACTION_EXCEPTION_TRAP
} sxd_trap_action_t;

typedef enum sxd_trap_group {
    SXD_TRAP_GROUP_0 = 0,
    SXD_TRAP_GROUP_1 = 1,
    SXD_TRAP_GROUP_2 = 2,
    SXD_TRAP_GROUP_3 = 3,
    SXD_TRAP_GROUP_4 = 4, /* EMADs only */
    SXD_TRAP_GROUP_DISABLE = 0xff,

    SXD_TRAP_GROUP_MIN = SXD_TRAP_GROUP_0,
    SXD_TRAP_GROUP_MAX = SXD_TRAP_GROUP_4
} sxd_trap_group_t;

/************************************************
 *  Macros
 ***********************************************/

#define SXD_TRAP_ID_COUNT SXD_TRAP_ID_MAX - SXD_TRAP_ID_MIN + 1

#define SXD_TRAP_GROUP_COUNT SXD_TRAP_GROUP_MAX - SXD_TRAP_GROUP_MIN + 1

#define SXD_TRAP_CHECK_TRAP_RANGE(TRAP_ID) SXD_CHECK_RANGE(SXD_TRAP_ID_MIN, TRAP_ID, SXD_TRAP_ID_MAX)
#define SXD_TRAP_CHECK_TRAP_ACTION_RANGE(TRAP_ACTION) \
    SXD_CHECK_RANGE(SXD_TRAP_ACTION_MIN,              \
                    TRAP_ACTION,                      \
                    SXD_TRAP_ACTION_MAX)
#define SXD_TRAP_CHECK_TRAP_GROUP_RANGE(TRAP_GROUP) \
    SXD_CHECK_RANGE(SXD_TRAP_GROUP_MIN,             \
                    TRAP_GROUP,                     \
                    SXD_TRAP_GROUP_MAX)

#define SXD_TRAP_CHECK_TRAP_IPTRAP_RANGE(TRAP_ID) \
    SXD_CHECK_RANGE(SXD_TRAP_ID_IPTRAP_MIN,       \
                    TRAP_ID,                      \
                    SXD_TRAP_ID_IPTRAP_MAX)
#define SXD_TRAP_CHECK_TRAP_ACL_RANGE(TRAP_ID) SXD_CHECK_RANGE(SXD_TRAP_ID_ACL_MIN, TRAP_ID, SXD_TRAP_ID_ACL_MAX)

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_TRAP_ID_H__ */
