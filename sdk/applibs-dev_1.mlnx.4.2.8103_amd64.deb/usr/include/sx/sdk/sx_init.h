/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */

#ifndef __SX_INIT_H__
#define __SX_INIT_H__

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_TCAM_OPT_MODE(F)                           \
    F(SX_TCAM_OPT_MODE_DYNAMIC = 0, "Dynamic")             \
    F(SX_TCAM_OPT_MODE_STATIC, "Static")                   \
    F(SX_TCAM_OPT_MODE_DISABLED, "Disabled")               \
    F(SX_TCAM_OPT_MODE_MIN = SX_TCAM_OPT_MODE_DYNAMIC, "") \
    F(SX_TCAM_OPT_MODE_MAX = SX_TCAM_OPT_MODE_DISABLED, "")

typedef enum sx_tcam_opt_mode {
    FOREACH_TCAM_OPT_MODE(SX_GENERATE_ENUM)
} sx_tcam_opt_mode_t;

#define SX_TCAM_OPT_MODE_CHECK_RANGE(mode) \
    SX_CHECK_RANGE(SX_TCAM_OPT_MODE_MIN,   \
                   (int)mode,              \
                   SX_TCAM_OPT_MODE_MAX)


#define FOREACH_TCAM_OPT_MODE_PARAM(F)                              \
    F(SX_TCAM_OPT_MODE_PARAM_NONE = 0, "None")                      \
    F(SX_TCAM_OPT_MODE_PARAM_FWS_64B, "FWS_64B")                    \
    F(SX_TCAM_OPT_MODE_PARAM_FWS_128B, "FWS_128B")                  \
    F(SX_TCAM_OPT_MODE_PARAM_FWS_256B, "FWS_256B")                  \
    F(SX_TCAM_OPT_MODE_PARAM_FWS_512B, "FWS_512B")                  \
    F(SX_TCAM_OPT_MODE_PARAM_FWS_1024B, "FWS_1024B")                \
    F(SX_TCAM_OPT_MODE_PARAM_MIN = SX_TCAM_OPT_MODE_PARAM_NONE, "") \
    F(SX_TCAM_OPT_MODE_PARAM_MAX = SX_TCAM_OPT_MODE_PARAM_FWS_1024B, "")

typedef enum sx_tcam_opt_mode_param {
    FOREACH_TCAM_OPT_MODE_PARAM(SX_GENERATE_ENUM)
} sx_tcam_opt_mode_param_t;

#define SX_TCAM_OPT_MODE_PARAM_CHECK_RANGE(param) \
    SX_CHECK_RANGE(SX_TCAM_OPT_MODE_PARAM_MIN,    \
                   (int)param,                    \
                   SX_TCAM_OPT_MODE_PARAM_MAX)


/**
 * sx_tcam_opt_params_t struct is used for holding TCAM optimization mode and
 * parameters
 */
typedef struct sx_tcam_opt_params {
    sx_tcam_opt_mode_t       tcam_opt_mode;
    sx_tcam_opt_mode_param_t tcam_opt_mode_param;
} sx_tcam_opt_params_t;

#endif /* __SX_INIT_H__ */
