/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2016 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PORT_REG_H__
#define __SXD_EMAD_PORT_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_pspa_reg_t structure is used to store PSPA register
 * layout.
 */
typedef struct sxd_emad_pspa_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t sub_port;
    uint8_t reserved1[5];
} PACK_SUFFIX sxd_emad_pspa_reg_t;

/**
 * sxd_emad_spmcr_reg_t structure is used to store SPMCR register
 * layout.
 */
typedef struct sxd_emad_spmcr_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t max_sub_port;
    uint8_t reserved1[3];
    net16_t base_stag_vid;
} PACK_SUFFIX sxd_emad_spmcr_reg_t;

/**
 * sxd_emad_pmtu_reg_t structure is used to store PMTU register
 * layout.
 */
typedef struct sxd_emad_pmtu_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    net16_t max_mtu;
    net16_t reserved3;
    net16_t admin_mtu;
    net16_t reserved4;
    net16_t oper_mtu;
    net16_t reserved5;
} PACK_SUFFIX sxd_emad_pmtu_reg_t;

/**
 * sxd_emad_pmcr_reg_t structure is used to store PMCR register
 * layout.
 */
typedef struct sxd_emad_pmcr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    net16_t reserved2;
    net32_t reserved3;
    uint8_t reserved4[3];
    uint8_t cdr_override;
    net32_t reserved5;
} PACK_SUFFIX sxd_emad_pmcr_reg_t;

/**
 * sxd_emad_sbcm_reg_t structure is used to store SBCM register
 * layout.
 */
typedef struct sxd_emad_sbcm_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t pg_buff;
    uint8_t dir;
    uint8_t reserved2[12];
    net32_t buff_occupancy;
    net32_t clr_max_buff_occupancy;
    net32_t min_buff;
    net32_t max_buff;
    uint8_t reserved3[7];
    uint8_t pool;
} PACK_SUFFIX sxd_emad_sbcm_reg_t;

/**
 * sxd_emad_sbpm_reg_t structure is used to store SBPM register
 * layout.
 */
typedef struct sxd_emad_sbpm_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t pool;
    uint8_t dir;
    uint8_t reserved2[12];
    net32_t buff_occupancy;
    net32_t clr_max_buff_occupancy;
    net32_t min_buff;
    net32_t max_buff;
    uint8_t reserved3[8];
} PACK_SUFFIX sxd_emad_sbpm_reg_t;

/**
 * sxd_emad_pplr_reg_t structure is used to store PPLR register
 * layout.
 */
typedef struct sxd_emad_pplr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[5];
    uint8_t el_il;
} PACK_SUFFIX sxd_emad_pplr_reg_t;

/**
 * sxd_emad_ptys_reg_t structure is used to store PTYS register
 * layout.
 */
typedef struct sxd_emad_ptys_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t proto_mask;
    net32_t reserved3;
    net32_t fc_proto_capability;
    net32_t eth_proto_capability;
    net32_t ib_proto_capability;
    net32_t fc_proto_admin;
    net32_t eth_proto_admin;
    net32_t ib_proto_admin;
    net32_t fc_proto_oper;
    net32_t eth_proto_oper;
    net32_t ib_proto_oper;
    net32_t reserved4[5];
} PACK_SUFFIX sxd_emad_ptys_reg_t;

/**
 * sxd_emad_ppad_reg_t structure is used to store PPAD register
 * layout.
 */
typedef struct sxd_emad_ppad_reg {
    uint8_t reserved0;
    uint8_t reserved1;
    uint8_t base_mac[6];
    net32_t reserved2[2];
} PACK_SUFFIX sxd_emad_ppad_reg_t;

/**
 * sxd_emad_paos_reg_t structure is used to store PAOS register
 * layout.
 */
typedef struct sxd_emad_paos_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t admin_status;
    uint8_t oper_status;
    uint8_t ase_ee;
    uint8_t reserved2[2];
    uint8_t e;
    net32_t reserved3[2];
} PACK_SUFFIX sxd_emad_paos_reg_t;

/**
 * sxd_emad_pmaos_reg_t structure is used to store PMAOS register
 * layout.
 */
typedef struct sxd_emad_pmaos_reg {
    uint8_t reserved0;
    uint8_t module_id;
    uint8_t admin_status;
    uint8_t oper_status;
    uint8_t ase_ee;
    uint8_t reserved2[2];
    uint8_t e;
    net32_t reserved3[2];
} PACK_SUFFIX sxd_emad_pmaos_reg_t;


/**
 * sxd_emad_pcap_reg_t structure is used to store PCAP register
 * layout.
 */
typedef struct sxd_emad_pcap_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[2];
    net32_t port_capability_mask[4];
} PACK_SUFFIX sxd_emad_pcap_reg_t;

/**
 * sxd_emad_pplm_reg_t structure is used to store PPLM register
 * layout.
 */
typedef struct sxd_emad_pplm_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  reserved2[2];
    net32_t  reserved3;
    uint8_t  port_profile_mode;
    uint8_t  static_port_profile;
    uint8_t  active_port_profile;
    uint8_t  reserved4;
    uint32_t retransmission_active_fec_mode_active;
    net16_t  reserved5;
    uint8_t  fec_override_cap_100g_fec_override_cap_50g;
    uint8_t  fec_override_cap_25g_fec_override_cap_10g_40g;
    net16_t  reserved6;
    uint8_t  fec_override_admin_100g_fec_override_admin_50g;
    uint8_t  fec_override_admin_25g_fec_override_admin_10g_40g;
} PACK_SUFFIX sxd_emad_pplm_reg_t;

/**
 * sxd_emad_pbmc_reg_t structure is used to store PER BUFFER
 * register layout.
 */
typedef struct sxd_emad_pbrl_reg {
    uint8_t  lossy_epsb;
    uint8_t  reserved1;
    uint16_t size;
    uint16_t xof_threshold;
    uint16_t xon_threshold;
} PACK_SUFFIX sxd_emad_pbrl_reg_t;

/**
 * sxd_emad_pbmc_reg_t structure is used to store PBMC register
 * layout.
 */
typedef struct sxd_emad_pbmc_reg {
    uint8_t             reserved1;
    uint8_t             local_port;
    net16_t             reserved2;
    uint16_t            xof_timer_value;
    uint16_t            xof_refresh;
    net16_t             reserved3;
    net16_t             port_buffer_size;
    sxd_emad_pbrl_reg_t buffer[SXD_PORT_PBMC_NUM_BUFF];
    uint8_t             reserved4[16];
    sxd_emad_pbrl_reg_t port_shared_buffer;
} PACK_SUFFIX sxd_emad_pbmc_reg_t;

typedef struct sxd_emad_pelc_reg {
    uint8_t op;
    uint8_t local_port;
    net16_t reserved1;
    uint8_t op_admin;
    uint8_t op_capability;
    uint8_t op_request;
    uint8_t op_active;
    net64_t admin;
    net64_t capability;
    net64_t request;
    net64_t active;
} PACK_SUFFIX sxd_emad_pelc_reg_t;

/**
 * sxd_emad_sbpr_reg_t structure is used to store SBPR register
 * layout.
 */
typedef struct sxd_emad_sbpr_reg {
    uint8_t  direction;
    uint16_t reserved1;
    uint8_t  pool_id;
    uint32_t size;
    uint8_t  reserved2[3];
    uint8_t  mode;
    uint32_t curr_buff_occupancy;
    uint32_t clr_and_max_buff_occupancy;
} PACK_SUFFIX sxd_emad_sbpr_reg_t;

/**
 * sxd_emad_ppcnt_reg_t structure is used to store PPCNT register
 * layout.
 */
typedef struct sxd_emad_ppcnt_reg {
    uint8_t swid;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t grp;
    uint8_t clr;
    uint8_t reserved3[2];
    uint8_t prio;
    net64_t cntr_list[SXD_PORT_PPCNT_MAX_CNT_NUM];
} PACK_SUFFIX sxd_emad_ppcnt_reg_t;


/**
 * sxd_emad_pmlp_reg_t structure is used to store PMLP register
 * layout.
 */
typedef struct sxd_emad_pmlp_reg {
    uint8_t use_different_rx_tx;
    uint8_t local_port;
    uint8_t reserved1;
    uint8_t width;
    uint8_t rx_lane0;
    uint8_t lane0;
    uint8_t reserved2;
    uint8_t module0;
    uint8_t rx_lane1;
    uint8_t lane1;
    uint8_t reserved3;
    uint8_t module1;
    uint8_t rx_lane2;
    uint8_t lane2;
    uint8_t reserved4;
    uint8_t module2;
    uint8_t rx_lane3;
    uint8_t lane3;
    uint8_t reserved5;
    uint8_t module3;
    net32_t reserved6[11];
} PACK_SUFFIX sxd_emad_pmlp_reg_t;

/**
 * sxd_emad_pfcc_reg_t structure is used to store PFCC register
 * layout.
 */
typedef struct sxd_emad_pfcc_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2[2];
    uint8_t reserved3_1;
    uint8_t prio_mask_tx;
    uint8_t reserved3_2;
    uint8_t prio_mask_rx;
    uint8_t pptx;
    uint8_t pcftx;
    uint8_t reserved4;
    uint8_t cbftx;
    uint8_t pprx;
    uint8_t pcfrx;
    uint8_t reserved5;
    uint8_t cbfrx;
    net32_t reserved6[4];
} PACK_SUFFIX sxd_emad_pfcc_reg_t;

/**
 * sxd_emad_pude_reg_t structure is used to store PUDE register
 * layout.
 */
typedef struct sxd_emad_pude_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t oper_status;
    net32_t reserved3[3];
} PACK_SUFFIX sxd_emad_pude_reg_t;

/**
 * sxd_emad_pmpe_reg_t structure is used to store PMPE register
 * layout.
 */
typedef struct sxd_emad_pmpe_reg {
    uint8_t reserved1;
    uint8_t module_id;
    uint8_t reserved2;
    uint8_t oper_status;
    net32_t reserved3[3];
} PACK_SUFFIX sxd_emad_pmpe_reg_t;

/**
 * sxd_emad_plib_reg_t structure is used to store PLIB register
 * layout.
 */
typedef struct sxd_emad_plib_reg {
    uint8_t m;
    uint8_t local_port;
    uint8_t reserved1;
    uint8_t ib_port;
    net32_t reserved2[3];
} PACK_SUFFIX sxd_emad_plib_reg_t;

/**
 * sxd_emad_pptb_reg_t structure is used to store PPTB register
 * layout.
 */
typedef struct sxd_emad_pptb_reg {
    uint8_t mapping_mode;
    uint8_t local_port;
    uint8_t cm_um;
    uint8_t pm;
    uint8_t prio_7_6_buff;
    uint8_t prio_5_4_buff;
    uint8_t prio_3_2_buff;
    uint8_t prio_1_0_buff;
    uint8_t prio_buff_msb;
    uint8_t reserved1[2];
    uint8_t ctrl_untagged_buff;
    uint8_t prio_15_14_buff;
    uint8_t prio_13_12_buff;
    uint8_t prio_11_10_buff;
    uint8_t prio_9_8_buff;
} PACK_SUFFIX sxd_emad_pptb_reg_t;

/**
 * sxd_emad_qpbr_reg_t structure is used to store QPBR register
 * layout.
 */
typedef struct sxd_emad_qpbr_reg {
    uint8_t  op;
    uint8_t  port;
    uint16_t g_pid;
    uint8_t  reserved1[3];
    uint8_t  flow_metering_buff;
    uint8_t  reserved2[8];
} PACK_SUFFIX sxd_emad_qpbr_reg_t;

/**
 * sxd_emad_pifr_reg_t structure is used to store PIFR register
 * layout.
 */
typedef struct sxd_emad_pifr_reg {
    uint8_t  reserved1;
    uint8_t  local_port;
    uint8_t  reserved2[2];
    uint32_t reserved3[7];
    net32_t  ports_bitmap[8];
    net32_t  mask_bitmap[8];
} PACK_SUFFIX sxd_emad_pifr_reg_t;

/**
 * sxd_emad_pmpc_reg_t structure is used to store PMPC register
 * layout.
 */
typedef struct sxd_emad_pmpc_reg {
    net32_t module_state_updated_bitmap[8];
} PACK_SUFFIX sxd_emad_pmpc_reg_t;


/**
 * sxd_emad_plbf_reg_t structure is used to store PLBF register
 * layout.
 */
typedef struct sxd_emad_plbf_reg {
    uint8_t  reserved1;
    uint8_t  port;
    uint8_t  reserved2;
    uint8_t  lbf_mode;
    uint32_t reserved3;
} PACK_SUFFIX sxd_emad_plbf_reg_t;

/**
 * sxd_emad_mpsc_reg_t structure is used to store MPSC register
 * layout.
 */
typedef struct sxd_emad_mpsc_reg {
    uint8_t  reserved1;
    uint8_t  port;
    uint8_t  reserved2[2];
    uint8_t  c_e;
    uint8_t  reserved3[3];
    uint32_t rate;
    net64_t  count_sample_drops;
} PACK_SUFFIX sxd_emad_mpsc_reg_t;

/**
 * sxd_emad_mlcr_reg_t structure is used to store MLCR register
 * layout.
 */
typedef struct sxd_emad_mlcr_reg {
    uint8_t reserved1;
    uint8_t local_port;
    uint8_t reserved2;
    uint8_t cap_local_led_type;
    net16_t reserved3;
    net16_t beacon_duration;
    net16_t reserved4;
    net16_t beacon_remain;
} PACK_SUFFIX sxd_emad_mlcr_reg_t;

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_PORT_REG_H__ */
