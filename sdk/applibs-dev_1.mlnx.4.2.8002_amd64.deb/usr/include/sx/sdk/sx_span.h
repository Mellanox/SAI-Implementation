/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_SPAN_H__
#define __SX_SPAN_H__

#include <sx/sxd/sxd_emad_span.h>

#include <sx/sdk/sx_check.h>


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

/**
 * SPAN session ID
 */
typedef uint8_t sx_span_session_id_t;

#define SX_SPAN_INVALID_LOG_PORT 0

typedef enum sx_span_type {
    SX_SPAN_TYPE_LOCAL_ETH = 1,                     /* SwitchX only  */
    SX_SPAN_TYPE_REMOTE_ETH_VLAN,                   /* SwitchX only  */
    SX_SPAN_TYPE_REMOTE_ETH_L2,                     /* SwitchX only  */
    SX_SPAN_TYPE_LOCAL_IB,                          /* future        */
    SX_SPAN_TYPE_REMOTE_IB,                         /* future        */
    SX_SPAN_TYPE_LOCAL_ETH_TYPE1,                   /* Spectrum only */
    SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1,             /* Spectrum only */
    SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1,               /* Spectrum only */
    SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1,               /* Spectrum only */
    SX_SPAN_TYPE_MIN = SX_SPAN_TYPE_LOCAL_ETH,
    SX_SPAN_TYPE_MAX = SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1
} sx_span_type_t;

#define SX_SPAN_TYPE_CHECK_RANGE(type) (SX_CHECK_RANGE(SX_SPAN_TYPE_MIN, type, SX_SPAN_TYPE_MAX))

#define SX_SPAN_TRUNCATE_SIZE_MIN         32
#define SX_SPAN_TRUNCATE_SIZE_MAX         4088
#define SX_SPAN_TRUNCATE_SIZE_GRANULARITY 4

#define SX_SPAN_SWITCH_PRIO_MAX 14

typedef enum sx_span_qos_mode {
    SX_SPAN_QOS_CONFIGURED = 0, /**< switch prio, pcp, dei, dscp are configured */
    SX_SPAN_QOS_MAINTAIN = 1,   /**< QOS params same as in original packet      */
    SX_SPAN_QOS_MIN = SX_SPAN_QOS_CONFIGURED,
    SX_SPAN_QOS_MAX = SX_SPAN_QOS_MAINTAIN,
} sx_span_qos_mode_t;

typedef enum sx_span_analyzer_port_mode {
    SX_SPAN_STATIC_ANALYZER_PORT = 0,   /**< static analyzer port   */
    SX_SPAN_DYNAMIC_ANALYZER_PORT = 1,  /**< dynamic analyzer port  */
} sx_span_analyzer_port_mode_t;

typedef struct sx_span_type_format_local_eth {
    uint8_t tclass;
} sx_span_type_format_local_eth_t;

typedef struct sx_span_type_format_local_eth_type1 {
    sx_span_qos_mode_t qos_mode;
    uint8_t            switch_prio;
} sx_span_type_format_local_eth_type1_t;

typedef struct sx_span_type_format_remote_eth_vlan {
    uint8_t      tclass;
    sx_vlan_id_t vid;
    uint8_t      prio;
} sx_span_type_format_remote_eth_vlan_t;

typedef struct sx_span_type_format_remote_eth_vlan_type1 {
    sx_span_qos_mode_t qos_mode;
    uint8_t            switch_prio;
    sx_vlan_id_t       vid;
    uint8_t            vlan_ethertype_id;
    sx_cos_pcp_t       pcp;
    sx_cos_dei_t       dei;
} sx_span_type_format_remote_eth_vlan_type1_t;

typedef struct sx_span_type_format_remote_eth_l2 {
    uint8_t       tclass;
    sx_vlan_id_t  vid;
    uint8_t       prio;
    uint8_t       tp;
    sx_mac_addr_t mac;
} sx_span_type_format_remote_eth_l2_t;

typedef struct sx_span_type_format_remote_eth_l2_type1 {
    sx_span_qos_mode_t qos_mode;
    uint8_t            switch_prio;
    sx_vlan_id_t       vid;
    uint8_t            vlan_ethertype_id;
    sx_cos_pcp_t       pcp;
    sx_cos_dei_t       dei;
    uint8_t            tp;
    sx_mac_addr_t      mac;
} sx_span_type_format_remote_eth_l2_type1_t;

typedef struct sx_span_type_format_local_ib {
    uint8_t vl;
} sx_span_type_format_local_ib_t;

typedef struct sx_span_type_format_remote_ib {
    uint8_t vl;
    uint8_t slid;
    uint8_t dlid;
    uint8_t sl;
} sx_span_type_format_remote_ib_t;

typedef struct sx_span_type_format_remote_eth_l3_type1 {
    sx_span_qos_mode_t qos_mode;
    uint8_t            switch_prio;
    sx_vlan_id_t       vid;
    uint8_t            vlan_ethertype_id;
    sx_cos_pcp_t       pcp;
    sx_cos_dei_t       dei;
    uint8_t            tp;
    sx_mac_addr_t      mac;
    sx_mac_addr_t      smac;
    sx_ip_addr_t       dest_ip;
    sx_ip_addr_t       src_ip;
    uint8_t            dscp;
    sx_cos_ecn_t       ecn;
    uint8_t            ttl;
} sx_span_type_format_remote_eth_l3_type1_t;

/**
 * SPAN session type format
 */
typedef union sx_span_type_format {
    sx_span_type_format_local_eth_t             local_eth;              /**< SwitchX only            */
    sx_span_type_format_remote_eth_vlan_t       remote_eth_vlan;        /**< SwitchX only            */
    sx_span_type_format_remote_eth_l2_t         remote_eth_l2;          /**< SwitchX only            */
    sx_span_type_format_local_ib_t              local_ib;               /**< Currently not supported */
    sx_span_type_format_remote_ib_t             remote_ib;              /**< Currently not supported */
    sx_span_type_format_local_eth_type1_t       local_eth_type1;        /**< Spectrum only           */
    sx_span_type_format_remote_eth_vlan_type1_t remote_eth_vlan_type1;  /**< Spectrum only           */
    sx_span_type_format_remote_eth_l2_type1_t   remote_eth_l2_type1;    /**< Spectrum only           */
    sx_span_type_format_remote_eth_l3_type1_t   remote_eth_l3_type1;    /**< Spectrum only           */
} sx_span_type_format_t;

/**
 * SPAN session params
 */
typedef struct sx_span_session_params {
    sx_span_type_t        span_type;        /**< Span type : ETH/ETH VLAN .. */
    sx_span_type_format_t span_type_format; /**< Encapsulation */
    boolean_t             truncate;         /**< Truncate packets */
    uint16_t              truncate_size;    /**< Truncate size */
} sx_span_session_params_t;

typedef enum sx_span_cng_mng {
    SX_SPAN_CNG_MNG_DONT_DISCARD,
    SX_SPAN_CNG_MNG_DISCARD,
    SX_SPAN_CNG_MNG_MIN = SX_SPAN_CNG_MNG_DONT_DISCARD,
    SX_SPAN_CNG_MNG_MAX = SX_SPAN_CNG_MNG_DISCARD,
} sx_span_cng_mng_t;

typedef struct sx_span_analyzer_port_params {
    sx_span_cng_mng_t cng_mng;                                  /**< Congestion operation */
} sx_span_analyzer_port_params_t;

typedef enum sx_mirror_direction {
    SX_SPAN_MIRROR_INGRESS = 1,
    SX_SPAN_MIRROR_EGRESS,
    SX_SPAN_MIRROR_DIRECTION_MIN = SX_SPAN_MIRROR_INGRESS,
    SX_SPAN_MIRROR_DIRECTION_MAX = SX_SPAN_MIRROR_EGRESS,
} sx_mirror_direction_t;

typedef enum sx_mirror_mode {
    SX_MIRROR_MODE_DISABLED,
    SX_MIRROR_MODE_ENABLED,
    SX_MIRROR_MODE_MAX = SX_MIRROR_MODE_ENABLED,
} sx_mirror_mode_t;

typedef struct sx_span_mirror {
    sx_port_log_id_t      log_port;
    sx_mirror_direction_t mirror_direction;
} sx_span_mirror_t;

typedef enum sx_span_mirror_header_version {
    SX_SPAN_MIRROR_HEADER_VERSION_0,
    SX_SPAN_MIRROR_HEADER_VERSION_1,
    SX_SPAN_MIRROR_HEADER_NONE,
    SX_SPAN_MIRROR_HEADER_VERSION_MIN = SX_SPAN_MIRROR_HEADER_VERSION_0,
    SX_SPAN_MIRROR_HEADER_VERSION_MAX = SX_SPAN_MIRROR_HEADER_NONE,
} sx_span_mirror_header_version_t;

typedef struct sx_span_init_params {
    sx_span_mirror_header_version_t version;
} sx_span_init_params_t;

typedef struct sx_span_counter_set {
    uint64_t mirroring_best_effort_drop_packets;
} sx_span_counter_set_t;

#define FOREACH_SPAN_DROP_REASON(F)                                           \
    F(SX_SPAN_DROP_REASON_ALL_ROUTER_DROPS_E = 0, "All Router Drops")         \
    F(SX_SPAN_DROP_REASON_DISCARD_ING_PACKET_E, "Ingress Packet")             \
    F(SX_SPAN_DROP_REASON_DISCARD_ING_SWITCH_E, "Ingress Switch")             \
    F(SX_SPAN_DROP_REASON_DISCARD_LOOKUP_SWITCH_E, "Lookup Switch")           \
    F(SX_SPAN_DROP_REASON_DISCARD_ING_ROUTER_E, "Ingress Router")             \
    F(SX_SPAN_DROP_REASON_DISCARD_ING_LSR_E, "Ingress LSR")                   \
    F(SX_SPAN_DROP_REASON_DISCARD_ROUTER_E, "Router")                         \
    F(SX_SPAN_DROP_REASON_DISCARD_ROUTER2_E, "Router 2")                      \
    F(SX_SPAN_DROP_REASON_DISCARD_ROUTER3_E, "Router 3")                      \
    F(SX_SPAN_DROP_REASON_DISCARD_LSR_E, "LSR")                               \
    F(SX_SPAN_DROP_REASON_DISCARD_LSR2_E, "LSR 2")                            \
    F(SX_SPAN_DROP_REASON_DISCARD_LSR3_E, "LSR 3")                            \
    F(SX_SPAN_DROP_REASON_DISCARD_DEC_E, "Decap")                             \
    F(SX_SPAN_DROP_REASON_DISCARD_OVERLAY_SWITCH_E, "Overlay Switch")         \
    F(SX_SPAN_DROP_REASON_DISCARD_ISOLATION_E, "Isolation")                   \
    F(SX_SPAN_DROP_REASON_DISCARD_NON_ROUTED_E, "Non Routed")                 \
    F(SX_SPAN_DROP_REASON_DISCARD_EGR_LSR_E, "Ehress LSR")                    \
    F(SX_SPAN_DROP_REASON_DISCARD_MC_SCOPE_E, "MC Scope")                     \
    F(SX_SPAN_DROP_REASON_MIN_E = SX_SPAN_DROP_REASON_ALL_ROUTER_DROPS_E, "") \
    F(SX_SPAN_DROP_REASON_MAX_E = SX_SPAN_DROP_REASON_DISCARD_MC_SCOPE_E, "")

typedef enum sx_span_drop_reason {
    FOREACH_SPAN_DROP_REASON(SX_GENERATE_ENUM)
} sx_span_drop_reason_t;

#define SX_SPAN_DROP_REASON_COUNT (SX_SPAN_DROP_REASON_MAX_E + 1)
#define SX_SPAN_DROP_REASON_CHECK_RANGE(reason) (SX_CHECK_MAX(reason, SX_SPAN_DROP_REASON_MAX_E))

typedef struct sx_span_drop_mirroring_attr {
    int reserved;
} sx_span_drop_mirroring_attr_t;

/*
 * Filter for sx_api_span_session_iter_get
 */
typedef struct sx_span_filter {
    boolean_t             filter_by_drop_reason;
    sx_span_drop_reason_t drop_reason;
} sx_span_filter_t;

#endif /* __SX_SPAN_H__ */
