/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef SX_BRIDGE_H_
#define SX_BRIDGE_H_

#include <sx/sdk/sx_tunnel_id.h>

/************************************************
 *  Type definitions
 ***********************************************/
typedef uint16_t sx_bridge_id_t;

/*********
* ENUMS *
*********/
#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_BRIDGE_MODE(F)                                                          \
    F(SX_MODE_802_1Q = 0, "SX_MODE_802_1Q") /**< 802.1D */                              \
    F(SX_MODE_802_1D = 1, "SX_MODE_802_1D") /**< 802.1D */                              \
    F(SX_MODE_HYBRID = 2, "SX_MODE_HYBRID") /**< Hybrid, Supported devices: Spectrum */ \
    F(SX_MODE_MAX = SX_MODE_HYBRID, "")

typedef enum sx_bridge_mode {
    FOREACH_BRIDGE_MODE(SX_GENERATE_ENUM)
} sx_bridge_mode_t;

#define FOREACH_BRIDGE_MULTIPLE_VLAN_MODE(F)                                   \
    F(SX_BRIDGE_MULTIPLE_VLAN_MODE_HOMOGENOUS = 0, "HOMOGENEOUS MODE")         \
    F(SX_BRIDGE_MULTIPLE_VLAN_MODE_NON_HOMOGENOUS = 1, "NON HOMOGENEOUS MODE") \
    F(SX_BRIDGE_MULTIPLE_VLAN_MODE_MAX = SX_BRIDGE_MULTIPLE_VLAN_MODE_NON_HOMOGENOUS, "")

typedef enum sx_bridge_multiple_vlan_mode {
    FOREACH_BRIDGE_MULTIPLE_VLAN_MODE(SX_GENERATE_ENUM)
} sx_bridge_multiple_vlan_mode_t;

#define FOREACH_BRIDGE_TUNNEL_COUNTER_TYPE(F)                                         \
    F(SX_BRIDGE_COUNTER_TUNNEL_DECAP_E = 0, "SX_BRIDGE_COUNTER_TUNNEL_DECAP_E")       \
    F(SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E = 1, "SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E") \
    F(SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E = 2, "SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E") \
    F(SX_BRIDGE_COUNTER_TUNNEL_TYPE_MIN = SX_BRIDGE_COUNTER_TUNNEL_DECAP_E, "")       \
    F(SX_BRIDGE_COUNTER_TUNNEL_TYPE_MAX = SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E, "")

typedef enum sx_bridge_tunnel_counter_type {
    FOREACH_BRIDGE_TUNNEL_COUNTER_TYPE(SX_GENERATE_ENUM)
} sx_bridge_tunnel_counter_type_t;

/**********************************************
 *  DEFINITIONS
 ***********************************************/

typedef boolean_t sx_mode_802_1Q_t;

#define SX_BRIDGE_ID_INVALID 0xffff

typedef struct sx_mode_802_1D {
    uint32_t                       max_bridge_num;
    uint32_t                       max_virtual_ports_num;
    sx_bridge_multiple_vlan_mode_t multiple_vlan_bridge_mode;
} sx_mode_802_1D_t;

typedef struct sx_mode_hybrid {
    uint32_t max_bridge_num;
} sx_mode_hybrid_t;

typedef union sx_bridge_mode_params {
    sx_mode_802_1Q_t mode_1Q;
    sx_mode_802_1D_t mode_1D;
    sx_mode_hybrid_t mode_hybrid; /** Supported devices: Spectrum */
} sx_bridge_mode_params_t;

typedef struct sx_bridge_params {
    sx_bridge_mode_t        sdk_mode;
    sx_bridge_mode_params_t sdk_mode_params;
} sx_bridge_params_t;

typedef struct sx_bridge_port {
    sx_port_log_id_t           log_port;
    sx_vlan_id_t               vlan;
    sx_untagged_member_state_t egress_mode;
} sx_bridge_port_t;

typedef struct sx_bridge_tunnel_counter_attr {
    sx_bridge_tunnel_counter_type_t type;       /* type of bridge_tunnel flow counter*/
    sx_tunnel_id_t                  tunnel_id;  /* tunnel which is mapped to bridge */
} sx_bridge_tunnel_counter_attr_t;

typedef struct sx_bridge_filter {
    /* Reserved for future expansion*/
} sx_bridge_filter_t;


#endif /* SX_BRIDGE_H_ */
