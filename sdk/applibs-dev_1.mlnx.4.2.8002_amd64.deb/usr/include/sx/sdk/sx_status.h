/*
 *  Copyright (C) 2010-2018. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_STATUS_H__
#define __SX_STATUS_H__

#include <sx/sdk/sx_check.h>
#include <sx/sxd/sxd_status.h>

/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_SX_STATUS(F)                                                                                  \
    F(SX_STATUS_SUCCESS = 0, "Success")                                                                       \
    F(SX_STATUS_ERROR = 1, "Internal Error")                                                                  \
    F(SX_STATUS_SDK_NOT_INITIALIZED = 2, "SwitchX SDK wasn't Initialized")                                    \
    F(SX_STATUS_INVALID_HANDLE = 3, "Invalid Handle")                                                         \
    F(SX_STATUS_COMM_ERROR = 4, "Communication Error")                                                        \
    F(SX_STATUS_NO_RESOURCES = 5, "No More Resources")                                                        \
    F(SX_STATUS_NO_MEMORY = 6, "No More Memory")                                                              \
    F(SX_STATUS_MEMORY_ERROR = 7, "Memory Error")                                                             \
    F(SX_STATUS_CMD_ERROR = 8, "Command Error")                                                               \
    F(SX_STATUS_CMD_INCOMPLETE = 9, "Command Not Completed")                                                  \
    F(SX_STATUS_CMD_UNSUPPORTED = 10, "Command Unsupported")                                                  \
    F(SX_STATUS_CMD_UNPERMITTED = 11, "Command Unpermitted")                                                  \
    F(SX_STATUS_PARAM_NULL = 12, "Parameter NULL")                                                            \
    F(SX_STATUS_PARAM_ERROR = 13, "Parameter Error")                                                          \
    F(SX_STATUS_PARAM_EXCEEDS_RANGE = 14, "Parameter Exceeds Range")                                          \
    F(SX_STATUS_MESSAGE_SIZE_ZERO = 15, "Message Size Exceeds Limit")                                         \
    F(SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT = 16, "Message Size Exceeds Limit")                                \
    F(SX_STATUS_DB_ALREADY_INITIALIZED = 17, "Database Already Initialized")                                  \
    F(SX_STATUS_DB_NOT_INITIALIZED = 18, "Database Wasn't Initialized")                                       \
    F(SX_STATUS_DB_NOT_EMPTY = 19, "Database Not Empty")                                                      \
    F(SX_STATUS_END_OF_DB = 20, "End of Database")                                                            \
    F(SX_STATUS_ENTRY_NOT_FOUND = 21, "Entry Not Found")                                                      \
    F(SX_STATUS_ENTRY_ALREADY_EXISTS = 22, "Entry Already Exists")                                            \
    F(SX_STATUS_ENTRY_NOT_BOUND = 23, "Entry Not Bound")                                                      \
    F(SX_STATUS_ENTRY_ALREADY_BOUND = 24, "Entry Already bound")                                              \
    F(SX_STATUS_WRONG_POLICER_TYPE = 25, "Wrong Policer Type")                                                \
    F(SX_STATUS_UNEXPECTED_EVENT_TYPE = 26, "Unexpected event type")                                          \
    F(SX_STATUS_TRAP_ID_NOT_CONFIGURED = 27, "Trap ID not configured")                                        \
    F(SX_STATUS_INT_COMM_CLOSE = 28, "Internal Communication close")                                          \
    F(SX_STATUS_RESOURCE_IN_USE = 29, "Resource is in use")                                                   \
    F(SX_STATUS_EVENT_TRAP_ALREADY_ASSOCIATED = 30, "Trap ID is already associated to another trap priority") \
    F(SX_STATUS_ALREADY_INITIALIZED = 31, "Already initialized")                                              \
    F(SX_STATUS_TIMEOUT = 32, "TIMEOUT")                                                                      \
    F(SX_STATUS_MODULE_UNINITIALIZED = 33, "Module is uninitialized")                                         \
    F(SX_STATUS_UNSUPPORTED = 34, "Operation Unsupported")                                                    \
    F(SX_STATUS_SX_UTILS_RETURNED_NON_ZERO = 35, "Utils return status is Non-Zero")                           \
    F(SX_STATUS_PARTIALLY_COMPLETE = 36, "Partially complete")                                                \
    F(SX_STATUS_ACCEPTED = 37, "Accepted")                                                                    \
    F(SX_STATUS_INVALID1 /*38*/, "")                                                                          \
    F(SX_STATUS_INVALID2 /*39*/, "")                                                                          \
    F(SX_STATUS_INVALID3 /*40*/, "")                                                                          \
    F(SX_STATUS_INVALID4 /*41*/, "")                                                                          \
    F(SX_STATUS_INVALID5 /*42*/, "")                                                                          \
    F(SX_STATUS_INVALID6 /*43*/, "")                                                                          \
    F(SX_STATUS_INVALID7 /*44*/, "")                                                                          \
    F(SX_STATUS_INVALID8 /*45*/, "")                                                                          \
    F(SX_STATUS_INVALID9 /*46*/, "")                                                                          \
    F(SX_STATUS_INVALID10 /*47*/, "")                                                                         \
    F(SX_STATUS_INVALID11 /*48*/, "")                                                                         \
    F(SX_STATUS_INVALID12 /*49*/, "")                                                                         \
    F(SX_STATUS_INVALID13 /*50*/, "")                                                                         \
    F(SX_STATUS_INVALID14 /*51*/, "")                                                                         \
    F(SX_STATUS_INVALID15 /*52*/, "")                                                                         \
    F(SX_STATUS_INVALID16 /*53*/, "")                                                                         \
    F(SX_STATUS_INVALID17 /*54*/, "")                                                                         \
    F(SX_STATUS_INVALID18 /*55*/, "")                                                                         \
    F(SX_STATUS_INVALID19 /*56*/, "")                                                                         \
    F(SX_STATUS_INVALID20 /*57*/, "")                                                                         \
    F(SX_STATUS_INVALID21 /*58*/, "")                                                                         \
    F(SX_STATUS_INVALID22 /*59*/, "")                                                                         \
    F(SX_STATUS_INVALID23 /*60*/, "")                                                                         \
    F(SX_STATUS_INVALID24 /*61*/, "")                                                                         \
    F(SX_STATUS_INVALID25 /*62*/, "")                                                                         \
    F(SX_STATUS_INVALID26 /*63*/, "")                                                                         \
    F(SX_STATUS_INVALID27 /*64*/, "")                                                                         \
    F(SX_STATUS_INVALID28 /*65*/, "")                                                                         \
    F(SX_STATUS_INVALID29 /*66*/, "")                                                                         \
    F(SX_STATUS_INVALID30 /*67*/, "")                                                                         \
    F(SX_STATUS_INVALID31 /*68*/, "")                                                                         \
    F(SX_STATUS_INVALID32 /*69*/, "")                                                                         \
    F(SX_STATUS_INVALID33 /*70*/, "")                                                                         \
    F(SX_STATUS_INVALID34 /*71*/, "")                                                                         \
    F(SX_STATUS_INVALID35 /*72*/, "")                                                                         \
    F(SX_STATUS_INVALID36 /*73*/, "")                                                                         \
    F(SX_STATUS_INVALID37 /*74*/, "")                                                                         \
    F(SX_STATUS_INVALID38 /*75*/, "")                                                                         \
    F(SX_STATUS_INVALID39 /*76*/, "")                                                                         \
    F(SX_STATUS_INVALID40 /*77*/, "")                                                                         \
    F(SX_STATUS_INVALID41 /*78*/, "")                                                                         \
    F(SX_STATUS_INVALID42 /*79*/, "")                                                                         \
    F(SX_STATUS_INVALID43 /*80*/, "")                                                                         \
    F(SX_STATUS_INVALID44 /*81*/, "")                                                                         \
    F(SX_STATUS_INVALID45 /*82*/, "")                                                                         \
    F(SX_STATUS_INVALID46 /*83*/, "")                                                                         \
    F(SX_STATUS_INVALID47 /*84*/, "")                                                                         \
    F(SX_STATUS_INVALID48 /*85*/, "")                                                                         \
    F(SX_STATUS_INVALID50 /*86*/, "")                                                                         \
    F(SX_STATUS_INVALID51 /*87*/, "")                                                                         \
    F(SX_STATUS_INVALID52 /*88*/, "")                                                                         \
    F(SX_STATUS_INVALID53 /*89*/, "")                                                                         \
    F(SX_STATUS_INVALID54 /*90*/, "")                                                                         \
    F(SX_STATUS_INVALID55 /*91*/, "")                                                                         \
    F(SX_STATUS_INVALID56 /*92*/, "")                                                                         \
    F(SX_STATUS_INVALID57 /*93*/, "")                                                                         \
    F(SX_STATUS_INVALID58 /*94*/, "")                                                                         \
    F(SX_STATUS_INVALID59 /*95*/, "")                                                                         \
    F(SX_STATUS_INVALID60 /*96*/, "")                                                                         \
    F(SX_STATUS_INVALID61 /*97*/, "")                                                                         \
    F(SX_STATUS_INVALID62 /*98*/, "")                                                                         \
    F(SX_STATUS_INVALID63 /*99*/, "")                                                                         \
    F(SX_STATUS_INVALID64 /*100*/, "")                                                                        \
    F(SX_STATUS_SXD_RETURNED_NON_ZERO = 101, "Driver's Return Status is Non-Zero")                            \
    F(SX_STATUS_MIN = SX_STATUS_SUCCESS, "")                                                                  \
    F(SX_STATUS_MAX = SX_STATUS_SXD_RETURNED_NON_ZERO, "")

/**
 * sx_status_t
 * Enumerated type - Provides functions' return values.
 */
typedef enum sx_status {
    FOREACH_SX_STATUS(SX_GENERATE_ENUM)
} sx_status_t;

static __attribute__((__used__)) const sx_status_t sxd_status2sx_status_arr[] = {
    /* SXD_STATUS_SUCCESS */
    SX_STATUS_SUCCESS,
    /* SXD_STATUS_ERROR */
    SX_STATUS_ERROR,
    /* SXD_STATUS_NO_RESOURCES */
    SX_STATUS_NO_RESOURCES,
    /* SXD_STATUS_NO_MEMORY */
    SX_STATUS_NO_MEMORY,
    /* SXD_STATUS_PARAM_ERROR */
    SX_STATUS_PARAM_ERROR,
    /* SXD_STATUS_NOT_INITIALIZED */
    SX_STATUS_ERROR,
    /* SXD_STATUS_DEVICE_OPEN_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_CLOSE_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_GET_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_DEVICE_IOCTL_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_HANDLE_ERROR */
    SX_STATUS_INVALID_HANDLE,
    /* SXD_STATUS_INVALID_ACCESS_CMD */
    SX_STATUS_CMD_ERROR,
    /* SXD_STATUS_TIMEOUT */
    SX_STATUS_TIMEOUT,
    /* SXD_STATUS_CMD_UNSUPPORTED */
    SX_STATUS_CMD_UNSUPPORTED,
    /* SXD_STATUS_NO_PATH_TO_DEVICE */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_ERROR */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_BUSY */
    SX_STATUS_SXD_RETURNED_NON_ZERO,
    /* SXD_STATUS_FW_NO_RESOURCES */
    SX_STATUS_NO_RESOURCES
};

#define SXD_STATUS_TO_SX_STATUS(STATUS)                                 \
    SXD_STATUS_CHECK_RANGE(STATUS) ? sxd_status2sx_status_arr[STATUS] : \
    SX_STATUS_SXD_RETURNED_NON_ZERO

static inline sx_status_t sxd_status_to_sx_status(sxd_status_t sxd_status)
{
    return SXD_STATUS_TO_SX_STATUS((int)sxd_status);
}


/************************************************
 *  Macro definitions
 ***********************************************/


#define SX_STATUS_CHECK_RANGE(STATUS) SX_CHECK_RANGE(SX_STATUS_MIN, (int)STATUS, SX_STATUS_MAX)


#endif /* __SX_STATUS_H__ */
