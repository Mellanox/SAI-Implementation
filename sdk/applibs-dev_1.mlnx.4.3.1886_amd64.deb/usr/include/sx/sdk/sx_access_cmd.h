/*
 *  Copyright (C) 2010-2019. Mellanox Technologies, Ltd. ALL RIGHTS RESERVED.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License"); you may
 *    not use this file except in compliance with the License. You may obtain
 *    a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 *    THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 *    CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 *    LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 *    FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 *    See the Apache Version 2.0 License for specific language governing
 *    permissions and limitations under the License.
 *
 */


#ifndef __SX_ACCESS_CMD_H__
#define __SX_ACCESS_CMD_H__

#include <sx/sdk/sx_check.h>


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define FOREACH_ACCESS_CMD(F)                                    \
    F(SX_ACCESS_CMD_NONE = 0, "NONE")                            \
    F(SX_ACCESS_CMD_ADD = 1, "ADD")                              \
    F(SX_ACCESS_CMD_EDIT = 2, "EDIT")                            \
    F(SX_ACCESS_CMD_DELETE = 3, "DELETE")                        \
    F(SX_ACCESS_CMD_DELETE_ALL = 4, "DELETE ALL")                \
    F(SX_ACCESS_CMD_SOFT_ADD = 5, "SOFT ADD")                    \
    F(SX_ACCESS_CMD_SOFT_EDIT = 6, "SOFT EDIT")                  \
    F(SX_ACCESS_CMD_SOFT_DELETE = 7, "SOFT DELETE")              \
    F(SX_ACCESS_CMD_TEST = 8, "TEST")                            \
    F(SX_ACCESS_CMD_APPLY = 9, "APPLY")                          \
    F(SX_ACCESS_CMD_ENABLE = 10, "ENABLE")                       \
    F(SX_ACCESS_CMD_DISABLE = 11, "DISABLE")                     \
    F(SX_ACCESS_CMD_CREATE = 12, "CREATE")                       \
    F(SX_ACCESS_CMD_DESTROY = 13, "DESTROY")                     \
    F(SX_ACCESS_CMD_COUNT = 14, "COUNT")                         \
    F(SX_ACCESS_CMD_SET = 15, "SET")                             \
    F(SX_ACCESS_CMD_UNSET = 16, "UNSET")                         \
    F(SX_ACCESS_CMD_GET = 17, "GET")                             \
    F(SX_ACCESS_CMD_GETNEXT = 18, "GET NEXT")                    \
    F(SX_ACCESS_CMD_REGISTER = 19, "REGISTER")                   \
    F(SX_ACCESS_CMD_DEREGISTER = 20, "DEREGISTER")               \
    F(SX_ACCESS_CMD_GET_ALL = 21, "GET ALL")                     \
    F(SX_ACCESS_CMD_TEST_HW = 22, "TEST HW")                     \
    F(SX_ACCESS_CMD_ADD_PORTS = 23, "ADD PORTS")                 \
    F(SX_ACCESS_CMD_DELETE_PORTS = 24, "DELETE PORTS")           \
    F(SX_ACCESS_CMD_BIND = 25, "BIND")                           \
    F(SX_ACCESS_CMD_UNBIND = 26, "UNBIND")                       \
    F(SX_ACCESS_CMD_GET_FIRST = 27, "GET FIRST")                 \
    F(SX_ACCESS_CMD_REPLACE_ALL_PORTS = 28, "REPLACE ALL PORTS") \
    F(SX_ACCESS_CMD_DELETE_ALL_PORTS = 29, "DELETE ALL PORTS")   \
    F(SX_ACCESS_CMD_READY = 30, "READY")                         \
    F(SX_ACCESS_CMD_READ = 31, "READ")                           \
    F(SX_ACCESS_CMD_READ_CLEAR = 32, "READ CLEAR")               \
    F(SX_ACCESS_CMD_CLEAR = 33, "CLEAR")                         \
    F(SX_ACCESS_CMD_DELETE_PORT = 34, "DELETE PORT")             \
    F(SX_ACCESS_CMD_MARK = 35, "MARK")                           \
    F(SX_ACCESS_CMD_MIN = SX_ACCESS_CMD_NONE, "")                \
    F(SX_ACCESS_CMD_MAX = SX_ACCESS_CMD_MARK, "")
/**
 * sx_access_cmd_t
 * Enumerated type - Used to note the command access required. *
 */
typedef enum sx_access_cmd {
    FOREACH_ACCESS_CMD(SX_GENERATE_ENUM)
} sx_access_cmd_t;

/************************************************
 *  Macro definitions
 ***********************************************/

#define SX_ACCESS_CMD_DEFAULT SX_ACCESS_CMD_NONE
#define SX_ACCESS_CMD_MIN_MAX SX_ACCESS_CMD_MIN, SX_ACCESS_CMD_MAX
#define SX_ACCESS_CMD_CHECK_RANGE(cmd) SX_CHECK_RANGE(SX_ACCESS_CMD_MIN, (int)cmd, SX_ACCESS_CMD_MAX)


#endif /* __SX_ACCESS_CMD_H__ */
