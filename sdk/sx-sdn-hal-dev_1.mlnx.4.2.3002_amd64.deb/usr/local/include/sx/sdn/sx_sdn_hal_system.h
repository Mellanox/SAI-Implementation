/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_SYSTEM_H__
#define __SX_SDN_HAL_SYSTEM_H__

#include <sx/sdn/sx_sdn_hal_general.h>


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * SDN HAL library path len.
 */
#define SX_SDN_HAL_LIB_PATH_LEN 128

/**
 * SDN HAL System profile.
 */
typedef struct sx_sdn_hal_system_profile {
    char connector_library_path[SX_SDN_HAL_LIB_PATH_LEN];
    char fpt_library_path[SX_SDN_HAL_LIB_PATH_LEN];
} sx_sdn_hal_system_profile_t;

/**
 * SDN HAL system fragmentation mode.
 */
typedef enum sx_sdn_hal_system_frag {
    SX_SDN_HAL_SYSTEM_FRAG_NORMAL,  /**< No special handling for fragments. */
    SX_SDN_HAL_SYSTEM_FRAG_DROP,    /**< Drop fragments. */
    SX_SDN_HAL_SYSTEM_FRAG_REASM,   /**< Reassemble fragments. */

    SX_SDN_HAL_SYSTEM_FRAG_MIN = SX_SDN_HAL_SYSTEM_FRAG_NORMAL,
    SX_SDN_HAL_SYSTEM_FRAG_MAX = SX_SDN_HAL_SYSTEM_FRAG_REASM,
} sx_sdn_hal_system_frag_t;


static __attribute__((__used__)) const char *sx_sdn_hal_system_frag_str_arr[] = {
    "NORMAL",
    "DROP",
    "REASM",
};

#define SX_SDN_HAL_SYSTEM_FRAG_CHECK_RANGE(FRAG) \
    SX_SDN_HAL_CHECK_RANGE(SX_SDN_HAL_SYSTEM_FRAG_MIN, (int)FRAG, SX_SDN_HAL_SYSTEM_FRAG_MAX)

#define SX_SDN_HAL_SYSTEM_FRAG_STR(FRAG)       \
    SX_SDN_HAL_SYSTEM_FRAG_CHECK_RANGE(FRAG) ? \
    sx_sdn_hal_system_frag_str_arr[FRAG] : "Unknown fragmentation mode"

/**
 * SDN HAL capabilities.
 */
typedef struct sx_sdn_hal_capabilities {
    sx_sdn_hal_system_frag_t frag;      /**< fragmentation mode. */
    uint16_t                 miss_send_len; /**< Max bytes of new flow that datapath should send to the controller. */
} sx_sdn_hal_capabilities_t;

#endif /* __SX_SDN_HAL_SYSTEM_H__ */
