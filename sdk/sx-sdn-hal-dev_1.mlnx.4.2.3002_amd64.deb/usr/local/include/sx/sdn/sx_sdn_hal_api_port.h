/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_API_PORT_H__
#define __SX_SDN_HAL_API_PORT_H__

#include <sx/sdn/sx_sdn_hal_types.h>


/************************************************
 *  API functions
 ***********************************************/

/**
 *  This function retrieves all available ports.
 *
 * @param[out] port_arr - Port array.
 * @param[in,out] port_num - Port array size.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_arr_get(sx_sdn_hal_port_t *port_arr,
                                            uint32_t          *port_num);

/**
 *  This function retrieves port capabilities.
 *
 * @param[in] port - Port ID.
 * @param[out] port_cap - Port capabilities.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_capabilities_get(sx_sdn_hal_port_t               port,
                                                     sx_sdn_hal_port_capabilities_t *port_cap);

/**
 *  This function sets port administrative state.
 *
 * @param[in] port - Port ID.
 * @param[in] admin_state - Port administrative state.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_state_set(sx_sdn_hal_port_t       port,
                                              sx_sdn_hal_port_state_t admin_state);

/**
 *  This function retrieves port administrative and operational
 *  states.
 *
 * @param[in] port - Port ID.
 * @param[out] admin_state - Port operational state.
 * @param[out] oper_state - Port administrative state.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_state_get(sx_sdn_hal_port_t        port,
                                              sx_sdn_hal_port_state_t *admin_state,
                                              sx_sdn_hal_port_state_t *oper_state);

/**
 *  This function sets port RSTP state.
 *
 * @param[in] port - Port ID.
 * @param[in] port_state - Port STP state.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_rstp_state_set(sx_sdn_hal_port_t           port,
                                                   sx_sdn_hal_stp_port_state_t port_state);

/**
 *  This function retrieves port RSTP state.
 *
 * @param[in] port - Port ID.
 * @param[out] port_state - Port STP state.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_rstp_state_get(sx_sdn_hal_port_t            port,
                                                   sx_sdn_hal_stp_port_state_t *port_state);


/**
 *  This function retrieves port MAC address.
 *
 * @param[in] port - Port ID.
 * @param[out] mac_addr - Port MAC address.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_phys_addr_get(sx_sdn_hal_port_t      port,
                                                  sx_sdn_hal_mac_addr_t *mac_addr);

/**
 *  This function sets port administrative speed.
 *
 * @param[in] port - Port ID.
 * @param[in] admin_speed - Port administrative speed.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_speed_set(sx_sdn_hal_port_t                         port,
                                              const sx_sdn_hal_port_speed_capability_t *admin_speed);

/**
 *  This function retrieves port administrative and operational
 *  speeds.
 *
 * @param[in] port - Port ID.
 * @param[out] admin_speed - Port administrative speed.
 * @param[out] oper_speed - Port operational speed.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_speed_get(sx_sdn_hal_port_t                   port,
                                              sx_sdn_hal_port_speed_capability_t *admin_speed,
                                              sx_sdn_hal_port_speed_oper_t       *oper_speed);

/**
 *  This function retrieves port speed capability.
 *
 * @param[in] port - Port ID.
 * @param[out] speed_capability - Port speed capability.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_speed_capability_get(sx_sdn_hal_port_t                   port,
                                                         sx_sdn_hal_port_speed_capability_t *speed_capability);

/**
 *  This function sets port flood mode.
 *
 * @param[in] port - Port ID.
 * @param[in] flood_mode - Port flood mode.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_flood_mode_set(sx_sdn_hal_port_t            port,
                                                   sx_sdn_hal_port_flood_mode_t flood_mode);

/**
 *  This function retrieves port flood mode.
 *
 * @param[in] port - Port ID.
 * @param[out] flood_mode - Port flood mode.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_flood_mode_get(sx_sdn_hal_port_t             port,
                                                   sx_sdn_hal_port_flood_mode_t *flood_mode);

/**
 *  This function sets port MTU size.
 *
 * @param[in] port - Port ID.
 * @param[in] port_mtu - Port MTU size.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_mtu_set(sx_sdn_hal_port_t     port,
                                            sx_sdn_hal_port_mtu_t port_mtu);

/**
 *  This function retrieves port MTU size.
 *
 * @param[in] port - Port ID.
 * @param[out] port_mtu - Port MTU size.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 *  @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_mtu_get(sx_sdn_hal_port_t      port,
                                            sx_sdn_hal_port_mtu_t *port_mtu);

/**
 *  This function retrieves port counters.
 *
 * @param[in] port - Port ID.
 * @param[out] port_cntr - Port counters.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_cntr_get(sx_sdn_hal_port_t          port,
                                             sx_sdn_hal_port_cntr_of_t *port_cntr);

/**
 *  This function clears port counters.
 *
 * @param[in] port - Port ID.
 * @param[in] all_port - Clear all port counters.
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully.
 * @return SX_SDN_HAL_STATUS_PARAM_EXCEEDS_RANGE if parameters exceed range.
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if port is not found.
 * @return SX_SDN_HAL_STATUS_ERROR general error.
 */
sx_sdn_hal_status_t sx_sdn_hal_port_cntr_clear(sx_sdn_hal_port_t port,
                                               boolean_t         all_port);

#endif /* __SX_SDN_HAL_API_PORT_H__ */
