/*
 * Copyright (C) Mellanox Technologies, Ltd. 2015-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SHSPM_DATA_H__
#define __SXD_EMAD_SHSPM_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/sxd_vlan.h>
#include <sx/sxd/sxd_router.h>
#include <sx/sxd/sxd_emad_common_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_ralta_data_t structure is used to store RALTA register data.
 */
typedef struct sxd_emad_ralta_data {
    sxd_emad_common_data_t common;
    struct ku_ralta_reg   *reg_data;
} sxd_emad_ralta_data_t;

/**
 * sxd_emad_ralst_data_t structure is used to store RALST register data.
 */
typedef struct sxd_emad_ralst_data {
    sxd_emad_common_data_t common;
    struct ku_ralst_reg   *reg_data;
} sxd_emad_ralst_data_t;

/**
 * sxd_emad_raltb_data_t structure is used to store RALTB register data.
 */
typedef struct sxd_emad_raltb_data {
    sxd_emad_common_data_t common;
    struct ku_raltb_reg   *reg_data;
} sxd_emad_raltb_data_t;

/**
 * sxd_emad_ralue_data_t structure is used to store RALUE register data.
 */
typedef struct sxd_emad_ralue_data {
    sxd_emad_common_data_t common;
    struct ku_ralue_reg   *reg_data;
} sxd_emad_ralue_data_t;

/**
 * sxd_emad_raleu_data_t structure is used to store RALEU register data.
 */
typedef struct sxd_emad_raleu_data {
    sxd_emad_common_data_t common;
    struct ku_raleu_reg   *reg_data;
} sxd_emad_raleu_data_t;

/**
 * sxd_emad_ralbu_data_t structure is used to store RALBU register data.
 */
typedef struct sxd_emad_ralbu_data {
    sxd_emad_common_data_t common;
    struct ku_ralbu_reg   *reg_data;
} sxd_emad_ralbu_data_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __SXD_EMAD_SHSPM_DATA_H__ */
