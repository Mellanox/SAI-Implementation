/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2019 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_MSTP_H__
#define __SXD_EMAD_MSTP_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_mstp_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD MSTP MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_mstp_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                               IN sx_verbosity_level_t *verbosity_level_p);

/**
 * This function Sets the SPMS Switch Spanning Tree Descriptor fields.
 *
 * @param[in,out]	spms_data_arr - SLDR EMAD SPMS array
 * @param[in]		spms_data_num - Number of SLDR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spms_set(sxd_emad_spms_data_t         *spms_data_arr,
                               uint32_t                      spms_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 * This function Retrieves the SPMS Switch Spanning Tree Descriptor fields.
 *
 * @param[in,out]	spms_data_arr - SLDR EMAD SPMS array
 * @param[in]		spms_data_num - Number of SLDR EMAD data
 * @param[in]		handler - Sender ID
 * @param[in,out]	context - Cookie
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_spms_get(sxd_emad_spms_data_t         *spms_data_arr,
                               uint32_t                      spms_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

#endif /* __SXD_EMAD_MSTP_H__ */
