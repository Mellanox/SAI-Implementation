/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_ACCESS_CMD_H__
#define __SX_SDN_HAL_ACCESS_CMD_H__


/************************************************
 *  Type definitions
 ***********************************************/

typedef enum sx_sdn_hal_command {
    SX_SDN_HAL_CMD_ADD,
    SX_SDN_HAL_CMD_MODIFY,
    SX_SDN_HAL_CMD_DELETE,
    SX_SDN_HAL_CMD_ADD_PORTS,
    SX_SDN_HAL_CMD_DELETE_PORTS,

    SX_SDN_HAL_CMD_MIN = SX_SDN_HAL_CMD_ADD,
    SX_SDN_HAL_CMD_MAX = SX_SDN_HAL_CMD_DELETE_PORTS,
} sx_sdn_hal_command_t;

#endif /* __SX_SDN_HAL_ACCESS_CMD_H__ */
