/*
 * Copyright (C) Mellanox Technologies, Ltd. 2013-2015 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_SDN_HAL_API_TABLES_H__
#define __SX_SDN_HAL_API_TABLES_H__


#include <sx/sdn/sx_sdn_hal_types.h>
#include <sx/sdn/sx_sdn_hal_tables.h>

/**
 * This function returns the table module capabilities
 *
 * @param[out]    capabilities            -  struct containing
 *              table module capabilities
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters
 *         is null
 * @return SX_SDN_HAL_STATUS_ERROR general error
 */
sx_sdn_hal_status_t sx_sdn_hal_table_capabilities_get(sx_sdn_hal_table_module_capabilities_t *capabilities);

/**
 * This function returns the table capabilities
 *
 * @param[in]     table_id       -  table index
 * @param[out]    capabilities	-  struct containing table
 *              capabilities
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters
 *         is null
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_MEMORY_ERROR error handling memory
 */
sx_sdn_hal_status_t sx_sdn_hal_table_table_capabilities_get(sx_sdn_hal_table_id_t            table_id,
                                                            sx_sdn_hal_table_capabilities_t *capabilities);
/**
 * This function is used for (multiple) flow configuration - the
 * supported commands are ADD and REMOVE per flow or a group of
 * flows in the size of flow_num
 *
 * @param[in]           cmd				- command
 * @param[in]		table_id		- table index
 * @param[in,out]       flows			- an array of flows
 * @param[in]		flow_num		- number of flows within
 *       flows array
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters
 *         is null
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_MEMORY_ERROR error handling memory
 */
sx_sdn_hal_status_t sx_sdn_hal_table_entry_set(sx_sdn_hal_command_t          cmd,
                                               sx_sdn_hal_table_id_t         table_id,
                                               sx_sdn_hal_flow_attributes_t *flows,
                                               uint32_t                      flow_num);


/**
 * This function sets multicast groups to be used in forwarding
 * actions. setting a multicast group consumes a resource out of
 * the FDB. the multicast group is created with access cmd ADD
 * and afterwards ports can be added or deleted from the group
 * by using ADD_PORTS or DELETE_PORTS access cmd. in order to
 * delete the group use DELETE cmd when the multicast group is
 * not in use by any rule
 *
 * @param[in] cmd - ADD / ADD_PORTS / DELETE_PORTS / DELETE
 * @param[in] port_num -  relevant only on ADD , ADD_PORTS &
 *       DELETE_PORTS cmd. represents the number of ports to add
 *       or delete (size of port_arr)
 * @param[in] port_arr  - array of logical ports
 * @param[in,out] mcg_id - multicast group ID. given when ADD
 *       command is used, and used as index for all other
 *       commands
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes
 *         successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameter
 *         is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range.
 * @return SX_SDN_HAL_STATUS_CMD_UNSUPPORTED if unsupported
 *         command is requested
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if requested
 *         element is not found in DB, i.e the acl_name or
 *         logical_port not found while trying to bind/unbind
 *         it.
 *
 */
sx_sdn_hal_status_t sx_sdn_hal_table_mcast_group_set(sx_sdn_hal_command_t cmd,
                                                     uint32_t             port_num,
                                                     sx_sdn_hal_port_t   *port_arr,
                                                     sx_sdn_hal_mcg_id_t *mcg_id);

/**
 * This function gets a multicast group
 *
 * @param[in] mcg_id -  multicast group ID
 * @param[in,out] port_num  - indicates the size of the ports
 *       array and returns the actual number of ports found
 * @param[in,out] port_arr - array for getting the ports, its
 *       size is allocated by the user
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes
 *         successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameter
 *         is invalid
 * @return SX_ACL_RM_STATUS_PARAM_EXCEEDS_RANGE if any input parameter exceeds range.
 * @return SX_SDN_HAL_STATUS_CMD_UNSUPPORTED if unsupported
 *         command is requested
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if requested
 *         element is not found in DB, i.e the acl_name or
 *         logical_port not found while trying to bind/unbind
 *         it.
 */
sx_sdn_hal_status_t sx_sdn_hal_table_mcast_group_get(sx_sdn_hal_mcg_id_t mcg_id,
                                                     uint32_t           *port_num,
                                                     sx_sdn_hal_port_t  *port_arr);


/**
 * This function is used for getting a specific flow or a group
 * of flows, according to provided unique IDs. the flows
 * attributes are written to the flows array, which needs to be
 * pre-allocated by the user and start_flow must be NULL.
 * In case flow_start is not NULL, flows will be retrieved starting from flow_start ID.
 *
 * @param[in]		table_id		- table index
 * @param[in,out]       flow_start		- Iteration start point.
 * @param[in]           flow_ids		- requested flow unique index
 * @param[in,out]        flow_num               - number of flows to get
 * @param[in,out]	flows			- flow attributes
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters
 *         is null
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if entry does not
 *         exist
 */
sx_sdn_hal_status_t sx_sdn_hal_table_entry_get(sx_sdn_hal_table_id_t         table_id,
                                               sx_sdn_hal_flow_id_t         *flow_start,
                                               sx_sdn_hal_flow_id_t         *flow_ids,
                                               uint32_t                     *flow_num,
                                               sx_sdn_hal_flow_attributes_t *flows);


/**
 * This function is used for getting flow statistics
 *
 * @param[in] table_id - table index
 * @param[in] flow_ids - requested flow unique index
 * @param[in] flow_num - number of flows to get
 * @param[in,out] flow_stats - flow statistics
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters
 *         is null
 * @return SX_SDN_HAL_STATUS_ERROR general
 *         error
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if entry does not
 *         exist
 */
sx_sdn_hal_status_t sx_sdn_hal_table_entry_stat_get(sx_sdn_hal_table_id_t         table_id,
                                                    sx_sdn_hal_flow_id_t         *flow_ids,
                                                    uint32_t                      flow_num,
                                                    sx_sdn_hal_flow_statistics_t *flow_stats);

/**
 * This function is used for getting table statistics
 *
 * @param[in]		table_id		- table index
 * @param[out]		table_stats		- table statistics
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_ERROR general error
 * @return SX_SDN_HAL_STATUS_ENTRY_NOT_FOUND if entry does not
 *                exist
 */
sx_sdn_hal_status_t sx_sdn_hal_table_table_stat_get(sx_sdn_hal_table_id_t          table_id,
                                                    sx_sdn_hal_table_statistics_t *table_stats);


/**
 * This function is used for (multiple) flow activity check.
 * This action also clears the activity state of the given flows.
 * flows_activity array is filled with the activity state (DOWN /UP / NOT_FOUND).
 *
 * @param[in]	table_id- table index
 * @param[in]   flows_id - an array of flows ID
 * @param[in]   flow_num - number of flows within
 * @param[out] flows_activity - an array of flow�s activity state
 *
 * @return SX_SDN_HAL_STATUS_SUCCESS if operation completes successfully
 * @return SX_SDN_HAL_STATUS_PARAM_NULL if any input parameters is null
 * @return SX_SDN_HAL_STATUS_PARAM_ERROR if any input parameters is not valid
 * @return SX_SDN_HAL_STATUS_ERROR general error
 */
sx_sdn_hal_status_t sx_sdn_hal_table_entry_activity_get(sx_sdn_hal_table_id_t       table_id,
                                                        sx_sdn_hal_flow_id_t       *flows_id,
                                                        uint32_t                    flow_num,
                                                        sx_sdn_hal_flow_activity_t *flows_activity);


#endif /* ifndef __SX_SDN_HAL_API_TABLES_H__ */
