/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_REDECN_H__
#define __SXD_EMAD_PARSER_REDECN_H__


#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_redecn_data.h>
#include <sx/sxd/sxd_emad_redecn_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_redecn_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwgcr(sxd_emad_cwgcr_data_t *cwgcr_data,
                                  sxd_emad_cwgcr_reg_t  *cwgcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwgcr(sxd_emad_cwgcr_data_t *cwgcr_data,
                                    sxd_emad_cwgcr_reg_t  *cwgcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwtp(sxd_emad_cwtp_data_t *cwtp_data,
                                 sxd_emad_cwtp_reg_t  *cwtp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwtp(sxd_emad_cwtp_data_t *cwtp_data,
                                   sxd_emad_cwtp_reg_t  *cwtp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwtpm(sxd_emad_cwtpm_data_t *cwtpm_data,
                                  sxd_emad_cwtpm_reg_t  *cwtpm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwtpm(sxd_emad_cwtpm_data_t *cwtpm_data,
                                    sxd_emad_cwtpm_reg_t  *cwtpm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwpp(sxd_emad_cwpp_data_t *cwpp_data,
                                 sxd_emad_cwpp_reg_t  *cwpp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwpp(sxd_emad_cwpp_data_t *cwpp_data,
                                   sxd_emad_cwpp_reg_t  *cwpp_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cwppm(sxd_emad_cwppm_data_t *cwppm_data,
                                  sxd_emad_cwppm_reg_t  *cwppm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cwppm(sxd_emad_cwppm_data_t *cwppm_data,
                                    sxd_emad_cwppm_reg_t  *cwppm_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_cpqe(sxd_emad_cpqe_data_t *cpqe_data,
                                 sxd_emad_cpqe_reg_t  *cpqe_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_cpqe(sxd_emad_cpqe_data_t *cpqe_data,
                                   sxd_emad_cpqe_reg_t  *cpqe_reg);


#endif /* __SXD_EMAD_PARSER_REDECN_H__ */
