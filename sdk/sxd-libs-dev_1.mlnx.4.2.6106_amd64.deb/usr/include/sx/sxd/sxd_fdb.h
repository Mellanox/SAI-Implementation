/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_FDB_H__
#define __SXD_FDB_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/
/**
 * Default FID.
 */
#define SXD_FDB_DEFAULT_FID      (1)
#define SXD_FDB_DEFAULT_AGE_TIME (300)

/**
 * FDB maximum/minimum age time values.
 */
#define SXD_FDB_AGE_TIME_MIN (10)
#define SXD_FDB_AGE_TIME_MAX (1000000)

#define SXD_FDB_AGE_TIME_CHECK_RANGE(FDB_AGE_TIME) \
    SXD_CHECK_RANGE(SXD_FDB_AGE_TIME_MIN,          \
                    FDB_AGE_TIME,                  \
                    SXD_FDB_AGE_TIME_MAX)
/**
 * SXD_FDB_SMPU_MAX_RECORDS define maximum records supported by one SMPU
 */
#define SXD_FDB_SMPU_MAX_RECORDS (255)


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/
/**
 * FDB ID.
 */
typedef uint16_t sxd_fid_t;

/**
 * Multicast ID.
 */
typedef uint16_t sxd_mid_t;

/**
 * Port group identifier.
 */
typedef uint16_t sxd_pgi_t;

/**
 * Default FDB age time.
 */

/**
 * sxd_fdb_flush_type_t enumerated type is used to note FDB
 * flush type.
 */
typedef enum sxd_fdb_flush_type {
    SXD_FDB_FLUSH_TYPE_SWID = 0,
    SXD_FDB_FLUSH_TYPE_FID = 1,
    SXD_FDB_FLUSH_TYPE_PORT = 2,
    SXD_FDB_FLUSH_TYPE_PORT_FID = 3,
    SXD_FDB_FLUSH_TYPE_LAG = 4,
    SXD_FDB_FLUSH_TYPE_LAG_FID = 5,
    SXD_FDB_FLUSH_TYPE_NVE = 6,
    SXD_FDB_FLUSH_TYPE_NVE_FID = 7
} sxd_fdb_flush_type_t;

/**
 * sxd_fdb_key_filter_field_valid enumerated type is set key filter field valid or no valid
 *
 */
typedef enum sxd_fdb_key_filter_field_valid {
    SXD_FDB_KEY_FILTER_FIELD_NOT_VALID_E = 0,
    SXD_FDB_KEY_FILTER_FIELD_VALID_E = 1,
} sxd_fdb_key_filter_field_valid_e;

/**
 * sxd_fdb_smpu_op_e used for op field in SMPU register.
 */
typedef enum sxd_fdb_smpu_op_e {
    SXD_FDB_SMPU_OP_SET_E = 0,
    SXD_FDB_SMPU_OP_CLEAR_E = 1,
} sxd_fdb_smpu_op_e;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/


#endif /* __SXD_FDB_H__ */
