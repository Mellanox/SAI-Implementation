/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2017 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_ROUTER_H__
#define __SXD_EMAD_ROUTER_H__

#include <complib/sx_log.h>

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_router_data.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD ROUTER MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t sxd_emad_router_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function gets RCAP register data.
 *
 * @param[in] rcap_data_arr - RCAP data array.
 * @param[in] rcap_data_num - RCAP data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rcap_get(sxd_emad_rcap_data_t         *rcap_data_arr,
                               uint32_t                      rcap_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RGCR register data.
 *
 * @param[in] rgcr_data_arr - RGCR data array.
 * @param[in] rgcr_data_num - RGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rgcr_set(sxd_emad_rgcr_data_t         *rgcr_data_arr,
                               uint32_t                      rgcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RGCR register data.
 *
 * @param[in] rgcr_data_arr - RGCR data array.
 * @param[in] rgcr_data_num - RGCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rgcr_get(sxd_emad_rgcr_data_t         *rgcr_data_arr,
                               uint32_t                      rgcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RITR register data.
 *
 * @param[in] ritr_data_arr - RITR data array.
 * @param[in] ritr_data_num - RITR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ritr_set(sxd_emad_ritr_data_t         *ritr_data_arr,
                               uint32_t                      ritr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RITR register data.
 *
 * @param[in] ritr_data_arr - RITR data array.
 * @param[in] ritr_data_num - RITR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ritr_get(sxd_emad_ritr_data_t         *ritr_data_arr,
                               uint32_t                      ritr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RIGR register data.
 *
 * @param[in] rigr_data_arr - RIGR data array.
 * @param[in] rigr_data_num - RIGR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rigr_set(sxd_emad_rigr_data_t         *rigr_data_arr,
                               uint32_t                      rigr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RIGR register data.
 *
 * @param[in] rigr_data_arr - RIGR data array.
 * @param[in] rigr_data_num - RIGR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rigr_get(sxd_emad_rigr_data_t         *rigr_data_arr,
                               uint32_t                      rigr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RIGRv2 register data.
 *
 * @param[in] rigr_v2_data_arr - RIGRv2 data array.
 * @param[in] rigr_v2_data_num - RIGRv2 data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rigr_v2_set(sxd_emad_rigr_v2_data_t      *rigr_v2_data_arr,
                                  uint32_t                      rigr_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 *  This function gets RIGRv2 register data.
 *
 * @param[in] rigr_v2_data_arr - RIGRv2 data array.
 * @param[in] rigr_v2_data_num - RIGRv2 data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rigr_v2_get(sxd_emad_rigr_v2_data_t      *rigr_v2_data_arr,
                                  uint32_t                      rigr_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 *  This function sets RMEIR register data.
 *
 * @param[in] rmeir_data_arr - RMEIR data array.
 * @param[in] rmeir_data_num - RMEIR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmeir_set(sxd_emad_rmeir_data_t        *rmeir_data_arr,
                                uint32_t                      rmeir_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets RMEIR register data.
 *
 * @param[in] rmeir_data_arr - RMEIR data array.
 * @param[in] rmeir_data_num - RMEIR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmeir_get(sxd_emad_rmeir_data_t        *rmeir_data_arr,
                                uint32_t                      rmeir_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RMID register data.
 *
 * @param[in] rmid_data_arr - RMID data array.
 * @param[in] rmid_data_num - RMID data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmid_set(sxd_emad_rmid_data_t         *rmid_data_arr,
                               uint32_t                      rmid_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RMID register data.
 *
 * @param[in] rmid_data_arr - RMID data array.
 * @param[in] rmid_data_num - RMID data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmid_get(sxd_emad_rmid_data_t         *rmid_data_arr,
                               uint32_t                      rmid_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RMPE register data.
 *
 * @param[in] rmpe_data_arr - RMPE data array.
 * @param[in] rmpe_data_num - RMPE data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmpe_set(sxd_emad_rmpe_data_t         *rmpe_data_arr,
                               uint32_t                      rmpe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RMPE register data.
 *
 * @param[in] rmpe_data_arr - RMPE data array.
 * @param[in] rmpe_data_num - RMPE data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmpe_get(sxd_emad_rmpe_data_t         *rmpe_data_arr,
                               uint32_t                      rmpe_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RMPU register data.
 *
 * @param[in] rmpu_data_arr - RMPU data array.
 * @param[in] rmpu_data_num - RMPU data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmpu_set(sxd_emad_rmpu_data_t         *rmpu_data_arr,
                               uint32_t                      rmpu_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RTAR register data.
 *
 * @param[in] rtar_data_arr - RTAR data array.
 * @param[in] rtar_data_num - RTAR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtar_set(sxd_emad_rtar_data_t         *rtar_data_arr,
                               uint32_t                      rtar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RTAR register data.
 *
 * @param[in] rtar_data_arr - RTAR data array.
 * @param[in] rtar_data_num - RTAR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtar_get(sxd_emad_rtar_data_t         *rtar_data_arr,
                               uint32_t                      rtar_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RECR register data.
 *
 * @param[in] recr_data_arr - RECR data array.
 * @param[in] recr_data_num - RECR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_recr_set(sxd_emad_recr_data_t         *recr_data_arr,
                               uint32_t                      recr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RECR register data.
 *
 * @param[in] recr_data_arr - RECR data array.
 * @param[in] recr_data_num - RECR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_recr_get(sxd_emad_recr_data_t         *recr_data_arr,
                               uint32_t                      recr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RECRv2 register data.
 *
 * @param[in] recr_v2_data_arr - RECRv2 data array.
 * @param[in] recr_v2_data_num - RECRv2 data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_recr_v2_set(sxd_emad_recr_v2_data_t      *recr_v2_data_arr,
                                  uint32_t                      recr_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 *  This function gets RECRv2 register data.
 *
 * @param[in] recr_v2_data_arr - RECRv2 data array.
 * @param[in] recr_v2_data_num - RECRv2 data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_recr_v2_get(sxd_emad_recr_v2_data_t      *recr_v2_data_arr,
                                  uint32_t                      recr_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 *  This function sets RUFT register data.
 *
 * @param[in] ruft_data_arr - RUFT data array.
 * @param[in] ruft_data_num - RUFT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ruft_set(sxd_emad_ruft_data_t         *ruft_data_arr,
                               uint32_t                      ruft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RUFT register data.
 *
 * @param[in] ruft_data_arr - RUFT data array.
 * @param[in] ruft_data_num - RUFT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ruft_get(sxd_emad_ruft_data_t         *ruft_data_arr,
                               uint32_t                      ruft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RUHT register data.
 *
 * @param[in] ruht_data_arr - RUHT data array.
 * @param[in] ruht_data_num - RUHT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ruht_set(sxd_emad_ruht_data_t         *ruht_data_arr,
                               uint32_t                      ruht_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RUHT register data.
 *
 * @param[in] ruht_data_arr - RUHT data array.
 * @param[in] ruht_data_num - RUHT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ruht_get(sxd_emad_ruht_data_t         *ruht_data_arr,
                               uint32_t                      ruht_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);


/**
 *  This function sets RAUHT register data.
 *
 * @param[in] rauht_data_arr - RAUHT data array.
 * @param[in] rauht_data_num - RAUHT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rauht_set(sxd_emad_rauht_data_t        *rauht_data_arr,
                                uint32_t                      rauht_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets RAUHT register data.
 *
 * @param[in] rauht_data_arr - RAUHT data array.
 * @param[in] rauht_data_num - RAUHT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rauht_get(sxd_emad_rauht_data_t        *rauht_data_arr,
                                uint32_t                      rauht_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RAUHTD register data.
 *
 * @param[in] rauhtd_data_arr - RAUHTD data array.
 * @param[in] rauhtd_data_num - RAUHTD data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rauhtd_set(sxd_emad_rauhtd_data_t       *rauhtd_data_arr,
                                 uint32_t                      rauhtd_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context);

/**
 *  This function gets RAUHTD register data.
 *
 * @param[in] rauhtd_data_arr - RAUHTD data array.
 * @param[in] rauhtd_data_num - RAUHTD data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rauhtd_get(sxd_emad_rauhtd_data_t       *rauhtd_data_arr,
                                 uint32_t                      rauhtd_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context);

/**
 *  This function sets RMFT register data.
 *
 * @param[in] rmft_data_arr - RMFT data array.
 * @param[in] rmft_data_num - RMFT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmft_set(sxd_emad_rmft_data_t         *rmft_data_arr,
                               uint32_t                      rmft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RMFT register data.
 *
 * @param[in] rmft_data_arr - RMFT data array.
 * @param[in] rmft_data_num - RMFT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmft_get(sxd_emad_rmft_data_t         *rmft_data_arr,
                               uint32_t                      rmft_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RMFTv2 register data.
 *
 * @param[in] rmft_v2_data_arr - RMFTv2 data array.
 * @param[in] rmft_v2_data_num - RMFTv2 data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmft_v2_set(sxd_emad_rmft_v2_data_t      *rmft_v2_data_arr,
                                  uint32_t                      rmft_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 *  This function gets RMFTv2 register data.
 *
 * @param[in] rmft_v2_data_arr - RMFTv2 data array.
 * @param[in] rmft_v2_data_num - RMFTv2 data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rmft_v2_get(sxd_emad_rmft_v2_data_t      *rmft_v2_data_arr,
                                  uint32_t                      rmft_v2_data_num,
                                  sxd_emad_completion_handler_t handler,
                                  void                         *context);

/**
 *  This function sets RATR register data.
 *
 * @param[in] ratr_data_arr - RATR data array.
 * @param[in] ratr_data_num - RATR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ratr_set(sxd_emad_ratr_data_t         *ratr_data_arr,
                               uint32_t                      ratr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RATR register data.
 *
 * @param[in] ratr_data_arr - RATR data array.
 * @param[in] ratr_data_num - RATR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ratr_get(sxd_emad_ratr_data_t         *ratr_data_arr,
                               uint32_t                      ratr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RATRAD register data.
 *
 * @param[in] ratrad_data_arr - RATRAD data array.
 * @param[in] ratrad_data_num - RATRAD data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ratrad_set(sxd_emad_ratrad_data_t       *ratrad_data_arr,
                                 uint32_t                      ratrad_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context);

/**
 *  This function gets RATRAD register data.
 *
 * @param[in] ratrad_data_arr - RATRAD data array.
 * @param[in] ratrad_data_num - RATRAD data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ratrad_get(sxd_emad_ratrad_data_t       *ratrad_data_arr,
                                 uint32_t                      ratrad_data_num,
                                 sxd_emad_completion_handler_t handler,
                                 void                         *context);

/**
 *  This function sets RTDP register data.
 *
 * @param[in] rtdp_data_arr - RTDP data array.
 * @param[in] rtdp_data_num - RTDP data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtdp_set(sxd_emad_rtdp_data_t         *rtdp_data_arr,
                               uint32_t                      rtdp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RTDP register data.
 *
 * @param[in] rtdp_data_arr - RTDP data array.
 * @param[in] rtdp_data_num - RTDP data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtdp_get(sxd_emad_rtdp_data_t         *rtdp_data_arr,
                               uint32_t                      rtdp_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RIPS register data.
 *
 * @param[in] rips_data_arr - RIPS data array.
 * @param[in] rips_data_num - RIPS data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rips_set(sxd_emad_rips_data_t         *rips_data_arr,
                               uint32_t                      rips_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RIPS register data.
 *
 * @param[in] rips_data_arr - RIPS data array.
 * @param[in] rips_data_num - RIPS data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rips_get(sxd_emad_rips_data_t         *rips_data_arr,
                               uint32_t                      rips_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RDPM register data.
 *
 * @param[in] rdpm_data_arr - RDPM data array.
 * @param[in] rdpm_data_num - RDPM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rdpm_set(sxd_emad_rdpm_data_t         *rdpm_data_arr,
                               uint32_t                      rdpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RDPM register data.
 *
 * @param[in] rdpm_data_arr - RDPM data array.
 * @param[in] rdpm_data_num - RDPM data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rdpm_get(sxd_emad_rdpm_data_t         *rdpm_data_arr,
                               uint32_t                      rdpm_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RRCR register data.
 *
 * @param[in] rrcr_data_arr - RRCR data array.
 * @param[in] rrcr_data_num - RRCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rrcr_set(sxd_emad_rrcr_data_t         *rrcr_data_arr,
                               uint32_t                      rrcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RRCR register data.
 *
 * @param[in] rrcr_data_arr - RRCR data array.
 * @param[in] rrcr_data_num - RRCR data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rrcr_get(sxd_emad_rrcr_data_t         *rrcr_data_arr,
                               uint32_t                      rrcr_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RICA register data.
 *
 * @param[in] rica_data_arr - RICA data array.
 * @param[in] rica_data_num - RICA data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rica_set(sxd_emad_rica_data_t         *rica_data_arr,
                               uint32_t                      rica_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RICA register data.
 *
 * @param[in] rica_data_arr - RICA data array.
 * @param[in] rica_data_num - RICA data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rica_get(sxd_emad_rica_data_t         *rica_data_arr,
                               uint32_t                      rica_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RICNT register data.
 *
 * @param[in] ricnt_data_arr - RICNT data array.
 * @param[in] ricnt_data_num - RICNT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ricnt_set(sxd_emad_ricnt_data_t        *ricnt_data_arr,
                                uint32_t                      ricnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function gets RICNT register data.
 *
 * @param[in] ricnt_data_arr - RICNT data array.
 * @param[in] ricnt_data_num - RICNT data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_ricnt_get(sxd_emad_ricnt_data_t        *ricnt_data_arr,
                                uint32_t                      ricnt_data_num,
                                sxd_emad_completion_handler_t handler,
                                void                         *context);

/**
 *  This function sets RTCA register data.
 *
 * @param[in] rtca_data_arr - RTCA data array.
 * @param[in] rtca_data_num - RTCA data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtca_set(sxd_emad_rtca_data_t         *rtca_data_arr,
                               uint32_t                      rtca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RTCA register data.
 *
 * @param[in] rtca_data_arr - RTCA data array.
 * @param[in] rtca_data_num - RTCA data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtca_get(sxd_emad_rtca_data_t         *rtca_data_arr,
                               uint32_t                      rtca_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function sets RTPS register data.
 *
 * @param[in] rtps_data_arr - RTPS data array.
 * @param[in] rtps_data_num - RTPS data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtps_set(sxd_emad_rtps_data_t         *rtps_data_arr,
                               uint32_t                      rtps_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);

/**
 *  This function gets RTPS register data.
 *
 * @param[in] rtps_data_arr - RTPS data array.
 * @param[in] rtps_data_num - RTPS data array size.
 * @param[in] handler - Completion handler.
 * @param[in] context - Completion handler context.
 *
 * @return SXD_STATUS_SUCCESS if operation completes successfully.
 * @return SXD_STATUS_PARAM_ERROR if any input parameters is invalid.
 * @return SXD_STATUS_NO_MEMORY if no memory is available to allocate.
 * @return SXD_STATUS_NO_RESOURCES if no transaction is available to create.
 */
sxd_status_t sxd_emad_rtps_get(sxd_emad_rtps_data_t         *rtps_data_arr,
                               uint32_t                      rtps_data_num,
                               sxd_emad_completion_handler_t handler,
                               void                         *context);
#endif /* __SXD_EMAD_ROUTER_H__ */
