/*
 * Copyright (C) Mellanox Technologies, Ltd. 2010-2018 ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Mellanox Technologies, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_TUNNEL_H__
#define __SXD_EMAD_PARSER_TUNNEL_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_tunnel_data.h>
#include <sx/sxd/sxd_emad_tunnel_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_tunnel_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                    IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function formats TNGCR register layout from TNGCR register data.
 *
 * @param[in] tngcr_data - TNGCR register data.
 * @param[out] tngcr_reg - TNGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tngcr(sxd_emad_tngcr_data_t *tngcr_data,
                                  sxd_emad_tngcr_reg_t  *tngcr_reg);

/**
 *  This function formats TNGCR register data from TNGCR register layout.
 *
 * @param[out] tngcr_data - TNGCR register data.
 * @param[in] tngcr_reg - TNGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tngcr(sxd_emad_tngcr_data_t *tngcr_data,
                                    sxd_emad_tngcr_reg_t  *tngcr_reg);

/**
 *  This function formats TNCR register layout from TNCR register data.
 *
 * @param[in] tncr_data - TNCR register data.
 * @param[out] tncr_reg - TNCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tncr(sxd_emad_tncr_data_t *tncr_data,
                                 sxd_emad_tncr_reg_t  *tncr_reg);

/**
 *  This function formats TNCR register data from TNCR register layout.
 *
 * @param[out] tncr_data - TNCR register data.
 * @param[in] tncr_reg - TNCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tncr(sxd_emad_tncr_data_t *tncr_data,
                                   sxd_emad_tncr_reg_t  *tncr_reg);

/**
 *  This function formats TNUMT register layout from TNUMT register data.
 *
 * @param[in] tnumt_data - TNUMT register data.
 * @param[out] tnumt_reg - TNUMT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tnumt(sxd_emad_tnumt_data_t *tnumt_data,
                                  sxd_emad_tnumt_reg_t  *tnumt_reg);

/**
 *  This function formats TNUMT register data from TNUMT register layout.
 *
 * @param[out] tnumt_data - TNUMT register data.
 * @param[in] tnumt_reg - TNUMT register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tnumt(sxd_emad_tnumt_data_t *tnumt_data,
                                    sxd_emad_tnumt_reg_t  *tnumt_reg);

/**
 *  This function formats TNQCR register layout from TNQCR register data.
 *
 * @param[in] tnqcr_data - TNQCR register data.
 * @param[out] tnqcr_reg - TNQCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tnqcr(sxd_emad_tnqcr_data_t *tnqcr_data,
                                  sxd_emad_tnqcr_reg_t  *tnqcr_reg);

/**
 *  This function formats TNQCR register data from TNQCR register layout.
 *
 * @param[out] tnqcr_data - TNQCR register data.
 * @param[in] tnqcr_reg - TNQCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tnqcr(sxd_emad_tnqcr_data_t *tnqcr_data,
                                    sxd_emad_tnqcr_reg_t  *tnqcr_reg);

/**
 *  This function formats TNQDR register layout from TNQDR register data.
 *
 * @param[in] tnqdr_data - TNQDR register data.
 * @param[out] tnqdr_reg - TNQDR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tnqdr(sxd_emad_tnqdr_data_t *tnqdr_data,
                                  sxd_emad_tnqdr_reg_t  *tnqdr_reg);

/**
 *  This function formats TNQDR register data from TNQDR register layout.
 *
 * @param[out] tnqdr_data - TNQDR register data.
 * @param[in] tnqdr_reg - TNQDR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tnqdr(sxd_emad_tnqdr_data_t *tnqdr_data,
                                    sxd_emad_tnqdr_reg_t  *tnqdr_reg);

/**
 *  This function formats TIGCR register layout from TIGCR register data.
 *
 * @param[in] tigcr_data - TIGCR register data.
 * @param[out] tigcr_reg - TIGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tigcr(sxd_emad_tigcr_data_t *tigcr_data,
                                  sxd_emad_tigcr_reg_t  *tigcr_reg);

/**
 *  This function formats TIGCR register data from TIGCR register layout.
 *
 * @param[out] tigcr_data - TIGCR register data.
 * @param[in] tigcr_reg - TIGCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tigcr(sxd_emad_tigcr_data_t *tigcr_data,
                                    sxd_emad_tigcr_reg_t  *tigcr_reg);

/**
 *  This function formats TIQDR register layout from TIQDR register data.
 *
 * @param[in] tiqdr_data - TIQDR register data.
 * @param[out] tiqdr_reg - TIQDR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tiqdr(sxd_emad_tiqdr_data_t *tiqdr_data,
                                  sxd_emad_tiqdr_reg_t  *tiqdr_reg);

/**
 *  This function formats TIQDR register data from TIQDR register layout.
 *
 * @param[out] tiqdr_data - TIQDR register data.
 * @param[in] tiqdr_reg - TIQDR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tiqdr(sxd_emad_tiqdr_data_t *tiqdr_data,
                                    sxd_emad_tiqdr_reg_t  *tiqdr_reg);

/**
 *  This function formats TIQCR register layout from TIQCR register data.
 *
 * @param[in] tiqcr_data - TIQCR register data.
 * @param[out] tiqcr_reg - TIQCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tiqcr(sxd_emad_tiqcr_data_t *tiqcr_data,
                                  sxd_emad_tiqcr_reg_t  *tiqcr_reg);

/**
 *  This function formats TIQCR register data from TIQCR register layout.
 *
 * @param[out] tiqcr_data - TIQCR register data.
 * @param[in] tiqcr_reg - TIQCR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tiqcr(sxd_emad_tiqcr_data_t *tiqcr_data,
                                    sxd_emad_tiqcr_reg_t  *tiqcr_reg);

/**
 *  This function formats TIEEM register layout from TIEEM register data.
 *
 * @param[in] tieem_data - TIEEM register data.
 * @param[out] tieem_reg - TIEEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tieem(sxd_emad_tieem_data_t *tieem_data,
                                  sxd_emad_tieem_reg_t  *tieem_reg);

/**
 *  This function formats TIEEM register data from TIEEM register layout.
 *
 * @param[out] tieem_data - TIEEM register data.
 * @param[in] tieem_reg - TIEEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tieem(sxd_emad_tieem_data_t *tieem_data,
                                    sxd_emad_tieem_reg_t  *tieem_reg);

/**
 *  This function formats TIDEM register layout from TIDEM register data.
 *
 * @param[in] tidem_data - TIDEM register data.
 * @param[out] tidem_reg - TIDEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tidem(sxd_emad_tidem_data_t *tidem_data,
                                  sxd_emad_tidem_reg_t  *tidem_reg);

/**
 *  This function formats TIDEM register data from TIDEM register layout.
 *
 * @param[out] tidem_data - TIDEM register data.
 * @param[in] tidem_reg - TIDEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tidem(sxd_emad_tidem_data_t *tidem_data,
                                    sxd_emad_tidem_reg_t  *tidem_reg);

/**
 *  This function formats TNEEM register layout from TNEEM register data.
 *
 * @param[in] tneem_data - TNEEM register data.
 * @param[out] tneem_reg - TNEEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tneem(sxd_emad_tneem_data_t *tneem_data,
                                  sxd_emad_tneem_reg_t  *tneem_reg);

/**
 *  This function formats TNEEM register data from TNEEM register layout.
 *
 * @param[out] tneem_data - TNEEM register data.
 * @param[in] tneem_reg - TNEEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tneem(sxd_emad_tneem_data_t *tneem_data,
                                    sxd_emad_tneem_reg_t  *tneem_reg);

/**
 *  This function formats TNDEM register layout from TNDEM register data.
 *
 * @param[in] tndem_data - TNDEM register data.
 * @param[out] tndem_reg - TNDEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tndem(sxd_emad_tndem_data_t *tndem_data,
                                  sxd_emad_tndem_reg_t  *tndem_reg);

/**
 *  This function formats TNDEM register data from TNDEM register layout.
 *
 * @param[out] tndem_data - TNDEM register data.
 * @param[in] tndem_reg - TNDEM register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tndem(sxd_emad_tndem_data_t *tndem_data,
                                    sxd_emad_tndem_reg_t  *tndem_reg);

/**
 *  This function formats TNIFR register layout from TNIFR register data.
 *
 * @param[in] tnifr_data - TNIFR register data.
 * @param[out] tnifr_reg - TNIFR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_tnifr(sxd_emad_tnifr_data_t *tnifr_data,
                                  sxd_emad_tnifr_reg_t  *tnifr_reg);

/**
 *  This function formats TNIFR register data from TNIFR register layout.
 *
 * @param[out] tnifr_data - TNIFR register data.
 * @param[in] tnifr_reg - TNIFR register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_tnifr(sxd_emad_tnifr_data_t *tnifr_data,
                                    sxd_emad_tnifr_reg_t  *tnifr_reg);

#endif /* __SXD_EMAD_PARSER_TUNNEL_H__ */
